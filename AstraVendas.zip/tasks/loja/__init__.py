from disnake.ext import commands

def setup(bot: commands.Bot):
    """O carregamento agora é gerenciado pelo core/bot_loader.py"""
    pass
