import disnake
from disnake.ext import commands, tasks
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
from datetime import datetime

class LojaTaskCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.daily_report.start()

    def cog_unload(self):
        self.daily_report.cancel()

    @tasks.loop(hours=24)
    async def daily_report(self):
        """Gera um relatório diário de vendas"""
        # Lógica para enviar relatório no canal de logs
        pass

def setup(bot: commands.Bot):
    bot.add_cog(LojaTaskCog(bot))
