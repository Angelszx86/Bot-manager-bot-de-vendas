from functions.database import database as db
from disnake.ext import tasks
import disnake
import itertools

def get_status_obj(status_type: str) -> disnake.Status:
    status_map = {
        "online": disnake.Status.online,
        "idle": disnake.Status.idle,
        "dnd": disnake.Status.dnd,
        # "streaming" nao e um status valido de presenca no Discord (o gateway so aceita
        # online/idle/dnd/invisible). O indicador roxo de "transmitindo" vem da ATIVIDADE
        # (disnake.Streaming), nao do campo de status. Por isso mapeamos para online aqui.
        "streaming": disnake.Status.online,
        "offline": disnake.Status.invisible,
    }
    return status_map.get(status_type, disnake.Status.online)

def build_activity(activity_type: str, name: str) -> disnake.BaseActivity:
    """Monta a Activity correta de acordo com o tipo escolhido no dashboard
    (Jogando / Ouvindo / Assistindo / Transmitindo / Competindo)."""
    if activity_type == "streaming":
        return disnake.Streaming(name=name, url="https://twitch.tv/discord")
    if activity_type == "listening":
        return disnake.Activity(type=disnake.ActivityType.listening, name=name)
    if activity_type == "watching":
        return disnake.Activity(type=disnake.ActivityType.watching, name=name)
    if activity_type == "competing":
        return disnake.Activity(type=disnake.ActivityType.competing, name=name)
    # "playing" (padrao) e qualquer valor desconhecido cai aqui
    return disnake.Game(name=name)

@tasks.loop(seconds=5)
async def status_rotator_task(bot: disnake.Client):
    database = db.get_document("custom_status")
    status_type = database.get("type", "online")
    activity_type = database.get("activityType", "playing")
    auto_rotate = database.get("autoRotate", True)
    rotation_interval = database.get("rotationInterval", 5)
    status_obj = get_status_obj(status_type)

    # Ajusta o intervalo do loop dinamicamente conforme configurado no dashboard
    try:
        interval = max(1, min(300, int(rotation_interval)))
    except (TypeError, ValueError):
        interval = 5
    if status_rotator_task.seconds != interval:
        status_rotator_task.change_interval(seconds=interval)

    names = database.get("names")
    if not names:  # Backwards compatibility
        name = database.get("name")
        names = [name] if name else []

    # Migração compatível de atividades antigas salvas antes da troca de marca.
    names = [
        str(name)
        .replace("Ocean Applications", "Astra Applications")
        .replace("oceanapplications.com", "Astra Application")
        for name in names
    ]

    if not names:
        await bot.change_presence(status=status_obj, activity=None)
        return

    if not auto_rotate:
        # Rotação desligada: fixa sempre na primeira atividade cadastrada
        status_name = names[0]
        bot._status_names = names
        bot._status_cycler = itertools.cycle(names)
    else:
        # Reinicia o cycler se a lista de atividades mudou
        if not hasattr(bot, "_status_cycler") or getattr(bot, "_status_names", []) != names:
            bot._status_names = names
            bot._status_cycler = itertools.cycle(names)
        status_name = next(bot._status_cycler)

    activity = build_activity(activity_type, status_name)
    await bot.change_presence(status=status_obj, activity=activity)
