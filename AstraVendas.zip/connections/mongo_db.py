import pymongo
import json

with open("config.json", "r", encoding="utf-8") as f:
    config = json.load(f)

with open("configs/config_mongo.json", "r", encoding="utf-8") as f:
    mongo_config = json.load(f)

mongo_url = mongo_config.get("mongoURL")
bot_id = config.get("botID")
database_name = mongo_config.get("databaseName", "sync_bots")

# 🔥 BOOSTER DE CONEXÃO
client = pymongo.MongoClient(
    mongo_url,
    maxPoolSize=50,              # Pool maior de conexões
    minPoolSize=5,               # Já mantém conexões abertas
    serverSelectionTimeoutMS=3000,  # Não trava tentando conectar
    connectTimeoutMS=3000,
    socketTimeoutMS=5000,
    retryWrites=True
)

# ⚡ Força conexão imediata (evita delay na primeira consulta)
client.admin.command("ping")

database = client[database_name]
collection = database[bot_id]