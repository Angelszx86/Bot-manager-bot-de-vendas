import disnake
from disnake.ext import commands, tasks
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
from datetime import datetime

class AssinaturasCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.check_expirations.start()

    def cog_unload(self):
        self.check_expirations.cancel()

    @tasks.loop(hours=1)
    async def check_expirations(self):
        """Verifica assinaturas expiradas e remove cargos"""
        now = datetime.now().timestamp()
        subscriptions = db.get_document("loja_subscriptions") or {}
        
        to_remove = []
        for sub_id, sub in subscriptions.items():
            if sub["expiry"] < now:
                to_remove.append(sub_id)
                guild = self.bot.get_guild(utils.obter_server_principal())
                if guild:
                    member = guild.get_member(int(sub["user_id"]))
                    if member:
                        role = guild.get_role(int(sub.get("role_id", 0)))
                        if role:
                            try:
                                await member.remove_roles(role, reason="Assinatura expirada")
                            except:
                                pass
        
        if to_remove:
            for sub_id in to_remove:
                del subscriptions[sub_id]
            db.save_document("loja_subscriptions", subscriptions)

    @commands.slash_command(
        name="gerenciar_assinaturas",
        description="Painel de gerenciamento de assinaturas (Admin)",
        guild_ids=[utils.obter_server_principal()]
    )
    @commands.has_permissions(administrator=True)
    async def gerenciar_assinaturas(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.defer(ephemeral=True)
        
        subscriptions = db.get_document("loja_subscriptions") or {}
        
        embed = disnake.Embed(
            title=f"{emoji.receipt} Gerenciamento de Assinaturas",
            description=f"Total de assinaturas ativas: **{len(subscriptions)}**",
            color=disnake.Color.blurple()
        )
        
        await inter.followup.send(embed=embed, ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(AssinaturasCog(bot))
