from . import cog
def setup(bot): cog.setup(bot)
