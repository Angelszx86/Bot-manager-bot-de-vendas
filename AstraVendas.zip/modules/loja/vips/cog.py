import disnake
from disnake.ext import commands, tasks
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
from datetime import datetime

class VipsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.check_vips.start()

    def cog_unload(self):
        self.check_vips.cancel()

    @tasks.loop(hours=1)
    async def check_vips(self):
        """Verifica VIPs expirados e remove cargos"""
        now = datetime.now().timestamp()
        vips = db.get_document("loja_vips") or {}
        
        to_remove = []
        for user_id, vip in vips.items():
            if vip["expiry"] < now:
                to_remove.append(user_id)
                guild = self.bot.get_guild(utils.obter_server_principal())
                if guild:
                    member = guild.get_member(int(user_id))
                    if member:
                        # Lógica para remover cargo VIP configurado
                        config = db.get_document("cargos")
                        vip_role_id = config.get("vip")
                        if vip_role_id:
                            role = guild.get_role(int(vip_role_id))
                            if role:
                                try:
                                    await member.remove_roles(role, reason="VIP expirado")
                                except:
                                    pass
        
        if to_remove:
            for user_id in to_remove:
                del vips[user_id]
            db.save_document("loja_vips", vips)

def setup(bot: commands.Bot):
    bot.add_cog(VipsCog(bot))
