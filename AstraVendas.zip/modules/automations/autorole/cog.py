import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils

class AutoRoleCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        if member.bot:
            return
            
        config = db.get_document("automacoes").get("autorole", {})
        if not config.get("enabled", False):
            return
            
        role_ids = config.get("roles", [])
        if not role_ids:
            return
            
        roles_to_add = []
        for role_id in role_ids:
            role = member.guild.get_role(int(role_id))
            if role and role < member.guild.me.top_role:
                roles_to_add.append(role)
                
        if roles_to_add:
            try:
                await member.add_roles(*roles_to_add, reason="AutoRole - Entrada de novo membro")
            except Exception as e:
                print(f"Erro ao adicionar cargos automáticos: {e}")

    @commands.slash_command(
        name="autorole",
        description="Configura o sistema de cargos automáticos",
        guild_ids=[utils.obter_server_principal()]
    )
    @commands.has_permissions(administrator=True)
    async def autorole(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.defer(ephemeral=True)
        
        config = db.get_document("automacoes").get("autorole", {})
        enabled = config.get("enabled", False)
        role_ids = config.get("roles", [])
        
        embed = disnake.Embed(
            title=f"{emoji.settings} Configuração AutoRole",
            description="Cargos que serão adicionados automaticamente quando um novo membro entrar.",
            color=disnake.Color.blurple()
        )
        
        status = f"{emoji.correct} Ativado" if enabled else f"{emoji.wrong} Desativado"
        embed.add_field(name="Status", value=status, inline=True)
        
        roles_mentions = [f"<@&{rid}>" for rid in role_ids]
        embed.add_field(name="Cargos", value=", ".join(roles_mentions) if roles_mentions else "Nenhum", inline=False)
        
        components = [
            disnake.ui.ActionRow(
                disnake.ui.Button(
                    label="Ativar/Desativar",
                    style=disnake.ButtonStyle.green if not enabled else disnake.ButtonStyle.red,
                    custom_id="AutoRole_Toggle"
                ),
                disnake.ui.Button(
                    label="Configurar Cargos",
                    style=disnake.ButtonStyle.blurple,
                    custom_id="AutoRole_Config"
                )
            )
        ]
        
        await inter.followup.send(embed=embed, components=components, ephemeral=True)

    @commands.Cog.listener("on_button_click")
    async def on_button_click(self, inter: disnake.MessageInteraction):
        if inter.component.custom_id == "AutoRole_Toggle":
            automacoes = db.get_document("automacoes")
            config = automacoes.get("autorole", {})
            config["enabled"] = not config.get("enabled", False)
            automacoes["autorole"] = config
            db.save_document("automacoes", automacoes)
            
            # Re-chamar o painel
            await self.autorole.callback(self, inter)
            
        elif inter.component.custom_id == "AutoRole_Config":
            await inter.response.send_message("Use `/autorole_add` ou `/autorole_remove` para gerenciar os cargos.", ephemeral=True)

def setup(bot: commands.Bot):
    bot.add_cog(AutoRoleCog(bot))
