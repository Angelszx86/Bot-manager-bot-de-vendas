import disnake
from disnake.ext import commands
from functions.database import database as db
from functions.emoji import emoji
from functions.utils import utils
import asyncio

class DisparadorDMCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(
        name="disparar_dm",
        description="Envia uma mensagem na DM de todos os membros (Admin)",
        guild_ids=[utils.obter_server_principal()]
    )
    @commands.has_permissions(administrator=True)
    async def disparar_dm(
        self, 
        inter: disnake.ApplicationCommandInteraction,
        mensagem: str = commands.Param(description="Mensagem a ser enviada"),
        incluir_bots: bool = commands.Param(description="Incluir bots no disparo?", default=False)
    ):
        await inter.response.defer(ephemeral=True)
        
        members = inter.guild.members
        if not incluir_bots:
            members = [m for m in members if not m.bot]
            
        total = len(members)
        sucesso = 0
        falha = 0
        
        embed_status = disnake.Embed(
            title=f"{emoji.sync} Disparo em Andamento",
            description=f"Enviando mensagem para {total} membros...",
            color=disnake.Color.blurple()
        )
        
        status_msg = await inter.followup.send(embed=embed_status, ephemeral=True)
        
        for member in members:
            try:
                await member.send(mensagem)
                sucesso += 1
            except:
                falha += 1
                
            # Atualizar status a cada 10 membros
            if (sucesso + falha) % 10 == 0:
                embed_status.description = f"Progresso: {sucesso + falha}/{total}\n✅ Sucesso: {sucesso}\n❌ Falha: {falha}"
                await status_msg.edit(embed=embed_status)
                
            # Delay para evitar rate limit
            await asyncio.sleep(0.5)
            
        embed_status.title = f"{emoji.correct} Disparo Concluído"
        embed_status.description = f"O disparo foi finalizado!\n\n👥 Total: {total}\n✅ Sucesso: {sucesso}\n❌ Falha: {falha}"
        embed_status.color = disnake.Color.green()
        
        await status_msg.edit(embed=embed_status)

def setup(bot: commands.Bot):
    bot.add_cog(DisparadorDMCog(bot))
