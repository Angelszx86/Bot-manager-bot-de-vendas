from functions.database import database as db
from disnake.ext import commands
import disnake
from tasks.bot.status_rotator import status_rotator_task

def get_status_obj(status_type: str) -> disnake.Status:
    status_map = {
        "online": disnake.Status.online,
        "idle": disnake.Status.idle,
        "dnd": disnake.Status.dnd,
        # "streaming" nao e um status valido de presenca no Discord (o gateway so aceita
        # online/idle/dnd/invisible). O indicador roxo de "transmitindo" vem da ATIVIDADE
        # (disnake.Streaming), nao do campo de status. Por isso mapeamos para online aqui.
        "streaming": disnake.Status.online,
        "offline": disnake.Status.invisible,
    }
    return status_map.get(status_type, disnake.Status.online)

async def change_status(bot: commands.Bot):
    if not status_rotator_task.is_running():
        status_rotator_task.start(bot)

def get_status() -> disnake.Status:
    database = db.get_document("custom_status")
    return get_status_obj(database.get("type", "online"))