const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const { TicketService } = require('../dist/services/tickets.js');
const { JsonDatabase } = require('../dist/core/json-db.js');

const gid = '1485091010911408258';
const logger = { warn(){}, error(){}, success(){}, info(){}, debug(){} };
const credentials = {};
const option = {
  id: 'OPT_current', name: 'Suporte', description: 'Falar com a equipe', emojiSemantic: 'support',
  categoryId: '', supportRoleIds: [], channelPrefix: 'ticket', openingTitle: 'Atendimento aberto',
  openingDescription: 'Explique como podemos ajudar.', closeMessage: 'Encerrado.', askSubject: true,
  maxOpenTicketsPerUser: 1, mentionSupport: true, active: true, position: 0
};
const panel = {
  id: 'TPN_current', guildId: gid, name: 'Atendimento', title: 'Central de Atendimento',
  description: 'Selecione o assunto', color: '#3155ff', imageUrl: '', thumbnailUrl: '', footer: '',
  mode: 'SELECT', buttonLabel: 'Selecione', buttonStyle: 'SECONDARY', emojiSemantic: 'ticket',
  fields: [], options: [structuredClone(option)], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
  channelId: '', messageId: ''
};

// 1) Painel listado por panel.id precisa continuar resolvendo mesmo se a chave do objeto vier de versão antiga.
let saves = 0;
const fakeDb = {
  state: { ticketPanels: { 'legacy-storage-key': structuredClone(panel) } },
  save(){ saves++; }, audit(){}, guild(){ return { ticketLogChannelId: '' }; }
};
const svc = new TicketService({}, fakeDb, {}, logger);
assert.equal(svc.getPanel('TPN_current', gid).id, 'TPN_current');

// 2) Um customId antigo/stale deve ser recuperado pelo optionId, sem editar painel aleatório.
assert.equal(svc.getPanelForOption('TPN_stale_from_old_message', 'OPT_current', gid).id, 'TPN_current');
svc.updateOption('TPN_stale_from_old_message', 'OPT_current', { categoryId: '123456789012345678' }, 'admin', gid);
assert.equal(fakeDb.state.ticketPanels['legacy-storage-key'].options[0].categoryId, '123456789012345678');
assert.ok(saves > 0);

// 3) Se só existe um painel no servidor, botões efêmeros antigos podem ser autocorrigidos com segurança.
assert.equal(svc.resolvePanel('TPN_old_after_restart', gid).id, 'TPN_current');

// 4) Com mais de um painel e sem optionId/fieldId válido, nunca selecionar um painel ao acaso.
fakeDb.state.ticketPanels.second = { ...structuredClone(panel), id: 'TPN_second', name: 'Outro', options: [{ ...structuredClone(option), id: 'OPT_second' }] };
assert.throws(() => svc.resolvePanel('TPN_unknown', gid), /Painel de ticket não encontrado/);

// 5) O loader deve reparar persistentemente chave != panel.id e preservar referências de tickets.
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'zenyx-r18-9-18-'));
const cfg = path.join(tmp, gid, 'tickets');
fs.mkdirSync(cfg, { recursive: true });
fs.writeFileSync(path.join(cfg, 'configuracoes.json'), JSON.stringify({ 'old-key': panel }, null, 2));
fs.writeFileSync(path.join(cfg, 'tickets-abertos.json'), JSON.stringify({ TKT_1: {
  id: 'TKT_1', guildId: gid, channelId: '123456789012345679', ownerId: '123456789012345680',
  panelId: 'old-key', optionId: 'OPT_current', subject: 'teste', status: 'OPEN', claimedBy: '', addedUserIds: [],
  selectedOrderId: '', purchaseGateStatus: 'NONE', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
  closedAt: '', archivedAt: ''
}}, null, 2));
const db = new JsonDatabase(tmp, logger, credentials);
assert.ok(db.state.ticketPanels.TPN_current, 'painel deve ser reindexado por panel.id');
assert.equal(db.state.ticketPanels['old-key'], undefined, 'chave antiga não deve permanecer ativa');
assert.equal(db.state.tickets.TKT_1.panelId, 'TPN_current', 'ticket aberto deve acompanhar o ID canônico');
fs.rmSync(tmp, { recursive: true, force: true });

console.log('R18_9_18_TICKET_ROUTING_REGRESSION_OK');
