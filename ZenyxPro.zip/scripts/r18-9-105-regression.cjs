const fs=require('fs'); const path=require('path');
const root=path.resolve(__dirname,'..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const assert=(c,m)=>{if(!c) throw new Error(m)};
for(const p of ['src/discord/router.ts','src/services/orders.ts','src/services/tickets.ts','src/services/giveaways.ts']){
 const s=read(p); assert(s.includes('displayBrandNameSafe'), `${p}: fallback ausente`); assert(!s.includes(' displayBrandName,'), `${p}: import legado ainda presente`);
}
const u=read('dist/core/utils.js'); assert(u.includes('exports.displayBrandName'), 'core util sem export de compatibilidade');
for(const p of ['dist/discord/router.js','dist/services/orders.js','dist/services/tickets.js','dist/services/giveaways.js']){
 const s=read(p); assert(s.includes('displayBrandNameSafe'), `${p}: dist sem fallback`); assert(!s.includes('utils_js_1.displayBrandName'), `${p}: dist ainda chama export fragil`);
}
const pkg=JSON.parse(read('package.json')); assert(pkg.version==='18.9.105','versao errada');
console.log('R18.9.105 regression OK');
