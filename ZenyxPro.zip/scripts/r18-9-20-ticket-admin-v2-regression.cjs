const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const ok = (condition, message) => { if (!condition) throw new Error(message); };

const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const dist = read('dist/discord/router.js');
const validator = read('src/discord/payload-validator.ts');

ok(pkg.version === '18.9.20', 'child version must be 18.9.20');
ok(pkg.zenyxBuild === '2026-09-10-r18.9.20-ticket-admin-v2-migration', 'child build mismatch');

// Any component-driven admin navigation must end in Components V2.
ok(router.includes('return views.adminPageEdit(guildId, payload, hasDefaultBanner);'), 'admin legacy payload is not normalized to V2');
ok(!router.includes('return sourceIsV2 ? views.adminPageEdit(guildId, payload, hasDefaultBanner) : payload;'), 'legacy-preserving admin branch returned');
ok(router.includes('await target.deferUpdate();'), 'legacy message migration must ACK with deferUpdate');
ok(router.includes('target.editReply({ ...next, content: null, embeds: [], attachments: [], poll: null }'), 'legacy -> V2 edit does not reset legacy fields');
ok(router.includes('const { content: _content, embeds: _embeds, stickers: _stickers, poll: _poll, ...safe } = payload;'), 'native V2 payload sanitizer missing');

// Ticket option modals were the main source of fresh legacy embeds.
const wrappedModalReplies = (router.match(/this\.views\.adminPage\(gid, this\.ticketOptionDetail\(/g) || []).length;
ok(wrappedModalReplies >= 5, `expected >=5 V2 ticket-option modal replies, got ${wrappedModalReplies}`);
ok(!/i\.reply\(\{ \.\.\.this\.ticketOptionDetail\([^\n]+flags: MessageFlags\.Ephemeral \}\)/.test(router), 'ticket option modal still creates a legacy ephemeral embed');

// Keep the create-payload guard: V2 create/reply payloads themselves must not carry legacy fields.
ok(validator.includes('for (const field of ["content", "embeds", "stickers", "poll"] as const)'), 'V2 legacy-field validator missing');

// Deployment JS must contain the same migration, not only TypeScript source.
ok(dist.includes('return views.adminPageEdit(guildId, payload, hasDefaultBanner);'), 'compiled router does not normalize admin pages to V2');
ok(dist.includes('await target.deferUpdate();'), 'compiled legacy -> V2 migration missing');
ok(dist.includes('content: null, embeds: [], attachments: [], poll: null'), 'compiled migration does not reset legacy fields');
ok((dist.match(/this\.views\.adminPage\(gid, this\.ticketOptionDetail\(/g) || []).length >= 5, 'compiled ticket option modal replies are stale');

console.log('R18_9_20_TICKET_ADMIN_V2_MIGRATION_REGRESSION_OK');
