const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const must=(v,m)=>{if(!v)throw new Error(m)};
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const pkg=JSON.parse(read('package.json'));
const index=read('src/index.ts');
const router=read('src/discord/router.ts');
const distIndex=read('dist/index.js');
const distRouter=read('dist/discord/router.js');
const invite='https://discord.gg/V2v8JnwdgR';
must(pkg.version==='18.9.19','versão child não é R18.9.19');
for(const t of [index,router,distIndex,distRouter]){must(t.includes(robot),'emoji robô canônico ausente'); must(t.includes(crown),'emoji coroa canônico ausente'); must(t.includes(invite),'convite novo ausente');}
must(index.includes('function lockedApplicationBio()'),'guard local ausente');
must(!index.includes('if (!desired) return;'),'guard ainda pode abandonar a Bio');
must(router.includes('Bio ZENYX bloqueada para bots filhos'),'UI de bloqueio ausente');
must(!read('src/core/json-db.ts').includes('Automação completa para Discord • vendas, tickets e pagamentos 24/7.'),'fallback antigo ainda é fonte de verdade');
console.log('R18.9.19 child bio canonical regression: OK');
