const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const srcR = fs.readFileSync(path.join(root, 'src/discord/router.ts'), 'utf8');
const distR = fs.readFileSync(path.join(root, 'dist/discord/router.js'), 'utf8');
function ok(cond, msg){ if(!cond) throw new Error(msg); }
ok(srcR.includes('setURL(this.zcloud.panelAuthorizeUrl(guildId))'), 'src painel deixou de abrir OAuth Discord diretamente');
ok(distR.includes('setURL(this.zcloud.panelAuthorizeUrl(guildId))'), 'dist painel deixou de abrir OAuth Discord diretamente');
console.log('R18_9_3_REGRESSION_OK');
