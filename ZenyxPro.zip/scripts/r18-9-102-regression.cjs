'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const views = read('src/discord/views.ts');
const types = read('src/types.ts');
const products = read('src/services/products.ts');
const db = read('src/core/json-db.ts');
const magnus = read('src/payments/providers/magnus-pay.ts');

assert.equal(pkg.version, '18.9.102');
assert.equal(pkg.zenyxBuild, 'R18.9.102');

// Preço definido pela equipe: oculto na vitrine, editável no ticket e persistente.
assert.match(types, /"FIXED" \| "CUSTOMER" \| "STAFF" \| "HIDDEN"/);
assert.match(products, /staffPriceEnabled\(/);
assert.match(products, /return mode === "FIXED" \|\| mode === "CUSTOMER"/);
assert.match(views, /priceMode === "HIDDEN" \|\| priceMode === "STAFF" \? ""/);
assert.match(views, /admin:product:simple-price-mode:[^`]+:STAFF/);
assert.match(views, /admin:product:field-price-mode:[^`]+:STAFF/);
assert.match(router, /product-ticket:price:/);
assert.match(router, /product-ticket:price-modal:/);
assert.match(router, /Defina o valor da venda antes de enviar o PIX/);
assert.match(router, /Defina o valor da venda antes de confirmar o produto/);
assert.match(db, /product\.simpleTicketPriceMode === "STAFF"/);

// Categoria própria por produto e nome curto de recibo.
for (const token of ['simpleTicketCategoryId', 'simpleReceiptName']) {
  assert.ok(types.includes(token), `types sem ${token}`);
  assert.ok(products.includes(token), `products sem ${token}`);
  assert.ok(db.includes(token), `db sem ${token}`);
  assert.ok(router.includes(token), `router sem ${token}`);
  assert.ok(views.includes(token), `views sem ${token}`);
}
assert.match(router, /ChannelType\.GuildCategory/);
assert.match(router, /product\.simpleTicketCategoryId \|\| settings\.purchaseCategoryId \|\| settings\.ticketCategoryId/);
assert.match(router, /simpleProductDisplayName\(/);

// Recibo compacto e preto.
assert.match(router, /width="840" height="410"/);
assert.match(router, /fill="#000000"/);
assert.match(router, /Compra confirmada/);
assert.match(router, /productName: displayProductName/);

// MagnusPay: compatibilidade entre schemas sem reintroduzir formulário obrigatório.
for (const token of ['transactionId', 'externalId', 'externalReference', 'clientReference', 'amountCents', 'customer', 'X-API-Key', 'Authorization']) {
  assert.ok(magnus.includes(token), `MagnusPay sem compatibilidade ${token}`);
}
assert.match(magnus, /\[400, 422\]/);
assert.match(magnus, /error\.status === 404/);
assert.doesNotMatch(magnus, /exige CPF/);
assert.doesNotMatch(magnus, /exige o nome completo/);

// Fechamento real do ticket continua presente.
const closeStart = router.indexOf('if (action === "close")');
const closeBlock = router.slice(closeStart, closeStart + 2200);
assert.match(closeBlock, /channel\.delete\(/);
assert.match(closeBlock, /mantendo-o bloqueado/);

console.log('R18.9.102 static regression: OK');
