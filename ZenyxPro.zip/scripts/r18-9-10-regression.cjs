const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const ok = (condition, message) => { if (!condition) throw new Error(message); };

const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const views = read('src/discord/views.ts');
const tickets = read('src/services/tickets.ts');
const validator = read('src/discord/payload-validator.ts');
const types = read('src/types.ts');

ok(pkg.version === '18.9.10', 'child version must be 18.9.10');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.10-admin-v2-ticket-panels', 'child build mismatch');

// Exact Discord error: V2 payloads must never carry legacy top-level fields,
// even as null or empty arrays.
ok(validator.includes('for (const field of ["content", "embeds", "stickers", "poll"] as const)'), 'strict V2 legacy-field guard missing');
ok(validator.includes('Object.prototype.hasOwnProperty.call(json, field)'), 'V2 guard must reject present-but-empty legacy fields');
ok(!/publishedProductEdit[\s\S]{0,400}embeds:\s*\[\]/.test(views), 'publishedProductEdit still sends embeds: []');
ok(!/publicTicketPanelEdit[\s\S]{0,400}embeds:\s*\[\]/.test(views), 'publicTicketPanelEdit still sends embeds: []');
ok(!/botMessageEdit[\s\S]{0,400}embeds:\s*\[\]/.test(views), 'botMessageEdit still sends embeds: []');
ok(views.includes('return { ...this.publishedProduct(guildId, product), attachments: [] };'), 'safe published product V2 edit missing');
ok(views.includes('return { ...this.publicTicketPanel(guildId, panel), attachments: [] };'), 'safe ticket panel V2 edit missing');

// /painel navigation must keep one rendering model and strip forbidden fields.
ok(router.includes('const { content: _content, embeds: _embeds, stickers: _stickers, poll: _poll, ...safe } = payload;'), 'admin V2 normalization does not strip legacy fields');
ok(router.includes('return sourceIsV2 ? views.adminPageEdit(guildId, payload, hasDefaultBanner) : payload;'), 'admin V2/legacy compatibility path missing');
ok((router.match(/this\.views\.adminPage\(gid,/g) || []).length >= 20, 'admin modal replies were not migrated consistently to V2');

// Ticket main surface and private customer/staff panels.
ok(tickets.includes('ticket:staff-panel:${ticket.id}'), 'staff panel button missing from ticket');
ok(tickets.includes('ticket:user-panel:${ticket.id}'), 'user panel button missing from ticket');
ok(tickets.includes('ticket:info:${ticket.id}'), 'ticket information button missing');
ok(router.includes('## Painel do Usuário'), 'private customer panel missing');
ok(router.includes('## Painel do Atendente'), 'private staff panel missing');
ok(router.includes('Você não possui o cargo ou a permissão de atendimento necessária para abrir o Painel do Atendente.'), 'explicit unauthorized staff-panel response missing');
ok(router.includes('Este painel é privado e só pode ser aberto pelo cliente que criou o ticket.'), 'private customer-panel ownership guard missing');
ok(router.includes('...(option?.supportRoleIds ?? [])'), 'per-option ticket support roles are not honored by permission checks');
ok(router.includes('ticket:transfer-select:${ticketId}'), 'staff transfer selector missing');
ok(router.includes('ticket:notify-staff:${ticket.id}'), 'customer notify-staff action missing');
ok(tickets.includes('async notifyStaff(ticketId: string, actorId: string)'), 'notifyStaff service missing');
ok(tickets.includes('async transfer(ticketId: string, target: GuildMember, actorId: string)'), 'ticket transfer service missing');
ok(types.includes('lastStaffNotifiedAt?: string;') && types.includes('staffNotificationCount?: number;'), 'ticket notification state fields missing');

// Compiled deployment must contain the same fix.
const distRouter = read('dist/discord/router.js');
const distViews = read('dist/discord/views.js');
const distTickets = read('dist/services/tickets.js');
ok(distRouter.includes('Painel do Atendente') && distRouter.includes('Painel do Usuário'), 'compiled router is stale');
ok(distTickets.includes('ticket:staff-panel:') && distTickets.includes('ticket:user-panel:'), 'compiled ticket service is stale');
ok(!/publishedProductEdit[\s\S]{0,400}embeds:\s*\[\]/.test(distViews), 'compiled publishedProductEdit still sends embeds: []');

console.log('R18_9_10_ADMIN_V2_TICKET_PANELS_REGRESSION_OK');
