const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const must=(v,m)=>{if(!v)throw new Error(m)};
const pkg=JSON.parse(read('package.json'));
const index=read('src/index.ts');
const zcloud=read('src/services/zcloud.ts');
const router=read('src/discord/router.ts');
const orders=read('src/services/orders.ts');
const views=read('src/discord/views.ts');

must(pkg.version==='18.9.31','child version mismatch');
must(pkg.zenyxBuild==='2026-09-11-r18.9.31-private-supervision-guild-validation','child build mismatch');
const commandPos=index.indexOf('Registrando comandos de aplicação isolados...');
const emojiPos=index.indexOf('Instalação automática de emojis detectada.');
must(commandPos>=0 && emojiPos>=0 && commandPos<emojiPos,'guild/commands must validate before heavy emoji sync');
must(zcloud.includes('guildAvailable') && zcloud.includes('this.client.guilds.fetch(targetGuildId)'), 'ZCloud still trusts guild cache only');
must(zcloud.includes('await g.roles.fetch()'), 'ZCloud role validation does not refresh roles');

// Critical R18.9.30 guarantees remain present after the R18.9.31 manager changes.
must(views.includes('delivery_bolt') && views.includes('product:field-select:'), 'professional product storefront regressed');
must(router.includes('admin:zcloud:emoji-remove') && router.includes('reaction-emoji-search'), 'emoji/ZCloud picker regressed');
must(orders.includes('fulfillmentLocks') && orders.includes('deliveryNotificationPageIds'), 'delivery idempotency regressed');
console.log('R18_9_31_CHILD_REGRESSION_OK');
