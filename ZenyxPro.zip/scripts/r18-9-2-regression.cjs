const fs = require('fs');
const assert = require('assert');

const router = fs.readFileSync('src/discord/router.ts', 'utf8');
const zcloud = fs.readFileSync('src/services/zcloud.ts', 'utf8');
const types = fs.readFileSync('src/types.ts', 'utf8');

// O painel público deve apontar direto para discord.com/oauth2/authorize.
assert(zcloud.includes('panelAuthorizeUrl(guildId: string)'));
assert(zcloud.includes('return this.authorizeUrl(guildId, this.panelState(guildId))'));
assert(zcloud.includes('https://discord.com/oauth2/authorize?'));
assert(router.includes('setURL(this.zcloud.panelAuthorizeUrl(guildId))'));
assert(!router.includes('const start=this.zcloud.publicStartUrl(gid)'));

// State assinado impede adulteração do guildId no link público.
assert(zcloud.includes('createHmac("sha256"'));
assert(zcloud.includes('timingSafeEqual'));
assert(zcloud.includes('zcloud_state_secret'));
assert(zcloud.includes('verifyPanelState(guildId, state)'));

// Personalização solicitada.
for (const field of ['panelImageUrl', 'panelColor', 'panelFooter', 'panelMode', 'buttonEmoji']) assert(types.includes(field));
assert(router.includes('Link da imagem / banner'));
assert(router.includes('Cor lateral / accent (#RRGGBB)'));
assert(router.includes('Emoji do botão'));
assert(router.includes('admin:zcloud:panel-mode'));
assert(router.includes('Components V2'));
assert(router.includes('Embed normal'));
assert(router.includes('Pré-visualizar'));
assert(router.includes('MediaGalleryBuilder'));
assert(router.includes('MessageFlags.IsComponentsV2'));

// A página só aparece no callback e possui loading real em etapas.
assert(zcloud.includes('Sincronizando seu acesso'));
assert(zcloud.includes('Conectando ao Discord'));
assert(zcloud.includes('Validando autorização'));
assert(zcloud.includes('Verificando usuário'));
assert(zcloud.includes('Sincronizando acesso'));
assert(zcloud.includes('Voltando para o Discord em'));

console.log('R18_9_2_REGRESSION_OK');
