const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
function must(ok, msg){ if(!ok){ console.error('FAIL:',msg); process.exitCode=1; } else console.log('PASS:',msg); }
const views = read('src/discord/views.ts');
const emojis = read('src/emojis/manager.ts');
const router = read('src/discord/router.ts');
const voice = read('src/services/voice.ts');
const pkg = JSON.parse(read('package.json'));

must(pkg.version === '18.9.55', 'child version is 18.9.55');
const nav = views.indexOf('.setCustomId("admin:navigate")');
const v = views.indexOf('.setLabel("Conectar em call")', nav);
const c = views.indexOf('.setLabel("Comandos")', nav);
const ord = views.indexOf('.setLabel("Pedidos")', nav);
must(nav >= 0 && v > nav && c > v && ord > c, 'voice/commands are at the beginning of the navigation menu');
const row = views.indexOf('this.button(guildId, "admin:voice"');
const prod = views.indexOf('this.button(guildId, "admin:products"', row);
must(row >= 0 && views.indexOf('this.button(guildId, "admin:commands"', row) < prod, 'voice/commands are first-row panel buttons');
must(emojis.includes('criticalCustomOnly = semantic === "voice" || semantic === "commands"'), 'voice/commands never prefer unicode fallback');
must(emojis.includes('"voice", "commands"') && emojis.includes('ensureBrandEmojis'), 'voice/commands are critical application emojis');
must(router.includes('if (isAdminSelect && !interaction.deferred && !interaction.replied) await interaction.deferUpdate();'), 'admin selects ACK before heavy work');
must(voice.includes('disconnected-after-resume-window') && voice.includes('keepalive') && voice.includes('connection.rejoin?.()'), 'voice service has persistent reconnect/keepalive logic');
if(process.exitCode) process.exit(process.exitCode); else console.log('R18.9.55 child regression OK');
