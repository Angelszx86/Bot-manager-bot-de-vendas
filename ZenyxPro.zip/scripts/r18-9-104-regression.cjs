const fs = require('fs');
const assert = require('assert');
const files = {
  utils: fs.readFileSync('src/core/utils.ts', 'utf8'),
  index: fs.readFileSync('src/index.ts', 'utf8'),
  router: fs.readFileSync('src/discord/router.ts', 'utf8'),
  distUtils: fs.readFileSync('dist/core/utils.js', 'utf8')
};
assert(files.utils.includes('export const displayBrandName'), 'displayBrandName ausente no source');
assert(files.router.includes('displayBrandName('), 'router nao usa displayBrandName');
assert(files.index.includes('Options.cacheWithLimits'), 'cache otimizado ausente');
assert(files.index.includes('messages: { interval: 300, lifetime: 900 }'), 'sweeper de mensagens ausente');
assert(files.router.includes('setInterval(pollZcloudRuntime, 5_000)'), 'poll ZCloud nao otimizado');
console.log('source checks: OK');
