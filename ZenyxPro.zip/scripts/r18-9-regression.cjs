const fs = require('fs');
const assert = require('assert');

const router = fs.readFileSync('src/discord/router.ts', 'utf8');
const zcloud = fs.readFileSync('src/services/zcloud.ts', 'utf8');
const views = fs.readFileSync('src/discord/views.ts', 'utf8');
const db = fs.readFileSync('src/core/json-db.ts', 'utf8');
const config = fs.readFileSync('src/config.ts', 'utf8');

const panel = router.slice(router.indexOf('private publicRobuxPanel'), router.indexOf('private robuxCalcMenu'));
assert(panel.includes('robux:buy'));
assert(panel.includes('robux:calc'));
assert(!panel.includes('robux:manual'));

assert(router.includes('checkoutCreating?: boolean'));
assert(router.includes('pendingOrderId?: string'));
assert(router.includes('Falha ao editar cobrança Robux; usando mensagem de recuperação.'));
assert(router.includes('this.robux.setPurchaseMessage(order.id, replacement.id)'));

assert(router.includes('"admin:zcloud"'));
assert(views.includes('setLabel("ZCloud")'));
assert(views.includes('this.emojis.component("zcloud"'));

assert(zcloud.includes('randomBytes(32)'));
assert(zcloud.includes('identify guilds.join'));
assert(zcloud.includes('zcloud_client_secret'));
assert(zcloud.includes('zcloud_refresh_'));
assert(zcloud.includes('/health'));
assert(zcloud.includes('id="count">3'));
assert(zcloud.includes('this.config.zcloudEdgeBaseUrl'));
assert(zcloud.includes('this.config.zcloudCloudflaredPath'));
assert(zcloud.includes('this.config.zcloudTunnelAuto'));
const forbiddenEnv = 'process' + '.env';
assert(!zcloud.includes(forbiddenEnv));
assert(!config.includes(forbiddenEnv));

assert(db.includes('state.version = 14'));
assert(db.includes('this.state.version !== 14'));
assert(db.includes('"zcloud", "configuracoes.json"'));
assert(db.includes('"zcloud", "membros.json"'));

console.log('R18_9_REGRESSION_OK');
