'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const views = read('src/discord/views.ts');
const types = read('src/types.ts');
const products = read('src/services/products.ts');
const db = read('src/core/json-db.ts');
const orders = read('src/services/orders.ts');
const tickets = read('src/services/tickets.ts');
const robux = read('src/services/robux.ts');
const giveaways = read('src/services/giveaways.ts');

assert.equal(pkg.version, '18.9.100');
assert.equal(pkg.zenyxBuild, 'R18.9.100');

// Interação da tela Produtos / Opções: ACK + editReply, nunca update depois do defer.
assert.match(router, /if \(id\.startsWith\("admin:product:fields:"\)\)[\s\S]*?await i\.deferUpdate\(\);[\s\S]*?return i\.editReply\(this\.views\.productFieldsView/);
assert.doesNotMatch(router, /await i\.deferUpdate\(\);\s*const product = this\.products\.get\(id\.split\(":"\)\[3\]!, gid\);\s*return i\.update\(this\.views\.productFieldsView/);

// O select administrativo não deve carregar emoji custom salvo/stale no payload.
const fieldsView = views.slice(views.indexOf('productFieldsView('), views.indexOf('productFieldDetail('));
assert.ok(fieldsView.includes('admin:product:field-select:'));
assert.ok(!fieldsView.includes('.setEmoji('), 'productFieldsView ainda injeta emoji no select administrativo');

// Preço informado pelo cliente: padrão do produto + override por item.
for (const token of ['simpleCustomerPriceEnabled']) {
  assert.ok(types.includes(token));
  assert.ok(products.includes(token));
  assert.ok(db.includes(token));
}
assert.match(products, /customerPriceEnabled\(/);
assert.match(products, /setFieldCustomerPriceMode\(/);
assert.match(views, /Preço informado pelo cliente/);
assert.match(views, /Preço no ticket: pedir/);
assert.match(views, /Usar padrão do produto/);
assert.match(router, /product:simple-price-modal:/);
assert.match(router, /simpleProductPriceCents/);
assert.match(router, /simpleProductPriceSource/);
assert.match(router, /Valor combinado \(R\$\)/);
assert.match(router, /this\.simpleProductTicketPrice\(ticket, field\)/);

// DMs/recibos principais redesenhados com marca, avatar e navegação.
assert.match(orders, /setAuthor\(\{ name: brand\.name \|\| "ZENYX APPLICATIONS"/);
assert.match(orders, /setThumbnail\(avatar\)/);
assert.match(tickets, /Ticket criado/);
assert.match(tickets, /Abrir atendimento/);
assert.match(robux, /Robux entregues/);
assert.match(router, /Venda iniciada/);
assert.match(giveaways, /Você venceu o sorteio/);
assert.match(giveaways, /setAuthor/);

console.log('R18.9.100 regression: OK');
