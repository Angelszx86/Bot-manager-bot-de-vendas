const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const ok = (condition, message) => { if (!condition) throw new Error(message); };

const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const validator = read('src/discord/payload-validator.ts');
const payments = read('src/services/payments.ts');

ok(pkg.version === '18.9.11', 'child version must be 18.9.11');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.11-robux-pix-checkout', 'child build mismatch');

// Root cause from the failed manual checkout: Discord Section (type 9) requires
// an accessory. Manual checkout can have no Roblox avatar yet, so it must fall
// back to Text Display instead of emitting an accessory-less Section.
ok(router.includes('Discord Components V2 exige `accessory` em todo Section (type 9).'), 'manual checkout Section/accessory fix missing');
ok(router.includes('components.push({ type: 10, content: checkoutText });'), 'manual checkout Text Display fallback missing');
ok(router.includes('if (avatarUrl && !identityPending)'), 'avatar Section guard missing');
ok(validator.includes('Section exige um accessory (Button ou Thumbnail)'), 'validator does not reject accessory-less Sections');
ok(validator.includes('Section precisa ter entre 1 e 3 Text Displays'), 'validator does not enforce Section text count');

// The checkout must expose both payment artifacts to the buyer, not only a QR image.
ok(router.includes('**Chave PIX:**'), 'visible PIX key missing from Robux checkout');
ok(router.includes('robux:pix-key:${userId}:${order.id}'), 'PIX key action missing');
ok(router.includes('robux:pix-code:${userId}:${order.id}'), 'PIX copy-paste action missing');
ok(router.includes('**PIX copia e cola**'), 'PIX copy-paste reply missing');
ok(router.includes('checkedDiscordPayload({ components: [{ type: 17'), 'Robux checkout is not validated locally before Discord API submission');

// Manual PIX provider must still actually generate both copy-paste payload and QR.
ok(payments.includes('const pixCode = createStaticPixPayload'), 'manual PIX no longer generates copy-paste payload');
ok(payments.includes('qrCodeDataUrl: await pixQrDataUrl(pixCode)'), 'manual PIX no longer generates QR data');

const distRouter = read('dist/discord/router.js');
const distValidator = read('dist/discord/payload-validator.js');
ok(distRouter.includes('Section (type 9)'), 'compiled router is stale');
ok(distRouter.includes('robux:pix-key:'), 'compiled PIX key control missing');
ok(distRouter.includes('robux:pix-code:'), 'compiled PIX code control missing');
ok(distValidator.includes('Section exige um accessory'), 'compiled validator is stale');

// Execute the compiled validator against the exact structural regression.
const { assertDiscordPayload } = require(path.join(root, 'dist/discord/payload-validator.js'));
let rejected = false;
try {
  assertDiscordPayload({
    flags: 32768,
    components: [{ type: 17, components: [{ type: 9, components: [{ type: 10, content: 'Checkout Robux' }] }] }]
  }, 'manual checkout without avatar');
} catch (error) {
  rejected = String(error).includes('Section exige um accessory');
}
ok(rejected, 'validator did not reject the exact invalid Section shape');
assertDiscordPayload({
  flags: 32768,
  components: [{ type: 17, components: [{ type: 10, content: 'Checkout Robux sem avatar' }] }]
}, 'manual checkout text fallback');

console.log('R18_9_11_ROBUX_PIX_CHECKOUT_REGRESSION_OK');
