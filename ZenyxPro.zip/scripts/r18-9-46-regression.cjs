const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const views=read('src/discord/views.ts');
const router=read('src/discord/router.ts');
const validator=read('src/discord/payload-validator.ts');
function ok(v,m){if(!v)throw new Error(m);}
ok(views.includes('fieldBlocks.join("\\n\\n")'),'campos admin não foram compactados');
ok(views.includes('paymentProviderSettings'),'tela de provedor ausente');
ok(views.includes('admin:payment:${def.key}-toggle'),'ativação dos provedores não está acessível');
ok(router.includes('const content = `❌ ${truncate(message, 1800)}`'),'erro textual ainda depende de emoji customizado');
ok(router.includes('admin:payment:efi-configure'),'rota de configuração Efí ausente');
ok(validator.includes('componentCount > 40'),'validação recursiva global ausente');
const {assertDiscordPayload}=require('../dist/discord/payload-validator.js');
const buttons=Array.from({length:39},(_,i)=>({type:2,custom_id:`b${i}`,label:'x',style:2}));
const rows=[]; for(let i=0;i<buttons.length;i+=5) rows.push({type:1,components:buttons.slice(i,i+5)});
let threw=false; try{assertDiscordPayload({flags:32768,components:[{type:17,components:rows}]},'overflow-test')}catch(e){threw=/40 componentes/.test(String(e.message))}
ok(threw,'payload >40 não foi bloqueado localmente');
console.log('R18.9.46 child regression: OK');
