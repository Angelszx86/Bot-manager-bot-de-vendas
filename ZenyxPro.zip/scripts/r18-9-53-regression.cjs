const fs=require('fs');
function r(f){return fs.readFileSync(f,'utf8')}function must(v,m){if(!v)throw new Error(m)}
const pkg=JSON.parse(r('package.json')); const commands=r('src/discord/commands.ts'); const router=r('src/discord/router.ts'); const views=r('src/discord/views.ts'); const voice=r('src/services/voice.ts'); const index=r('src/index.ts'); const db=r('src/core/json-db.ts');
must(pkg.version==='18.9.53','version');
must(pkg.dependencies['@discordjs/voice'],'voice dependency');
must(commands.includes('setName("comandos")'),'comandos slash');
must(views.includes('Conectar em call') && views.includes('setValue("voice")'),'voice nav');
must(router.includes('admin:voice:channel-set') && router.includes('voiceAdminView'),'voice handlers');
must(router.includes('await interaction.deferUpdate()'),'admin ACK');
must(voice.includes('joinVoiceChannel') && voice.includes('restoreConfigured'),'voice persistence');
must(index.includes('GatewayIntentBits.GuildVoiceStates') && index.includes('voice.restoreConfigured()'),'voice boot restore');
must(db.includes('voiceConnection'),'voice database schema');
console.log('Child R18.9.53 regression OK');
