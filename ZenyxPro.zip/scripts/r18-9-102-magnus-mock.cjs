'use strict';
const assert = require('node:assert/strict');
const { MagnusPayProvider } = require('../dist/payments/providers/magnus-pay.js');

(async () => {
  const originalFetch = global.fetch;
  const calls = [];
  global.fetch = async (url, options = {}) => {
    const body = options.body ? JSON.parse(options.body) : {};
    calls.push({ url: String(url), headers: options.headers || {}, body });
    if (calls.length === 1) {
      return new Response(JSON.stringify({ message: 'Dados incompletos' }), { status: 422, headers: { 'content-type': 'application/json' } });
    }
    return new Response(JSON.stringify({ data: { transactionId: 'TX-MOCK-102', status: 'pending' } }), { status: 200, headers: { 'content-type': 'application/json' } });
  };

  try {
    const provider = new MagnusPayProvider('mock-valid-key');
    const charge = await provider.createCharge({
      guildId: '123456789012345678',
      orderId: 'ORD-R18102',
      amountCents: 590,
      description: 'Checkout de teste',
      customer: { discordId: '123456789012345678', name: 'Cliente Discord', email: '', document: '' },
      expiresAt: new Date(Date.now() + 15 * 60_000).toISOString()
    });

    assert.equal(charge.externalId, 'TX-MOCK-102');
    assert.equal(calls.length, 2);
    assert.equal(calls[0].body.amount, 5.9);
    assert.equal(calls[0].body.value, 5.9);
    assert.equal(calls[0].body.amountCents, 590);
    assert.equal(calls[0].body.transactionId, 'ORD-R18102');
    assert.equal(calls[0].body.externalReference, 'ORD-R18102');
    assert.equal(calls[0].body.customer.discordId, '123456789012345678');
    assert.equal(calls[1].body.transactionId, 'ORD-R18102');
    console.log('R18.9.102 MagnusPay mock: OK');
  } finally {
    global.fetch = originalFetch;
  }
})().catch((error) => { console.error(error); process.exitCode = 1; });
