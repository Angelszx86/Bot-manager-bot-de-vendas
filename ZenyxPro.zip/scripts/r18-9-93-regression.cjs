const fs=require('fs'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..'); const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const router=read('src/discord/router.ts'), orders=read('src/services/orders.ts'), magnus=read('src/payments/providers/magnus-pay.ts'), payments=read('src/services/payments.ts');
assert(router.includes('if (settings.manualShortcutEnabled) {'));
assert(router.includes('if (id === "robux:search" || id === "robux:manual-quick")'));
assert(!router.includes('setLabel("Compra manual")'));
assert(!router.includes('modal("modal:robux-public:checkout-magnus"'));
assert(router.includes('provider: "MAGNUS_PAY"'));
assert(router.includes('"EVO_PAY", "MAGNUS_PAY", "IMAP_PIX"'));
assert(!orders.includes('["STRIPE", "MISTIC_PAY", "MAGNUS_PAY"].includes(provider)'));
assert(!magnus.includes('payerName,')); assert(!magnus.includes('payerDocument,'));
assert(payments.includes('validateMagnusApiKey'));
assert(router.includes('await this.payments.validateMagnusApiKey(token)'));
assert(router.includes('await this.payments.validateMagnusApiKey(apiKey)'));

(async()=>{
  const calls=[];
  global.fetch=async(url,init={})=>{
    const body=init.body?JSON.parse(init.body):{};
    calls.push({url:String(url),headers:init.headers||{},body});
    if(String(url).endsWith('/api/transactions/create')) return new Response(JSON.stringify({transactionId:'txn-93',transactionState:'PENDING',qrCode:'000201TEST'}),{status:200,headers:{'content-type':'application/json'}});
    if(String(url).endsWith('/api/transactions/check')) return new Response(JSON.stringify({transactionId:body.transactionId,transactionState:'PENDING'}),{status:200,headers:{'content-type':'application/json'}});
    throw new Error('unexpected url');
  };
  const {MagnusPayProvider}=require('../dist/payments/providers/magnus-pay.js');
  const provider=new MagnusPayProvider('valid-test-key-93');
  const charge=await provider.createCharge({guildId:'1',orderId:'ORD93',amountCents:999,description:'Teste',customer:{discordId:'1',name:'',email:'',document:''},expiresAt:new Date(Date.now()+900000).toISOString()});
  assert.equal(charge.externalId,'txn-93');
  assert.equal(calls[0].headers['X-API-Key'],'valid-test-key-93');
  assert.deepEqual(Object.keys(calls[0].body).sort(),['amount','description','expiresIn','externalId'].sort());
  assert.equal(await provider.test(),'MagnusPay autenticada e API Key validada');

  global.fetch=async()=>new Response(JSON.stringify({message:'not found'}),{status:404,headers:{'content-type':'application/json'}});
  const invalidLike=new MagnusPayProvider('random-anything-93');
  await assert.rejects(()=>invalidLike.test(),/Não foi possível validar a API Key MagnusPay/);
  console.log('R18.9.93 regression: OK');
})().catch((e)=>{console.error(e);process.exit(1)});
