 'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const pkg = JSON.parse(read('package.json'));
const router = read('src/discord/router.ts');
const views = read('src/discord/views.ts');
const types = read('src/types.ts');
const products = read('src/services/products.ts');
const db = read('src/core/json-db.ts');

assert.equal(pkg.version, '18.9.101');
assert.equal(pkg.zenyxBuild, 'R18.9.101');

// Tri-state de preço.
for (const token of ['simpleTicketPriceMode', '"FIXED" | "CUSTOMER" | "HIDDEN"']) {
  assert.ok(types.includes(token), `types sem ${token}`);
}
assert.match(products, /ticketPriceMode\(/);
assert.match(products, /ticketPriceVisible\(/);
assert.match(products, /setFieldTicketPriceMode\(/);
assert.match(db, /product\.simpleTicketPriceMode/);
assert.match(db, /field\.simpleTicketPriceMode/);

// Administração explícita: produto + override por item.
assert.match(views, /Preço fixo/);
assert.match(views, /Cliente informa/);
assert.match(views, /Ocultar preço/);
assert.match(views, /Herdar do produto/);
assert.match(router, /admin:product:simple-price-mode:/);
assert.match(router, /admin:product:field-price-mode:/);

// Vitrine: preço oculto não é colocado no select/publicação.
assert.match(views, /priceMode === "HIDDEN" \? ""/);
assert.match(views, /if \(priceMode === "FIXED"\) descriptionParts\.push\(formatMoney\(field\.priceCents\)\)/);
assert.match(views, /else if \(priceMode === "CUSTOMER"\) descriptionParts\.push\("valor informado no atendimento"\)/);

// Ticket simples/venda assistida migrados para Components V2.
const start = router.indexOf('private simpleProductTicketPayload');
const end = router.indexOf('private async refreshSimpleProductTicketMessage', start);
const payload = router.slice(start, end);
assert.ok(start > -1 && end > start);
assert.match(payload, /new ContainerBuilder\(\)/);
assert.match(payload, /new SectionBuilder\(\)/);
assert.match(payload, /new ThumbnailBuilder\(\)/);
assert.match(payload, /MessageFlags\.IsComponentsV2/);
assert.match(payload, /checkedDiscordPayload/);
assert.doesNotMatch(payload, /embeds:\s*\[/);

// Snapshot impede que o preço escondido reapareça no ticket aberto.
assert.match(router, /simpleProductPriceHidden:\s*!this\.products\.ticketPriceVisible\(product, field\)/);
assert.match(router, /ticket\.simpleProductPriceHidden/);

// Fechar ticket simples realmente tenta excluir o canal e possui fallback seguro.
const closeStart = router.indexOf('if (action === "close")');
const closeBlock = router.slice(closeStart, closeStart + 1800);
assert.match(closeBlock, /this\.tickets\.close\(ticket\.id, i\.user\.id\)/);
assert.match(closeBlock, /channel\.delete\(/);
assert.match(closeBlock, /mantendo-o bloqueado/);

// Correção R18.9.100 de ACK não regrediu.
assert.match(router, /if \(id\.startsWith\("admin:product:fields:"\)\)[\s\S]*?await i\.deferUpdate\(\);[\s\S]*?return i\.editReply\(this\.views\.productFieldsView/);

console.log('R18.9.101 regression: OK');
