const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');const ok=(v,m)=>{if(!v)throw new Error(m)};
const payments=read('src/services/payments.ts');
const robux=read('src/services/robux.ts');
const router=read('src/discord/router.ts');
const types=read('src/types.ts');
const methods=['MERCADO_PAGO','EFI_BANK','STRIPE','MISTIC_PAY','PURIN_CASH','IMAP_PIX','MANUAL_PIX'];
for(const method of methods){
  ok(payments.includes(`name === "${method}"`) || payments.includes(`"${method}"`),`Payment method ${method} missing`);
  ok(router.includes(`"${method}"`),`Robux router does not expose ${method}`);
}
for(const mode of ['MANUAL','ASSISTED','COOKIE_AUTO','WEBHOOK']){
  ok(robux.includes(`settings.deliveryMode === "${mode}"`) || robux.includes(`deliveryMode: "${mode}"`) || router.includes(`setValue("${mode}")`),`Delivery mode ${mode} missing`);
}
ok(router.includes('checkoutCreating'),'Checkout concurrency lock missing');
ok(router.includes('pendingOrderId'),'Checkout pending order reuse missing');
ok(router.includes('refreshRobuxOrderMessage'),'Order page recovery missing');
ok(robux.includes('paymentConfirmationRequestedAt'),'Manual payment confirmation tracking missing');
ok(robux.includes('sellerPaymentConfirmedAt'),'Seller confirmation tracking missing');
ok(robux.includes('deliverViaWebhook'),'Webhook delivery missing');
ok(robux.includes('deliverWithConfiguredAccount'),'Configured-account delivery missing');
ok(robux.includes('awaitingGamepassLink'),'Manual missing-gamepass recovery missing');
ok(robux.includes('handlePurchaseThreadMessage'),'Gamepass link recovery handler missing');
ok(robux.includes('cancelPending'),'Pending order cancel/back flow missing');
ok(robux.includes('retryDelivery'),'Delivery retry missing');
ok(robux.includes('markDelivered'),'Manual delivery confirmation missing');
// exact custom_id parsing sanity
for(const id of ['robux:seller-confirm-payment:RBX_TEST','robux:seller-auto-deliver:RBX_TEST','robux:seller-confirm-delivery:RBX_TEST']) ok(id.split(':')[2]==='RBX_TEST',`Unexpected custom id shape ${id}`);
console.log('R18_9_7_PAYMENT_DELIVERY_AUDIT_OK methods=7 deliveryModes=4');
