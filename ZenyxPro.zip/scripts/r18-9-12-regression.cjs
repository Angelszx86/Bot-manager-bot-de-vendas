const fs = require('node:fs');
const path = require('node:path');

function ok(value, message) {
  if (!value) throw new Error(message);
}
const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const robux = fs.readFileSync(path.join(root, 'src/services/robux.ts'), 'utf8');
const router = fs.readFileSync(path.join(root, 'src/discord/router.ts'), 'utf8');
const robuxDist = fs.readFileSync(path.join(root, 'dist/services/robux.js'), 'utf8');
const routerDist = fs.readFileSync(path.join(root, 'dist/discord/router.js'), 'utf8');

ok(pkg.version === '18.9.12', 'child version must be 18.9.12');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.12-gamepass-tax-flow', 'child build mismatch');

for (const [name, text] of [['robux src', robux], ['robux dist', robuxDist]]) {
  ok(text.includes('assertGamepassMatchesRequested'), `${name}: missing centralized Game Pass validation`);
  ok(text.includes('recommendedGamepassPrice'), `${name}: missing recommended Game Pass price helper`);
  ok(text.includes('taxa de 30%'), `${name}: missing Roblox fee guidance`);
  ok(text.includes('parece uma quantidade/preço'), `${name}: numeric-only text can still be accepted as a username`);
  ok(!text.includes('Math.abs(estimated - order.requestedRobux) > 1'), `${name}: legacy net tolerance validation still present`);
}
for (const [name, text] of [['router src', router], ['router dist', routerDist]]) {
  ok(text.includes('crie ou ajuste sua Game Pass para'), `${name}: delivery page does not show the required Game Pass price`);
  ok(text.includes('assertGamepassMatchesRequested'), `${name}: manual reference URL bypasses centralized validation`);
  ok(!text.includes('A Game Pass informada entrega cerca de'), `${name}: legacy misleading Game Pass error still present`);
}

const requested = 500;
const recommended = Math.ceil(requested / 0.7);
const net = Math.floor(recommended * 0.7);
ok(recommended === 715, `500 Robux must recommend a 715 Robux Game Pass, got ${recommended}`);
ok(net === requested, `715 Robux Game Pass must estimate 500 net, got ${net}`);
ok(Math.floor(500 * 0.7) === 350, '500 Robux Game Pass fee example must estimate 350 net');

console.log('R18.9.12 child regression OK');
