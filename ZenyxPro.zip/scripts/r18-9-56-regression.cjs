const fs=require('fs');const path=require('path');const root=path.join(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');function must(x,m){if(!x){console.error('FAIL:',m);process.exitCode=1}else console.log('PASS:',m)}
const pkg=JSON.parse(read('package.json'));const views=read('src/discord/views.ts');const em=read('src/emojis/manager.ts');const voice=read('src/services/voice.ts');const router=read('src/discord/router.ts');const pay=read('src/services/payments.ts');const types=read('src/types.ts');const db=read('src/core/json-db.ts');const idx=read('src/index.ts');
must(pkg.version==='18.9.56','child version 18.9.56');
const nav=views.indexOf('.setCustomId("admin:navigate")');const vv=views.indexOf('.setLabel("Conectar em call")',nav);const cc=views.indexOf('.setLabel("Comandos")',nav);const ord=views.indexOf('.setLabel("Pedidos")',nav);must(nav>=0&&vv>nav&&cc>vv&&ord>cc,'voice and commands stay at start of navigation');
const row=views.indexOf('this.button(guildId, "admin:voice"');must(row>=0&&views.indexOf('this.button(guildId, "admin:commands"',row)>row&&views.indexOf('this.button(guildId, "admin:products"',row)>views.indexOf('this.button(guildId, "admin:commands"',row),'voice/commands are first panel buttons');
must(em.includes('"delivery_bolt", "loading", "voice", "commands"'),'voice/commands are force-refreshed critical emojis');
must(voice.includes('handleVoiceStateUpdate')&&voice.includes('VoiceConnectionStatus.Ready, 12_000')&&voice.includes('connection.rejoin?.()'),'voice service has state monitor and resume/rejoin path');
must(idx.includes('Events.VoiceStateUpdate')&&idx.indexOf('voice.restoreConfigured()')<idx.indexOf('emojis.syncAutomatic()'),'voice restores before emoji sync and monitors discord state');
must(types.includes('manualPixEnabled: boolean')&&db.includes('manualPixEnabled: true'),'manual pix toggle persisted with backward-compatible default');
must(pay.includes('s.manualPixEnabled !== false'),'disabled manual pix is removed from enabled methods');
must(views.includes('admin:payment:manual-toggle')&&router.includes('admin:payment:manual-toggle'),'manual pix toggle exists in UI and router');
if(process.exitCode)process.exit(process.exitCode);else console.log('R18.9.56 child regression OK');
