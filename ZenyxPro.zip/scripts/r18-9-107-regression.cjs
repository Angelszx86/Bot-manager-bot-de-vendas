const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const router = fs.readFileSync(path.join(root, 'src/discord/router.ts'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
function must(ok, msg){ if(!ok){ console.error('FAIL:', msg); process.exit(1); } console.log('OK:', msg); }
must(pkg.version === '18.9.107', 'versão 18.9.107');
must(router.includes('.setLabel("Valor")'), 'ticket possui botão Valor');
must(!router.includes('setLabel(staffPricePending ? "Definir valor" : "Alterar valor")'), 'rótulo antigo removido');
must(router.includes('via: "VALUE_BUTTON"'), 'override por atendimento auditado');
must(router.includes('ticket.simpleProductPriceMode = "STAFF"'), 'valor do vendedor vira snapshot STAFF do ticket');
must(router.includes('ticket.simpleProductPixSentAt = ""'), 'PIX antigo é invalidado ao alterar valor');
must(router.includes('await this.sendSimpleProductPix(ticket, i.user.id, true);'), 'PIX é regenerado após definir valor');
must(router.includes('product.simplePixQrEnabled ? " com QR Code" : ""'), 'feedback respeita QR habilitado');
must(!router.includes('O PIX já foi enviado; o valor não pode mais ser alterado.'), 'valor pode ser corrigido antes da confirmação');
console.log('R18.9.107 regression PASS');
