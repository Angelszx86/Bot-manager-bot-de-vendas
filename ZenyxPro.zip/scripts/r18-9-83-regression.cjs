const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const must=(x,m)=>{if(!x)throw new Error(m)};
const router=read('src/discord/router.ts');
const views=read('src/discord/views.ts');
const db=read('src/core/json-db.ts');
const giveaways=read('src/services/giveaways.ts');
const types=read('src/types.ts');
const pkg=JSON.parse(read('package.json'));
must(pkg.version==='18.9.83' && pkg.zenyxBuild==='R18.9.83','versão child incorreta');
for (const marker of [
  'admin:stock:(?:add|ghost)',
  'admin:message:(?:basic|visual|link-add)',
  'admin:ticket:(?:field-add|field-edit|option-edit',
  'admin:payment:(?:mp-configure|efi-configure',
  'admin:giveaway:configure:'
]) must(router.includes(marker),`cobertura modal ausente: ${marker}`);
must(router.includes('id === "admin:giveaway:channel-set"'),'sorteio sem channel select');
must(router.includes('id === "robux:search" || id === "robux:buy"'),'atalho de busca Robux ausente');
must(router.includes('.setButtonAccessory(search)'),'lupa Robux não está no topo');
must(router.includes('new MediaGalleryItemBuilder().setURL(banner).setDescription("Loja de Robux")'),'banner Robux não está em MediaGallery');
must(views.includes('"admin:wallet", "Zwallet"') && views.includes('"admin:automations", "Automações"') && views.includes('"admin:messages", "Mensagens"') && views.includes('"admin:channels", "Canais"'),'segunda linha do painel incompleta');
must(giveaways.includes('giveaway:leave:') && giveaways.includes('leave(id: string, userId: string)'),'botão sair do sorteio ausente');
must(giveaways.includes('winnerDmPrize') && types.includes('winnerDmPrize?: string'),'entrega automática DM do sorteio ausente');
must(!db.includes('footer: "Automação completa para Discord"'),'rodapé legado ainda é padrão');
must(router.includes('hasValidPanelBanner'),'fallback do banner da central ausente');
console.log('R18.9.83 regression: PASS');
