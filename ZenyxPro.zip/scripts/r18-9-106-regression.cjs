'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

(async () => {
  const providerSource = read('src/payments/providers/magnus-pay.ts');
  const routerSource = read('src/discord/router.ts');
  const viewsSource = read('src/discord/views.ts');
  const dbSource = read('src/core/json-db.ts');

  assert.match(providerSource, /\/api\/v1\/pagamentos/);
  assert.doesNotMatch(providerSource, /\/api\/transactions\/create/);
  assert.doesNotMatch(providerSource, /\/api\/transactions\/check/);
  assert.match(providerSource, /"X-API-Key"/);
  assert.match(viewsSource, /POST \/api\/v1\/pagamentos/);
  assert.match(viewsSource, /GET \/api\/v1\/pagamentos\/\{id\}/);
  assert.match(dbSource, /createPath: "\/api\/v1\/pagamentos"/);
  assert.match(dbSource, /statusPath: "\/api\/v1\/pagamentos\/\{id\}"/);

  assert.match(routerSource, /product-ticket:name:/);
  assert.match(routerSource, /product-ticket:name-modal:/);
  assert.match(routerSource, /isAssistedSaleSeller\(member, ticket\)/);
  assert.match(routerSource, /isAssistedSaleConfirmer\(member, ticket\)/);
  assert.match(routerSource, /Somente o responsável\/dono ou um cargo autorizado de confirmação/);
  assert.match(routerSource, /product\.simplePixKeyVisible/);
  assert.match(routerSource, /product\.simplePixQrEnabled/);
  assert.match(routerSource, /files: \[new AttachmentBuilder\(image/);
  assert.match(routerSource, /embeds: \[buildEmbed\(\)\]/);

  const { MagnusPayProvider } = require('../dist/payments/providers/magnus-pay.js');
  const originalFetch = global.fetch;
  const calls = [];
  global.fetch = async (url, options = {}) => {
    const u = String(url);
    const headers = new Headers(options.headers || {});
    calls.push({ url: u, method: options.method || 'GET', headers, body: options.body ? JSON.parse(String(options.body)) : undefined });
    assert.equal(headers.get('X-API-Key'), 'magnus-valid-key');

    if (u === 'https://magnuspay.onrender.com/api/v1/pagamentos' && (options.method || 'GET') === 'POST') {
      const body = JSON.parse(String(options.body));
      assert.deepEqual(Object.keys(body).sort(), ['amount', 'description']);
      assert.equal(body.amount, 5.9);
      assert.equal(body.description, 'Pedido Magnus R18.9.106');
      return Response.json({ pixId: 'PIX-106', pixCode: '000201MAGNUS106', qrCode: 'data:image/png;base64,QUJDRA==', status: 'pending' });
    }
    if (u === 'https://magnuspay.onrender.com/api/v1/pagamentos/PIX-106' && (options.method || 'GET') === 'GET') {
      return Response.json({ pixId: 'PIX-106', pixCode: '000201MAGNUS106', status: 'paid' });
    }
    if (u === 'https://magnuspay.onrender.com/api/v1/pagamentos' && (options.method || 'GET') === 'GET') {
      return Response.json({ data: [] });
    }
    throw new Error(`URL inesperada: ${u}`);
  };

  try {
    const provider = new MagnusPayProvider('magnus-valid-key');
    const charge = await provider.createCharge({
      guildId: '123456789012345678',
      orderId: 'ORD-106',
      amountCents: 590,
      description: 'Pedido Magnus R18.9.106',
      customer: { discordId: '223456789012345678', name: 'Cliente', email: '', document: '' },
      expiresAt: new Date(Date.now() + 15 * 60_000).toISOString()
    });
    assert.equal(charge.externalId, 'PIX-106');
    assert.equal(charge.pixCode, '000201MAGNUS106');
    assert.match(charge.qrCodeDataUrl || '', /^data:image\/png;base64,/);

    const status = await provider.getCharge('PIX-106');
    assert.equal(status.status, 'paid');
    assert.equal(await provider.test(), 'MagnusPay autenticada • API Key aceita pela API oficial');
    assert.equal(calls.length, 3);
  } finally {
    global.fetch = originalFetch;
  }

  console.log('R18.9.106_OK: MagnusPay oficial + permissões venda assistida + nome/preço no ticket + PIX granular + recibo imagem+embed');
})().catch((error) => { console.error(error); process.exitCode = 1; });
