'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const router = read('src/discord/router.ts');
const pkg = JSON.parse(read('package.json'));

assert.equal(pkg.version, '18.9.108');
assert.match(router, /const ticketId = parts\[parts\.length - 1\] \|\| "";/, 'modal usa último segmento do customId');
assert.match(router, /resolveSimpleProductTicket\(gid, ticketId, i\.channelId\)/, 'modal/botão usa resolvedor robusto');
assert.match(router, /ticket\.channelId === channel/, 'resolvedor possui fallback pelo canal atual');
assert.match(router, /\(mode === "STAFF" \|\| mode === "HIDDEN"\) && ticket\.simpleProductPriceSource !== "STAFF"/, 'HIDDEN/STAFF aguardam preço do vendedor');
assert.match(router, /!this\.simpleProductNeedsSellerPrice\(ticket, product, field\)/, 'PIX automático é bloqueado enquanto falta preço da equipe');
assert.match(router, /await this\.sendSimpleProductPix\(ticket, i\.user\.id, true\);/, 'PIX é gerado após salvar valor');
console.log('R18.9.108_OK: modal Valor robusto + PIX/QR somente após valor do vendedor em STAFF/HIDDEN');
