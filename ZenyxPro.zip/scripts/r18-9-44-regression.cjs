const fs=require('fs');
function ok(v,m){if(!v)throw new Error(m)}
const src=fs.readFileSync('src/services/orders.ts','utf8');
ok(/Seu produto foi entregue!/.test(src),'recibo precisa do novo título');
ok(/Conteúdo entregue/.test(src),'recibo precisa mostrar conteúdo entregue');
ok(/Copiar conteúdo/.test(src),'entrega única precisa de botão de cópia claro');
ok(/Mensagem da loja/.test(src),'mensagem personalizada precisa ser preservada');
ok(/brand\.showAccentColors\) embed\.setColor\(colorNumber\(brand\.color\)\)/.test(src),'cor lateral deve continuar opt-in');
ok(!/setColor\(0x22c55e\)/.test(src.slice(src.indexOf('private deliveryReceipt'),src.indexOf('private buildDeliveryRows'))),'recibo não pode forçar verde');
console.log('R18.9.44 child regression OK');
