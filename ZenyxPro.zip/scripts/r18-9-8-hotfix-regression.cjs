const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const ok = (c, m) => { if (!c) throw new Error(m); };
const router = read('src/discord/router.ts');

ok(router.includes('private robuxSellerOrderId('), 'Seller order-id parser helper missing');
ok(router.includes('customId.slice(prefix.length).trim()'), 'Seller order-id parser must use prefix slicing');
ok(router.includes('this.robuxSellerOrderId(id, "confirm-payment")'), 'Confirm PIX seller route must use safe order parser');
ok(router.includes('this.robuxSellerOrderId(id, "auto-deliver")'), 'Auto-delivery seller route must use safe order parser');
ok(router.includes('this.robuxSellerOrderId(id, "confirm-delivery")'), 'Delivery confirmation seller route must use safe order parser');
ok(!router.includes('const orderId = id.split(":")[3];\n      if (!orderId) return i.reply({ content: "Pedido Robux inválido."'), 'Legacy seller split parser must be gone');

ok(router.includes('attachment://robux-pix.png'), 'Checkout must render PIX QR through Components V2 Media Gallery');
ok(router.includes('new MediaGalleryBuilder()'), 'PIX QR Media Gallery builder missing');
ok(router.includes('robuxCheckoutPayload(order.guildId, order.discordUserId, order, false)'), 'QR fallback must rebuild checkout without media attachment');
ok(router.includes('QR Code PIX\\nPedido **${order.id}**'), 'Plain-attachment QR recovery message missing');

ok(router.includes('return this.robuxContainer(guildId, `${this.emojis.text("robux", guildId)} Central Robux`'), 'Robux admin main page must be native Components V2');
ok(router.includes('const alreadyV2 = (flags & Number(MessageFlags.IsComponentsV2))'), 'Admin navigation must preserve already-native Components V2 payloads');

console.log('R18_9_8_HOTFIX_REGRESSION_OK');
