const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');const ok=(c,m)=>{if(!c)throw new Error(m)};
const r=read('src/discord/router.ts');
const t=read('src/services/tickets.ts');
const idx=read('src/index.ts');
ok(r.includes('const [, , , panelId, optionId] = id.split(":");'),'ticket route split fix missing');
ok(r.includes('admin:ticket:option-category-set:${panelId}:${optionId}'),'ticket category custom id missing');
ok(r.includes('admin:ticket:option-roles-set:${panelId}:${optionId}'),'ticket role custom id missing');
ok(!r.includes('const [, , , , panelId, optionId] = id.split(":");'),'old off-by-one ticket split still present');
ok(t.includes('reconcileOpenTickets'),'stale ticket reconciliation missing');
ok(t.includes('handleChannelDelete'),'channel deletion reconciliation missing');
ok(t.includes('Nada ficou preso no limite de tickets'),'ticket rollback protection missing');
ok(t.includes('guild.members.fetchMe()'),'bot membership guard missing');
ok(idx.includes('Events.GuildDelete'),'guild removal reconciliation missing');
ok(idx.includes('Events.GuildCreate'),'guild re-add command restore missing');
ok(idx.includes('Comandos restaurados após a aplicação voltar'),'command restoration log missing');
const publicFiles=['src/core/json-db.ts','src/discord/commands.ts','src/discord/router.ts','src/discord/views.ts','src/index.ts','src/services/automations.ts','src/services/payments.ts','src/services/robux.ts','src/services/robux-image.ts','src/services/server-backups.ts','src/services/tickets.ts'];
for(const f of publicFiles){const s=read(f);ok(!/Zenyx Sallers/.test(s),`legacy hosted-bot branding still visible in ${f}`)}
console.log('R18_9_5_CHILD_REGRESSION_OK');
