const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { EmbedBuilder } = require('discord.js');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

(async () => {
  // Reproduz a causa real do erro do Discord.js: footer vazio é inválido.
  assert.throws(() => new EmbedBuilder().setFooter({ text: '' }), /Received one or more errors/);

  const router = read('src/discord/router.ts');
  const views = read('src/discord/views.ts');
  const payments = read('src/services/payments.ts');
  const orders = read('src/services/orders.ts');
  const providerSource = read('src/payments/providers/magnus-pay.ts');

  assert.match(router, /const footer = String\(b\.footer \|\| ""\)\.trim\(\);/);
  assert.match(router, /if \(footer\) embed\.setFooter/);
  assert.doesNotMatch(router, /\.setFooter\(\{ text: b\.footer \}\)/);

  assert.match(router, /MagnusPay • API Key/);
  assert.match(router, /input\("token", "API Key"/);
  assert.match(views, /Agora você configura somente a \*\*API Key\*\*/);
  assert.match(payments, /new MagnusPayProvider\(\s*this\.db\.getSecret\("magnus_token", guildId\) \?\? ""\s*\)/);
  assert.match(orders, /\["STRIPE", "MISTIC_PAY", "MAGNUS_PAY"\]/);
  assert.match(providerSource, /"X-API-Key"/);
  assert.match(providerSource, /\/api\/transactions\/create/);
  assert.match(providerSource, /\/api\/transactions\/check/);

  const calls = [];
  global.fetch = async (url, init = {}) => {
    const body = init.body ? JSON.parse(init.body) : undefined;
    calls.push({ url: String(url), method: init.method || 'GET', headers: init.headers || {}, body });
    if (String(url).endsWith('/api/transactions/create')) {
      return new Response(JSON.stringify({
        transactionId: 'txn-create-91',
        transactionState: 'PENDING',
        qrCodeBase64: 'A'.repeat(120),
        externalId: body.externalId
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    if (String(url).endsWith('/api/transactions/check')) {
      return new Response(JSON.stringify({
        transactionId: body.transactionId,
        transactionState: 'COMPLETED',
        qrCodeBase64: 'A'.repeat(120)
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    throw new Error(`URL inesperada: ${url}`);
  };

  const { MagnusPayProvider } = require('../dist/payments/providers/magnus-pay.js');
  const provider = new MagnusPayProvider('test-api-key-123456');
  const charge = await provider.createCharge({
    guildId: '123456789012345678',
    orderId: 'ORD-R18991',
    amountCents: 1234,
    description: 'Teste MagnusPay R18.9.91',
    customer: {
      discordId: '123456789012345678',
      name: 'Cliente Teste',
      email: 'cliente@example.invalid',
      document: '12345678901'
    },
    expiresAt: new Date(Date.now() + 15 * 60_000).toISOString()
  });
  assert.equal(charge.externalId, 'txn-create-91');
  assert.equal(charge.status, 'pending');

  const createCall = calls[0];
  assert.equal(createCall.url, 'https://magnuspay.onrender.com/api/transactions/create');
  assert.equal(createCall.method, 'POST');
  assert.equal(createCall.headers['X-API-Key'], 'test-api-key-123456');
  assert.deepEqual(Object.keys(createCall.body).sort(), ['amount','description','expiresIn','externalId','payerDocument','payerName'].sort());
  assert.equal(createCall.body.amount, 12.34);
  assert.equal(createCall.body.payerName, 'Cliente Teste');
  assert.equal(createCall.body.payerDocument, '12345678901');
  assert.equal(createCall.body.externalId, 'ORD-R18991');

  const checked = await provider.getCharge('txn-create-91');
  assert.equal(checked.status, 'paid');
  const checkCall = calls[1];
  assert.equal(checkCall.url, 'https://magnuspay.onrender.com/api/transactions/check');
  assert.equal(checkCall.method, 'POST');
  assert.deepEqual(checkCall.body, { transactionId: 'txn-create-91' });

  console.log('R18.9.91 regression: OK');
})();
