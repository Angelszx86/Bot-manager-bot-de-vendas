const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { InteractionRouter } = require('../dist/discord/router.js');

(async () => {
  let updateCalls = 0;
  let deferUpdateCalls = 0;
  let messageEditCalls = 0;
  let captured;
  const fakeViews = {
    adminPageEdit(guildId, payload, hasDefaultBanner) {
      assert.equal(guildId, '123456789012345678');
      assert.equal(hasDefaultBanner, true);
      assert.equal(payload.marker, 'screen');
      return { flags: 32768, components: [{ type: 17, components: [{ type: 10, content: 'ok' }] }] };
    }
  };
  const interaction = {
    message: {
      flags: { has: flag => flag === 32768 },
      attachments: { some: fn => fn({ name: 'panel-banner.png' }) },
      edit: async () => { messageEditCalls++; }
    },
    update: async payload => { updateCalls++; captured = payload; return payload; },
    editReply: async payload => payload,
    deferUpdate: async () => { deferUpdateCalls++; }
  };

  const wrapped = InteractionRouter.prototype.adminInteraction.call({ views: fakeViews }, interaction, '123456789012345678');
  await wrapped.update({ marker: 'screen' });
  assert.equal(updateCalls, 1, 'admin V2 wrapper must call interaction.update exactly once');
  assert.equal(deferUpdateCalls, 0, 'admin wrapper must not deferUpdate before UPDATE_MESSAGE');
  assert.equal(messageEditCalls, 0, 'admin wrapper must not call message.edit');
  assert.equal(captured.flags, 32768, 'admin V2 update must preserve IsComponentsV2 flag');
  assert.equal(captured.embeds, undefined, 'admin V2 update cannot contain legacy embeds');
  assert.equal(captured.components[0].type, 17, 'admin V2 update remains Components V2');

  let legacyCaptured;
  const legacy = {
    message: {
      flags: { has: () => false },
      attachments: { some: () => false }
    },
    update: async payload => { legacyCaptured = payload; return payload; },
    editReply: async payload => payload
  };
  const legacyWrapped = InteractionRouter.prototype.adminInteraction.call({ views: fakeViews }, legacy, '123456789012345678');
  await legacyWrapped.update({ marker: 'legacy', embeds: [{ title: 'Produto' }], components: [{ type: 1, components: [] }] });
  assert.equal(legacyCaptured.flags, undefined, 'legacy admin messages must not be forced into Components V2');
  assert.deepEqual(legacyCaptured.embeds, [{ title: 'Produto' }], 'legacy embeds must survive legacy navigation');

  const routerSource = fs.readFileSync(path.join(__dirname, '../dist/discord/router.js'), 'utf8');
  assert.match(routerSource, /sourceIsV2[\s\S]{0,500}?views\.adminPageEdit/, 'wrapper must branch based on source message format');

  const viewsSource = fs.readFileSync(path.join(__dirname, '../dist/discord/views.js'), 'utf8');
  assert.match(viewsSource, /setLabel\("Robux"\)[\s\S]{0,500}?setValue\("robux"\)[\s\S]{0,500}?component\("robux", guildId\)/,
    'Robux navigation option must use robux semantic');
  assert.match(viewsSource, /this\.button\(guildId, "admin:robux", "Robux", "robux"/,
    'Robux top-level button must use robux semantic');

  const emojiSource = fs.readFileSync(path.join(__dirname, '../dist/emojis/manager.js'), 'utf8');
  assert.match(emojiSource, /\["brand_robot", "brand_crown", "robux", "robux_buy", "robux_calc"\]/,
    'Robux assets must be in the critical emoji set');
  assert.match(emojiSource, /attempt <= 3/,
    'critical emoji installation must retry transient failures');

  const pkg = require('../package.json');
  assert.equal(pkg.version, '18.4.0');
  console.log('R18 regression: navegação híbrida V2/legacy validada e emojis Robux preservados.');
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
