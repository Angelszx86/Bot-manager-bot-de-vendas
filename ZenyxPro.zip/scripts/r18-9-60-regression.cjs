const fs=require('fs');const path=require('path');const root=path.resolve(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');let p=0,f=0;const ok=(c,m)=>{if(c){console.log('✓',m);p++;}else{console.error('✗',m);f++;}};
const pkg=JSON.parse(read('package.json'));ok(pkg.version==='18.9.60','child 18.9.60');
const router=read('src/discord/router.ts');ok(router.includes('adminLoadingPayload')&&router.includes('acknowledgeAdminLoading'),'loading visual V2 presente');ok(router.includes('property === "deferUpdate"')&&router.includes('property === "deferReply"'),'ACK administrativo idempotente');ok(router.includes('admin:payment:magnus')&&router.includes('modal:payment:magnus'),'configuração Magnus presente');
const payments=read('src/services/payments.ts');ok(payments.includes('MAGNUS_PAY')&&payments.includes('magnusManagerEnabled'),'MagnusPay respeita trava do Manager');
const orders=read('src/services/orders.ts');ok(orders.includes('Compra concluída • entrega disponível')&&orders.includes('brand.bannerUrl'),'recibo de entrega modernizado');
const voice=read('src/services/voice.ts');ok(voice.includes('desiredTargets')&&voice.includes('scheduleReconnect'),'voz mantém destino e reconexão');
console.log(`\nR18.9.60 child regression: ${p} passed / ${f} failed`);if(f)process.exit(1);
