const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const must = (value, message) => { if (!value) throw new Error(message); };

const pkg = JSON.parse(read('package.json'));
const types = read('src/types.ts');
const db = read('src/core/json-db.ts');
const views = read('src/discord/views.ts');
const router = read('src/discord/router.ts');
const orders = read('src/services/orders.ts');
const products = read('src/services/products.ts');
const payments = read('src/services/payments.ts');
const robux = read('src/services/robux.ts');
const emojiManager = read('src/emojis/manager.ts');
const evo = read('src/payments/providers/evopay.ts');
const manifest = JSON.parse(read('assets/emojis/manifest.json'));

must(Number(pkg.version.split('.')[2]) >= 30, 'child version older than R18.9.30');
must(String(pkg.zenyxBuild || '').includes('r18.9.'), 'child build id missing');

// Produto / vitrine
must(views.includes('MessageFlags.IsComponentsV2'), 'Components V2 ausente');
must(views.includes('new MediaGalleryBuilder()') && views.includes('new ContainerBuilder()'), 'vitrine V2 sem banner/container');
must(views.includes('fields.length > 1') && views.includes('product:field-select:'), 'select para múltiplas opções ausente');
must(views.includes('product:buy:') && views.includes('Comprar agora'), 'botão para opção única ausente');
must(views.includes('A vitrine pública não anuncia “entrega manual”'), 'regra de omissão de entrega manual ausente');
must(!/publicProduct\([\s\S]{0,5000}ENTREGA MANUAL/.test(views), 'publicProduct ainda anuncia entrega manual');
must(views.includes('delivery_bolt') && views.includes('Array.from({ length: 7 }'), 'faixa de entrega automática incompleta');
must(Array.from({ length: 7 }, (_, i) => `entrega${i}`).every((semantic) => manifest.some((e) => e.semantic === semantic)), 'assets entrega0..entrega6 incompletos');

// Emojis
must(manifest.some((e) => e.semantic === 'delivery_bolt'), 'delivery_bolt ausente do manifest');
must(manifest.some((e) => e.semantic === 'loading'), 'loading ausente do manifest');
must(manifest.length === 205, `esperado 205 emojis, encontrado ${manifest.length}`);
must(emojiManager.includes('delivery_bolt') && emojiManager.includes('loading'), 'EmojiManager não conhece novos semantics');

// Checkout / interação
must(router.includes('Preparando sua compra privada'), 'loading inicial do checkout ausente');
must(router.includes('i.guild.channels.cache.get(cart.channelId) ?? await i.guild.channels.fetch(cart.channelId)'), 'fast path do carrinho ausente');
must(router.includes('Ações da equipe'), 'controles protegidos de staff ausentes');
must(router.includes('requirePermission') || router.includes('PAYMENTS'), 'permissão de pagamentos não encontrada');

// Entrega / idempotência
for (const key of ['fulfilledItemKeys', 'fulfillmentCompletedAt', 'deliveryNotificationSentAt', 'deliveryNotificationPageIds', 'profileAccountingAppliedAt', 'manualDeliveryCompletedAt']) {
  must(types.includes(key), `campo idempotente ausente: ${key}`);
}
must(orders.includes('fulfillmentLocks'), 'lock de fulfillment ausente');
must(orders.includes('consumedContentsForOrder'), 'recuperação de estoque consumido ausente');
must(products.includes('consumedContentsForOrder'), 'ProductService não recupera estoque consumido');
must(orders.includes('Checkpoint por item'), 'checkpoint de entrega por item ausente');
must(orders.includes('deliveryNotificationPageIds'), 'checkpoint de páginas de DM ausente');
must(orders.includes('status = manual ? "AWAITING_DELIVERY" : "DELIVERED"'), 'estado manual/automático incorreto');

// EvoPay no filho
must(types.includes('"EVO_PAY"'), 'EVO_PAY ausente de PaymentProviderName');
must(db.includes('evoPay: { enabled: false, expiresIn: 900 }'), 'default EvoPay ausente');
must(payments.includes('new EvoPayProvider'), 'PaymentManager não instancia EvoPay');
must(payments.includes('evopay_token'), 'credencial EvoPay não usa secret store');
must(evo.includes('https://api.evopay.cash/v1'), 'base URL EvoPay incorreta');
must(evo.includes('method: "POST"') && evo.includes('/pix/'), 'criação PIX EvoPay ausente');
must(evo.includes('COMPLETED') && evo.includes('Authorization: `Bearer'), 'status/auth EvoPay ausentes');
must(robux.includes('"EVO_PAY"'), 'Robux não aceita EvoPay');
must(!views.includes('${this.db.getSecret(\"evopay_token\"'), 'token EvoPay foi interpolado em view');

// ZCloud / reação automática
must(router.includes('admin:zcloud:emoji-remove') && router.includes('buttonEmoji:"__none__"'), 'remoção visual de emoji ZCloud ausente');
must(router.includes('admin:automations:reaction-emoji-set:') && router.includes('slice(safePage * 25'), 'picker paginado de Guild Emoji ausente');
must(router.includes('reaction-emoji-search'), 'pesquisa por nome de emoji ausente');
must(!router.includes('ID do emoji personalizado'), 'UX antiga de ID manual ainda presente no router');

console.log('R18_9_30_CHILD_REGRESSION_OK');
