DISPLAY_NAME=Aplicação hospedada
DESCRIPTION=Aplicação hospedada com produtos, carrinho, pagamentos, tickets configuráveis, entrega automática e banco JSON por servidor
MAIN=dist/index.js
RUNTIME=nodejs
MEMORY=512
VERSION=recommended
AUTORESTART=true
