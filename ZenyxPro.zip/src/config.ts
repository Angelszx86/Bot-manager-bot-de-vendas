import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import type { AppConfig } from "./types.js";

const DISCORD_ID = /^\d{15,22}$/;
const TOKEN_PLACEHOLDERS = new Set([
  "",
  "token-bot",
  "seu_token_aqui",
  "cole_o_token_do_bot",
  "cole_o_token_do_bot_aqui",
  "changeme"
]);

interface TokenFile { token?: unknown; }
interface RuntimeFile {
  clientId?: unknown;
  guildId?: unknown;
  ownerIds?: unknown;
  databasePath?: unknown;
  autoInstallEmojis?: unknown;
  emojiInstallLimit?: unknown;
  privilegedIntents?: unknown;
  logLevel?: unknown;
  zcloudPort?: unknown;
  zcloudEdgeBaseUrl?: unknown;
  zcloudCloudflaredPath?: unknown;
  zcloudTunnelAuto?: unknown;
  zcloudManagerEnabled?: unknown;
  walletManagerEnabled?: unknown;
  magnusManagerEnabled?: unknown;
}

const text = (value: unknown): string => String(value ?? "").trim();

function ensureJsonFile(path: string, initialValue: unknown): void {
  if (existsSync(path)) return;
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, `${JSON.stringify(initialValue, null, 2)}\n`, "utf8");
}

function readJson<T>(path: string, label: string): T {
  try {
    return JSON.parse(readFileSync(path, "utf8")) as T;
  } catch (error) {
    throw new Error(`${label} não pôde ser lido como JSON válido: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export function isUsableToken(value: unknown): value is string {
  const token = text(value);
  return token.length >= 20 && !TOKEN_PLACEHOLDERS.has(token.toLowerCase());
}

export function loadConfig(projectRoot = process.cwd()): AppConfig {
  const tokenPath = resolve(projectRoot, "Token.json");
  const runtimePath = resolve(projectRoot, "config/runtime.json");

  ensureJsonFile(tokenPath, { token: "" });
  ensureJsonFile(runtimePath, {
    clientId: "",
    guildId: "",
    ownerIds: [],
    databasePath: "database",
    autoInstallEmojis: true,
    emojiInstallLimit: 0,
    privilegedIntents: false,
    logLevel: "info",
    zcloudPort: 3000,
    zcloudEdgeBaseUrl: "",
    zcloudCloudflaredPath: "",
    zcloudTunnelAuto: false,
    zcloudManagerEnabled: true,
    walletManagerEnabled: true,
    magnusManagerEnabled: true
  });

  const tokenFile = readJson<TokenFile>(tokenPath, "Token.json");
  if (!isUsableToken(tokenFile.token)) {
    throw new Error("Token.json está sem um token válido. Preencha apenas o campo token e reinicie o bot.");
  }

  const runtime = readJson<RuntimeFile>(runtimePath, "config/runtime.json");
  const ownerIds = Array.isArray(runtime.ownerIds)
    ? [...new Set(runtime.ownerIds.map(text).filter((id) => DISCORD_ID.test(id)))]
    : [];
  const rawLimit = Number(runtime.emojiInstallLimit ?? 0);
  const databasePath = text(runtime.databasePath) || "database";

  return {
    botToken: text(tokenFile.token),
    clientId: DISCORD_ID.test(text(runtime.clientId)) ? text(runtime.clientId) : undefined,
    guildId: DISCORD_ID.test(text(runtime.guildId)) ? text(runtime.guildId) : undefined,
    ownerIds,
    databasePath,
    autoInstallEmojis: runtime.autoInstallEmojis !== false,
    emojiInstallLimit: Number.isFinite(rawLimit) && rawLimit >= 0 ? Math.trunc(rawLimit) : 0,
    privilegedIntents: runtime.privilegedIntents === true,
    logLevel: text(runtime.logLevel) || "info",
    zcloudPort: Number.isFinite(Number(runtime.zcloudPort)) ? Math.max(1, Math.min(65535, Math.trunc(Number(runtime.zcloudPort)))) : 3000,
    zcloudEdgeBaseUrl: text(runtime.zcloudEdgeBaseUrl),
    zcloudCloudflaredPath: text(runtime.zcloudCloudflaredPath),
    zcloudTunnelAuto: runtime.zcloudTunnelAuto === true,
    zcloudManagerEnabled: runtime.zcloudManagerEnabled !== false,
    walletManagerEnabled: runtime.walletManagerEnabled !== false,
    magnusManagerEnabled: runtime.magnusManagerEnabled !== false
  };
}
