import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { Client, Guild, GuildMember, Invite, PartialGuildMember } from "discord.js";
import type { Logger } from "../core/logger.js";
import { nowIso } from "../core/utils.js";

type InviteSettings = {
  enabled: boolean;
  channelId: string;
  message: string;
  trackLeaves: boolean;
  fakeAccountDays: number;
  ignoreBots: boolean;
  updatedAt: string;
};
type InviteStat = { userId:string; joins:number; leaves:number; fake:number; updatedAt:string };
type JoinRecord = { userId:string; inviterId:string; code:string; joinedAt:string; fake:boolean; leftAt?:string };
type Stored = { settings:InviteSettings; stats:Record<string,InviteStat>; joins:Record<string,JoinRecord> };

const DEFAULTS: InviteSettings = {
  enabled:false,
  channelId:"",
  message:"{member} entrou usando o convite de {inviter}. Convites válidos: **{invites}**.",
  trackLeaves:true,
  fakeAccountDays:3,
  ignoreBots:true,
  updatedAt:""
};
function clone<T>(x:T):T{return structuredClone(x);}
function safeRead<T>(path:string,fallback:T):T{try{return existsSync(path)?JSON.parse(readFileSync(path,"utf8")) as T:clone(fallback);}catch{return clone(fallback);}}
function atomic(path:string,value:unknown){mkdirSync(join(path,".."),{recursive:true});const tmp=`${path}.${process.pid}.${Date.now()}.tmp`;writeFileSync(tmp,`${JSON.stringify(value,null,2)}\n`);renameSync(tmp,path);}

export class InviteTrackerService {
  private cache = new Map<string, Map<string, number>>();
  private state = new Map<string, Stored>();
  constructor(private readonly client:Client, private readonly databaseRoot:string, private readonly logger:Logger) {}
  private dir(gid:string){return join(this.databaseRoot,gid,"invites");}
  private load(gid:string):Stored{
    let s=this.state.get(gid);if(s)return s;const dir=this.dir(gid);
    const settings={...DEFAULTS,...safeRead<Partial<InviteSettings>>(join(dir,"configuracoes.json"),{})};
    s={settings:{...settings,updatedAt:settings.updatedAt||nowIso()},stats:safeRead(join(dir,"stats.json"),{}),joins:safeRead(join(dir,"joins.json"),{})};this.state.set(gid,s);return s;
  }
  private save(gid:string){const s=this.load(gid),dir=this.dir(gid);atomic(join(dir,"configuracoes.json"),s.settings);atomic(join(dir,"stats.json"),s.stats);atomic(join(dir,"joins.json"),s.joins);}
  settings(gid:string){return clone(this.load(gid).settings);}
  update(gid:string,patch:Partial<InviteSettings>){const s=this.load(gid);s.settings={...s.settings,...patch,updatedAt:nowIso()};this.save(gid);return this.settings(gid);}
  stats(gid:string){return Object.values(this.load(gid).stats).sort((a,b)=>this.score(b)-this.score(a));}
  score(s:InviteStat){return Math.max(0,s.joins-s.leaves-s.fake);}
  top(gid:string,limit=10){return this.stats(gid).slice(0,limit);}
  reset(gid:string){const s=this.load(gid);s.stats={};s.joins={};this.save(gid);}
  async start(){for(const guild of this.client.guilds.cache.values())await this.prime(guild);this.logger.success("Invite Tracker preparado para os servidores conectados.");}
  async prime(guild:Guild){try{const invites=await guild.invites.fetch();this.cache.set(guild.id,new Map([...invites.values()].map(i=>[i.code,i.uses||0])));}catch(error){this.logger.warn("Invite Tracker não conseguiu ler convites; confira Gerenciar Servidor.",{guildId:guild.id,error:String(error)});}}
  async handleInviteCreate(invite:Invite){if(invite.guild){const map=this.cache.get(invite.guild.id)??new Map<string,number>();map.set(invite.code,invite.uses||0);this.cache.set(invite.guild.id,map);}}
  async handleInviteDelete(invite:Invite){if(invite.guild){const map=this.cache.get(invite.guild.id);if(map)map.delete(invite.code);}}
  private detect(before:Map<string,number>, current:Iterable<Invite>){let used:Invite|undefined;let delta=0;for(const invite of current){const d=(invite.uses||0)-(before.get(invite.code)||0);if(d>delta){delta=d;used=invite;}}return used;}
  async handleMemberAdd(member:GuildMember){const cfg=this.settings(member.guild.id);if(!cfg.enabled||(cfg.ignoreBots&&member.user.bot))return;const existing=this.load(member.guild.id).joins[member.id];if(existing&&!existing.leftAt)return;const before=this.cache.get(member.guild.id)||new Map<string,number>();let invites;try{invites=await member.guild.invites.fetch();}catch{return;}const used=this.detect(before,invites.values());this.cache.set(member.guild.id,new Map([...invites.values()].map(i=>[i.code,i.uses||0])));if(!used?.inviter?.id)return;
    const s=this.load(member.guild.id);if(s.joins[member.id]&&!s.joins[member.id]!.leftAt)return;const inviterId=used.inviter.id;const fakeDays=Math.max(0,Number(cfg.fakeAccountDays)||0);const ageDays=(Date.now()-member.user.createdTimestamp)/86400000;const fake=fakeDays>0&&ageDays<fakeDays;const stat=s.stats[inviterId]||{userId:inviterId,joins:0,leaves:0,fake:0,updatedAt:nowIso()};stat.joins++;if(fake)stat.fake++;stat.updatedAt=nowIso();s.stats[inviterId]=stat;s.joins[member.id]={userId:member.id,inviterId,code:used.code,joinedAt:nowIso(),fake};this.save(member.guild.id);
    if(cfg.channelId){const channel=await this.client.channels.fetch(cfg.channelId).catch(()=>null);if(channel?.isSendable()){const text=cfg.message.replaceAll('{member}',`<@${member.id}>`).replaceAll('{inviter}',`<@${inviterId}>`).replaceAll('{invites}',String(this.score(stat))).replaceAll('{code}',used.code).replaceAll('{server}',member.guild.name);await channel.send({content:text.slice(0,2000)}).catch(()=>null);}}
  }
  async handleMemberRemove(member:GuildMember | PartialGuildMember){const cfg=this.settings(member.guild.id);if(!cfg.enabled||!cfg.trackLeaves)return;const s=this.load(member.guild.id),rec=s.joins[member.id];if(!rec||rec.leftAt)return;rec.leftAt=nowIso();const stat=s.stats[rec.inviterId];if(stat){stat.leaves++;stat.updatedAt=nowIso();}this.save(member.guild.id);}
}
