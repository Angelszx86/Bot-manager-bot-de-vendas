import type { RobuxCalculation, RobuxOrder, RobuxSettings, RobloxUser } from "./robux.js";


type SharpInstance = { png(): SharpInstance; toBuffer(): Promise<Buffer> };
type SharpFactory = (input: Buffer) => SharpInstance;

function loadSharp(): SharpFactory {
  try {
    const loaded = require("sharp") as SharpFactory | { default?: SharpFactory };
    return typeof loaded === "function" ? loaded : loaded.default!;
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    throw new Error(`Gerador PNG indisponível. Instale sharp: ${reason}`);
  }
}

function money(cents: number): string {
  return (Math.max(0, cents) / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function number(value: number): string {
  return Math.max(0, Math.trunc(value)).toLocaleString("pt-BR");
}

function xml(value: string): string {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function safeText(value: string, max = 64): string {
  return String(value || "").replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
}

function metricCard(x: number, y: number, width: number, label: string, value: string, detail: string, accent: string): string {
  return `
  <g>
    <rect x="${x}" y="${y}" width="${width}" height="128" rx="22" fill="#0b1222" stroke="#243250" stroke-width="1.4"/>
    <rect x="${x + 1}" y="${y + 1}" width="${width - 2}" height="4" rx="2" fill="${accent}" opacity=".95"/>
    <circle cx="${x + 27}" cy="${y + 34}" r="5" fill="${accent}"/>
    <text x="${x + 42}" y="${y + 39}" class="label">${xml(label.toUpperCase())}</text>
    <text x="${x + 24}" y="${y + 83}" class="value">${xml(value)}</text>
    <text x="${x + 24}" y="${y + 109}" class="detail">${xml(detail)}</text>
  </g>`;
}

function baseDefs(): string {
  return `<defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#060b16"/>
      <stop offset=".52" stop-color="#0a1224"/>
      <stop offset="1" stop-color="#07101d"/>
    </linearGradient>
    <radialGradient id="glowA" cx="0" cy="0" r="1" gradientTransform="translate(105 40) rotate(35) scale(520 350)">
      <stop offset="0" stop-color="#3155ff" stop-opacity=".24"/>
      <stop offset="1" stop-color="#3155ff" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="glowB" cx="0" cy="0" r="1" gradientTransform="translate(860 30) rotate(145) scale(420 320)">
      <stop offset="0" stop-color="#00c2ff" stop-opacity=".16"/>
      <stop offset="1" stop-color="#00c2ff" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="accent" x1="0" x2="1">
      <stop offset="0" stop-color="#4169ff"/>
      <stop offset=".48" stop-color="#7a5cff"/>
      <stop offset="1" stop-color="#00c8ff"/>
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="20" flood-color="#000000" flood-opacity=".35"/>
    </filter>
    <style>
      .brand{font-family:Inter,Arial,Helvetica,sans-serif;font-size:12px;font-weight:800;fill:#a9bcff;letter-spacing:1.6px}
      .title{font-family:Inter,Arial,Helvetica,sans-serif;font-size:38px;font-weight:800;fill:#f8fbff;letter-spacing:-.5px}
      .subtitle{font-family:Inter,Arial,Helvetica,sans-serif;font-size:15px;fill:#8fa3c5}
      .label{font-family:Inter,Arial,Helvetica,sans-serif;font-size:12px;font-weight:800;fill:#8ea4c9;letter-spacing:1px}
      .value{font-family:Inter,Arial,Helvetica,sans-serif;font-size:29px;font-weight:800;fill:#f8fafc;letter-spacing:-.3px}
      .detail{font-family:Inter,Arial,Helvetica,sans-serif;font-size:12px;fill:#7185a7}
      .small{font-family:Inter,Arial,Helvetica,sans-serif;font-size:12px;fill:#7185a7}
      .meta{font-family:Inter,Arial,Helvetica,sans-serif;font-size:14px;font-weight:700;fill:#d8e1f2}
    </style>
  </defs>`;
}

/**
 * Card premium da calculadora Robux. Continua sendo um PNG real enviado no
 * canal configurado; não depende de embed para o visual principal.
 */
export async function renderRobuxCalculationPng(settings: RobuxSettings, calc: RobuxCalculation, serverName = "Servidor"): Promise<Buffer> {
  const sharp = loadSharp();
  const shopTitle = safeText(serverName || "Servidor", 28);
  const stamp = new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
  const rate = `${money(settings.pricePer1000Cents)} / 1.000`;

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="600" viewBox="0 0 1000 600">
  ${baseDefs()}
  <rect width="1000" height="600" fill="#0b0d12"/>
  <rect x="24" y="24" width="952" height="552" rx="18" fill="#11141a" stroke="#2b3039"/>
  <rect x="24" y="24" width="952" height="4" rx="2" fill="#e7e9ee"/>

  <rect x="58" y="58" width="258" height="36" rx="18" fill="#171b22" stroke="#343a45"/>
  <circle cx="80" cy="76" r="6" fill="#e7e9ee"/>
  <text x="96" y="81" class="brand">${xml(shopTitle.toUpperCase())}</text>
  <text x="942" y="81" class="brand" text-anchor="end">LOJA • ROBUX</text>

  <text x="58" y="151" class="title">Calculadora Robux</text>
  <text x="58" y="180" class="subtitle">Conversão instantânea conforme a configuração atual da loja.</text>
  <rect x="58" y="202" width="884" height="46" rx="15" fill="#171b22" stroke="#303640"/>
  <text x="80" y="231" class="small">TAXA CONFIGURADA</text>
  <text x="230" y="231" class="meta">${xml(rate)}</text>
  <text x="600" y="231" class="small">FAIXA</text>
  <text x="655" y="231" class="meta">${xml(`${number(settings.minRobux)} – ${number(settings.maxRobux)} Robux`)}</text>

  ${metricCard(58, 270, 426, "Robux solicitados", `${number(calc.requestedRobux)} Robux`, "Quantidade calculada para esta consulta", "#d7dbe3")}
  ${metricCard(516, 270, 426, "Valor da compra", money(calc.amountCents), "Preço final com base no valor configurado", "#d7dbe3")}
  ${metricCard(58, 418, 426, "Preço da Game Pass", `${number(calc.gamepassPrice)} Robux`, "Valor recomendado considerando a taxa da plataforma", "#d7dbe3")}
  ${metricCard(516, 418, 426, "Recebimento estimado", `${number(calc.estimatedNetRobux)} Robux`, "Estimativa líquida após a taxa da plataforma", "#d7dbe3")}

  <text x="58" y="565" class="small">Digite também <tspan fill="#a9bcff" font-weight="700">nick</tspan> neste canal para consultar uma conta Roblox e suas gamepasses.</text>
  <text x="942" y="565" class="small" text-anchor="end">${xml(stamp)}</text>
</svg>`;

  return sharp(Buffer.from(svg, "utf8")).png().toBuffer();
}

export async function renderRobloxProfilePng(user: RobloxUser, gamepassCount: number, serverName = "Servidor", avatarBytes?: Buffer): Promise<Buffer> {
  const sharp = loadSharp();
  const created = user.createdAt ? new Date(user.createdAt) : undefined;
  const createdText = created && Number.isFinite(created.getTime())
    ? created.toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })
    : "Não informado";
  const years = created && Number.isFinite(created.getTime())
    ? Math.max(0, Math.floor((Date.now() - created.getTime()) / (365.2425 * 24 * 60 * 60 * 1000)))
    : undefined;
  const avatarData = avatarBytes?.length ? `data:image/png;base64,${avatarBytes.toString("base64")}` : "";
  const description = safeText(user.description || "Sem descrição pública.", 110);
  const server = safeText(serverName, 28);

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="500" viewBox="0 0 1000 500">
  ${baseDefs()}
  <clipPath id="avatarClip"><circle cx="172" cy="247" r="88"/></clipPath>
  <rect width="1000" height="500" fill="url(#bg)"/>
  <rect width="1000" height="500" fill="url(#glowA)"/>
  <rect width="1000" height="500" fill="url(#glowB)"/>
  <rect x="24" y="24" width="952" height="452" rx="30" fill="#080f1e" fill-opacity=".74" stroke="#1e2d49" filter="url(#shadow)"/>
  <rect x="24" y="24" width="952" height="6" rx="3" fill="url(#accent)"/>

  <rect x="58" y="58" width="258" height="36" rx="18" fill="#0d1830" stroke="#263d72"/>
  <circle cx="80" cy="76" r="6" fill="#4d70ff"/>
  <text x="96" y="81" class="brand">${xml(server.toUpperCase())}</text>
  <text x="942" y="81" class="brand" text-anchor="end">CONSULTA ROBLOX</text>

  <circle cx="172" cy="247" r="96" fill="#0d1930" stroke="#4267ff" stroke-width="3"/>
  ${avatarData ? `<image href="${avatarData}" x="84" y="159" width="176" height="176" preserveAspectRatio="xMidYMid slice" clip-path="url(#avatarClip)"/>` : `<text x="172" y="260" text-anchor="middle" class="title" font-size="58">R</text>`}
  <circle cx="238" cy="313" r="16" fill="#22c55e" stroke="#08101e" stroke-width="5"/>

  <text x="310" y="160" class="small">CONTA ROBLOX</text>
  <text x="310" y="205" class="title">${xml(safeText(user.displayName || user.name, 32))}</text>
  <text x="310" y="236" class="subtitle">@${xml(safeText(user.name, 32))} • ID ${Math.trunc(user.id)}</text>
  <text x="310" y="277" class="subtitle">${xml(description)}</text>

  <rect x="310" y="310" width="198" height="100" rx="18" fill="#0b1222" stroke="#243250"/>
  <text x="332" y="342" class="label">CONTA CRIADA</text>
  <text x="332" y="378" class="meta">${xml(createdText)}</text>
  ${years !== undefined ? `<text x="332" y="398" class="small">há aproximadamente ${years} ano(s)</text>` : ""}

  <rect x="526" y="310" width="198" height="100" rx="18" fill="#0b1222" stroke="#243250"/>
  <text x="548" y="342" class="label">GAMEPASSES</text>
  <text x="548" y="380" class="value" font-size="26">${Math.max(0, gamepassCount)}</text>
  <text x="548" y="400" class="small">pública(s) encontrada(s)</text>

  <rect x="742" y="310" width="200" height="100" rx="18" fill="#0b1222" stroke="#243250"/>
  <text x="764" y="342" class="label">STATUS</text>
  <text x="764" y="380" class="meta" fill="${user.isBanned ? "#fb7185" : "#5ee6a8"}">${user.isBanned ? "Conta indisponível" : "Conta encontrada"}</text>
  <text x="764" y="400" class="small">dados públicos do Roblox</text>

  <text x="58" y="454" class="small">Use o menu abaixo da imagem para selecionar uma gamepass e abrir os detalhes.</text>
  <text x="942" y="454" class="small" text-anchor="end">Automação</text>
</svg>`;

  return sharp(Buffer.from(svg, "utf8")).png().toBuffer();
}

export async function renderRobuxPurchasePng(settings: RobuxSettings, order: RobuxOrder, serverName = "Servidor", avatarBytes?: Buffer): Promise<Buffer> {
  const sharp = loadSharp();
  const when = new Date(order.deliveredAt || order.updatedAt || order.createdAt || Date.now()).toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit"
  });
  const avatarData = avatarBytes?.length ? `data:image/png;base64,${avatarBytes.toString("base64")}` : "";
  const displayName = safeText(
    order.robloxDisplayName && !/aguardando|conta informada/i.test(order.robloxDisplayName)
      ? order.robloxDisplayName
      : order.discordUsername || "Cliente",
    30
  );
  const handle = order.robloxUsername && !/aguardando|via-gamepass/i.test(order.robloxUsername)
    ? `@${safeText(order.robloxUsername, 28)}`
    : `@${safeText(order.discordUsername || "cliente", 28)}`;
  const server = safeText(serverName, 34);
  const item = `${number(order.requestedRobux)}x Robux`;
  const total = money(order.amountCents);

  const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="960" height="520" viewBox="0 0 960 520">
  <defs>
    <linearGradient id="receiptBg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#080a0e"/>
      <stop offset="1" stop-color="#101319"/>
    </linearGradient>
    <linearGradient id="green" x1="0" x2="1">
      <stop offset="0" stop-color="#20c86d"/>
      <stop offset="1" stop-color="#5bec8c"/>
    </linearGradient>
    <filter id="receiptShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="18" stdDeviation="22" flood-color="#000" flood-opacity=".52"/>
    </filter>
    <clipPath id="saleAvatar"><circle cx="112" cy="90" r="42"/></clipPath>
    <style>
      .r-main{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f7f8fa}
      .r-muted{font-family:Inter,Arial,Helvetica,sans-serif;fill:#8d929c}
      .r-small{font-family:Inter,Arial,Helvetica,sans-serif;fill:#a5a9b1;font-size:17px}
      .r-label{font-family:Inter,Arial,Helvetica,sans-serif;fill:#aeb2ba;font-size:20px;font-weight:650}
      .r-title{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f8fafc;font-size:34px;font-weight:800}
      .r-name{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f8fafc;font-size:25px;font-weight:760}
      .r-total{font-family:Inter,Arial,Helvetica,sans-serif;fill:#38dc79;font-size:42px;font-weight:850}
    </style>
  </defs>
  <rect width="960" height="520" fill="#050608"/>
  <rect x="28" y="24" width="904" height="472" rx="38" fill="url(#receiptBg)" stroke="#232831" stroke-width="2" filter="url(#receiptShadow)"/>
  <rect x="29" y="25" width="902" height="470" rx="37" fill="none" stroke="#ffffff" stroke-opacity=".025"/>

  <circle cx="112" cy="90" r="47" fill="#151922" stroke="#2c333f" stroke-width="2"/>
  ${avatarData ? `<image href="${avatarData}" x="70" y="48" width="84" height="84" preserveAspectRatio="xMidYMid slice" clip-path="url(#saleAvatar)"/>` : `<text x="112" y="101" text-anchor="middle" class="r-main" font-size="34" font-weight="800">${xml(displayName.slice(0, 1).toUpperCase())}</text>`}
  <text x="174" y="81" class="r-name">${xml(displayName)}</text>
  <text x="174" y="111" class="r-small">${xml(handle)}</text>
  <text x="882" y="82" text-anchor="end" class="r-small">${xml(when)}</text>

  <circle cx="78" cy="174" r="18" fill="#24c96b"/>
  <path d="M69 174l6 6 12-14" fill="none" stroke="#06140b" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
  <text x="112" y="186" class="r-title">Compra Realizada</text>

  <text x="64" y="246" class="r-label">Carrinho</text>
  <rect x="64" y="266" width="832" height="76" rx="18" fill="#0c0f14" stroke="#222831"/>
  <circle cx="100" cy="304" r="19" fill="#151a22"/>
  <text x="100" y="311" text-anchor="middle" class="r-main" font-size="18" font-weight="800">R$</text>
  <text x="136" y="299" class="r-main" font-size="22" font-weight="760">${xml(item)}</text>
  <text x="136" y="325" class="r-muted" font-size="16">Entrega via Game Pass</text>
  <text x="864" y="311" text-anchor="end" class="r-main" font-size="22" font-weight="760">${xml(total)}</text>

  <line x1="64" y1="374" x2="896" y2="374" stroke="#252a31" stroke-width="2"/>
  <text x="64" y="430" class="r-label">Valor pago</text>
  <text x="896" y="439" text-anchor="end" class="r-total">${xml(total)}</text>

  <text x="64" y="474" class="r-small">${xml(server)}</text>
  <text x="896" y="474" text-anchor="end" class="r-small">Pedido ${xml(order.id)}</text>
</svg>`;
  return sharp(Buffer.from(svg, "utf8")).png().toBuffer();
}
