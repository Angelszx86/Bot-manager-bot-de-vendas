import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Client, EmbedBuilder, GuildMember, Message, PermissionFlagsBits, TextChannel, type PartialGuildMember } from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { Logger } from "../core/logger.js";
import { colorNumber, truncate } from "../core/utils.js";
import type { LockService } from "./locks.js";

export class AutomationService {
  private spam = new Map<string, number[]>();
  private scheduleTimer?: NodeJS.Timeout;
  private messageTimer?: NodeJS.Timeout;
  private scheduleRunning = false;
  private messageRunning = false;
  private started = false;
  private readonly onMemberAdd = (member: GuildMember) => void this.memberAdd(member);
  private readonly onMemberRemove = (member: GuildMember | PartialGuildMember) => void this.memberRemove(member);
  private readonly onMessageDelete = (message: Message | import("discord.js").PartialMessage) => void this.deleted(message as Message);
  private readonly onMessageUpdate = (oldMessage: Message | import("discord.js").PartialMessage, newMessage: Message | import("discord.js").PartialMessage) => void this.edited(oldMessage as Message, newMessage as Message);
  constructor(private readonly client: Client, private readonly db: JsonDatabase, private readonly logger: Logger, private readonly locks: LockService) {}
  start() {
    if (this.started) return;
    this.started = true;
    this.client.on("guildMemberAdd", this.onMemberAdd);
    this.client.on("guildMemberRemove", this.onMemberRemove);
    this.client.on("messageDelete", this.onMessageDelete);
    this.client.on("messageUpdate", this.onMessageUpdate);
    this.scheduleTimer = setInterval(() => void this.runChannelSchedules(), 30_000);
    this.scheduleTimer.unref?.();
    this.messageTimer = setInterval(() => void this.runMessageAutomations(), 15_000);
    this.messageTimer.unref?.();
    setTimeout(() => void this.runChannelSchedules(), 5000).unref?.();
    setTimeout(() => void this.runMessageAutomations(), 7000).unref?.();
  }
  stop() {
    if (!this.started) return;
    this.started = false;
    if (this.scheduleTimer) clearInterval(this.scheduleTimer);
    if (this.messageTimer) clearInterval(this.messageTimer);
    this.scheduleTimer = undefined;
    this.messageTimer = undefined;
    this.client.off("guildMemberAdd", this.onMemberAdd);
    this.client.off("guildMemberRemove", this.onMemberRemove);
    this.client.off("messageDelete", this.onMessageDelete);
    this.client.off("messageUpdate", this.onMessageUpdate);
  }

  private clock(timezone: string): { date: string; time: string } {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23"
    }).formatToParts(new Date());
    const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((entry) => entry.type === type)?.value ?? "";
    return { date: `${part("year")}-${part("month")}-${part("day")}`, time: `${part("hour")}:${part("minute")}` };
  }

  async runChannelSchedules(): Promise<void> {
    if (this.scheduleRunning || !this.client.isReady()) return;
    this.scheduleRunning = true;
    try {
      for (const [guildId, settings] of Object.entries(this.db.state.guildAutomations)) {
        for (const schedule of settings.channelSchedules ?? []) {
          if (!schedule.enabled || !schedule.channelIds.length) continue;
          let current: { date: string; time: string };
          try { current = this.clock(schedule.timezone || "America/Sao_Paulo"); }
          catch { current = this.clock("America/Sao_Paulo"); }
          const action = current.time === schedule.lockTime && schedule.lastLockDate !== current.date
            ? "LOCK"
            : current.time === schedule.unlockTime && schedule.lastUnlockDate !== current.date
              ? "UNLOCK"
              : "";
          if (!action) continue;

          const actor = { id: this.client.user?.id ?? "system" };
          let changed = 0;
          const failures: Array<{ channelId: string; error: string }> = [];
          for (const channelId of schedule.channelIds) {
            const channel = await this.client.channels.fetch(channelId).catch(() => undefined);
            if (!(channel instanceof TextChannel) || channel.guild.id !== guildId) {
              failures.push({ channelId, error: "Canal não encontrado ou pertence a outro servidor." });
              continue;
            }
            try {
              if (action === "LOCK") await this.locks.lock(channel, actor, `Automação ${schedule.name}`);
              else await this.locks.unlock(channel, actor, `Automação ${schedule.name}`);
              const message = action === "LOCK" ? schedule.lockMessage : schedule.unlockMessage;
              if (message.trim()) await channel.send({ content: truncate(message, 1800), allowedMentions: { parse: [] } }).catch(() => undefined);
              changed++;
            } catch (error) {
              failures.push({ channelId, error: String(error) });
            }
          }
          if (action === "LOCK") schedule.lastLockDate = current.date;
          else schedule.lastUnlockDate = current.date;
          schedule.updatedAt = new Date().toISOString();
          this.db.audit("system", `CHANNEL_SCHEDULE_${action}`, "channel_schedule", schedule.id, { guildId, changed, failures }, guildId);
          this.db.save();
          this.logger.info(`Automação de canais executada: ${schedule.name}.`, { guildId, action, changed, failures: failures.length });
        }
      }
    } finally {
      this.scheduleRunning = false;
    }
  }
  private template(value: string, member: GuildMember | PartialGuildMember) { return value.replaceAll("{user}", `<@${member.id}>`).replaceAll("{username}", member.user.username).replaceAll("{server}", member.guild.name).replaceAll("{count}", String(member.guild.memberCount)); }

  private automaticBadge() {
    return new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("zenyx:automatic-message")
        .setLabel("Mensagem Automática")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
  }

  private due(lastSentAt: string, intervalMinutes: number): boolean {
    const last = Date.parse(lastSentAt || "");
    return !Number.isFinite(last) || Date.now() - last >= Math.max(1, intervalMinutes) * 60_000;
  }

  async runMessageAutomations(): Promise<void> {
    if (this.messageRunning || !this.client.isReady()) return;
    this.messageRunning = true;
    try {
      for (const [guildId, settings] of Object.entries(this.db.state.guildAutomations)) {
        const guild = this.client.guilds.cache.get(guildId);
        if (!guild) continue;

        for (const rule of settings.repeatingMessages ?? []) {
          if (!rule.enabled || !rule.channelId || !rule.content.trim() || !this.due(rule.lastSentAt, rule.intervalMinutes)) continue;
          const channel = await this.client.channels.fetch(rule.channelId).catch(() => undefined);
          if (!(channel instanceof TextChannel) || channel.guild.id !== guildId) continue;
          try {
            if (rule.lastMessageId) {
              const previous = await channel.messages.fetch(rule.lastMessageId).catch(() => undefined);
              if (previous?.author.id === this.client.user?.id) await previous.delete().catch(() => undefined);
            }
            const sent = await channel.send({ content: truncate(rule.content, 1900), allowedMentions: { parse: [] }, components: [this.automaticBadge()] });
            rule.lastMessageId = sent.id;
            rule.lastSentAt = new Date().toISOString();
            rule.updatedAt = rule.lastSentAt;
            this.db.save();
          } catch (error) {
            this.logger.warn("Falha ao reenviar mensagem recorrente.", { guildId, ruleId: rule.id, error: String(error) });
          }
        }

        for (const rule of settings.mentionMessages ?? []) {
          if (!rule.enabled || !rule.channelId || !rule.content.trim() || !["EXISTING_MEMBERS", "BOTH"].includes(rule.audience) || !this.due(rule.lastSentAt, rule.intervalMinutes)) continue;
          const channel = await this.client.channels.fetch(rule.channelId).catch(() => undefined);
          if (!(channel instanceof TextChannel) || channel.guild.id !== guildId) continue;
          try {
            await guild.members.fetch().catch(() => undefined);
            const members = [...guild.members.cache.values()].filter((member) => !member.user.bot).sort((a, b) => a.id.localeCompare(b.id));
            if (!members.length) continue;
            const index = rule.cursor % members.length;
            const member = members[index]!;
            await channel.send({
              content: truncate(this.template(rule.content, member), 1900),
              allowedMentions: { parse: [], users: [member.id] },
              components: [this.automaticBadge()]
            });
            rule.cursor = (index + 1) % members.length;
            rule.lastSentAt = new Date().toISOString();
            rule.updatedAt = rule.lastSentAt;
            this.db.save();
          } catch (error) {
            this.logger.warn("Falha ao enviar mensagem automática com menção.", { guildId, ruleId: rule.id, error: String(error) });
          }
        }
      }
    } finally {
      this.messageRunning = false;
    }
  }
  private async memberAdd(member: GuildMember) {
    const auto = this.db.automations(member.guild.id); const guild = this.db.guild(member.guild.id);
    if (auto.autoRoleEnabled && guild.autoRoleId) await member.roles.add(guild.autoRoleId, "Autorole da aplicação").catch((error) => this.logger.warn("Falha no autorole.", error));
    if (auto.welcomeEnabled && guild.welcomeChannelId) {
      const channel = await member.guild.channels.fetch(guild.welcomeChannelId).catch(() => undefined);
      if (channel instanceof TextChannel) {
        if (auto.welcomeMode === "TEMPORARY") {
          const sent = await channel.send({
            content: this.template(auto.welcomeMessage, member),
            allowedMentions: { parse: [], users: [member.id] },
            components: [this.automaticBadge()]
          }).catch(() => undefined);
          if (sent) setTimeout(() => void sent.delete().catch(() => undefined), Math.max(3, Math.min(120, auto.welcomeDeleteAfterSeconds || 8)) * 1000);
        } else {
          await channel.send({ embeds: [new EmbedBuilder().setColor(colorNumber(this.db.brand(member.guild.id).color)).setDescription(this.template(auto.welcomeMessage, member)).setThumbnail(member.user.displayAvatarURL()).setTimestamp()], components: [this.automaticBadge()] }).catch(() => undefined);
        }
      }
    }
    for (const rule of auto.mentionMessages ?? []) {
      if (!rule.enabled || !rule.channelId || !rule.content.trim() || !["NEW_MEMBERS", "BOTH"].includes(rule.audience)) continue;
      const channel = await member.guild.channels.fetch(rule.channelId).catch(() => undefined);
      if (!(channel instanceof TextChannel)) continue;
      await channel.send({ content: truncate(this.template(rule.content, member), 1900), allowedMentions: { parse: [], users: [member.id] }, components: [this.automaticBadge()] }).catch((error) => this.logger.warn("Falha ao enviar mensagem para novo membro.", { guildId: member.guild.id, ruleId: rule.id, error: String(error) }));
    }
  }
  private async memberRemove(member: GuildMember | PartialGuildMember) {
    const auto = this.db.automations(member.guild.id); const guild = this.db.guild(member.guild.id); if (!auto.goodbyeEnabled || !guild.goodbyeChannelId) return;
    const channel = await member.guild.channels.fetch(guild.goodbyeChannelId).catch(() => undefined);
    if (channel instanceof TextChannel) await channel.send({ embeds: [new EmbedBuilder().setColor(0x64748b).setDescription(this.template(auto.goodbyeMessage, member)).setTimestamp()], components: [this.automaticBadge()] }).catch(() => undefined);
  }
  async handleMessage(message: Message) {
    if (!message.guild || message.author.bot || !message.member) return;
    const protection = this.db.protection(message.guild.id);
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      const lower = message.content.toLowerCase();
      const urls = lower.match(/https?:\/\/[^\s]+|discord(?:\.gg|\.com\/invite)\/[^\s]+/g) ?? [];
      if (protection.antiLink && urls.length) {
        const allowed = protection.allowedDomains.some((domain) => urls.some((url) => url.includes(domain.toLowerCase())));
        const inviteBlocked = protection.blockInvites && urls.some((url) => /discord(?:\.gg|\.com\/invite)/.test(url));
        if (!allowed || inviteBlocked) { await message.delete().catch(() => undefined); const warn = message.channel.isSendable() ? await message.channel.send(`${message.author}, links não são permitidos aqui.`).catch(() => undefined) : undefined; if (warn) setTimeout(() => void warn.delete().catch(() => undefined), 5000); return; }
      }
      if (protection.antiSpam) {
        const key = `${message.guild.id}:${message.author.id}`; const now = Date.now(); const windowMs = protection.spamWindowSeconds * 1000;
        const rows = (this.spam.get(key) ?? []).filter((time) => now - time <= windowMs); rows.push(now); this.spam.set(key, rows);
        if (rows.length >= protection.spamMessages) { await message.member.timeout(protection.spamTimeoutSeconds * 1000, "Anti-spam da aplicação").catch(() => undefined); if (message.channel.isSendable()) await message.channel.send(`${message.author}, você foi silenciado temporariamente por spam.`).catch(() => undefined); this.spam.delete(key); return; }
      }
    }
    const auto = this.db.automations(message.guild.id);
    for (const rule of auto.autoReactions ?? []) {
      if (!rule.enabled || rule.channelId !== message.channel.id || !rule.emojiId) continue;
      // Reações usam Guild Emoji, não Application Emoji. O ID fica persistido
      // internamente, mas o dono escolhe tudo pelo seletor visual.
      const emoji = message.guild!.emojis.cache.get(rule.emojiId);
      if (!emoji) {
        this.logger.warn("Emoji configurado para reação automática não está mais disponível no servidor.", { guildId: message.guild!.id, channelId: message.channel.id, ruleId: rule.id, emojiId: rule.emojiId });
        continue;
      }
      await message.react(emoji).catch((error) => this.logger.warn("Falha na reação automática.", { guildId: message.guild!.id, channelId: message.channel.id, ruleId: rule.id, emojiId: rule.emojiId, error: String(error) }));
    }
    if (auto.autoResponsesEnabled) {
      for (const rule of auto.autoResponses) {
        const match = rule.exact ? message.content.trim().toLowerCase() === rule.trigger.toLowerCase() : message.content.toLowerCase().includes(rule.trigger.toLowerCase());
        if (match) { await message.reply({ content: rule.response.replaceAll("{user}", `<@${message.author.id}>`), components: [this.automaticBadge()] }).catch(() => undefined); break; }
      }
    }
  }
  private async logChannel(guildId: string): Promise<TextChannel | undefined> { const id = this.db.guild(guildId).logChannelId; if (!id) return; const channel = await this.client.channels.fetch(id).catch(() => undefined); return channel instanceof TextChannel ? channel : undefined; }
  private async deleted(message: Message) { if (!message.guild || message.author?.bot || !this.db.protection(message.guild.id).logDeletedMessages) return; const channel = await this.logChannel(message.guild.id); await channel?.send({ embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Mensagem apagada").addFields({ name: "Autor", value: message.author ? `<@${message.author.id}>` : "Desconhecido", inline: true }, { name: "Canal", value: `<#${message.channel.id}>`, inline: true }, { name: "Conteúdo", value: truncate(message.content || "[sem conteúdo]", 1024) }).setTimestamp()] }).catch(() => undefined); }
  private async edited(oldMessage: Message, newMessage: Message) { if (!newMessage.guild || newMessage.author?.bot || !this.db.protection(newMessage.guild.id).logEditedMessages || oldMessage.content === newMessage.content) return; const channel = await this.logChannel(newMessage.guild.id); await channel?.send({ embeds: [new EmbedBuilder().setColor(0xf59e0b).setTitle("Mensagem editada").addFields({ name: "Autor", value: `<@${newMessage.author.id}>`, inline: true }, { name: "Canal", value: `<#${newMessage.channel.id}>`, inline: true }, { name: "Antes", value: truncate(oldMessage.content || "[vazio]", 1024) }, { name: "Depois", value: truncate(newMessage.content || "[vazio]", 1024) }).setTimestamp()] }).catch(() => undefined); }
}
