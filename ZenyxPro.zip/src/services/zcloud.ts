import { createServer, type Server, type ServerResponse } from "node:http";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { spawn, type ChildProcess } from "node:child_process";
import { resolve } from "node:path";
import type { Client } from "discord.js";
import type { AppConfig, ZCloudSettings, ZCloudVerifiedMember } from "../types.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { CredentialStore } from "../core/credential-store.js";
import type { Logger } from "../core/logger.js";
import { nowIso } from "../core/utils.js";

const DEFAULTS: Omit<ZCloudSettings, "updatedAt"> = {
  enabled: false,
  clientId: "",
  redirectUri: "",
  publicBaseUrl: "",
  primaryGuildId: "",
  backupGuildId: "",
  backupInviteUrl: "",
  backupTransferEnabled: false,
  backupTransferLimit: 50,
  verificationRoleId: "",
  verificationChannelId: "",
  panelMessageId: "",
  panelTitle: "ZENYX VERIFICATION",
  panelDescription: "Sua verificação é necessária para garantir seu acesso à comunidade. Clique abaixo para verificar sua conta Discord.",
  panelImageUrl: "",
  panelColor: "#3155ff",
  panelFooter: "",
  panelMode: "EMBED",
  buttonLabel: "Verificar minha conta",
  buttonEmoji: "",
  discordReturnUrl: "https://discord.com/channels/@me",
  requireRole: true,
  allowBackupJoin: true,
  autoJoinEnabled: false,
  autoJoinGuildId: "",
  autoJoinInviteUrl: ""
};

type StateRecord = { guildId: string; createdAt: number; used: boolean };
type OAuthTokenResponse = {
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
  scope?: string;
  token_type?: string;
};
type DiscordUser = { id: string; username: string; global_name?: string | null; avatar?: string | null };

const DISCORD_API = "https://discord.com/api/v10";
const STATE_TTL_MS = 10 * 60_000;
const REGISTER_INTERVAL_MS = 4 * 60_000;

function isHttpsUrl(value: string): boolean {
  try { return new URL(value).protocol === "https:"; } catch { return false; }
}
function isLocalUrl(value: string): boolean {
  try {
    const u = new URL(value);
    return ["localhost", "127.0.0.1", "0.0.0.0", "::1"].includes(u.hostname);
  } catch { return false; }
}
function isTryCloudflareUrl(value: string): boolean {
  try {
    const host = new URL(value).hostname.toLowerCase();
    return host.endsWith(".trycloudflare.com") || host === "trycloudflare.com";
  } catch { return false; }
}
function normalizeBase(value: string): string {
  const clean = String(value || "").trim().replace(/\/+$/, "");
  return isHttpsUrl(clean) ? clean : "";
}
function isDiscordInviteUrl(value: string): boolean {
  const raw = String(value || "").trim();
  if (!raw) return false;
  try {
    const u = new URL(raw);
    const host = u.hostname.toLowerCase();
    return u.protocol === "https:" && ((host === "discord.gg" && /^\/[A-Za-z0-9_-]+\/?$/.test(u.pathname)) || (host === "discord.com" && /^\/invite\/[A-Za-z0-9_-]+\/?$/.test(u.pathname)));
  } catch { return false; }
}

function isLegacyGatewayUrl(value: string): boolean {
  try {
    const u = new URL(value);
    return /\/functions\/v1\/zcloud-gateway(?:\/|$)/i.test(u.pathname);
  } catch { return false; }
}

export class ZCloudService {
  private states = new Map<string, StateRecord>();
  private server?: Server;
  private tunnel?: ChildProcess;
  private tunnelUrl = "";
  private tunnelStarting = false;
  private stopping = false;
  private registerTimer?: NodeJS.Timeout;
  private tunnelRestartTimer?: NodeJS.Timeout;
  private gatewayRegisteredGuilds = new Set<string>();

  constructor(
    private readonly client: Client,
    private readonly config: AppConfig,
    private readonly db: JsonDatabase,
    private readonly credentials: CredentialStore,
    private readonly logger: Logger
  ) {}

  /** O Manager controla globalmente se o recurso pode ser usado. A leitura é
   * dinâmica para que /botconfig consiga ligar/desligar sem reiniciar o bot filho. */
  private runtimeZcloud(): { zcloudManagerEnabled?: unknown; zcloudEdgeBaseUrl?: unknown } {
    try {
      return JSON.parse(readFileSync(resolve(process.cwd(), "config/runtime.json"), "utf8")) as { zcloudManagerEnabled?: unknown; zcloudEdgeBaseUrl?: unknown };
    } catch { return {}; }
  }

  managerEnabled(): boolean {
    const runtime = this.runtimeZcloud();
    return runtime.zcloudManagerEnabled === undefined ? this.config.zcloudManagerEnabled !== false : runtime.zcloudManagerEnabled !== false;
  }

  private managedBaseUrl(): string {
    const runtime = this.runtimeZcloud();
    return normalizeBase(String(runtime.zcloudEdgeBaseUrl ?? this.config.zcloudEdgeBaseUrl ?? ""));
  }

  private managedRedirectUri(guildId: string): string {
    const base = this.managedBaseUrl();
    return base ? `${base}/zcloud/${guildId}/callback` : "";
  }

  managedPublicBaseUrl(): string { return this.managedBaseUrl(); }

  settings(guildId: string): ZCloudSettings {
    const current = this.db.state.zcloudSettings[guildId];
    const merged: ZCloudSettings = {
      ...DEFAULTS,
      ...(current ?? {}),
      primaryGuildId: current?.primaryGuildId || guildId,
      updatedAt: current?.updatedAt || nowIso()
    };

    // Migração visual: versões antigas persistiam uma assinatura promocional
    // no rodapé do painel público. Ela é removida sem apagar personalizações reais.
    if (merged.panelFooter === "ZENYX Applications • ZCloud Auth") merged.panelFooter = "";

    const managed = this.managedBaseUrl();
    // Quando o Manager fornece a rota pública, ela é a fonte de verdade. Isso
    // impede URLs antigas do Supabase/Quick Tunnel ou callbacks manuais de
    // continuarem ativos após a migração para a HidenCloud.
    if (managed) merged.publicBaseUrl = managed;
    const managedRedirect = this.managedRedirectUri(guildId);
    if (managedRedirect) merged.redirectUri = managedRedirect;

    const changed = !current || JSON.stringify(current) !== JSON.stringify(merged);
    this.db.state.zcloudSettings[guildId] = merged;
    if (changed) this.db.save();
    return merged;
  }

  update(guildId: string, patch: Partial<ZCloudSettings>): ZCloudSettings {
    const s = this.settings(guildId);
    Object.assign(s, patch, { updatedAt: nowIso() });
    this.db.save();
    return s;
  }

  secretConfigured(guildId: string): boolean { return this.credentials.has(guildId, "zcloud_client_secret"); }
  setSecret(guildId: string, value: string): void { this.credentials.set(guildId, "zcloud_client_secret", value); }
  members(guildId: string): ZCloudVerifiedMember[] {
    return Object.values(this.db.state.zcloudMembers).filter((x) => x.guildId === guildId && !x.revoked);
  }

  /** Renova o OAuth somente quando o token necessário para guilds.join expirou.
   * Nunca adiciona contas que não concederam explicitamente guilds.join. */
  private async usableGuildJoinToken(guildId: string, member: ZCloudVerifiedMember): Promise<string | null> {
    if (member.revoked || !member.scopes.includes("guilds.join")) return null;
    const accessKey = `zcloud_access_${member.userId}`;
    const refreshKey = `zcloud_refresh_${member.userId}`;
    const current = this.credentials.get(guildId, accessKey);
    const expiry = Date.parse(member.tokenExpiresAt || "");
    if (current && (!Number.isFinite(expiry) || expiry > Date.now() + 30_000)) return current;
    const refresh = this.credentials.get(guildId, refreshKey);
    const secret = this.credentials.get(guildId, "zcloud_client_secret");
    const clientId = this.settings(guildId).clientId;
    if (!refresh || !secret || !clientId) return null;
    const form = new URLSearchParams({ client_id: clientId, client_secret: secret, grant_type: "refresh_token", refresh_token: refresh });
    const response = await fetch(`${DISCORD_API}/oauth2/token`, { method:"POST", headers:{"content-type":"application/x-www-form-urlencoded"}, body:form, signal:AbortSignal.timeout(15_000) });
    if (!response.ok) return null;
    const tok = await response.json() as OAuthTokenResponse;
    if (!tok.access_token) return null;
    const scopes = String(tok.scope || member.scopes.join(" ")).split(/\s+/).filter(Boolean);
    if (!scopes.includes("guilds.join")) return null;
    this.credentials.set(guildId, accessKey, tok.access_token);
    if (tok.refresh_token) this.credentials.set(guildId, refreshKey, tok.refresh_token);
    member.scopes = scopes;
    member.tokenExpiresAt = new Date(Date.now() + Number(tok.expires_in || 3600) * 1000).toISOString();
    member.updatedAt = nowIso();
    this.db.save();
    return tok.access_token;
  }

  async transferVerifiedMembersToBackup(guildId: string, requestedLimit?: number): Promise<{requested:number;eligible:number;joined:number;already:number;skipped:number;failed:number;targetGuildId:string}> {
    const s = this.settings(guildId);
    if (!s.backupTransferEnabled) throw new Error("O envio para servidor de backup está desativado.");
    const targetGuildId = String(s.backupGuildId || "");
    if (!/^\d{15,22}$/.test(targetGuildId)) throw new Error("Configure o ID do servidor de backup.");
    if (targetGuildId === (s.primaryGuildId || guildId)) throw new Error("O servidor de backup precisa ser diferente do servidor principal.");
    if (!this.client.guilds.cache.has(targetGuildId)) throw new Error("Adicione este bot ao servidor de backup antes de iniciar o envio.");
    const requested = Math.max(1, Math.min(500, Math.trunc(Number(requestedLimit) || Number(s.backupTransferLimit) || 50)));
    const source = this.members(guildId).filter(m => m.backupEligible && m.scopes.includes("guilds.join") && !m.revoked);
    let joined=0, already=0, skipped=0, failed=0;
    for (const member of source.slice(0, requested)) {
      try {
        const check = await fetch(`${DISCORD_API}/guilds/${targetGuildId}/members/${member.userId}`, { headers:{authorization:`Bot ${this.config.botToken}`}, signal:AbortSignal.timeout(10_000) });
        if (check.ok) { already++; continue; }
        if (check.status !== 404) { failed++; continue; }
        const access = await this.usableGuildJoinToken(guildId, member);
        if (!access) { skipped++; continue; }
        const put = await fetch(`${DISCORD_API}/guilds/${targetGuildId}/members/${member.userId}`, { method:"PUT", headers:{authorization:`Bot ${this.config.botToken}`,"content-type":"application/json"}, body:JSON.stringify({access_token:access}), signal:AbortSignal.timeout(15_000) });
        if (put.ok || [201,204].includes(put.status)) joined++; else failed++;
      } catch { failed++; }
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    this.db.audit(guildId, "ZCLOUD_BACKUP_TRANSFER", "guild", targetGuildId, { requested, eligible:source.length, joined, already, skipped, failed }, guildId);
    return {requested,eligible:source.length,joined,already,skipped,failed,targetGuildId};
  }

  effectivePublicBaseUrl(guildId: string): string {
    const s = this.settings(guildId);
    return normalizeBase(s.publicBaseUrl) || this.managedBaseUrl() || normalizeBase(this.tunnelUrl);
  }

  effectiveRedirectUri(guildId: string): string {
    const s = this.settings(guildId);
    if (isHttpsUrl(s.redirectUri) && !isLocalUrl(s.redirectUri)) return s.redirectUri;
    const base = this.effectivePublicBaseUrl(guildId);
    return base ? `${base}/zcloud/${guildId}/callback` : "";
  }

  private stateSigningSecret(guildId: string): string {
    const existing = this.credentials.get(guildId, "zcloud_state_secret");
    if (existing) return existing;
    const generated = randomBytes(32).toString("hex");
    this.credentials.set(guildId, "zcloud_state_secret", generated);
    return generated;
  }

  private panelState(guildId: string): string {
    const payload = Buffer.from(JSON.stringify({ v: 1, g: guildId, k: "panel" }), "utf8").toString("base64url");
    const signature = createHmac("sha256", this.stateSigningSecret(guildId)).update(payload).digest("base64url");
    return `${payload}.${signature}`;
  }

  private verifyPanelState(guildId: string, state: string): boolean {
    const [payload, signature, extra] = state.split(".");
    if (!payload || !signature || extra) return false;
    const expected = createHmac("sha256", this.stateSigningSecret(guildId)).update(payload).digest("base64url");
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
    try {
      const value = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { v?: number; g?: string; k?: string };
      return value.v === 1 && value.g === guildId && value.k === "panel";
    } catch { return false; }
  }

  private authorizeUrl(guildId: string, state: string): string {
    const s = this.settings(guildId);
    const redirectUri = this.effectiveRedirectUri(guildId);
    if (!this.managerEnabled()) throw new Error("ZCloud está desativado pelo Astra Application Manager.");
    if (!s.enabled || !s.clientId || !redirectUri || !this.secretConfigured(guildId)) {
      throw new Error("ZCloud OAuth ainda não está configurado.");
    }
    const connectedAppId = this.client.application?.id ?? this.client.user?.id;
    if (connectedAppId && s.clientId !== connectedAppId) {
      throw new Error("O Client ID do ZCloud precisa pertencer à mesma aplicação Discord do bot.");
    }
    const q = new URLSearchParams({
      client_id: s.clientId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: (s.allowBackupJoin || s.autoJoinEnabled || s.backupTransferEnabled) ? "identify guilds.join" : "identify",
      state,
      prompt: "consent"
    });
    return `https://discord.com/oauth2/authorize?${q}`;
  }

  /** Link público vai direto ao OAuth oficial do Discord. Assim o usuário não
   * atravessa uma página intermediária antes de ver a tela de autorização.
   * O callback continua sendo servido pelo Reverse Proxy HTTPS da HidenCloud. */
  panelAuthorizeUrl(guildId: string): string {
    if (!this.managerEnabled()) throw new Error("ZCloud está desativado pelo Astra Application Manager.");
    return this.authorizeUrl(guildId, this.panelState(guildId));
  }

  authUrl(guildId: string): string {
    const state = randomBytes(32).toString("hex");
    this.pruneStates();
    this.states.set(state, { guildId, createdAt: Date.now(), used: false });
    return this.authorizeUrl(guildId, state);
  }

  publicStartUrl(guildId: string): string {
    const base = this.effectivePublicBaseUrl(guildId);
    return base ? `${base}/zcloud/${guildId}/auth` : "";
  }

  async test(guildId: string): Promise<string[]> {
    const s = this.settings(guildId);
    const problems: string[] = [];
    const publicBaseUrl = this.effectivePublicBaseUrl(guildId);
    const redirectUri = this.effectiveRedirectUri(guildId);

    if (!/^\d{15,22}$/.test(s.clientId)) problems.push("Client ID inválido");
    const connectedAppId = this.client.application?.id ?? this.client.user?.id;
    if (connectedAppId && s.clientId && s.clientId !== connectedAppId) problems.push("Client ID não pertence à mesma aplicação do bot");
    if (!this.secretConfigured(guildId)) problems.push("Client Secret ausente");
    if (!publicBaseUrl || !isHttpsUrl(publicBaseUrl)) problems.push("URL pública HTTPS indisponível");
    if (!redirectUri || !isHttpsUrl(redirectUri)) problems.push("Redirect URI HTTPS indisponível");
    if (redirectUri && !redirectUri.endsWith(`/zcloud/${guildId}/callback`)) problems.push("Redirect URI não aponta para o callback deste servidor");

    // Não confie apenas no cache: um bot recém-adicionado pode ainda não ter o
    // guild materializado no cache local quando o dono aperta “Testar”. Buscar
    // diretamente no Discord elimina o falso “bot não está no servidor”.
    const guildAvailable = async (targetGuildId: string) => {
      if (!targetGuildId) return false;
      if (this.client.guilds.cache.has(targetGuildId)) return true;
      const fetched = await this.client.guilds.fetch(targetGuildId).catch(() => null);
      return Boolean(fetched?.id);
    };
    if (s.primaryGuildId && !(await guildAvailable(s.primaryGuildId))) problems.push("Bot não está no servidor principal");
    if (s.backupGuildId && !(await guildAvailable(s.backupGuildId))) problems.push("Bot não está no servidor backup");
    if (s.backupTransferEnabled) {
      if (!/^\d{15,22}$/.test(s.backupGuildId)) problems.push("Backup de membros: ID do servidor inválido");
      if (s.backupInviteUrl && !isDiscordInviteUrl(s.backupInviteUrl)) problems.push("Backup de membros: convite inválido");
    }
    if (s.autoJoinEnabled) {
      if (!/^\d{15,22}$/.test(s.autoJoinGuildId)) problems.push("Servidor adicional: ID inválido");
      else if (!(await guildAvailable(s.autoJoinGuildId))) problems.push("Servidor adicional: o bot precisa estar presente nele");
      if (!isDiscordInviteUrl(s.autoJoinInviteUrl)) problems.push("Servidor adicional: link de convite Discord inválido");
    }

    if (s.verificationRoleId) {
      const targetGuildId = s.primaryGuildId || guildId;
      const g = this.client.guilds.cache.get(targetGuildId) ?? await this.client.guilds.fetch(targetGuildId).catch(() => undefined);
      if (g) await g.roles.fetch().catch(() => undefined);
      const r = g?.roles.cache.get(s.verificationRoleId);
      const me = g?.members.me;
      if (!r) problems.push("Cargo de verificação não encontrado");
      else if (me && r.position >= me.roles.highest.position) problems.push("Cargo de verificação está acima/igual ao maior cargo do bot");
    }

    if (!this.managerEnabled()) problems.push("ZCloud está desativado no /botconfig do Manager");
    if (publicBaseUrl && isHttpsUrl(publicBaseUrl)) {
      try {
        const health = await fetch(`${publicBaseUrl}/zcloud/${guildId}/health`, { signal: AbortSignal.timeout(10_000), redirect: "manual" });
        if (!health.ok) problems.push("Reverse Proxy HTTPS do ZCloud não respondeu corretamente");
      } catch { problems.push("Reverse Proxy HTTPS do ZCloud está inacessível"); }
    }

    return [...new Set(problems)];
  }

  start(): void {
    if (this.server) return;
    const port = this.config.zcloudPort;
    this.server = createServer((req, res) => void this.handle(req, res));
    this.server.on("error", (error) => this.logger.error("ZCloud HTTP falhou.", { error: String(error) }));
    this.server.listen(port, "127.0.0.1", () => {
      this.logger.success("ZCloud HTTP local iniciado.", { port });
      if (this.config.zcloudTunnelAuto) void this.startManagedTunnel();
    });

    this.client.once("clientReady", () => void this.registerAllGuilds());
    this.registerTimer = setInterval(() => void this.registerAllGuilds(), REGISTER_INTERVAL_MS);
    this.registerTimer.unref?.();
  }

  stop(): void {
    this.stopping = true;
    if (this.registerTimer) clearInterval(this.registerTimer);
    if (this.tunnelRestartTimer) clearTimeout(this.tunnelRestartTimer);
    this.registerTimer = undefined;
    this.tunnelRestartTimer = undefined;
    try { this.tunnel?.kill("SIGTERM"); } catch {}
    this.tunnel = undefined;
    this.tunnelUrl = "";
    this.gatewayRegisteredGuilds.clear();
    try { this.server?.close(); } catch {}
    this.server = undefined;
  }

  private async startManagedTunnel(): Promise<void> {
    if (this.stopping || this.tunnelStarting || this.tunnel) return;
    const binary = String(this.config.zcloudCloudflaredPath || "").trim();
    if (!binary || !existsSync(binary)) {
      this.logger.warn("ZCloud: cloudflared não está disponível; o bot continua online, mas o site público precisa de um túnel HTTPS.");
      return;
    }
    this.tunnelStarting = true;
    try {
      const child = spawn(binary, ["tunnel", "--no-autoupdate", "--url", `http://127.0.0.1:${this.config.zcloudPort}`], {
        stdio: ["ignore", "pipe", "pipe"],
        env: { PATH: "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", HOME: this.config.databasePath ? process.cwd() : ".", TMPDIR: "/tmp" }
      });
      this.tunnel = child;
      const parse = (chunk: Buffer | string) => {
        const text = String(chunk);
        const match = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
        if (!match) return;
        const next = normalizeBase(match[0]);
        if (!next || next === this.tunnelUrl) return;
        this.tunnelUrl = next;
        this.gatewayRegisteredGuilds.clear();
        this.logger.success("ZCloud Cloudflare Tunnel conectado.");
        void this.registerAllGuilds();
      };
      child.stdout?.on("data", parse);
      child.stderr?.on("data", parse);
      child.once("error", (error) => {
        this.logger.warn("ZCloud Cloudflare Tunnel não pôde ser iniciado.", { error: String(error) });
      });
      child.once("exit", () => {
        if (this.tunnel === child) this.tunnel = undefined;
        this.tunnelUrl = "";
        this.gatewayRegisteredGuilds.clear();
        if (!this.stopping) {
          this.tunnelRestartTimer = setTimeout(() => void this.startManagedTunnel(), 5000);
          this.tunnelRestartTimer.unref?.();
        }
      });
    } finally {
      this.tunnelStarting = false;
    }
  }

  private async registerAllGuilds(): Promise<void> {
    if (this.stopping || !this.tunnelUrl) return;
    const base = this.managedBaseUrl();
    if (!base) {
      // Fallback: sem Supabase, o Quick Tunnel ainda pode ser usado diretamente.
      for (const guildId of this.client.guilds.cache.keys()) {
        const s = this.settings(guildId);
        if (!s.publicBaseUrl || isLocalUrl(s.publicBaseUrl) || isTryCloudflareUrl(s.publicBaseUrl)) {
          s.publicBaseUrl = this.tunnelUrl;
          s.redirectUri = `${this.tunnelUrl}/zcloud/${guildId}/callback`;
          s.updatedAt = nowIso();
        }
      }
      this.db.save();
      return;
    }
    const guildIds = [...this.client.guilds.cache.keys()].filter((id) => /^\d{15,22}$/.test(id));
    if (!guildIds.length) return;
    try {
      const response = await fetch(`${base}/register`, {
        method: "POST",
        headers: {
          authorization: `Bot ${this.config.botToken}`,
          "content-type": "application/json"
        },
        body: JSON.stringify({ guildIds, tunnelUrl: this.tunnelUrl }),
        signal: AbortSignal.timeout(20_000)
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json() as { accepted?: string[] };
      this.gatewayRegisteredGuilds = new Set(Array.isArray(body.accepted) ? body.accepted : []);
      if (this.gatewayRegisteredGuilds.size) this.logger.success("ZCloud rota HTTPS registrada no gateway público.", { guilds: this.gatewayRegisteredGuilds.size });
    } catch (error) {
      this.gatewayRegisteredGuilds.clear();
      this.logger.warn("ZCloud ainda não conseguiu registrar o túnel no gateway Supabase.", { error: String(error) });
    }
  }

  private pruneStates(): void {
    const now = Date.now();
    for (const [key, state] of this.states) if (state.used || now - state.createdAt > STATE_TTL_MS) this.states.delete(key);
  }

  private headers(res: ServerResponse, status = 200, type = "text/html; charset=utf-8"): void {
    res.writeHead(status, {
      "content-type": type,
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
      "referrer-policy": "no-referrer",
      "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; img-src https: data:; script-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'; form-action https://discord.com",
      "cache-control": "no-store"
    });
  }

  private shell(title: string, body: string, redirect = ""): string {
    const safe = (x: string) => this.escape(x);
    const js = redirect ? `<script>let n=7;const e=document.getElementById('count');const t=setInterval(()=>{n--;if(e)e.textContent=String(Math.max(0,n));if(n<=0){clearInterval(t);location.replace(${JSON.stringify(redirect)})}},1000)</script>` : "";
    return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#020204"><title>${safe(title)} • ZCloud</title><style>
:root{color-scheme:dark;--bg:#020204;--card:#08090df2;--card2:#0d0f16;--line:#ffffff12;--text:#f5f7ff;--muted:#8994b3;--brand:#4b63ff;--brand2:#7b4dff;--ok:#22d39a;--bad:#ff5f78}*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:var(--bg)}body{min-height:100dvh;color:var(--text);font:15.5px Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;overflow-x:hidden;background-image:radial-gradient(circle at 50% -10%,#5265ff2a,transparent 34rem),linear-gradient(#4b63ff08 1px,transparent 1px),linear-gradient(90deg,#4b63ff08 1px,transparent 1px);background-size:auto,42px 42px,42px 42px}.page{min-height:100dvh;display:flex;flex-direction:column;align-items:center;padding:clamp(22px,5vw,54px) 18px 24px}.brand{display:flex;align-items:center;gap:11px;padding:8px 13px;border:1px solid var(--line);background:#08090de8;backdrop-filter:blur(14px);border-radius:999px;box-shadow:0 15px 50px #0005;margin-bottom:clamp(42px,10vh,90px)}.mark{width:31px;height:31px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(145deg,var(--brand),var(--brand2));box-shadow:0 0 30px #5265ff66;font-weight:900}.brand b{font-size:14px;letter-spacing:.1px}.brand span{color:#92a0ca}.shell{width:min(100%,650px)}.card{position:relative;overflow:hidden;padding:clamp(24px,5vw,38px);border:1px solid #ffffff17;border-radius:28px;background:linear-gradient(180deg,#0b0d13f7,#050609fb);box-shadow:0 35px 100px #000a,0 0 70px #4b63ff13}.card:before{content:"";position:absolute;inset:-1px;pointer-events:none;background:linear-gradient(120deg,#6b7cff24,transparent 25%,transparent 70%,#8b54ff1b);mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);padding:1px;border-radius:inherit}.eyebrow{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border-radius:10px;background:#4b63ff13;border:1px solid #6077ff26;color:#aebaff;font-weight:800;font-size:12px;letter-spacing:.12em;text-transform:uppercase}.eyebrow i{width:7px;height:7px;border-radius:50%;background:var(--brand);box-shadow:0 0 14px #6277ff}.hero{display:flex;gap:18px;align-items:center;margin:22px 0 12px}.avatar{width:82px;height:82px;flex:0 0 82px;border-radius:50%;object-fit:cover;border:3px solid #6577ff55;box-shadow:0 0 0 7px #4b63ff0c,0 0 34px #4b63ff30}.avatar-placeholder{width:82px;height:82px;flex:0 0 82px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(145deg,#18223e,#27386c);border:3px solid #6577ff3b;font-size:30px}.hero-copy{min-width:0}h1{font-size:clamp(25px,6vw,34px);line-height:1.12;margin:0 0 9px;letter-spacing:-.035em}h2{font-size:18px;margin:0 0 8px}p{margin:8px 0;color:#aab4d0;line-height:1.62}.muted{color:var(--muted)}.ok{color:var(--ok)}.bad{color:var(--bad)}.notice{margin:20px 0 0;padding:14px 15px;border:1px solid #ffffff12;border-radius:14px;background:#ffffff07;color:#9ca8c7}.notice.okbox{border-color:#22d39a2f;background:#22d39a0d}.notice.badbox{border-color:#ff5f7838;background:#ff5f780d}.btns{display:grid;gap:10px;margin-top:22px}.btn{display:flex;justify-content:center;align-items:center;gap:9px;text-align:center;padding:14px 16px;border:1px solid #ffffff12;border-radius:13px;background:linear-gradient(135deg,var(--brand),var(--brand2));color:white;text-decoration:none;font-weight:850;box-shadow:0 12px 28px #4b63ff2a;transition:.18s transform,.18s filter}.btn:hover{transform:translateY(-1px);filter:brightness(1.08)}.btn.secondary{background:#ffffff08;box-shadow:none;color:#d7def5}.count{display:inline-grid;place-items:center;min-width:27px;height:27px;padding:0 7px;border-radius:9px;background:#ffffff0d;color:#fff;font-weight:900}.foot{margin-top:auto;padding-top:28px;color:#606b88;text-align:center;font-size:12.5px}@media(max-width:520px){.brand{margin-bottom:36px}.card{border-radius:22px}.hero{align-items:flex-start}.avatar,.avatar-placeholder{width:68px;height:68px;flex-basis:68px}h1{font-size:27px}}
</style></head><body><div class="page"><div class="brand"><div class="mark">Z</div><div><b>ZCloud</b></div></div><div class="shell"><main class="card">${body}</main></div><div class="foot">Autorização segura via Discord OAuth2</div></div>${js}</body></html>`;
  }

  private loadingStart(): string {
    return `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#020204"><title>ZCloud Auth</title><style>
:root{color-scheme:dark;--bg:#020204;--text:#f5f7ff;--muted:#6f7b9b;--brand:#4b63ff;--brand2:#7b4dff;--ok:#22d39a;--bad:#ff5f78}*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:var(--bg)}body{min-height:100dvh;color:var(--text);font:15.5px Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background-image:radial-gradient(circle at 50% 3%,#5066ff24,transparent 35rem),linear-gradient(#4b63ff07 1px,transparent 1px),linear-gradient(90deg,#4b63ff07 1px,transparent 1px);background-size:auto,44px 44px,44px 44px}.page{min-height:100dvh;display:flex;flex-direction:column;align-items:center;padding:clamp(22px,5vw,50px) 18px 24px}.brand{display:flex;align-items:center;gap:11px;padding:8px 13px;border:1px solid #ffffff12;background:#08090def;backdrop-filter:blur(14px);border-radius:999px;margin-bottom:clamp(42px,10vh,86px)}.mark{width:31px;height:31px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(145deg,var(--brand),var(--brand2));box-shadow:0 0 30px #5265ff66;font-weight:900}.brand span{color:#92a0ca}.shell{width:min(100%,650px)}.card{position:relative;overflow:hidden;padding:clamp(26px,5vw,40px);border:1px solid #ffffff17;border-radius:28px;background:linear-gradient(180deg,#0b0d13f8,#050609fb);box-shadow:0 35px 100px #000a,0 0 80px #4b63ff12}.orb-wrap{display:grid;place-items:center;margin-bottom:24px}.orb{position:relative;width:94px;height:94px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 35% 28%,#7a8bff,#4b63ff 45%,#2d3fa6);box-shadow:0 0 0 10px #4b63ff0d,0 0 65px #4b63ff55;font-size:31px;font-weight:900}.orb:before,.orb:after{content:"";position:absolute;border:1px solid #6b7dff73;border-radius:50%;animation:spin 5s linear infinite}.orb:before{inset:-15px;border-left-color:transparent}.orb:after{inset:-27px;border-right-color:transparent;animation-direction:reverse;animation-duration:8s}@keyframes spin{to{transform:rotate(360deg)}}.title{text-align:center}.title small{display:block;color:#8fa3ff;font-weight:850;letter-spacing:.28em;font-size:12px}.title h1{font-size:27px;margin:10px 0 8px;letter-spacing:-.03em}.title p{margin:0;color:#7d89a8}.progress{height:3px;background:#ffffff0a;border-radius:999px;overflow:hidden;margin:28px 0 24px}.bar{height:100%;width:0%;background:linear-gradient(90deg,var(--brand),#37d6b3);box-shadow:0 0 14px #4b63ff;transition:width .35s ease}.steps{display:grid;gap:15px}.step{display:grid;grid-template-columns:24px 1fr;gap:11px;align-items:center;color:#596681;transition:.25s color}.dot{width:11px;height:11px;margin-left:6px;border-radius:50%;background:#2b3348;box-shadow:inset 0 0 0 1px #ffffff0a}.step.active{color:#f5f7ff}.step.active .dot{background:var(--ok);box-shadow:0 0 16px #22d39a99}.step.done{color:#9da9c8}.step.done .dot{background:var(--brand);box-shadow:0 0 12px #4b63ff77}.result{margin-top:26px;padding-top:24px;border-top:1px solid #ffffff10}.eyebrow{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border-radius:10px;background:#4b63ff13;border:1px solid #6077ff26;color:#aebaff;font-weight:800;font-size:12px;letter-spacing:.12em;text-transform:uppercase;margin-bottom:16px}.eyebrow i{width:7px;height:7px;border-radius:50%;background:var(--brand);box-shadow:0 0 14px #6277ff}.hero{display:flex;align-items:center;gap:15px;margin:4px 0 12px}.hero-copy{min-width:0}.hero-copy h2{margin-bottom:6px}h2{font-size:25px;margin:0 0 10px}.ok{color:var(--ok)}.bad{color:var(--bad)}p{color:#aab4d0;line-height:1.62}.muted{color:#7d89a8}.avatar{width:74px;height:74px;border-radius:50%;object-fit:cover;border:3px solid #6577ff55;box-shadow:0 0 30px #4b63ff2c;margin:4px 0 12px}.btn{display:flex;justify-content:center;align-items:center;text-align:center;margin-top:12px;padding:14px 16px;border-radius:13px;background:linear-gradient(135deg,var(--brand),var(--brand2));color:#fff;text-decoration:none;font-weight:850;border:1px solid #ffffff12}.btn.secondary{background:#ffffff08;color:#d7def5}.foot{margin-top:auto;padding-top:28px;color:#606b88;text-align:center;font-size:12.5px}@media(max-width:520px){.brand{margin-bottom:36px}.card{border-radius:22px}}
</style></head><body><div class="page"><div class="brand"><div class="mark">Z</div><div><b>ZCloud</b></div></div><div class="shell"><main class="card"><div class="orb-wrap"><div class="orb">Z</div></div><div class="title"><small>ZCLOUD AUTH</small><h1>Sincronizando seu acesso</h1><p>Concluindo a autorização com segurança.</p></div><div class="progress"><div id="bar" class="bar"></div></div><div class="steps"><div id="s1" class="step"><span class="dot"></span><span>Conectando ao Discord</span></div><div id="s2" class="step"><span class="dot"></span><span>Validando autorização</span></div><div id="s3" class="step"><span class="dot"></span><span>Verificando usuário</span></div><div id="s4" class="step"><span class="dot"></span><span>Sincronizando acesso</span></div></div><div id="result" class="result" hidden></div></main></div><div class="foot">Não feche esta janela durante a verificação.</div></div><script>let visibleStage=0,pendingStage=0,stageBusy=false;const widths=[0,14,39,67,90];function renderStage(n){for(let i=1;i<=4;i++){const e=document.getElementById('s'+i);e.className='step '+(i<n?'done':i===n?'active':'')}const b=document.getElementById('bar');if(b)b.style.width=String(widths[n]||0)+'%'}function pumpStage(){if(stageBusy||visibleStage>=pendingStage)return;stageBusy=true;const delay=visibleStage===0?280:360;setTimeout(()=>{visibleStage++;renderStage(visibleStage);stageBusy=false;pumpStage()},delay)}function queueStage(n){pendingStage=Math.max(pendingStage,Math.min(4,Number(n)||0));pumpStage()}function finish(html){pendingStage=4;const wait=()=>{if(visibleStage<4){pumpStage();return setTimeout(wait,180)}for(let i=1;i<=4;i++)document.getElementById('s'+i).className='step done';const b=document.getElementById('bar');if(b)b.style.width='100%';const r=document.getElementById('result');r.hidden=false;r.innerHTML=html};wait()}</script>`;
  }

  private writeStage(res: ServerResponse, stage: number): void {
    res.write(`<script>queueStage(${stage})</script>`);
  }

  private finishStream(res: ServerResponse, bodyHtml: string, redirect = ""): void {
    const countdown = redirect ? `let n=7;const e=document.getElementById('count');const t=setInterval(()=>{n--;if(e)e.textContent=String(Math.max(0,n));if(n<=0){clearInterval(t);location.href=${JSON.stringify(redirect)}}},1000);` : "";
    const reveal = `setTimeout(()=>{finish(${JSON.stringify(bodyHtml)});${countdown}},350);`;
    res.end(`<script>${reveal}</script></body></html>`);
  }

  private async handle(req: any, res: ServerResponse): Promise<void> {
    try {
      const url = new URL(req.url || "/", "http://localhost");
      if (url.pathname === "/health") {
        this.headers(res, 200, "application/json; charset=utf-8");
        res.end(JSON.stringify({ status: "ok", service: "zcloud-auth", managerEnabled: this.managerEnabled(), publicBaseUrl: Boolean(this.effectivePublicBaseUrl(this.config.guildId || "")) })); return;
      }
      const m = url.pathname.match(/^\/zcloud\/(\d{15,22})\/(auth|callback|health)$/);
      if (!m) {
        this.headers(res, 404);
        res.end(this.shell("ZCloud", "<h1>Rota não encontrada</h1><p>O link de verificação não é válido.</p>")); return;
      }
      const guildId = m[1]!;
      const action = m[2]!;
      if (action === "health") {
        this.headers(res, 200, "application/json; charset=utf-8");
        res.end(JSON.stringify({ status: "ok", guildId, managerEnabled: this.managerEnabled() })); return;
      }
      if (!this.managerEnabled()) {
        this.headers(res, 503);
        res.end(this.shell("ZCloud desativado", `<div class="eyebrow"><i></i>RECURSO PAUSADO</div><h1>ZCloud desativado</h1><p>A verificação foi desativada pelo administrador do Astra Application Manager. Nenhuma autorização foi iniciada.</p>`)); return;
      }
      if (action === "auth") {
        const location = this.authUrl(guildId);
        res.writeHead(302, { location, "cache-control": "no-store" });
        res.end(); return;
      }
      await this.handleCallback(guildId, url, res); return;
    } catch (error) {
      this.logger.warn("ZCloud HTTP falhou.", { error: error instanceof Error ? error.message : String(error) });
      if (!res.headersSent) this.headers(res, 400);
      if (!res.writableEnded) res.end(this.shell("Falha na verificação", `<h1 class="bad">Não foi possível concluir a verificação</h1><p>${this.escape(this.userMessage(error))}</p>`));
    }
  }

  private async handleCallback(guildId: string, url: URL, res: ServerResponse): Promise<void> {
    const s = this.settings(guildId);
    if (!this.managerEnabled()) {
      this.headers(res, 503);
      res.end(this.shell("ZCloud desativado", `<div class="eyebrow"><i></i>RECURSO PAUSADO</div><h1>ZCloud desativado</h1><p>A verificação foi desativada pelo administrador. Nenhum token foi trocado ou salvo.</p><div class="btns"><a class="btn secondary" href="${this.escape(s.discordReturnUrl)}">Voltar para o Discord</a></div>`));
      return;
    }
    const oauthError = url.searchParams.get("error");
    if (oauthError) {
      this.headers(res, 400);
      const retry = (() => { try { return this.panelAuthorizeUrl(guildId); } catch { return this.publicStartUrl(guildId); } })();
      res.end(this.shell("Verificação não concluída", `<div class="eyebrow"><i></i>OAUTH CANCELADO</div><h1 class="bad">Não foi possível concluir</h1><p>A autorização do Discord foi cancelada ou recusada. Nenhuma verificação foi registrada.</p><div class="btns">${retry ? `<a class="btn" href="${this.escape(retry)}">Tentar novamente</a>` : ""}<a class="btn secondary" href="${this.escape(s.discordReturnUrl)}">Voltar para o Discord</a></div>`)); return;
    }

    const state = url.searchParams.get("state") || "";
    const code = url.searchParams.get("code") || "";
    const st = this.states.get(state);
    const transientStateValid = Boolean(st && st.guildId === guildId && !st.used && Date.now() - st.createdAt <= STATE_TTL_MS);
    const publishedPanelStateValid = this.verifyPanelState(guildId, state);
    if (!transientStateValid && !publishedPanelStateValid) {
      throw new Error("Esta sessão de verificação é inválida ou expirou. Inicie a verificação novamente.");
    }
    if (st && transientStateValid) { st.used = true; this.states.delete(state); }
    if (!code) throw new Error("O Discord não retornou o código de autorização.");

    this.headers(res, 200);
    res.write(this.loadingStart());
    try {
      const secret = this.credentials.get(guildId, "zcloud_client_secret");
      if (!secret) throw new Error("Client Secret não configurado.");
      const redirectUri = this.effectiveRedirectUri(guildId);
      if (!redirectUri) throw new Error("Redirect URI pública não configurada.");

      this.writeStage(res, 1);
      const form = new URLSearchParams({
        client_id: s.clientId,
        client_secret: secret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri
      });
      const tokenResponse = await fetch(`${DISCORD_API}/oauth2/token`, {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: form,
        signal: AbortSignal.timeout(15_000)
      });
      if (!tokenResponse.ok) throw new Error("O Discord recusou a troca do código OAuth. Confirme o Client Secret e o Redirect URI cadastrado no Developer Portal.");
      const tok = await tokenResponse.json() as OAuthTokenResponse;
      if (!tok.access_token) throw new Error("O Discord não retornou um access token válido.");

      this.writeStage(res, 2);
      const userResponse = await fetch(`${DISCORD_API}/users/@me`, {
        headers: { authorization: `Bearer ${tok.access_token}` },
        signal: AbortSignal.timeout(10_000)
      });
      if (!userResponse.ok) throw new Error("Não foi possível identificar a conta Discord autorizada.");
      const user = await userResponse.json() as DiscordUser;
      if (!/^\d{15,22}$/.test(user.id)) throw new Error("A identidade retornada pelo Discord é inválida.");

      this.writeStage(res, 3);
      const key = `${guildId}:${user.id}`;
      const existing = this.db.state.zcloudMembers[key];
      const alreadyVerified = Boolean(existing && !existing.revoked);
      const scopes = String(tok.scope || "").split(/\s+/).filter(Boolean);

      const primaryGuildId = s.primaryGuildId || guildId;
      let memberExists = false;
      const memberCheck = await fetch(`${DISCORD_API}/guilds/${primaryGuildId}/members/${user.id}`, {
        headers: { authorization: `Bot ${this.config.botToken}` },
        signal: AbortSignal.timeout(10_000)
      });
      memberExists = memberCheck.ok;
      if (!memberExists && memberCheck.status === 404 && scopes.includes("guilds.join")) {
        const join = await fetch(`${DISCORD_API}/guilds/${primaryGuildId}/members/${user.id}`, {
          method: "PUT",
          headers: { authorization: `Bot ${this.config.botToken}`, "content-type": "application/json" },
          body: JSON.stringify({ access_token: tok.access_token }),
          signal: AbortSignal.timeout(15_000)
        });
        memberExists = join.ok || [201, 204].includes(join.status);
      }
      if (!memberExists) throw new Error("Sua conta não pôde ser sincronizada com o servidor. Confirme que você ainda está no servidor e tente novamente.");

      this.writeStage(res, 4);
      let roleGranted = !s.verificationRoleId;
      if (s.verificationRoleId) {
        const rr = await fetch(`${DISCORD_API}/guilds/${primaryGuildId}/members/${user.id}/roles/${s.verificationRoleId}`, {
          method: "PUT",
          headers: { authorization: `Bot ${this.config.botToken}` },
          signal: AbortSignal.timeout(10_000)
        });
        roleGranted = rr.ok;
        if (s.requireRole && !rr.ok) throw new Error("O cargo obrigatório não pôde ser aplicado. Um administrador precisa conferir a hierarquia e a permissão Manage Roles.");
      }

      let autoJoinGranted = false;
      if (s.autoJoinEnabled) {
        if (!scopes.includes("guilds.join")) throw new Error("A autorização não concedeu o escopo necessário para adicionar sua conta ao servidor configurado. Tente autorizar novamente.");
        const targetGuildId = s.autoJoinGuildId;
        if (!/^\d{15,22}$/.test(targetGuildId) || !this.client.guilds.cache.has(targetGuildId)) throw new Error("O servidor adicional configurado está indisponível. Um administrador precisa revisar o ZCloud.");
        if (targetGuildId === primaryGuildId) {
          autoJoinGranted = memberExists;
        } else {
          const targetCheck = await fetch(`${DISCORD_API}/guilds/${targetGuildId}/members/${user.id}`, {
            headers: { authorization: `Bot ${this.config.botToken}` },
            signal: AbortSignal.timeout(10_000)
          });
          if (targetCheck.ok) autoJoinGranted = true;
          else if (targetCheck.status === 404) {
            const targetJoin = await fetch(`${DISCORD_API}/guilds/${targetGuildId}/members/${user.id}`, {
              method: "PUT",
              headers: { authorization: `Bot ${this.config.botToken}`, "content-type": "application/json" },
              body: JSON.stringify({ access_token: tok.access_token }),
              signal: AbortSignal.timeout(15_000)
            });
            autoJoinGranted = targetJoin.ok || [201, 204].includes(targetJoin.status);
          }
        }
        if (!autoJoinGranted) throw new Error("Não foi possível adicionar sua conta ao servidor adicional configurado. Tente novamente ou use o convite disponibilizado pelo administrador.");
      }

      this.credentials.set(guildId, `zcloud_access_${user.id}`, tok.access_token);
      if (tok.refresh_token) this.credentials.set(guildId, `zcloud_refresh_${user.id}`, tok.refresh_token);
      const member: ZCloudVerifiedMember = {
        guildId,
        userId: user.id,
        username: user.username,
        displayName: user.global_name || user.username,
        avatar: user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png` : "",
        verifiedAt: existing?.verifiedAt || nowIso(),
        updatedAt: nowIso(),
        scopes,
        tokenExpiresAt: new Date(Date.now() + Number(tok.expires_in || 0) * 1000).toISOString(),
        revoked: false,
        roleGranted,
        backupEligible: scopes.includes("guilds.join"),
        autoJoinGuildId: s.autoJoinEnabled ? s.autoJoinGuildId : "",
        autoJoinGranted
      };
      this.db.state.zcloudMembers[key] = member;
      this.db.save();
      this.db.audit(user.id, alreadyVerified ? "ZCLOUD_ALREADY_VERIFIED" : "ZCLOUD_AUTH_SUCCESS", "user", user.id, { scopes, roleGranted, autoJoinGranted, autoJoinGuildId: s.autoJoinEnabled ? s.autoJoinGuildId : "" }, guildId);

      const avatar = member.avatar ? `<img class="avatar" src="${this.escape(member.avatar)}" alt="Avatar Discord">` : "";
      const title = alreadyVerified ? "Conta já verificada" : "Verificação concluída";
      const description = alreadyVerified ? "Sua autorização foi atualizada e seu acesso continua ativo." : "Sua conta foi validada e o acesso ao servidor foi sincronizado.";
      const guildName = this.client.guilds.cache.get(primaryGuildId)?.name || "servidor Discord";
      const roleText = s.verificationRoleId && roleGranted ? `<p class="muted">Cargo de verificação aplicado com sucesso.</p>` : "";
      const targetGuildName = s.autoJoinEnabled && autoJoinGranted ? (this.client.guilds.cache.get(s.autoJoinGuildId)?.name || "servidor adicional") : "";
      const targetText = targetGuildName ? `<div class="notice okbox">Sua conta também foi adicionada a <b>${this.escape(targetGuildName)}</b>.</div>` : "";
      const body = `<div class="eyebrow"><i></i>${alreadyVerified ? "ACESSO JÁ ATIVO" : "AUTORIZAÇÃO CONCLUÍDA"}</div><div class="hero">${avatar}<div class="hero-copy"><h2 class="ok">${this.escape(title)}</h2><p><b>${this.escape(member.displayName)}</b><br><span class="muted">@${this.escape(member.username)}</span></p></div></div><p>${this.escape(description)}</p><p>Servidor: <b>${this.escape(guildName)}</b></p>${roleText}${targetText}<p>Voltando para o Discord em <b id="count">7</b> segundos...</p><a class="btn" href="${this.escape(s.discordReturnUrl)}">Voltar para o Discord</a>`;
      this.finishStream(res, body, s.discordReturnUrl); return;
    } catch (error) {
      this.logger.warn("ZCloud OAuth falhou.", { guildId, error: error instanceof Error ? error.message : String(error) });
      const retry = (() => { try { return this.panelAuthorizeUrl(guildId); } catch { return this.publicStartUrl(guildId); } })();
      const fallbackInvite = s.autoJoinEnabled && isDiscordInviteUrl(s.autoJoinInviteUrl) ? `<a class="btn secondary" href="${this.escape(s.autoJoinInviteUrl)}">Abrir convite do servidor</a>` : "";
      const body = `<div class="eyebrow"><i></i>VERIFICAÇÃO INTERROMPIDA</div><h2 class="bad">Não foi possível concluir a verificação</h2><p>${this.escape(this.userMessage(error))}</p>${retry ? `<a class="btn" href="${this.escape(retry)}">Tentar novamente</a>` : ""}${fallbackInvite}<a class="btn secondary" href="${this.escape(s.discordReturnUrl)}">Voltar para o Discord</a>`;
      this.finishStream(res, body); return;
    }
  }

  private userMessage(error: unknown): string {
    const raw = error instanceof Error ? error.message : "Falha inesperada na verificação.";
    return raw.replace(/[\r\n]/g, " ").slice(0, 500);
  }

  private escape(x: string): string {
    return String(x || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
  }
}
