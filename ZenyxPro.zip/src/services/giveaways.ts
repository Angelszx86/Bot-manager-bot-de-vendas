import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Client, EmbedBuilder, TextChannel } from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { EmojiManager } from "../emojis/manager.js";
import type { Giveaway } from "../types.js";
import { colorNumber, makeId, nowIso, truncate } from "../core/utils.js";

const displayBrandNameSafe = (value: unknown, fallback = "Astra Application") => {
  const normalized = String(value ?? "").trim();
  if (!normalized || /^(minha aplica[cç][aã]o|my application)$/i.test(normalized)) return fallback;
  return normalized.length <= 80 ? normalized : `${normalized.slice(0, 79)}…`;
};

export class GiveawayService {
  private timer?: NodeJS.Timeout;
  constructor(private readonly client: Client, private readonly db: JsonDatabase, private readonly emojis: EmojiManager) {}
  private activeEmbed(giveaway: Giveaway) {
    const brand = this.db.brand(giveaway.guildId);
    const embed = new EmbedBuilder()
      .setTitle(`${this.emojis.text("giveaway", giveaway.guildId)} Sorteio • ${giveaway.prize}`)
      .setDescription(`${giveaway.description?.trim() ? `${giveaway.description.trim()}\n\n` : ""}**Prêmio:** ${giveaway.prize}\n**Vencedores:** ${giveaway.winnersCount}\n**Termina:** <t:${Math.floor(Date.parse(giveaway.endsAt) / 1000)}:R>\n**Participantes:** ${giveaway.entries.length}\n\n-# Clique em Participar para entrar ou em Sair do sorteio para remover sua participação.`)
      .setTimestamp(new Date(giveaway.endsAt));
    if (brand.showAccentColors) embed.setColor(colorNumber(brand.color));
    if (brand.logoUrl) embed.setThumbnail(brand.logoUrl);
    if (brand.bannerUrl) embed.setImage(brand.bannerUrl);
    return embed;
  }
  private activeRow(giveaway: Giveaway) {
    const join = new ButtonBuilder().setCustomId(`giveaway:join:${giveaway.id}`).setLabel("Participar").setStyle(ButtonStyle.Success);
    const emoji = this.emojis.component("giveaway", giveaway.guildId);
    if (typeof emoji !== "string" || emoji.trim()) join.setEmoji(emoji);
    return new ActionRowBuilder<ButtonBuilder>().addComponents(
      join,
      new ButtonBuilder().setCustomId(`giveaway:leave:${giveaway.id}`).setLabel("Sair do sorteio").setStyle(ButtonStyle.Secondary)
    );
  }
  async create(input: { guildId: string; channelId: string; prize: string; description?: string; winnerDmPrize?: string; winnersCount: number; endsAt: string; actorId: string }): Promise<Giveaway> {
    const channel = await this.client.channels.fetch(input.channelId); if (!(channel instanceof TextChannel)) throw new Error("Canal inválido.");
    const draft: Giveaway = { id: makeId("GVW"), guildId: input.guildId, channelId: input.channelId, messageId: "", prize: input.prize.slice(0, 200), description: String(input.description || "").slice(0, 1200), winnerDmPrize: String(input.winnerDmPrize || "").slice(0, 1800), winnersCount: Math.max(1, Math.min(20, input.winnersCount)), endsAt: input.endsAt, entries: [], status: "ACTIVE", createdBy: input.actorId, createdAt: nowIso() };
    const message = await channel.send({ embeds: [this.activeEmbed(draft)], components: [this.activeRow(draft)] }); draft.messageId = message.id;
    this.db.state.giveaways[draft.id] = draft; this.db.audit(input.actorId, "GIVEAWAY_CREATE", "giveaway", draft.id); this.db.save(); return draft;
  }
  join(id: string, userId: string): { count: number; already: boolean } {
    const giveaway = this.db.state.giveaways[id]; if (!giveaway || giveaway.status !== "ACTIVE") throw new Error("Sorteio encerrado.");
    giveaway.entries = [...new Set(giveaway.entries.map(String))];
    if (giveaway.entries.includes(userId)) return { count: giveaway.entries.length, already: true };
    giveaway.entries.push(userId);
    this.db.save();
    return { count: giveaway.entries.length, already: false };
  }
  leave(id: string, userId: string): { count: number; removed: boolean } {
    const giveaway = this.db.state.giveaways[id]; if (!giveaway || giveaway.status !== "ACTIVE") throw new Error("Sorteio encerrado.");
    giveaway.entries = [...new Set(giveaway.entries.map(String))];
    const before = giveaway.entries.length;
    giveaway.entries = giveaway.entries.filter((entry) => entry !== userId);
    if (giveaway.entries.length !== before) this.db.save();
    return { count: giveaway.entries.length, removed: giveaway.entries.length !== before };
  }
  async refresh(id: string): Promise<number> {
    const giveaway = this.db.state.giveaways[id];
    if (!giveaway) throw new Error("Sorteio não encontrado.");
    giveaway.entries = [...new Set(giveaway.entries.map(String))];
    const channel = await this.client.channels.fetch(giveaway.channelId).catch(() => undefined);
    if (!(channel instanceof TextChannel)) return giveaway.entries.length;
    const message = await channel.messages.fetch(giveaway.messageId).catch(() => undefined);
    if (!message) return giveaway.entries.length;
    if (giveaway.status === "ACTIVE") await message.edit({ embeds: [this.activeEmbed(giveaway)], components: [this.activeRow(giveaway)] });
    return giveaway.entries.length;
  }
  start() { this.stop(); this.timer = setInterval(() => void this.check(), 15000); this.timer.unref?.(); setTimeout(() => void this.check(), 5000).unref?.(); }
  stop() { if (this.timer) clearInterval(this.timer); this.timer = undefined; }
  async check() { for (const giveaway of Object.values(this.db.state.giveaways)) if (giveaway.status === "ACTIVE" && Date.parse(giveaway.endsAt) <= Date.now()) await this.end(giveaway.id).catch(() => undefined); }
  async end(id: string): Promise<string[]> {
    const giveaway = this.db.state.giveaways[id]; if (!giveaway || giveaway.status !== "ACTIVE") return [];
    const pool = [...giveaway.entries]; const winners: string[] = [];
    while (pool.length && winners.length < giveaway.winnersCount) winners.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]!);
    giveaway.status = "ENDED"; this.db.save();
    const channel = await this.client.channels.fetch(giveaway.channelId).catch(() => undefined);
    if (channel instanceof TextChannel) {
      const message = await channel.messages.fetch(giveaway.messageId).catch(() => undefined);
      const description = winners.length ? `**Prêmio:** ${giveaway.prize}\n**Vencedor(es):** ${winners.map((u) => `<@${u}>`).join(", ")}\n**Participantes:** ${giveaway.entries.length}` : `**Prêmio:** ${giveaway.prize}\nNenhum participante válido.`;
      await message?.edit({ embeds: [new EmbedBuilder().setTitle("Sorteio encerrado").setDescription(description).setTimestamp()], components: [] });
      if (winners.length) await channel.send(`Parabéns, ${winners.map((u) => `<@${u}>`).join(", ")}! Você venceu **${giveaway.prize}**.`);
    }
    if (winners.length && giveaway.winnerDmPrize?.trim()) {
      for (const userId of winners) {
        const user = await this.client.users.fetch(userId).catch(() => undefined);
        if (!user) continue;
        const giveawayBrand = this.db.brand(giveaway.guildId);
        const winnerDm = new EmbedBuilder()
          .setAuthor({ name: displayBrandNameSafe(giveawayBrand.name, this.client.user?.username || "Astra Application"), iconURL: this.client.user?.displayAvatarURL() })
          .setTitle(`${this.emojis.text("giveaway", giveaway.guildId)} Você venceu o sorteio`)
          .setDescription("Sua participação foi selecionada como vencedora.")
          .addFields(
            { name: "Prêmio", value: `**${truncate(giveaway.prize, 220)}**`, inline: false },
            { name: "Entrega", value: truncate(giveaway.winnerDmPrize.trim() || "Entre em contato com a equipe para receber seu prêmio.", 700), inline: false },
            { name: "Status", value: "Vencedor confirmado", inline: true },
            { name: "Sorteio", value: `\`${giveaway.id}\``, inline: true }
          )
          .setThumbnail(user.displayAvatarURL())
          .setFooter({ text: "Parabéns • guarde esta mensagem" })
          .setTimestamp();
        if (giveawayBrand.showAccentColors) winnerDm.setColor(colorNumber(giveawayBrand.color));
        await user.send({ embeds: [winnerDm] }).catch(() => undefined);
      }
    }
    return winners;
  }
}
