import { ChannelType, Client, PermissionFlagsBits } from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { Logger } from "../core/logger.js";

type VoiceLib = {
  joinVoiceChannel(options: Record<string, unknown>): any;
  getVoiceConnection(guildId: string): any;
  entersState(connection: any, status: unknown, timeout: number): Promise<any>;
  VoiceConnectionStatus: { Ready: unknown; Disconnected: unknown; Destroyed: unknown; Signalling?: unknown; Connecting?: unknown };
};

let cachedVoice: VoiceLib | null = null;
function voiceLib(): VoiceLib {
  if (cachedVoice) return cachedVoice;
  try {
    // require é intencional: instalações antigas continuam iniciando e o Manager
    // instala a dependência antes de ativar o recurso de voz.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    cachedVoice = require("@discordjs/voice") as VoiceLib;
    return cachedVoice;
  } catch {
    throw new Error("O módulo @discordjs/voice não está instalado nesta aplicação. Reinicie pelo Manager para concluir a atualização das dependências.");
  }
}

export class VoiceService {
  private restoring = false;
  private keepaliveTimer?: NodeJS.Timeout;
  private readonly reconnectTimers = new Map<string, NodeJS.Timeout>();
  private readonly connecting = new Map<string, Promise<void>>();
  private readonly desiredTargets = new Map<string, string>();
  private readonly forceTargets = new Set<string>();
  private readonly attached = new WeakSet<object>();
  private readonly suppressReconnect = new Set<string>();
  private readonly retryCount = new Map<string, number>();

  constructor(private readonly client: Client, private readonly db: JsonDatabase, private readonly logger: Logger) {}

  settings(guildId: string) {
    return this.db.guild(guildId).voiceConnection;
  }

  private connection(guildId: string): any | undefined {
    try { return voiceLib().getVoiceConnection(guildId); } catch { return undefined; }
  }

  private isReady(connection: any): boolean {
    if (!connection) return false;
    try { return connection.state?.status === voiceLib().VoiceConnectionStatus.Ready; } catch { return false; }
  }

  status(guildId: string) {
    const cfg = this.settings(guildId);
    const connection = this.connection(guildId);
    const actualChannelId = String(connection?.joinConfig?.channelId ?? "");
    return {
      ...cfg,
      connected: this.isReady(connection),
      connecting: Boolean(this.connecting.get(guildId)),
      actualChannelId
    };
  }

  private persistDesired(guildId: string, channelId: string): void {
    this.db.updateGuild(guildId, (settings) => {
      settings.voiceConnection = {
        enabled: true,
        channelId,
        selfDeaf: true,
        selfMute: true,
        reconnect: true,
        updatedAt: new Date().toISOString()
      };
    });
  }

  private clearReconnect(guildId: string): void {
    const timer = this.reconnectTimers.get(guildId);
    if (timer) clearTimeout(timer);
    this.reconnectTimers.delete(guildId);
  }

  private scheduleReconnect(guildId: string, reason = "voice-disconnected"): void {
    const cfg = this.settings(guildId);
    if (!cfg.enabled || !cfg.channelId || this.suppressReconnect.has(guildId)) return;
    if (this.reconnectTimers.has(guildId) || this.connecting.has(guildId)) return;

    const attempt = Math.min(8, (this.retryCount.get(guildId) ?? 0) + 1);
    this.retryCount.set(guildId, attempt);
    const delay = Math.min(30_000, 1_500 * Math.pow(1.65, attempt - 1));
    const timer = setTimeout(() => {
      this.reconnectTimers.delete(guildId);
      const latest = this.settings(guildId);
      if (!latest.enabled || !latest.channelId) return;
      const live = this.connection(guildId);
      const liveChannelId = String(live?.joinConfig?.channelId ?? "");
      // VoiceStateUpdate pode chegar atrasado depois de uma troca bem-sucedida.
      // Não derrube/reconecte uma sessão que já está Ready no destino correto.
      if (this.isReady(live) && liveChannelId === latest.channelId) {
        this.retryCount.set(guildId, 0);
        return;
      }
      void this.connect(guildId, latest.channelId, true).catch((error) => {
        this.logger.warn("Falha ao manter o bot na call; nova tentativa será feita automaticamente.", { guildId, reason, attempt, error: String(error) });
        this.scheduleReconnect(guildId, "retry-failed");
      });
    }, delay);
    timer.unref?.();
    this.reconnectTimers.set(guildId, timer);
  }

  private attachLifecycle(guildId: string, channelId: string, connection: any): void {
    if (!connection || typeof connection !== "object" || this.attached.has(connection)) return;
    this.attached.add(connection);
    connection.on?.("stateChange", (_oldState: any, newState: any) => {
      let lib: VoiceLib;
      try { lib = voiceLib(); } catch { return; }
      if (newState?.status === lib.VoiceConnectionStatus.Ready) {
        const cfg = this.settings(guildId);
        // Uma conexão antiga pode ficar Ready durante uma troca. Só considere
        // saudável quando ela corresponde ao canal atualmente desejado.
        const actual = String(connection?.joinConfig?.channelId ?? channelId ?? "");
        if (cfg.enabled && cfg.channelId === actual) {
          this.retryCount.set(guildId, 0);
          this.clearReconnect(guildId);
        }
        return;
      }
      if (this.suppressReconnect.has(guildId) || this.connecting.has(guildId)) return;
      const cfg = this.settings(guildId);
      if (!cfg.enabled || cfg.channelId !== channelId) return;
      if (newState?.status === lib.VoiceConnectionStatus.Disconnected) {
        void (async () => {
          try {
            const waits: Promise<any>[] = [];
            if (lib.VoiceConnectionStatus.Signalling) waits.push(lib.entersState(connection, lib.VoiceConnectionStatus.Signalling, 5_000));
            if (lib.VoiceConnectionStatus.Connecting) waits.push(lib.entersState(connection, lib.VoiceConnectionStatus.Connecting, 5_000));
            if (waits.length) await Promise.race(waits);
          } catch {}
          try {
            await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 12_000);
            this.retryCount.set(guildId, 0);
            this.clearReconnect(guildId);
            return;
          } catch {}
          try { connection.rejoin?.({ channelId: cfg.channelId, selfDeaf: true, selfMute: true }); } catch {}
          try {
            await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 12_000);
            this.retryCount.set(guildId, 0);
            this.clearReconnect(guildId);
            return;
          } catch {}
          this.scheduleReconnect(guildId, "disconnected-after-resume-window");
        })();
        return;
      }
      if (newState?.status === lib.VoiceConnectionStatus.Destroyed) {
        this.scheduleReconnect(guildId, "destroyed");
      }
    });
  }

  private async validateChannel(guildId: string, channelId: string) {
    const guild = this.client.guilds.cache.get(guildId) ?? await this.client.guilds.fetch(guildId);
    const channel = await guild.channels.fetch(channelId);
    if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type as ChannelType)) {
      throw new Error("Escolha um canal de voz ou palco válido do servidor.");
    }
    const me = guild.members.me ?? await guild.members.fetchMe();
    const permissions = channel.permissionsFor(me);
    if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions.has(PermissionFlagsBits.Connect)) {
      throw new Error("O bot precisa das permissões Ver canal e Conectar nesse canal de voz.");
    }
    return { guild, channel };
  }

  private async connectInternal(guildId: string, channelId: string, force = false): Promise<void> {
    const { guild, channel } = await this.validateChannel(guildId, channelId);
    const lib = voiceLib();

    // Grave o destino ANTES de mover/destruir a conexão. VoiceStateUpdate chega
    // de forma assíncrona; se o banco ainda apontar para a call antiga ele pode
    // iniciar uma reconexão concorrente e puxar o bot de volta para o canal velho.
    this.persistDesired(guildId, channel.id);
    this.desiredTargets.set(guildId, channel.id);
    this.clearReconnect(guildId);

    let connection = lib.getVoiceConnection(guildId);
    const existingChannelId = String(connection?.joinConfig?.channelId ?? "");
    if (!force && connection && existingChannelId === channel.id && this.isReady(connection)) {
      this.attachLifecycle(guildId, channel.id, connection);
      this.retryCount.set(guildId, 0);
      return;
    }

    // A supressão permanece ativa durante TODA a transição, e não só durante o
    // destroy(). Isso elimina a corrida que fazia o bot sair da call/trocar de
    // volta enquanto o Discord ainda enviava VoiceStateUpdate do canal anterior.
    this.suppressReconnect.add(guildId);
    try {
      if (connection && typeof connection.rejoin === "function") {
        let rejoinAccepted = false;
        try {
          const result = connection.rejoin({
            channelId: channel.id,
            selfDeaf: true,
            selfMute: true
          });
          rejoinAccepted = result !== false;
        } catch {
          rejoinAccepted = false;
        }
        if (!rejoinAccepted) {
          try { connection.destroy?.(); } catch {}
          connection = undefined;
        }
      } else if (connection) {
        try { connection.destroy?.(); } catch {}
        connection = undefined;
      }

      if (!connection) {
        connection = lib.joinVoiceChannel({
          channelId: channel.id,
          guildId,
          adapterCreator: guild.voiceAdapterCreator,
          selfDeaf: true,
          selfMute: true
        });
      }
      this.attachLifecycle(guildId, channel.id, connection);

      try {
        await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 25_000);
      } catch (firstError) {
        // Uma reentrada pode falhar por uma sessão antiga presa. Faça UMA troca
        // limpa antes de declarar falha, mantendo a configuração persistida para
        // o keepalive continuar tentando depois.
        try { connection.destroy?.(); } catch {}
        connection = lib.joinVoiceChannel({
          channelId: channel.id,
          guildId,
          adapterCreator: guild.voiceAdapterCreator,
          selfDeaf: true,
          selfMute: true
        });
        this.attachLifecycle(guildId, channel.id, connection);
        if (this.desiredTargets.get(guildId) !== channel.id) return;
        try {
          await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 25_000);
        } catch (secondError) {
          try { connection.destroy?.(); } catch {}
          throw new Error(`O Discord não confirmou a conexão de voz. Primeira tentativa: ${firstError instanceof Error ? firstError.message : String(firstError)}. Segunda tentativa: ${secondError instanceof Error ? secondError.message : String(secondError)}`);
        }
      }

      // Se o usuário escolheu outra call enquanto esta tentativa estava em curso,
      // não sobrescreva o destino novo. O worker fará a próxima mudança logo em seguida.
      if (this.desiredTargets.get(guildId) === channel.id) {
        this.persistDesired(guildId, channel.id);
      }
      this.retryCount.set(guildId, 0);
      this.clearReconnect(guildId);
      this.logger.info("Conexão de voz persistente ativada.", { guildId, channelId: channel.id, forced: force });
    } finally {
      this.suppressReconnect.delete(guildId);
    }
  }

  private async runDesiredLoop(guildId: string): Promise<void> {
    let lastError: unknown;
    // Limite defensivo: normalmente são 1-2 ciclos; 6 evita loop infinito caso
    // um usuário troque de call repetidamente enquanto o Discord está conectando.
    for (let cycle = 0; cycle < 6; cycle++) {
      const target = this.desiredTargets.get(guildId);
      if (!target) return;
      const force = this.forceTargets.delete(guildId);
      try {
        await this.connectInternal(guildId, target, force);
        lastError = undefined;
      } catch (error) {
        lastError = error;
        // Só encerre imediatamente se o destino não mudou. Se mudou enquanto a
        // primeira tentativa falhava, tente o destino novo antes de devolver erro.
        if (this.desiredTargets.get(guildId) === target) throw error;
      }
      if (this.desiredTargets.get(guildId) === target && !this.forceTargets.has(guildId)) return;
    }
    if (lastError) throw lastError;
    throw new Error("Muitas alterações de call aconteceram ao mesmo tempo. Aguarde alguns segundos e tente novamente.");
  }

  async connect(guildId: string, channelId: string, force = false): Promise<void> {
    // Guarde a última escolha imediatamente. A persistência só acontece depois
    // que o canal/permissões forem validados, evitando salvar um destino inválido.
    this.desiredTargets.set(guildId, channelId);
    if (force) this.forceTargets.add(guildId);
    this.clearReconnect(guildId);

    const current = this.connecting.get(guildId);
    if (current) {
      // O worker atual observará desiredTargets e fará a troca mais recente.
      await current;
      const state = this.status(guildId);
      if (state.connected && state.actualChannelId === this.desiredTargets.get(guildId) && !this.forceTargets.has(guildId)) return;
    }

    const existingWorker = this.connecting.get(guildId);
    if (existingWorker) return existingWorker;
    const task = this.runDesiredLoop(guildId).finally(() => {
      if (this.connecting.get(guildId) === task) this.connecting.delete(guildId);
    });
    this.connecting.set(guildId, task);
    return task;
  }

  async reconnect(guildId: string): Promise<void> {
    const cfg = this.settings(guildId);
    if (!cfg.channelId) throw new Error("Escolha primeiro o canal de voz que o bot deve permanecer conectado.");
    await this.connect(guildId, cfg.channelId, true);
  }

  async disconnect(guildId: string): Promise<void> {
    this.clearReconnect(guildId);
    this.retryCount.delete(guildId);
    this.forceTargets.delete(guildId);
    this.desiredTargets.delete(guildId);

    // Desative no banco ANTES de destruir a conexão. Mesmo que o VoiceStateUpdate
    // chegue depois do finally, ele verá enabled=false e não reconectará sozinho.
    this.db.updateGuild(guildId, (settings) => {
      settings.voiceConnection = { ...settings.voiceConnection, enabled: false, channelId: "", updatedAt: new Date().toISOString() };
    });

    this.suppressReconnect.add(guildId);
    try { this.connection(guildId)?.destroy?.(); } catch {}
    finally { this.suppressReconnect.delete(guildId); }
    this.logger.info("Conexão de voz persistente desativada pelo usuário.", { guildId });
  }

  handleVoiceStateUpdate(oldState: any, newState: any): void {
    const botId = this.client.user?.id;
    if (!botId || String(newState?.id || oldState?.id || "") !== botId) return;
    const guildId = String(newState?.guild?.id || oldState?.guild?.id || "");
    if (!guildId) return;
    const cfg = this.settings(guildId);
    if (!cfg.enabled || !cfg.channelId || this.suppressReconnect.has(guildId) || this.connecting.has(guildId)) return;
    const currentChannel = String(newState?.channelId || "");
    if (currentChannel === cfg.channelId) {
      this.retryCount.set(guildId, 0);
      this.clearReconnect(guildId);
      return;
    }
    // Eventos de voz podem chegar fora de ordem. Confirme o estado REAL da
    // @discordjs/voice antes de interpretar um evento atrasado como queda.
    const live = this.connection(guildId);
    const liveChannelId = String(live?.joinConfig?.channelId ?? "");
    if (this.isReady(live) && liveChannelId === cfg.channelId) {
      this.retryCount.set(guildId, 0);
      this.clearReconnect(guildId);
      return;
    }
    this.logger.warn("Discord moveu/desconectou o bot da call configurada; reconexão automática agendada.", { guildId, configuredChannelId: cfg.channelId, currentChannelId: currentChannel || null });
    this.scheduleReconnect(guildId, "voice-state-update");
  }

  async restore(guildId: string): Promise<boolean> {
    const cfg = this.settings(guildId);
    if (!cfg.enabled || !cfg.channelId) return false;
    await this.connect(guildId, cfg.channelId);
    return true;
  }

  private startKeepalive(): void {
    if (this.keepaliveTimer) return;
    this.keepaliveTimer = setInterval(() => {
      for (const guild of this.client.guilds.cache.values()) {
        const cfg = this.settings(guild.id);
        if (!cfg.enabled || !cfg.channelId || this.connecting.has(guild.id)) continue;
        const connection = this.connection(guild.id);
        const actualChannelId = String(connection?.joinConfig?.channelId ?? "");
        if (this.isReady(connection) && actualChannelId === cfg.channelId) continue;
        let transient = false;
        try {
          const status = connection?.state?.status;
          const lib = voiceLib();
          transient = status === lib.VoiceConnectionStatus.Signalling || status === lib.VoiceConnectionStatus.Connecting;
        } catch {}
        if (!transient) this.scheduleReconnect(guild.id, "keepalive");
      }
    }, 12_000);
    this.keepaliveTimer.unref?.();
  }

  async restoreConfigured(): Promise<void> {
    this.startKeepalive();
    if (this.restoring) return;
    this.restoring = true;
    try {
      for (const guild of this.client.guilds.cache.values()) {
        const cfg = this.settings(guild.id);
        if (!cfg.enabled || !cfg.channelId) continue;
        this.desiredTargets.set(guild.id, cfg.channelId);
        try { await this.connect(guild.id, cfg.channelId); }
        catch (error) {
          this.logger.warn("Não foi possível restaurar a call configurada agora; o keepalive continuará tentando.", { guildId: guild.id, channelId: cfg.channelId, error: String(error) });
          this.scheduleReconnect(guild.id, "boot-restore");
        }
      }
    } finally { this.restoring = false; }
  }

  destroyAll(): void {
    if (this.keepaliveTimer) clearInterval(this.keepaliveTimer);
    this.keepaliveTimer = undefined;
    for (const timer of this.reconnectTimers.values()) clearTimeout(timer);
    this.reconnectTimers.clear();
    this.desiredTargets.clear();
    this.forceTargets.clear();
    for (const guild of this.client.guilds.cache.values()) {
      this.suppressReconnect.add(guild.id);
      try { this.connection(guild.id)?.destroy?.(); } catch {}
      finally { this.suppressReconnect.delete(guild.id); }
    }
  }
}
