declare module "qrcode" {
  const QRCode: {
    toBuffer(text: string, options?: Record<string, unknown>): Promise<Buffer>;
    toDataURL(text: string, options?: Record<string, unknown>): Promise<string>;
    toString(text: string, options?: Record<string, unknown>): Promise<string>;
  };
  export default QRCode;
}

declare module "mailparser" {
  export function simpleParser(source: unknown, options?: Record<string, unknown>): Promise<any>;
}
