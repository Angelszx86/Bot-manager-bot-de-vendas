import type { PaymentCharge } from "../../types.js";
import type { ChargeInput, PaymentProvider } from "../contracts.js";
import { GatewayHttpClient, objectAt, safeErrorText, textAt } from "../http-client.js";
import { pixQrDataUrl } from "../../services/pix.js";

const BASE_URL = "https://api.evopay.cash/v1";

function normalizeStatus(value: unknown): PaymentCharge["status"] {
  const current = textAt(value).toUpperCase();
  if (["COMPLETED", "PAID", "APPROVED", "SUCCESS", "SUCCEEDED"].includes(current)) return "paid";
  if (["EXPIRED", "TIMEOUT"].includes(current)) return "expired";
  if (["CANCELED", "CANCELLED", "ERROR", "FAILED", "REFUNDED", "REJECTED"].includes(current)) return "canceled";
  return "pending";
}

function firstTransaction(data: Record<string, unknown>): Record<string, unknown> {
  if (Array.isArray(data.data)) return (data.data[0] ?? {}) as Record<string, unknown>;
  if (Array.isArray(data.transactions)) return (data.transactions[0] ?? {}) as Record<string, unknown>;
  const transaction = objectAt(data, "transaction");
  return Object.keys(transaction).length ? transaction : data;
}

function normalizeBase64Image(value: string): string | undefined {
  const clean = value.trim();
  if (!clean) return undefined;
  if (/^data:image\//i.test(clean)) return clean;
  if (/^[A-Za-z0-9+/=\r\n]+$/.test(clean) && clean.length > 80) return `data:image/png;base64,${clean.replace(/\s+/g, "")}`;
  return undefined;
}

export class EvoPayProvider implements PaymentProvider {
  readonly name = "EVO_PAY" as const;
  private readonly http: GatewayHttpClient;

  constructor(private readonly token: string, private readonly expiresIn = 900) {
    if (!token.trim()) throw new Error("Configure o token da forma de pagamento automática.");
    this.http = new GatewayHttpClient("Gateway PIX", BASE_URL, { Authorization: `Bearer ${token.trim()}` });
  }

  async createCharge(input: ChargeInput): Promise<PaymentCharge> {
    const expiresIn = Math.max(180, Math.min(7200, Number(this.expiresIn) || Math.floor((Date.parse(input.expiresAt) - Date.now()) / 1000) || 900));
    const cleanName = input.customer.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z ]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
    const cleanEmail = /^\S+@\S+\.\S+$/.test(input.customer.email.trim()) ? input.customer.email.trim().slice(0, 200) : "";
    const cleanDocument = input.customer.document.replace(/\D/g, "").slice(0, 14);
    const payload: Record<string, unknown> = {
      amount: Number((input.amountCents / 100).toFixed(2)),
      expiresIn,
      clientReference: input.orderId.slice(0, 100)
    };
    if (cleanName) payload.generatedName = cleanName;
    if (cleanEmail) payload.generatedEmail = cleanEmail;
    if ([11, 14].includes(cleanDocument.length)) payload.generatedDocument = cleanDocument;

    const result = await this.http.request("/pix/", { method: "POST", retries: 1, json: payload, idempotencyKey: input.orderId });
    return await this.toCharge(firstTransaction(result.data), input.expiresAt, input.orderId);
  }

  async getCharge(externalId: string): Promise<PaymentCharge> {
    if (!externalId.trim()) throw new Error("Cobrança PIX sem identificador externo.");
    const result = await this.http.request(`/pix/?id=${encodeURIComponent(externalId.trim())}`, { retries: 1 });
    return await this.toCharge(firstTransaction(result.data), undefined, undefined, externalId);
  }

  async test(): Promise<string> {
    const reference = `ZENYX-CREDENTIAL-CHECK-${Date.now()}`;
    const response = await fetch(`${BASE_URL}/pix/?clientReference=${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${this.token.trim()}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000)
    });
    if (response.status === 401 || response.status === 403) throw new Error("Credencial recusada pela API de pagamento.");
    if (response.status >= 500) throw new Error(`API de pagamento indisponível (HTTP ${response.status}).`);
    if (response.status >= 400 && response.status !== 404) {
      const body = await response.text().catch(() => "");
      throw new Error(safeErrorText(body || `HTTP ${response.status}`, 300));
    }
    return "Credencial autenticada e API acessível";
  }

  private async toCharge(data: Record<string, unknown>, fallbackExpiresAt?: string, fallbackReference?: string, fallbackId?: string): Promise<PaymentCharge> {
    const externalId = textAt(data.id ?? data.transactionId ?? data.paymentId ?? fallbackId);
    if (!externalId) throw new Error("A API de pagamento não retornou o ID da cobrança.");
    const pixCode = textAt(data.qrCodeText ?? data.pixCode ?? data.copyPaste ?? data.brCode);
    const base64 = normalizeBase64Image(textAt(data.qrCodeBase64 ?? data.qrCodeImageBase64));
    const imageUrl = textAt(data.qrCodeUrl ?? data.qrCodeImage ?? data.imageUrl);
    const qrCodeDataUrl = base64 || (/^https?:\/\//i.test(imageUrl) ? imageUrl : (pixCode ? await pixQrDataUrl(pixCode) : undefined));
    const status = normalizeStatus(data.status ?? data.state ?? data.transactionStatus);
    const reference = textAt(data.clientReference ?? data.reference ?? fallbackReference) || undefined;
    const expiresAt = textAt(data.expiresAt ?? data.expirationDate ?? data.expiration) || fallbackExpiresAt;
    return { externalId, status, pixCode: pixCode || undefined, qrCodeDataUrl, expiresAt, reference, raw: data };
  }
}
