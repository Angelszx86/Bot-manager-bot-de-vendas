import type { PaymentCharge } from "../../types.js";
import type { ChargeInput, PaymentProvider } from "../contracts.js";
import { GatewayHttpClient, GatewayHttpError, objectAt, safeErrorText, textAt } from "../http-client.js";
import { pixQrDataUrl } from "../../services/pix.js";

const MAGNUS_BASE_URL = "https://magnuspay.onrender.com";
const MAGNUS_PAYMENTS_PATH = "/api/v1/pagamentos";

function normalizeStatus(value: unknown): PaymentCharge["status"] {
  const status = textAt(value).toLowerCase();
  if (["paid", "approved", "completed", "complete", "success", "succeeded", "concluida", "concluído", "recebido", "pago", "completo"].includes(status)) return "paid";
  if (["expired", "timeout", "expirada", "expirado"].includes(status)) return "expired";
  if (["canceled", "cancelled", "refused", "failed", "rejected", "cancelado", "cancelada", "erro", "error", "refunded"].includes(status)) return "canceled";
  return "pending";
}

function firstObject(data: Record<string, unknown>): Record<string, unknown> {
  for (const key of ["data", "payment", "pagamento", "pix", "charge", "transaction"]) {
    const value = data[key];
    if (Array.isArray(value) && value.length && value[0] && typeof value[0] === "object") return value[0] as Record<string, unknown>;
    const obj = objectAt(data, key);
    if (Object.keys(obj).length) return obj;
  }
  return data;
}

function looksLikePixPayload(value: string): boolean {
  const compact = value.replace(/\s+/g, "");
  return compact.startsWith("000201") && compact.length >= 40;
}

export class MagnusPayProvider implements PaymentProvider {
  readonly name = "MAGNUS_PAY" as const;
  private readonly http: GatewayHttpClient;

  constructor(private readonly apiKey: string) {
    const key = textAt(apiKey);
    if (!key) throw new Error("Configure a API Key da MagnusPay.");
    // Documentação oficial atual: autenticação exclusivamente por X-API-Key.
    this.http = new GatewayHttpClient("MagnusPay", MAGNUS_BASE_URL, { "X-API-Key": key });
  }

  async createCharge(input: ChargeInput): Promise<PaymentCharge> {
    const amount = Number((input.amountCents / 100).toFixed(2));
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Valor inválido para gerar cobrança MagnusPay.");

    try {
      // Documentação oficial atual: POST /api/v1/pagamentos
      // Body obrigatório: amount + description. Não enviar CPF/nome nem aliases
      // de versões antigas, pois isso fazia a API responder "Dados incompletos".
      const result = await this.http.request(MAGNUS_PAYMENTS_PATH, {
        method: "POST",
        json: {
          amount,
          description: input.description.slice(0, 255)
        },
        retries: 1,
        retryStatuses: [429, 500, 502, 503, 504]
      });
      return await this.toCharge(firstObject(result.data), input.expiresAt, input.orderId);
    } catch (error) {
      if (error instanceof GatewayHttpError) {
        if ([401, 403].includes(error.status)) throw new Error("API Key MagnusPay recusada. Gere uma chave válida no painel da MagnusPay e teste novamente.");
        if ([400, 422].includes(error.status)) throw new Error(`MagnusPay recusou os dados da cobrança: ${safeErrorText(error.message, 260)}`);
        throw new Error(`MagnusPay indisponível (HTTP ${error.status}): ${safeErrorText(error.message, 220)}`);
      }
      throw error instanceof Error ? error : new Error("A MagnusPay não conseguiu gerar a cobrança.");
    }
  }

  async getCharge(externalId: string): Promise<PaymentCharge> {
    const id = textAt(externalId);
    if (!id) throw new Error("Cobrança MagnusPay sem identificador externo.");
    try {
      // Documentação oficial atual: GET /api/v1/pagamentos/{id}
      const result = await this.http.request(`${MAGNUS_PAYMENTS_PATH}/${encodeURIComponent(id)}`, {
        method: "GET",
        retries: 1,
        retryStatuses: [429, 500, 502, 503, 504]
      });
      return await this.toCharge(firstObject(result.data), undefined, undefined, id);
    } catch (error) {
      if (error instanceof GatewayHttpError) {
        if ([401, 403].includes(error.status)) throw new Error("API Key MagnusPay recusada durante a consulta da cobrança.");
        if (error.status === 404) throw new Error("A cobrança MagnusPay não foi encontrada.");
        throw new Error(`Não foi possível consultar a cobrança MagnusPay: ${safeErrorText(error.message, 240)}`);
      }
      throw error instanceof Error ? error : new Error("Não foi possível consultar a cobrança MagnusPay.");
    }
  }

  async test(): Promise<string> {
    try {
      // GET /api/v1/pagamentos é a rota oficial de listagem e permite validar
      // a API Key sem criar uma cobrança de teste.
      await this.http.request(MAGNUS_PAYMENTS_PATH, {
        method: "GET",
        retries: 0,
        timeoutMs: 15_000
      });
      return "MagnusPay autenticada • API Key aceita pela API oficial";
    } catch (error) {
      if (error instanceof GatewayHttpError && [401, 403].includes(error.status)) throw new Error("API Key MagnusPay recusada.");
      if (error instanceof GatewayHttpError) throw new Error(`A MagnusPay respondeu HTTP ${error.status}: ${safeErrorText(error.message, 220)}`);
      throw new Error(`Não foi possível validar a API Key MagnusPay: ${safeErrorText(error instanceof Error ? error.message : error, 220)}`);
    }
  }

  private async toCharge(data: Record<string, unknown>, fallbackExpiresAt?: string, fallbackReference?: string, fallbackId?: string): Promise<PaymentCharge> {
    const externalId = textAt(
      data.pixId ?? data.id ?? data.paymentId ?? data.pagamentoId ?? data.transactionId ??
      data.transaction_id ?? data.txid ?? data.chargeId ?? data.identifier ?? fallbackId
    );
    if (!externalId) throw new Error("A MagnusPay não retornou o identificador da cobrança.");

    let pixCode = textAt(
      data.pixCode ?? data.pix_code ?? data.copyPaste ?? data.copy_paste ??
      data.copy_and_paste ?? data.brCode ?? data.pixCopiaECola ?? data.emv
    );
    const documentedQr = textAt(data.qrCode ?? data.qrcode);
    if (!pixCode && looksLikePixPayload(documentedQr)) pixCode = documentedQr;

    const base64 = textAt(data.qrCodeBase64 ?? data.qrCodeImageBase64 ?? data.base64 ?? data.qr_code_base64 ?? data.qrcodeBase64);
    const image = textAt(data.qrCodeUrl ?? data.qrcodeUrl ?? data.qrCodeImage ?? data.imageUrl ?? data.qr_image);
    let qrCodeDataUrl: string | undefined;
    if (/^data:image\//i.test(documentedQr)) qrCodeDataUrl = documentedQr;
    else if (/^https?:\/\//i.test(documentedQr)) qrCodeDataUrl = documentedQr;
    else if (/^[A-Za-z0-9+/=\r\n]+$/.test(documentedQr) && documentedQr.length > 100 && !looksLikePixPayload(documentedQr)) qrCodeDataUrl = `data:image/png;base64,${documentedQr.replace(/\s+/g, "")}`;
    else if (/^data:image\//i.test(base64)) qrCodeDataUrl = base64;
    else if (/^[A-Za-z0-9+/=\r\n]+$/.test(base64) && base64.length > 80) qrCodeDataUrl = `data:image/png;base64,${base64.replace(/\s+/g, "")}`;
    else if (/^https?:\/\//i.test(image)) qrCodeDataUrl = image;
    else if (pixCode) qrCodeDataUrl = await pixQrDataUrl(pixCode);

    return {
      externalId,
      status: normalizeStatus(data.status ?? data.transactionState ?? data.state ?? data.paymentStatus ?? data.transactionStatus),
      pixCode: pixCode || undefined,
      qrCodeDataUrl,
      expiresAt: textAt(data.expiresAt ?? data.expiration ?? data.expirationDate ?? data.expireAt) || fallbackExpiresAt,
      reference: textAt(data.externalReference ?? data.reference ?? data.clientReference ?? fallbackReference) || undefined,
      raw: data
    };
  }
}
