const BUCKET = "zcloud-gateway";
const ROUTE_TTL_MS = 15 * 60 * 1000;
const DISCORD_API = "https://discord.com/api/v10";

const SUPABASE_URL = (Deno.env.get("SUPABASE_URL") || "").replace(/\/$/, "");
function resolveStorageKey(): { key: string; bearer: boolean } {
  const legacy = (Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "").trim();
  if (legacy) return { key: legacy, bearer: true };
  try {
    const parsed = JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}");
    const key = String(parsed?.default || Object.values(parsed || {})[0] || "").trim();
    if (key) return { key, bearer: false };
  } catch {}
  return { key: "", bearer: false };
}
let bucketReady = false;

function json(data: unknown, status = 200, extra: HeadersInit = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      ...extra,
    },
  });
}

function html(title: string, message: string, status = 503) {
  const esc = (value: string) => value.replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch] || ch));
  return new Response(`<!doctype html><html lang="pt-BR"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#070b18;color:#eef2ff;font:16px system-ui}.card{width:min(92vw,560px);padding:28px;border:1px solid #ffffff18;border-radius:22px;background:#0f1528;box-shadow:0 25px 70px #0008}h1{font-size:25px}p{line-height:1.6;color:#b9c2dd}</style><main class="card"><h1>${esc(title)}</h1><p>${esc(message)}</p></main></html>`, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
      "referrer-policy": "no-referrer",
      "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'",
    },
  });
}

function storageHeaders(contentType = "application/json") {
  const { key, bearer } = resolveStorageKey();
  if (!key || !SUPABASE_URL) throw new Error("Gateway sem credencial interna de Storage.");
  const headers: Record<string, string> = { apikey: key, "content-type": contentType };
  // Legacy service_role is a JWT and may be used as Bearer. New sb_secret_ keys
  // must stay in the apikey header and are intentionally not sent as Bearer.
  if (bearer) headers.authorization = `Bearer ${key}`;
  return headers;
}

async function ensureBucket() {
  if (bucketReady) return;
  const r = await fetch(`${SUPABASE_URL}/storage/v1/bucket`, {
    method: "POST",
    headers: storageHeaders(),
    body: JSON.stringify({ id: BUCKET, name: BUCKET, public: false, file_size_limit: 1048576, allowed_mime_types: ["application/json"] }),
  });
  if (!r.ok && r.status !== 409) {
    const text = (await r.text()).slice(0, 300);
    if (!/already|exist|duplicate/i.test(text)) throw new Error(`Storage indisponível (${r.status}).`);
  }
  bucketReady = true;
}

type RouteRecord = {
  guildId: string;
  botId: string;
  tunnelUrl: string;
  updatedAt: string;
  expiresAt: number;
};

async function putRoute(record: RouteRecord) {
  await ensureBucket();
  const r = await fetch(`${SUPABASE_URL}/storage/v1/object/${BUCKET}/routes/${record.guildId}.json`, {
    method: "POST",
    headers: { ...storageHeaders(), "x-upsert": "true" },
    body: JSON.stringify(record),
  });
  if (!r.ok) throw new Error(`Não foi possível registrar a rota pública (${r.status}).`);
}

async function getRoute(guildId: string): Promise<RouteRecord | null> {
  await ensureBucket();
  const r = await fetch(`${SUPABASE_URL}/storage/v1/object/${BUCKET}/routes/${guildId}.json`, {
    headers: storageHeaders(),
  });
  if (r.status === 404 || r.status === 400) return null;
  if (!r.ok) throw new Error(`Não foi possível ler a rota pública (${r.status}).`);
  const value = await r.json() as RouteRecord;
  if (!value || value.guildId !== guildId || !value.tunnelUrl) return null;
  return value;
}

function cleanFunctionPath(pathname: string) {
  const marker = "/zcloud-gateway";
  const at = pathname.indexOf(marker);
  if (at >= 0) return pathname.slice(at + marker.length) || "/";
  return pathname;
}

function validGuildId(value: unknown): value is string {
  return /^\d{15,22}$/.test(String(value || ""));
}

function validTunnel(value: unknown): string | null {
  try {
    const u = new URL(String(value || ""));
    if (u.protocol !== "https:") return null;
    const host = u.hostname.toLowerCase();
    if (!(host.endsWith(".trycloudflare.com") || host === "trycloudflare.com")) return null;
    u.pathname = "";
    u.search = "";
    u.hash = "";
    return u.toString().replace(/\/$/, "");
  } catch {
    return null;
  }
}

async function validateBotToken(token: string) {
  const r = await fetch(`${DISCORD_API}/users/@me`, { headers: { authorization: `Bot ${token}` }, signal: AbortSignal.timeout(10000) });
  if (!r.ok) return null;
  const user = await r.json() as { id?: string; bot?: boolean };
  return user?.bot && validGuildId(user.id) ? user : null;
}

async function botCanSeeGuild(token: string, guildId: string) {
  const r = await fetch(`${DISCORD_API}/guilds/${guildId}`, { headers: { authorization: `Bot ${token}` }, signal: AbortSignal.timeout(10000) });
  return r.ok;
}

async function register(req: Request) {
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405, { allow: "POST" });
  const auth = req.headers.get("authorization") || "";
  const m = auth.match(/^Bot\s+(.+)$/i);
  if (!m) return json({ error: "unauthorized" }, 401);
  let body: { guildIds?: unknown; tunnelUrl?: unknown };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const tunnelUrl = validTunnel(body.tunnelUrl);
  const guildIds = Array.isArray(body.guildIds) ? [...new Set(body.guildIds.map(String).filter(validGuildId))].slice(0, 100) : [];
  if (!tunnelUrl || !guildIds.length) return json({ error: "invalid_registration" }, 400);

  const token = m[1]!.trim();
  const bot = await validateBotToken(token);
  if (!bot?.id) return json({ error: "invalid_bot_token" }, 401);

  const accepted: string[] = [];
  const rejected: string[] = [];
  for (const guildId of guildIds) {
    if (!(await botCanSeeGuild(token, guildId))) { rejected.push(guildId); continue; }
    await putRoute({ guildId, botId: bot.id, tunnelUrl, updatedAt: new Date().toISOString(), expiresAt: Date.now() + ROUTE_TTL_MS });
    accepted.push(guildId);
  }
  return json({ ok: true, accepted, rejected, ttlSeconds: Math.floor(ROUTE_TTL_MS / 1000) });
}

async function status(req: Request, url: URL) {
  const guildId = url.searchParams.get("guild") || "";
  if (!validGuildId(guildId)) return json({ registered: false }, 400);
  const route = await getRoute(guildId);
  const registered = Boolean(route && route.expiresAt > Date.now());
  return json({ registered, expiresAt: registered ? new Date(route!.expiresAt).toISOString() : null });
}

async function proxy(req: Request, url: URL, path: string) {
  const match = path.match(/^\/zcloud\/(\d{15,22})\/(auth|callback|health)$/);
  if (!match) return html("ZCloud", "Rota de autenticação não encontrada.", 404);
  const guildId = match[1]!;
  const route = await getRoute(guildId);
  if (!route || route.expiresAt <= Date.now()) {
    return html("ZCloud temporariamente indisponível", "O bot de verificação está reiniciando ou ainda não publicou a rota segura. Tente novamente em alguns segundos.", 503);
  }
  const target = new URL(`${route.tunnelUrl}${path}${url.search}`);
  const headers = new Headers(req.headers);
  for (const key of ["host", "authorization", "content-length", "x-forwarded-host", "x-forwarded-proto", "cf-connecting-ip"]) headers.delete(key);
  headers.set("x-zenyx-gateway", "supabase-edge");
  headers.set("x-forwarded-proto", "https");
  // Evita resposta comprimida/chunked atravessando dois proxies (Quick Tunnel + Edge Function).
  // WebViews móveis do Discord/Android podem interpretar incorretamente HTML streamado.
  headers.set("accept-encoding", "identity");
  try {
    const upstream = await fetch(target, {
      method: req.method,
      headers,
      body: ["GET", "HEAD"].includes(req.method) ? undefined : req.body,
      redirect: "manual",
      signal: AbortSignal.timeout(20000),
    });
    const outHeaders = new Headers(upstream.headers);
    // Nunca encaminhe metadados de compressão/chunking do Quick Tunnel. O Edge Runtime pode
    // descomprimir o body antes de nós criarmos a resposta final. Reutilizar esses headers é
    // suficiente para alguns WebViews exibirem o HTML como texto bruto.
    for (const key of ["content-encoding", "content-length", "transfer-encoding", "content-disposition"]) outHeaders.delete(key);
    outHeaders.set("cache-control", "no-store, no-transform");
    outHeaders.set("x-content-type-options", "nosniff");
    outHeaders.set("x-zenyx-gateway", "supabase-edge-r18.9.3");
    const action = match[2]!;

    // O callback contém a interface web do ZCloud. Bufferizamos o documento inteiro e criamos
    // uma NOVA Response HTML no Edge em vez de repassar um ReadableStream vindo do Quick
    // Tunnel. Isso remove a combinação que fazia Discord WebView/Chrome Android mostrar
    // literalmente "<!doctype html>..." em vez de renderizar a página.
    if (action === "callback") {
      const bytes = await upstream.arrayBuffer();
      const text = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
      outHeaders.set("content-type", "text/html; charset=utf-8");
      return new Response(text, { status: upstream.status, headers: outHeaders });
    }
    if (action === "health") {
      const text = await upstream.text();
      outHeaders.set("content-type", "application/json; charset=utf-8");
      return new Response(text, { status: upstream.status, headers: outHeaders });
    }

    // /auth normalmente é 302. Preserve o Location sem transformar o redirect.
    // Se o bot devolver um erro HTML em vez de 302, renderize a página de erro
    // corretamente em vez de deixar uma resposta vazia.
    if (action === "auth" && upstream.status >= 300 && upstream.status < 400 && outHeaders.get("location")) {
      return new Response(null, { status: upstream.status, headers: outHeaders });
    }
    const text = await upstream.text();
    outHeaders.set("content-type", "text/html; charset=utf-8");
    return new Response(text, { status: upstream.status, headers: outHeaders });
  } catch {
    return html("ZCloud temporariamente indisponível", "Não foi possível alcançar o bot de verificação agora. Tente novamente em alguns segundos.", 503);
  }
}

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const path = cleanFunctionPath(url.pathname);
    if (path === "/" || path === "/health") return json({ status: "ok", service: "zcloud-gateway", version: "18.9.3" });
    if (path === "/register") return await register(req);
    if (path === "/status") return await status(req, url);
    if (path.startsWith("/zcloud/")) return await proxy(req, url, path);
    return json({ error: "not_found" }, 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : "gateway_error";
    return json({ error: "gateway_error", message: message.replace(/[\r\n]/g, " ").slice(0, 180) }, 500);
  }
});
