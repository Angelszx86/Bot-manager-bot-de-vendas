'use strict';
const {
  ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType,
  Client, ContainerBuilder, GatewayIntentBits, MessageFlags, ModalBuilder, REST, Routes, SeparatorBuilder,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextDisplayBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const QRCode = require('qrcode');
const store = require('../Lib/partnerManagerStore');
const brandEnforcer = require('../Lib/brandEnforcer');

const managerId = String(process.env.PARTNER_MANAGER_ID || '');
const ownerId = String(process.env.PARTNER_MANAGER_OWNER || '');
const token = String(process.env.PARTNER_MANAGER_TOKEN || '');
if (!managerId || !ownerId || !token) throw new Error('Partner Manager sem ID, dono ou token.');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const pendingRpc = new Map();
const paymentWatchers = new Map();
let rpcSeq = 0;

function rpc(op, args = {}, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const requestId = `${process.pid}-${Date.now()}-${++rpcSeq}`;
    const timer = setTimeout(() => { pendingRpc.delete(requestId); reject(new Error(`Tempo excedido em ${op}.`)); }, timeoutMs);
    pendingRpc.set(requestId, { resolve, reject, timer });
    if (!process.send) { clearTimeout(timer); pendingRpc.delete(requestId); return reject(new Error('Canal IPC indisponível.')); }
    process.send({ type: 'rpc', requestId, op, args });
  });
}
process.on('message', (msg) => {
  if (msg?.type === 'rpc-result' && msg.requestId) {
    const item = pendingRpc.get(msg.requestId); if (!item) return;
    clearTimeout(item.timer); pendingRpc.delete(msg.requestId);
    if (msg.ok) item.resolve(msg.data); else item.reject(new Error(String(msg.error || 'Falha no Manager principal.')));
  }
  if (msg?.type === 'shutdown') void client.destroy();
});

function record() { const rec = store.get(managerId); if (!rec) throw new Error('Manager parceiro removido do Manager principal.'); return rec; }
function money(cents) { return (Number(cents || 0) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
function safe(s, n=1200) { return String(s ?? '').trim().slice(0,n); }
function owner(interaction) { if (String(interaction.user?.id || '') !== ownerId) throw new Error('Somente o proprietário deste Manager pode usar esta opção.'); }
function btn(id, label, style=ButtonStyle.Secondary, emoji) { const b=new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style); if(emoji) b.setEmoji(emoji); return b; }
function field(id,label,value='',style=TextInputStyle.Short,required=true,max=1000,placeholder='') { const t=new TextInputBuilder().setCustomId(id).setLabel(label.slice(0,45)).setStyle(style).setRequired(required).setMaxLength(Math.min(4000,max)); if(value)t.setValue(String(value).slice(0,Math.min(4000,max))); if(placeholder)t.setPlaceholder(placeholder.slice(0,100)); return new ActionRowBuilder().addComponents(t); }
function containerPayload(container, ephemeral=true) { return { flags:(ephemeral?MessageFlags.Ephemeral:0)|MessageFlags.IsComponentsV2, components:[container] }; }
function loadingPayload(text='Carregando...') { const c=new ContainerBuilder().setAccentColor(0x5865f2).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ⏳ ${text}\n-# Aguarde enquanto a alteração é aplicada com segurança.`)); return containerPayload(c,true); }

function homePayload() {
  const r=record();
  const c=new ContainerBuilder().setAccentColor(0x3155ff)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `## ASTRA APPLICATION • Manager parceiro\n-# Controle limitado e isolado, conectado à infraestrutura do Manager principal.\n\n`+
      `**Saldo disponível:** ${money(r.balanceCents)}\n**Vendas brutas:** ${money(r.grossSalesCents)}\n**Planos:** ${r.plans.filter(p=>p.enabled!==false).length} ativos\n\n`+
      `### Limites fixos\n• Sem teste grátis e sem Keys\n• Planos de até **90 dias** e preço de até **R$ 6,00**\n• Checkout exclusivamente automático pela EvoPay central\n• Taxa por venda/depósito: **R$ 1,50**\n• Saque mínimo: **R$ 20,00** • taxa: **R$ 3,90**\n• Você não recebe nem altera a credencial EvoPay central.`));
  c.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
  c.addActionRowComponents(
    new ActionRowBuilder().addComponents(btn('pm:plans','Planos',ButtonStyle.Primary,'📦'),btn('pm:publish','Publicar loja',ButtonStyle.Success,'🛒'),btn('pm:apps','Aplicações',ButtonStyle.Primary,'🤖')),
    new ActionRowBuilder().addComponents(btn('pm:brand','Personalização',ButtonStyle.Secondary,'🎨'),btn('pm:withdraw','Sacar',ButtonStyle.Secondary,'💳'),btn('pm:refresh','Atualizar',ButtonStyle.Secondary,'🔄'))
  );
  return containerPayload(c,true);
}
function plansPayload() {
  const r=record(), c=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Planos\n-# Máximo de 10 planos • 1–90 dias • até R$ 6,00.\n\n${r.plans.length?r.plans.map(p=>`**${p.label}** • ${p.days}d • ${money(Math.round(p.price*100))} • ${p.enabled!==false?'ativo':'desativado'}`).join('\n'):'Nenhum plano cadastrado.'}`));
  c.addActionRowComponents(new ActionRowBuilder().addComponents(btn('pm:plan:add','Criar plano',ButtonStyle.Success,'➕'),btn('pm:home','Voltar',ButtonStyle.Secondary,'↩️')));
  if(r.plans.length){ const sel=new StringSelectMenuBuilder().setCustomId('pm:plan:select').setPlaceholder('Editar um plano').addOptions(...r.plans.slice(0,25).map(p=>new StringSelectMenuOptionBuilder().setLabel(`${p.label} • ${p.days}d`).setDescription(`${money(Math.round(p.price*100))} • ${p.enabled!==false?'ativo':'desativado'}`).setValue(p.id))); c.addActionRowComponents(new ActionRowBuilder().addComponents(sel)); }
  return containerPayload(c,true);
}
function planDetailPayload(plan) {
  const c=new ContainerBuilder().setAccentColor(plan.enabled!==false?0x57f287:0x747f8d).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${plan.label}\n**Duração:** ${plan.days} dia(s)\n**Preço:** ${money(Math.round(plan.price*100))}\n**Status:** ${plan.enabled!==false?'Ativo':'Desativado'}`));
  c.addActionRowComponents(new ActionRowBuilder().addComponents(btn(`pm:plan:toggle:${plan.id}`,plan.enabled!==false?'Desativar':'Ativar',plan.enabled!==false?ButtonStyle.Danger:ButtonStyle.Success),btn(`pm:plan:edit:${plan.id}`,'Editar',ButtonStyle.Primary),btn(`pm:plan:delete:${plan.id}`,'Excluir',ButtonStyle.Danger),btn('pm:plans','Voltar',ButtonStyle.Secondary)));
  return containerPayload(c,true);
}
function brandPayload() {
  const b=record().brand, c=new ContainerBuilder().setAccentColor(Number(b.accentColor||0x3155ff)).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Personalização\n**Título:** ${b.title}\n**Descrição:** ${b.description}\n**Banner:** ${b.bannerUrl?b.bannerUrl:'padrão/sem banner'}\n\n-# A Bio institucional ZENYX do bot continua protegida pelo Manager principal.`));
  c.addActionRowComponents(new ActionRowBuilder().addComponents(btn('pm:brand:edit','Editar visual',ButtonStyle.Primary,'🎨'),btn('pm:home','Voltar',ButtonStyle.Secondary,'↩️'))); return containerPayload(c,true);
}
function storefrontPayload(guildId) {
  const r=record(), plans=r.plans.filter(p=>p.enabled!==false); const c=new ContainerBuilder().setAccentColor(Number(r.brand.accentColor||0x3155ff)).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${safe(r.brand.title,100)}\n${safe(r.brand.description,1500)}\n\n-# Pagamento automático • hospedagem gerenciada pela infraestrutura ZENYX`));
  if(plans.length){const sel=new StringSelectMenuBuilder().setCustomId('pm:buy').setPlaceholder('Escolha um plano').addOptions(...plans.slice(0,25).map(p=>new StringSelectMenuOptionBuilder().setLabel(`${p.label} • ${p.days}d`).setDescription(`${money(Math.round(p.price*100))} • pagamento automático`).setValue(p.id)));c.addActionRowComponents(new ActionRowBuilder().addComponents(sel));}
  else c.addTextDisplayComponents(new TextDisplayBuilder().setContent('Nenhum plano está disponível agora.'));
  return containerPayload(c,false);
}
async function refreshPublications() {
  const r=record(); let ok=0;
  for(const [guildId,pub] of Object.entries(r.published||{})){
    try{const ch=await client.channels.fetch(pub.channelId);if(!ch?.isTextBased?.())continue;const msg=await ch.messages.fetch(pub.messageId);await msg.edit({components:storefrontPayload(guildId).components,flags:MessageFlags.IsComponentsV2});ok++;}catch{}
  }
  return ok;
}
function appsPayload(items) {
  const c=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Aplicações\n${items.length?`**${items.filter(x=>x.running).length}/${items.length}** online`:'Nenhuma aplicação vinculada a este Manager.'}`));
  if(items.length){const sel=new StringSelectMenuBuilder().setCustomId('pm:app:select').setPlaceholder('Escolha uma aplicação').addOptions(...items.slice(0,25).map(a=>new StringSelectMenuOptionBuilder().setLabel(`${a.nome||a.childClientId||a.id} • ${a.running?'online':'offline'}`.slice(0,100)).setDescription(`${a.plano||'Plano'} • ${a.guildId||'servidor não informado'}`.slice(0,100)).setValue(a.id)));c.addActionRowComponents(new ActionRowBuilder().addComponents(sel));}
  c.addActionRowComponents(new ActionRowBuilder().addComponents(btn('pm:home','Voltar',ButtonStyle.Secondary,'↩️')));return containerPayload(c,true);
}
function appDetailPayload(app) {
  const c=new ContainerBuilder().setAccentColor(app.running?0x57f287:0xed4245).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${safe(app.nome||'Aplicação',100)}\n**Runtime:** \`${app.id}\`\n**Status:** ${app.running?'Online':'Offline'}${app.remoteProvider?` • ${app.remoteProvider}`:''}\n**Servidor:** \`${app.guildId||'-'}\`\n**Plano:** ${app.plano||'-'}\n**Validade:** ${app.dataExpiracao?`<t:${Math.floor(Date.parse(app.dataExpiracao)/1000)}:R>`:'-'}`));
  c.addActionRowComponents(new ActionRowBuilder().addComponents(btn(`pm:app:start:${app.id}`,'Ligar',ButtonStyle.Success),btn(`pm:app:restart:${app.id}`,'Reiniciar',ButtonStyle.Primary),btn(`pm:app:stop:${app.id}`,'Desligar',ButtonStyle.Secondary),btn(`pm:app:logs:${app.id}`,'Logs',ButtonStyle.Secondary),btn(`pm:app:remove:${app.id}`,'Excluir',ButtonStyle.Danger)),new ActionRowBuilder().addComponents(btn('pm:apps','Voltar',ButtonStyle.Secondary)));
  return containerPayload(c,true);
}

async function registerCommands(guildId) {
  const commands=[
    {name:'botconfig',description:'Abre a central de configuração do seu Manager parceiro.'},
    {name:'setar-plan',description:'Cria ou atualiza um plano de até 90 dias e R$ 6,00.',options:[{type:3,name:'nome',description:'Nome do plano',required:true},{type:4,name:'dias',description:'Duração de 1 a 90 dias',required:true,min_value:1,max_value:90},{type:10,name:'preco',description:'Preço de R$ 0,01 até R$ 6,00',required:true,min_value:0.01,max_value:6}]},
    {name:'planos',description:'Lista os planos cadastrados neste Manager.'},
    {name:'sacar',description:'Solicita um saque do saldo do Manager.',options:[{type:10,name:'valor',description:'Valor do saque (mínimo R$ 20,00)',required:true,min_value:20},{type:3,name:'pix',description:'Chave PIX que receberá o saque',required:true}]}
  ];
  const rest=new REST({version:'10'}).setToken(token); await rest.put(Routes.applicationGuildCommands(client.user.id,guildId),{body:commands});
}

async function watchOrder(interaction, orderId) {
  if(paymentWatchers.has(orderId)) return;
  const timer=setInterval(async()=>{
    try{
      const result=await rpc('payment-status',{orderId},20000);
      if(!result?.paid) return;
      clearInterval(timer); paymentWatchers.delete(orderId);
      const order=result.order;
      const c=new ContainerBuilder().setAccentColor(0x57f287).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ✅ Pagamento confirmado\n**Plano:** ${order.planLabel} • ${order.days}d\n**Valor:** ${money(order.amountCents)}\n\nAgora vincule o bot Discord que será hospedado. O benefício só poderá ser usado nesta compra.`));
      c.addActionRowComponents(new ActionRowBuilder().addComponents(btn(`pm:register-app:${order.id}`,'Cadastrar aplicação',ButtonStyle.Success,'🤖')));
      await interaction.editReply({components:[c],flags:MessageFlags.IsComponentsV2}).catch(()=>undefined);
      process.send?.({type:'sale',at:new Date().toISOString()});
    }catch(error){ /* timeout do gateway não derruba o worker */ }
  },8000); timer.unref?.(); paymentWatchers.set(orderId,timer);
  setTimeout(()=>{if(paymentWatchers.get(orderId)===timer){clearInterval(timer);paymentWatchers.delete(orderId);}},16*60*1000).unref?.();
}

async function handleCommand(i) {
  owner(i);
  if(i.commandName==='botconfig') return i.reply(homePayload());
  if(i.commandName==='planos') return i.reply(plansPayload());
  if(i.commandName==='setar-plan') {
    const label=safe(i.options.getString('nome',true),80),days=i.options.getInteger('dias',true),price=Number(i.options.getNumber('preco',true));
    if(days<1||days>90||price<=0||price>6) throw new Error('Use de 1 a 90 dias e preço máximo de R$ 6,00.');
    const r=record(), base=label.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,32)||`plan-${Date.now()}`;
    const plans=[...r.plans]; const idx=plans.findIndex(p=>p.id===base); const plan={id:base,label,days,price:Number(price.toFixed(2)),enabled:true}; if(idx>=0)plans[idx]=plan;else{if(plans.length>=10)throw new Error('Limite de 10 planos atingido.');plans.push(plan);} store.patch(managerId,{plans}); await refreshPublications(); return i.reply({content:`✅ Plano **${label}** salvo: ${days}d • ${money(Math.round(price*100))}.`,flags:MessageFlags.Ephemeral});
  }
  if(i.commandName==='sacar') { await i.deferReply({flags:MessageFlags.Ephemeral}); const wd=await rpc('withdraw',{amount:i.options.getNumber('valor',true),pixKey:i.options.getString('pix',true)}); return i.editReply(`✅ Solicitação **${wd.id}** criada. Valor: ${money(wd.amountCents)} • taxa: ${money(wd.feeCents)} • líquido previsto: ${money(wd.payoutCents)}.`); }
}

async function handleButton(i) {
  const id=i.customId;
  if(id.startsWith('pm:') && !id.startsWith('pm:buy') && !id.startsWith('pm:register-app:')) owner(i);
  if(id==='pm:home'||id==='pm:refresh') return i.update(homePayload());
  if(id==='pm:plans') return i.update(plansPayload());
  if(id==='pm:plan:add') return i.showModal(new ModalBuilder().setCustomId('pm:plan:add:modal').setTitle('Criar plano').addComponents(field('name','Nome do plano','',TextInputStyle.Short,true,80,'Mensal'),field('days','Dias (1 a 90)','30',TextInputStyle.Short,true,2,'30'),field('price','Preço (máx. R$ 6,00)','0,90',TextInputStyle.Short,true,8,'0,90')));
  if(id.startsWith('pm:plan:edit:')) {const p=record().plans.find(x=>x.id===id.split(':')[3]);if(!p)throw new Error('Plano não encontrado.');return i.showModal(new ModalBuilder().setCustomId(`pm:plan:edit:modal:${p.id}`).setTitle('Editar plano').addComponents(field('name','Nome do plano',p.label,TextInputStyle.Short,true,80),field('days','Dias (1 a 90)',String(p.days),TextInputStyle.Short,true,2),field('price','Preço (máx. R$ 6,00)',String(p.price).replace('.',','),TextInputStyle.Short,true,8)) );}
  if(id.startsWith('pm:plan:toggle:')) {const pid=id.split(':')[3],r=record(),plans=r.plans.map(p=>p.id===pid?{...p,enabled:p.enabled===false}:p);store.patch(managerId,{plans});await refreshPublications();return i.update(planDetailPayload(plans.find(p=>p.id===pid)));}
  if(id.startsWith('pm:plan:delete:')) {const pid=id.split(':')[3],plans=record().plans.filter(p=>p.id!==pid);store.patch(managerId,{plans});await refreshPublications();return i.update(plansPayload());}
  if(id==='pm:publish') return i.update({flags:MessageFlags.IsComponentsV2,components:[new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent('## Publicar loja\nEscolha o canal onde o painel de planos será enviado.')).addActionRowComponents(new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('pm:publish:channel').setPlaceholder('Selecione um canal').setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1))),new ActionRowBuilder().addComponents(btn('pm:home','Voltar',ButtonStyle.Secondary))]});
  if(id==='pm:brand') return i.update(brandPayload());
  if(id==='pm:brand:edit') {const b=record().brand;return i.showModal(new ModalBuilder().setCustomId('pm:brand:modal').setTitle('Personalizar Manager').addComponents(field('title','Título',b.title,TextInputStyle.Short,true,100),field('description','Descrição',b.description,TextInputStyle.Paragraph,true,1500),field('banner','URL do banner (opcional)',b.bannerUrl,TextInputStyle.Short,false,1000),field('color','Cor hexadecimal',`#${Number(b.accentColor||0x3155ff).toString(16).padStart(6,'0')}`,TextInputStyle.Short,true,7)) );}
  if(id==='pm:withdraw') return i.showModal(new ModalBuilder().setCustomId('pm:withdraw:modal').setTitle('Solicitar saque').addComponents(field('amount','Valor (mínimo R$ 20,00)','20,00',TextInputStyle.Short,true,12),field('pix','Chave PIX','',TextInputStyle.Short,true,180)));
  if(id==='pm:apps'){await i.update(loadingPayload('Carregando aplicações...'));const apps=await rpc('apps',{});return i.editReply(appsPayload(apps));}
  if(id.startsWith('pm:app:') && ['start','restart','stop','logs','remove'].includes(id.split(':')[2])) {const [, ,action,...rest]=id.split(':'),appId=rest.join(':');await i.update(loadingPayload('Aplicando ação na aplicação...'));const result=await rpc('app-action',{action,appId},45000);if(action==='logs'){const c=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Logs\n\`\`\`\n${safe(result.logs,3600).replace(/```/g,'')}\n\`\`\``)).addActionRowComponents(new ActionRowBuilder().addComponents(btn('pm:apps','Voltar',ButtonStyle.Secondary)));return i.editReply(containerPayload(c,true));}const apps=await rpc('apps',{});const app=apps.find(a=>a.id===appId);return i.editReply(app?appDetailPayload(app):appsPayload(apps));}
  if(id.startsWith('pm:register-app:')) {const order=store.getOrder(id.slice('pm:register-app:'.length));if(!order||String(order.userId)!==String(i.user.id)||order.status!=='PAID')throw new Error('Esta compra não está disponível para esta conta.');return i.showModal(new ModalBuilder().setCustomId(`pm:register-app:modal:${order.id}`).setTitle('Cadastrar aplicação').addComponents(field('token','Token do bot filho','',TextInputStyle.Short,true,1000),field('guild','ID do servidor destino','',TextInputStyle.Short,true,22)));}
}

async function handleSelect(i) {
  if(i.customId==='pm:plan:select'){owner(i);const p=record().plans.find(x=>x.id===i.values[0]);if(!p)throw new Error('Plano não encontrado.');return i.update(planDetailPayload(p));}
  if(i.customId==='pm:app:select'){owner(i);await i.update(loadingPayload('Abrindo aplicação...'));const apps=await rpc('apps',{});const app=apps.find(a=>a.id===i.values[0]);if(!app)throw new Error('Aplicação não encontrada.');return i.editReply(appDetailPayload(app));}
  if(i.customId==='pm:buy'){
    const p=record().plans.find(x=>x.id===i.values[0]&&x.enabled!==false);if(!p)throw new Error('Plano indisponível.');
    await i.deferReply({flags:MessageFlags.Ephemeral});
    const result=await rpc('create-payment',{planId:p.id,userId:i.user.id,username:i.user.username,guildId:i.guildId,channelId:i.channelId},30000); const charge=result.charge, order=result.order;
    let qr; if(charge.qrCodeText) qr=await QRCode.toBuffer(charge.qrCodeText,{width:420,margin:2}).catch(()=>null);
    const c=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## PIX criado • ${p.label}\n**Valor:** ${money(order.amountCents)}\n**Validade:** ${p.days} dia(s)\n\n${charge.qrCodeText?`\`\`\`\n${safe(charge.qrCodeText,1800)}\n\`\`\``:'Use o QR Code/link retornado pela EvoPay.'}\n\n-# A confirmação é automática. Não existe botão de aprovação manual.`));
    const payload={components:[c],flags:MessageFlags.IsComponentsV2}; if(qr)payload.files=[new AttachmentBuilder(qr,{name:'pix.png'})]; await i.editReply(payload); void watchOrder(i,order.id); return;
  }
}

async function handleChannelSelect(i){
  if(i.customId!=='pm:publish:channel')return;owner(i);const channel=await client.channels.fetch(i.values[0]);if(!channel?.isTextBased?.()||!channel.send)throw new Error('Canal inválido.');await i.deferUpdate();const sent=await channel.send(storefrontPayload(i.guildId));const r=record(),published={...(r.published||{}),[i.guildId]:{channelId:channel.id,messageId:sent.id}};store.patch(managerId,{published});return i.editReply(homePayload());
}
async function handleModal(i){
  if(i.customId.startsWith('pm:plan:')&&i.customId.includes(':modal')){owner(i);await i.deferReply({flags:MessageFlags.Ephemeral});const name=safe(i.fields.getTextInputValue('name'),80),days=Number(i.fields.getTextInputValue('days').replace(/\D/g,'')),price=Number(i.fields.getTextInputValue('price').replace(',','.'));if(!name||!Number.isInteger(days)||days<1||days>90||!Number.isFinite(price)||price<=0||price>6)throw new Error('Plano inválido. Use 1–90 dias e preço de até R$ 6,00.');const r=record(),plans=[...r.plans];let pid=i.customId.startsWith('pm:plan:edit:modal:')?i.customId.split(':').slice(4).join(':'):name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,32)||`plan-${Date.now()}`;const idx=plans.findIndex(p=>p.id===pid);const next={id:pid,label:name,days,price:Number(price.toFixed(2)),enabled:idx>=0?plans[idx].enabled!==false:true};if(idx>=0)plans[idx]=next;else{if(plans.length>=10)throw new Error('Limite de 10 planos atingido.');plans.push(next);}store.patch(managerId,{plans});await refreshPublications();return i.editReply('✅ Plano salvo e publicações atualizadas.');}
  if(i.customId==='pm:brand:modal'){owner(i);await i.deferReply({flags:MessageFlags.Ephemeral});const raw=i.fields.getTextInputValue('color').trim().replace('#','');if(!/^[0-9a-fA-F]{6}$/.test(raw))throw new Error('Cor inválida. Use #RRGGBB.');const brand={...record().brand,title:safe(i.fields.getTextInputValue('title'),100),description:safe(i.fields.getTextInputValue('description'),1500),bannerUrl:safe(i.fields.getTextInputValue('banner'),1000),accentColor:parseInt(raw,16)};store.patch(managerId,{brand});const count=await refreshPublications();return i.editReply(`✅ Personalização salva. ${count} publicação(ões) atualizada(s).`);}
  if(i.customId==='pm:withdraw:modal'){owner(i);await i.deferReply({flags:MessageFlags.Ephemeral});const amount=Number(i.fields.getTextInputValue('amount').replace(/[^\d,.-]/g,'').replace(',','.'));const wd=await rpc('withdraw',{amount,pixKey:i.fields.getTextInputValue('pix')});return i.editReply(`✅ Saque solicitado: ${money(wd.amountCents)} • taxa ${money(wd.feeCents)} • líquido ${money(wd.payoutCents)}. ID: \`${wd.id}\``);}
  if(i.customId.startsWith('pm:register-app:modal:')){const orderId=i.customId.slice('pm:register-app:modal:'.length),order=store.getOrder(orderId);if(!order||String(order.userId)!==String(i.user.id)||order.status!=='PAID')throw new Error('Compra inválida ou já indisponível.');await i.deferReply({flags:MessageFlags.Ephemeral});await i.editReply('⏳ Validando token, servidor e preparando a aplicação...');const result=await rpc('provision-app',{token:i.fields.getTextInputValue('token'),guildId:i.fields.getTextInputValue('guild'),userId:i.user.id,days:order.days,planLabel:order.planLabel},120000);store.patchOrder(orderId,{status:'DELIVERED',appId:result.appId,deliveredAt:new Date().toISOString()});process.send?.({type:'app-online',at:new Date().toISOString()});return i.editReply(`✅ **Aplicação online.**\nRuntime: \`${result.appId}\`\nBot: **${result.username}**\nValidade: <t:${Math.floor(Date.parse(result.expiresAt)/1000)}:R>.`);}
}

async function fail(i,error){const msg=`❌ ${safe(error?.message||error,1800)}`;try{if(i.deferred||i.replied)await i.editReply({content:msg,components:[],embeds:[]});else await i.reply({content:msg,flags:MessageFlags.Ephemeral});}catch{}}
client.on('interactionCreate',i=>void(async()=>{try{if(i.isChatInputCommand())return handleCommand(i);if(i.isButton())return handleButton(i);if(i.isStringSelectMenu())return handleSelect(i);if(i.isChannelSelectMenu())return handleChannelSelect(i);if(i.isModalSubmit())return handleModal(i);}catch(e){return fail(i,e);}})());
client.on('guildCreate',g=>void registerCommands(g.id).catch(()=>undefined));
client.once('ready',async()=>{
  for(const g of client.guilds.cache.values()) await registerCommands(g.id).catch(()=>undefined);
  try { await brandEnforcer.enforceOne({token}, String(process.env.MAIN_MANAGER_APPLICATION_ID||'')); } catch {}
  process.send?.({type:'ready'});
  console.log(`[PARTNER MANAGER] ${client.user.tag} online • ${managerId}`);
});
process.on('SIGTERM',()=>client.destroy());process.on('SIGINT',()=>client.destroy());
client.login(token).catch(error=>{console.error('[PARTNER MANAGER] login:',error?.message||error);process.exit(1);});
