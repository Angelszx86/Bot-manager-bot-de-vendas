const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const JSZip = require('jszip');
const camposcloudControl = require('../Lib/shardcloudControl');

function headers(extra={}) {
  const token = camposcloudControl.settings().token;
  if (!token) throw new Error('API da CamposCloud não configurada.');
  return { Authorization: `Bearer ${token}`, ...extra };
}
function api(pathname='') { return `${camposcloudControl.settings().baseUrl}${pathname}`; }
function safeError(error) {
  const status = error?.response?.status;
  const data = error?.response?.data;
  const msg = typeof data === 'string' ? data : data?.message || data?.error || error?.message;
  return `CamposCloud${status ? ` HTTP ${status}` : ''}: ${String(msg || 'falha desconhecida').slice(0,240)}`;
}
async function addDir(zip, root, dir=root) {
  for (const ent of fs.readdirSync(dir, { withFileTypes:true })) {
    if (['node_modules','.git','.cache'].includes(ent.name)) continue;
    if (['runtime.log','package-lock.json','processes.json'].includes(ent.name)) continue;
    const abs = path.join(dir, ent.name); const rel = path.relative(root, abs).replace(/\\/g,'/');
    if (ent.isDirectory()) await addDir(zip, root, abs);
    else if (ent.isFile()) zip.file(rel, fs.readFileSync(abs));
  }
}
async function projectZipBuffer(runtimeDir) {
  const zip = new JSZip();
  await addDir(zip, runtimeDir);
  return zip.generateAsync({ type:'nodebuffer', compression:'DEFLATE', compressionOptions:{level:6} });
}
async function createFromDirectory(runtimeDir, { main='index.js', lang='node', displayName='Astra Application' }={}) {
  try {
    const project = await projectZipBuffer(runtimeDir);
    const form = new FormData();
    form.append('file', project, { filename:'project.zip', contentType:'application/zip' });
    form.append('appName', String(displayName).slice(0,100));
    form.append('mainFile', String(main));
    form.append('memoryMB', String(camposcloudControl.settings().childMemoryMb));
    form.append('runtimeEnvironment', lang === 'python' ? 'python' : 'nodejs');
    form.append('autoRestartEnabled', 'true');
    const r = await axios.post(api('/v1/apps/create'), form, { headers: headers(form.getHeaders()), timeout:120000, maxBodyLength:Infinity, maxContentLength:Infinity });
    const id = r?.data?._id || r?.data?.id || r?.data?.app_id || r?.data?.applicationId;
    if (!id) throw new Error('A API da CamposCloud não retornou o ID da aplicação.');
    return { id:String(id), data:r.data };
  } catch (e) { throw new Error(safeError(e)); }
}
async function setStatus(appId, action) {
  try {
    const r = await axios.post(api(`/v1/apps/${encodeURIComponent(appId)}/${action}`), {}, { headers:headers({'Content-Type':'application/json'}), timeout:30000 });
    return r.data || {ok:true};
  } catch(e) { throw new Error(safeError(e)); }
}
async function run(appId){ return setStatus(appId,'start'); }
async function stop(appId){ return setStatus(appId,'stop'); }
async function restart(appId){ return setStatus(appId,'restart'); }
async function remove(appId){
  try { const r = await axios.delete(api(`/v1/apps/${encodeURIComponent(appId)}/delete`), {headers:headers(),timeout:30000}); return r.data||{ok:true}; }
  catch(e){ throw new Error(safeError(e)); }
}
async function status(appId){
  try { const r = await axios.get(api(`/v1/apps/${encodeURIComponent(appId)}`), {headers:headers(),timeout:30000}); return r.data || {}; }
  catch(e){ throw new Error(safeError(e)); }
}
async function testToken(){
  try { await axios.get(api('/v1/users/@me'), {headers:headers(),timeout:15000}); return {ok:true}; }
  catch(e){ return {ok:false,error:safeError(e)}; }
}
module.exports={ projectZipBuffer, createFromDirectory, run, stop, restart, status, remove, testToken };
