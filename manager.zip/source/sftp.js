const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
function safeId(value) {
  const id = String(value || '').trim();
  if (!/^[a-zA-Z0-9_-]+$/.test(id)) throw new Error('ID de aplicação inválido.');
  return id;
}
function mirrorDir(appId) { return path.join(ROOT, `zenyx-${safeId(appId)}`); }
function settings() {
  return {
    host: String(process.env.HIDENCLOUD_SFTP_HOST || process.env.SFTP_HOST || '').trim(),
    port: Math.max(1, Number(process.env.HIDENCLOUD_SFTP_PORT || process.env.SFTP_PORT || 22) || 22),
    username: String(process.env.HIDENCLOUD_SFTP_USER || process.env.SFTP_USER || '').trim(),
    password: String(process.env.HIDENCLOUD_SFTP_PASSWORD || process.env.SFTP_PASSWORD || '').trim(),
    privateKey: String(process.env.HIDENCLOUD_SFTP_PRIVATE_KEY || '').replace(/\\n/g, '\n').trim(),
    remoteRoot: String(process.env.HIDENCLOUD_SFTP_ROOT || process.env.SFTP_ROOT || '.').trim() || '.'
  };
}
function ready(s = settings()) { return Boolean(s.host && s.username && (s.password || s.privateKey)); }
function status() {
  const s = settings();
  return { ok: ready(s), hostConfigured: Boolean(s.host), userConfigured: Boolean(s.username), authConfigured: Boolean(s.password || s.privateKey), localMirror: true };
}
function latestLocalBackup(appId) {
  const dir = mirrorDir(appId);
  if (!fs.existsSync(dir)) return '';
  const files = fs.readdirSync(dir).filter(name => name.toLowerCase().endsWith('.zip')).map(name => path.join(dir, name));
  files.sort((a,b) => { try { return fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs; } catch { return 0; } });
  return files[0] || '';
}
async function uploadZip(zipPath, appId) {
  appId = safeId(appId);
  if (!zipPath || !fs.existsSync(zipPath)) throw new Error('ZIP de aplicação não encontrado para backup.');
  const dir = mirrorDir(appId); fs.mkdirSync(dir, { recursive: true });
  const local = path.join(dir, path.basename(zipPath));
  if (path.resolve(zipPath) !== path.resolve(local)) fs.copyFileSync(zipPath, local);
  const s = settings();
  if (!ready(s)) return { ok: true, local, remote: false };
  let client;
  try {
    const SftpClient = require('ssh2-sftp-client'); client = new SftpClient();
    await client.connect({ host:s.host, port:s.port, username:s.username, ...(s.privateKey ? { privateKey:s.privateKey } : { password:s.password }) });
    const remoteDir = `${s.remoteRoot.replace(/\\/g,'/').replace(/\/$/,'')}/zenyx-${appId}`;
    await client.mkdir(remoteDir, true).catch(() => undefined);
    await client.put(local, `${remoteDir}/${path.basename(local)}`);
    return { ok:true, local, remote:true };
  } finally { if (client) await client.end().catch(() => undefined); }
}
async function removeApp(appId) {
  appId = safeId(appId);
  try { fs.rmSync(mirrorDir(appId), { recursive:true, force:true }); } catch {}
  const s=settings(); if(!ready(s)) return {ok:true,remote:false};
  let client;
  try {
    const SftpClient=require('ssh2-sftp-client'); client=new SftpClient();
    await client.connect({host:s.host,port:s.port,username:s.username,...(s.privateKey?{privateKey:s.privateKey}:{password:s.password})});
    const remoteDir=`${s.remoteRoot.replace(/\\/g,'/').replace(/\/$/,'')}/zenyx-${appId}`;
    await client.rmdir(remoteDir,true).catch(()=>undefined);
    return {ok:true,remote:true};
  } finally { if(client) await client.end().catch(()=>undefined); }
}
module.exports={settings,status,uploadZip,removeApp,latestLocalBackup,mirrorDir};
