/**
 * Runtime local de hospedagem (estilo Zenyx) — Manager V2 + Zenyx Sallers.
 *
 * Roda os bots hospedados como PROCESSOS LOCAIS (subprocessos Node ou Python)
 * e mantém PID/logs/estado em disco. É isso que "deixa o bot online" sem
 * depender de API key da HidenCloud — igual o Zenyx faz.
 *
 * Também detecta o arquivo principal e instala dependências
 * (npm install / npm run build para Node; pip install -r requirements.txt
 * para Python) usando o squarecloud.config / squarecloud.app do projeto.
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const net = require('net');
const { ensureInfrastructure: ensureZcloudInfrastructure } = require('../Lib/zcloudGateway');
const zcloudControl = require('../Lib/zcloudControl');
const walletControl = require('../Lib/walletControl');
const magnusControl = require('../Lib/magnusControl');
const childBioControl = require('../Lib/childBioControl');
const evopay = require('../Lib/evopay');
const brandEnforcer = require('../Lib/brandEnforcer');
const shardcloudControl = require('../Lib/shardcloudControl');
const shardcloudApi = require('./shardcloud_api');
const sftp = require('./sftp');

async function enforceChildBioFromRuntime(appId) {
  try {
    const tokenFile = path.join(appDir(appId), 'Token.json');
    if (!fs.existsSync(tokenFile)) return { ok: false, skipped: true, reason: 'Token.json ausente' };
    const tokenData = JSON.parse(fs.readFileSync(tokenFile, 'utf8'));
    const token = String(tokenData?.token || '').trim();
    if (!token) return { ok: false, skipped: true, reason: 'token ausente' };
    return await brandEnforcer.enforceOne({ id: appId, idapp: appId, token }, null);
  } catch (error) {
    try { fs.appendFileSync(path.join(appDir(appId), 'runtime.log'), `\n[ZENYX BIO] Falha ao reforçar Bio institucional: ${String(error?.message || error).slice(0, 220)}\n`); } catch {}
    return { ok: false, error: String(error?.message || error) };
  }
}

const ZENYX_ASCII = String.raw`
███████╗███████╗███╗   ██╗██╗   ██╗██╗  ██╗
╚══███╔╝██╔════╝████╗  ██║╚██╗ ██╔╝╚██╗██╔╝
  ███╔╝ █████╗  ██╔██╗ ██║ ╚████╔╝  ╚███╔╝
 ███╔╝  ██╔══╝  ██║╚██╗██║  ╚██╔╝   ██╔██╗
███████╗███████╗██║ ╚████║   ██║   ██╔╝ ██╗
╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝`;

const RUNTIME_ROOT = path.join(__dirname, 'runtime');
const STATE_FILE = path.join(RUNTIME_ROOT, 'processes.json');
fs.mkdirSync(RUNTIME_ROOT, { recursive: true });

// R18.9.45: serializa boots por aplicação. Dois cliques/watchdogs simultâneos
// não podem criar dois processos usando o mesmo token do Discord.
const startInFlight = new Map();

// R18.9.53: fila global de inicialização. Subir dezenas de processos Node ao
// mesmo tempo provoca pico de RAM/CPU e pode fazer o host matar bots que já
// estavam online. A fila mantém no máximo poucas inicializações simultâneas.
const START_CONCURRENCY = Math.max(1, Math.min(4, Number(process.env.HIDENCLOUD_START_CONCURRENCY || 2) || 2));
let activeStarts = 0;
const startQueue = [];
function pumpStartQueue() {
  while (activeStarts < START_CONCURRENCY && startQueue.length) {
    const item = startQueue.shift();
    activeStarts++;
    Promise.resolve().then(item.run).then(item.resolve, item.reject).finally(() => {
      activeStarts--;
      setTimeout(pumpStartQueue, 250).unref?.();
    });
  }
}
function enqueueStart(run) {
  return new Promise((resolve, reject) => {
    startQueue.push({ run, resolve, reject });
    pumpStartQueue();
  });
}

function cgroupMemoryPressure() {
  try {
    const current = Number(fs.readFileSync('/sys/fs/cgroup/memory.current', 'utf8').trim());
    const rawMax = fs.readFileSync('/sys/fs/cgroup/memory.max', 'utf8').trim();
    const max = rawMax === 'max' ? 0 : Number(rawMax);
    if (current > 0 && max > 0) return { current, max, ratio: current / max };
  } catch {}
  return null;
}
async function waitForMemoryHeadroom() {
  // Não trava indefinidamente. Só espaça boots durante picos severos.
  for (let i = 0; i < 6; i++) {
    const mem = cgroupMemoryPressure();
    if (!mem || mem.ratio < 0.92) return;
    await sleep(2500);
  }
}

function appDir(appId) {
  if (!/^[a-zA-Z0-9_-]+$/.test(String(appId))) throw new Error('ID de aplicação inválido.');
  return path.join(RUNTIME_ROOT, String(appId));
}

function loadState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  } catch {
    return { processes: {} };
  }
}

function saveState(s) {
  fs.mkdirSync(RUNTIME_ROOT, { recursive: true });
  const tmp = `${STATE_FILE}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(s, null, 2));
  fs.renameSync(tmp, STATE_FILE);
}

function isAlive(pid) {
  if (!pid || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/**
 * Confirma que um PID salvo realmente pertence ao runtime desta aplicação.
 * Um processes.json empacotado/reutilizado em outro container pode conter um
 * PID que agora pertence a outro processo. Nunca devemos considerar esse PID
 * como o bot nem, principalmente, tentar encerrá-lo.
 */
function isManagedProcessAlive(appId, pid) {
  if (!isAlive(pid)) return false;
  if (process.platform !== 'linux') return true;
  try {
    const cwd = fs.realpathSync(`/proc/${pid}/cwd`);
    const expected = fs.realpathSync(appDir(appId));
    return cwd === expected;
  } catch {
    return false;
  }
}

/**
 * Descobre TODOS os processos que ainda estão executando dentro do diretório
 * de uma aplicação. Isso corrige runtimes órfãos criados por duas tentativas
 * simultâneas de start/restart: processes.json guardava só um PID e a segunda
 * cópia continuava conectada ao Discord, duplicando mensagens e eventos.
 */
function discoverManagedPids(appId) {
  const out = new Set();
  if (process.platform !== 'linux') return out;
  let expected;
  try { expected = fs.realpathSync(appDir(appId)); } catch { return out; }
  let entries = [];
  try { entries = fs.readdirSync('/proc', { withFileTypes: true }); } catch { return out; }
  for (const entry of entries) {
    if (!entry.isDirectory() || !/^\d+$/.test(entry.name)) continue;
    const pid = Number(entry.name);
    if (!pid || pid === process.pid || !isAlive(pid)) continue;
    try {
      const cwd = fs.realpathSync(`/proc/${pid}/cwd`);
      if (cwd === expected) out.add(pid);
    } catch {}
  }
  return out;
}

function killManagedPid(pid) {
  if (!pid || !isAlive(pid)) return true;
  try { process.kill(-pid, 'SIGTERM'); return true; }
  catch {
    try { process.kill(pid, 'SIGTERM'); return true; }
    catch { return false; }
  }
}

function reconcileManagedProcesses(appId) {
  const st = loadState();
  const cur = st.processes[appId] || {};
  const discovered = [...discoverManagedPids(appId)].sort((a, b) => a - b);
  const remembered = isManagedProcessAlive(appId, cur.pid) ? Number(cur.pid) : 0;
  const keeper = remembered || discovered[0] || 0;
  let removed = 0;
  if (keeper) {
    for (const pid of discovered) {
      if (pid === keeper) continue;
      if (killManagedPid(pid)) removed++;
    }
    st.processes[appId] = { ...cur, pid: keeper, appDir: appDir(appId), reconciledAt: Date.now() };
    saveState(st);
  } else if (cur.pid) {
    st.processes[appId] = { ...cur, pid: 0, reconciledAt: Date.now() };
    saveState(st);
  }
  return { pid: keeper, removed, discovered: discovered.length };
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function readLogs(appId, limit = 1800) {
  try {
    const f = path.join(appDir(appId), 'runtime.log');
    if (!fs.existsSync(f)) return 'Sem logs ainda.';
    const d = fs.readFileSync(f, 'utf8');
    return d.slice(-limit) || 'Sem logs ainda.';
  } catch {
    return 'Não consegui ler os logs.';
  }
}

function rotateLog(appId, maxBytes = Number(process.env.HIDENCLOUD_LOG_MAX_BYTES || 2 * 1024 * 1024)) {
  try {
    const f = path.join(appDir(appId), 'runtime.log');
    if (!fs.existsSync(f) || fs.statSync(f).size <= maxBytes) return;
    const old = `${f}.1`;
    try { fs.rmSync(old, { force: true }); } catch {}
    fs.renameSync(f, old);
  } catch {}
}

function listFiles(dir) {
  const out = new Set();
  const walk = (d) => {
    let entries;
    try {
      entries = fs.readdirSync(d, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      if (e.name === 'node_modules' || e.name === '.git' || e.name === '.venv') continue;
      const full = path.join(d, e.name);
      if (e.isDirectory()) walk(full);
      else out.add(path.relative(dir, full).split(path.sep).join('/'));
    }
  };
  walk(dir);
  return out;
}

function readCloudConfig(dir) {
  for (const name of ['camposcloud.config', 'squarecloud.config', 'squarecloud.app', 'discloud.config']) {
    const p = path.join(dir, name);
    if (!fs.existsSync(p)) continue;
    const txt = fs.readFileSync(p, 'utf8');
    const cfg = {};
    for (const line of txt.split(/\r?\n/)) {
      const m = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
      if (m) cfg[m[1].trim().toUpperCase()] = m[2].trim();
    }
    return cfg;
  }
  return null;
}

function detectRuntime(appId) {
  const dir = appDir(appId);
  const files = listFiles(dir);
  const hasPackage = fs.existsSync(path.join(dir, 'package.json'));
  const hasReq = fs.existsSync(path.join(dir, 'requirements.txt'));
  const cfg = readCloudConfig(dir);

  let lang = 'node';
  let main = '';
  if (cfg && cfg.MAIN) main = cfg.MAIN;
  if (cfg && cfg.RUNTIME) lang = String(cfg.RUNTIME).toLowerCase().includes('py') ? 'python' : 'node';
  if (cfg && cfg.TYPE === 'bot' && !cfg.MAIN) main = 'index.js';

  if (!main && hasPackage) {
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    if (typeof pkg.main === 'string') main = pkg.main;
  }
  if (!main) {
    for (const f of ['index.js', 'bot.js', 'main.js', 'app.js', 'server.js', 'src/index.js']) {
      if (files.has(f)) { main = f; break; }
    }
  }
  if (!main) {
    for (const f of ['bot.py', 'main.py', 'app.py', 'index.py', 'run.py', 'src/main.py']) {
      if (files.has(f)) { main = f; lang = 'python'; break; }
    }
  }
  if (!main) {
    for (const f of files) {
      if (f.endsWith('.py') && !f.includes('/')) { main = f; lang = 'python'; break; }
    }
    if (!main) {
      for (const f of files) {
        if (f.endsWith('.js') && !f.includes('/')) { main = f; break; }
      }
    }
  }
  if (!main) main = 'index.js';
  return { lang, main, hasPackage, hasReq, cfg };
}

async function extractZip(zipInput, appId) {
  const dir = appDir(appId);
  fs.mkdirSync(dir, { recursive: true });
  const JSZip = require('jszip');
  const data = Buffer.isBuffer(zipInput) ? zipInput : fs.readFileSync(zipInput);
  const zip = await JSZip.loadAsync(data);
  const base = path.resolve(dir);
  for (const [name, entry] of Object.entries(zip.files)) {
    if (entry.dir) continue;
    const dest = path.resolve(dir, name);
    // proteção contra path traversal
    if (dest !== base && !dest.startsWith(base + path.sep)) continue;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, await entry.async('nodebuffer'));
  }
  return { ok: true };
}

/**
 * R18.9.82 — recuperação de runtime ausente.
 * A HidenCloud pode reiniciar com o banco do Manager intacto enquanto a pasta
 * source/runtime/<appId> não foi restaurada ainda. O Manager mantém um espelho
 * local dos ZIPs em zenyx-<appId>/; quando existir, reconstruímos a aplicação
 * de forma atômica em staging em vez de declarar imediatamente "arquivos não
 * encontrados". Tokens/configs continuam vindo do próprio ZIP do cliente.
 */
async function recoverMissingRuntime(appId, options = {}) {
  const dir = appDir(appId);
  if (fs.existsSync(dir)) return { ok: true, recovered: false, dir };
  const backup = typeof sftp.latestLocalBackup === 'function' ? sftp.latestLocalBackup(appId) : '';
  if (!backup || !fs.existsSync(backup)) return { ok: false, recovered: false, msg: 'Arquivos do app não encontrados e nenhum backup local foi localizado.' };
  const stageId = `recover_${String(appId).replace(/[^a-zA-Z0-9_-]/g,'_')}_${Date.now()}_${process.pid}`;
  const stageDir = appDir(stageId);
  try {
    fs.rmSync(stageDir, { recursive: true, force: true });
    await extractZip(backup, stageId);
    const runtimeInfo = detectRuntime(stageId);
    if (!fs.existsSync(path.join(stageDir, runtimeInfo.main))) {
      if (options.prepare !== false) await prepare(stageId);
    }
    if (!fs.existsSync(path.join(stageDir, detectRuntime(stageId).main))) throw new Error('Backup localizado, mas o arquivo principal não pôde ser restaurado.');
    fs.mkdirSync(path.dirname(dir), { recursive: true });
    fs.renameSync(stageDir, dir);
    try { fs.appendFileSync(path.join(dir,'runtime.log'), `\n[ZENYX RECOVERY] Runtime restaurado automaticamente de ${path.basename(backup)} em ${new Date().toISOString()}.\n`); } catch {}
    return { ok: true, recovered: true, backup, dir };
  } catch (error) {
    try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch {}
    return { ok: false, recovered: false, msg: `Falha ao restaurar o runtime: ${String(error?.message || error).slice(0,300)}` };
  }
}


function ensureNodeModuleCompatibility(appId, main) {
  const dir = appDir(appId);
  const pkgPath = path.join(dir, 'package.json');
  const mainPath = path.join(dir, main || '');
  if (!fs.existsSync(pkgPath) || !fs.existsSync(mainPath) || !String(main).endsWith('.js')) return { changed: false };
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8')); } catch { return { changed: false }; }
  if (pkg.type !== 'module') return { changed: false };
  let head = '';
  try { head = fs.readFileSync(mainPath, 'utf8').slice(0, 12000); } catch { return { changed: false }; }
  const looksCommonJS = /Object\.defineProperty\(exports|\bmodule\.exports\b|\brequire\s*\(/.test(head);
  if (!looksCommonJS) return { changed: false };
  pkg.type = 'commonjs';
  fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n');
  try { fs.appendFileSync(path.join(dir, 'runtime.log'), '\n[ZENYX RUNTIME] package.json ajustado para CommonJS porque o dist compilado usa exports/require.\n'); } catch {}
  return { changed: true, type: 'commonjs' };
}

function packageLockMatchesPackage(dir) {
  const pkgPath = path.join(dir, 'package.json');
  const lockPath = path.join(dir, 'package-lock.json');
  if (!fs.existsSync(pkgPath) || !fs.existsSync(lockPath)) return false;
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    const locked = lock?.packages?.[''] || {};
    for (const section of ['dependencies', 'optionalDependencies']) {
      const wanted = pkg?.[section] || {};
      const got = locked?.[section] || {};
      for (const name of Object.keys(wanted)) if (!(name in got)) return false;
    }
    return true;
  } catch { return false; }
}

function nodeModulesSatisfyPackage(dir, pkg) {
  const modulesDir = path.join(dir, 'node_modules');
  if (!fs.existsSync(modulesDir)) return false;
  try {
    for (const section of ['dependencies', 'optionalDependencies']) {
      const wanted = pkg?.[section] || {};
      for (const name of Object.keys(wanted)) {
        const parts = String(name).split('/').filter(Boolean);
        const packageJson = path.join(modulesDir, ...parts, 'package.json');
        if (!fs.existsSync(packageJson)) return false;
      }
    }
    return true;
  } catch { return false; }
}

/** Instala dependências (e faz build se preciso) antes de ligar. */
async function prepare(appId) {
  const { lang, hasPackage, hasReq, main } = detectRuntime(appId);
  const dir = appDir(appId);
  rotateLog(appId);
  const fd = fs.openSync(path.join(dir, 'runtime.log'), 'a');
  const run = (cmd, args) => new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { cwd: dir, env: childEnv(appId), stdio: ['ignore', fd, fd] });
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('Instalação excedeu 5 minutos.')); }, 300000);
    child.once('error', error => { clearTimeout(timer); reject(error); });
    child.once('exit', code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error(`Preparação falhou (código ${code}); consulte os logs da aplicação.`)); });
  });
  try {
    if (lang === 'node' && hasPackage) {
      const installMode = packageLockMatchesPackage(dir) ? 'ci' : 'install';
      const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
      const needsBuild = !fs.existsSync(path.join(dir, main)) && Boolean(pkg.scripts?.build);
      // O template oficial já leva dist/ compilado. Nesse caso instalar apenas
      // dependências de produção evita TypeScript/tsx em cada bot e reduz muito
      // pico de RAM, tráfego e armazenamento durante atualizações em massa.
      const dependencyMode = needsBuild ? '--include=dev' : '--omit=dev';
      await run('npm', [installMode, '--ignore-scripts', dependencyMode, '--no-audit', '--no-fund']);
      if (needsBuild) await run('npm', ['run', 'build']);
      // Runtimes oficiais não precisam carregar TypeScript/tsx e outras
      // dependências de desenvolvimento depois do build. Isso reduz bastante o
      // armazenamento sem apagar banco, uploads, configs ou dependências de produção.
      if (isOfficialZenyx(appId) && needsBuild) {
        await run('npm', ['prune', '--omit=dev', '--ignore-scripts', '--no-audit', '--no-fund']).catch(() => undefined);
      }
    } else if (lang === 'python' && hasReq) await run(process.env.HIDENCLOUD_PYTHON || 'python3', ['-m', 'pip', 'install', '-r', 'requirements.txt']);
    if (!fs.existsSync(path.join(dir, main))) throw new Error('Arquivo principal não existe depois da preparação.');
    if (lang === 'node') ensureNodeModuleCompatibility(appId, main);
    return { ok: true };
  } finally { fs.closeSync(fd); }
}

function isOfficialZenyx(appId) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(appDir(appId), 'package.json'), 'utf8'));
    return pkg?.name === 'zenyx-pro-professional';
  } catch {
    return false;
  }
}

function portIsFree(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.unref();
    server.once('error', () => resolve(false));
    server.listen({ host: '127.0.0.1', port, exclusive: true }, () => {
      server.close(() => resolve(true));
    });
  });
}

function hashText(value) {
  let h = 2166136261;
  for (const ch of String(value)) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

async function allocateZcloudPort(appId, state) {
  const remembered = Number(state?.processes?.[appId]?.zcloudPort || 0);
  if (remembered >= 20000 && remembered <= 59999 && await portIsFree(remembered)) return remembered;
  const used = new Set(Object.values(state?.processes || {}).map((entry) => Number(entry?.zcloudPort || 0)).filter(Boolean));
  const base = 32000;
  const span = 18000;
  const start = base + (hashText(appId) % span);
  for (let offset = 0; offset < 300; offset++) {
    const candidate = base + ((start - base + offset) % span);
    if (used.has(candidate)) continue;
    if (await portIsFree(candidate)) return candidate;
  }
  throw new Error('Não encontrei uma porta local livre para o ZCloud Auth.');
}


function configureZcloudRuntime(appId, zcloudPort, infra) {
  if (!isOfficialZenyx(appId)) return { changed: false };
  const file = path.join(appDir(appId), 'config', 'runtime.json');
  let runtime = {};
  try { runtime = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
  const next = {
    ...runtime,
    zcloudPort: Number(zcloudPort) || Number(runtime.zcloudPort) || 3000,
    // A URL pública aponta para o Reverse Proxy HTTPS do próprio Manager na
    // HidenCloud e inclui o appId. Cada processo filho fica isolado por rota.
    zcloudEdgeBaseUrl: String(infra?.baseUrl || '').trim(),
    zcloudCloudflaredPath: '',
    zcloudTunnelAuto: false,
    zcloudManagerEnabled: zcloudControl.isEnabled(),
    walletManagerEnabled: walletControl.isEnabled(),
    magnusManagerEnabled: magnusControl.isEnabled()
  };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const before = JSON.stringify(runtime);
  const after = JSON.stringify(next);
  if (before !== after || !fs.existsSync(file)) {
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2) + '\n', 'utf8');
    fs.renameSync(tmp, file);
    return { changed: true };
  }
  return { changed: false };
}

function configureWalletRuntime(appId) {
  if (!isOfficialZenyx(appId)) return { changed: false };
  const file = path.join(appDir(appId), 'config', 'runtime.json');
  let runtime = {};
  try { runtime = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
  const next = { ...runtime, walletManagerEnabled: walletControl.isEnabled() };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const before = JSON.stringify(runtime);
  const after = JSON.stringify(next);
  if (before !== after || !fs.existsSync(file)) {
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2) + '\n', 'utf8');
    fs.renameSync(tmp, file);
    return { changed: true };
  }
  return { changed: false };
}

function configureMagnusRuntime(appId) {
  if (!isOfficialZenyx(appId)) return { changed: false };
  const file = path.join(appDir(appId), 'config', 'runtime.json');
  let runtime = {};
  try { runtime = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
  const next = { ...runtime, magnusManagerEnabled: magnusControl.isEnabled() };
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (JSON.stringify(runtime) !== JSON.stringify(next) || !fs.existsSync(file)) {
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2) + '\n', 'utf8');
    fs.renameSync(tmp, file);
    return { changed: true };
  }
  return { changed: false };
}

function childEnv(appId = '', zcloudPort = 0, infra = null) {
  // Credentials stay in the manager; hosted processes do not inherit them.
  const env = { PYTHONUNBUFFERED: '1' };
  for (const key of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'TZ', 'NODE_ENV']) if (process.env[key]) env[key] = process.env[key];
  // Evita que uma única instância Node consuma toda a máquina. O limite é
  // configurável e funciona como teto, não como memória reservada.
  const maxOldSpace = Math.max(64, parseInt(process.env.HIDENCLOUD_CHILD_MAX_OLD_SPACE_MB || '256', 10) || 256);
  env.NODE_OPTIONS = `${process.env.HIDENCLOUD_CHILD_NODE_OPTIONS || ''} --max-old-space-size=${maxOldSpace}`.trim();
  env.UV_THREADPOOL_SIZE = process.env.HIDENCLOUD_CHILD_UV_THREADPOOL_SIZE || '4';

  // ZCloud/Zwallet recebem configuração operacional por config/runtime.json.
  // O único segredo central permitido ao bot oficial é a credencial EvoPay
  // usada pelo Znypay; ela é entregue somente ao subprocesso e não é gravada
  // em config.json, .env ou no banco do assinante.
  if (isOfficialZenyx(appId) && walletControl.isEnabled()) {
    const central = evopay.settings();
    if (central.token) env.ZNYPAY_EVOPAY_TOKEN = central.token;
  }
  if (isOfficialZenyx(appId)) {
    const globalBio = childBioControl.bio();
    if (globalBio) env.ZENYX_GLOBAL_CHILD_BIO = globalBio;
  }
  return env;
}

async function startOnShardCloud(appId, reason = 'limite local') {
  let dir = appDir(appId);
  if (!fs.existsSync(dir)) { const recovery = await recoverMissingRuntime(appId); if (!recovery.ok) return { ok:false, msg:recovery.msg }; dir = appDir(appId); }
  if (!shardcloudControl.isReady()) return { ok:false, msg:'CamposCloud não está configurada.' };
  const runtimeInfo = detectRuntime(appId);
  let st = loadState();
  const current = st.processes[appId] || {};
  try {
    let remoteAppId = ['shardcloud','camposcloud'].includes(current.remoteProvider) ? current.remoteAppId : null;
    if (!remoteAppId) {
      const created = await shardcloudApi.createFromDirectory(dir, {
        main: runtimeInfo.main,
        lang: runtimeInfo.lang,
        displayName: `ZENYX ${appId}`
      });
      remoteAppId = created.id;
    }
    await shardcloudApi.run(remoteAppId);
    st = loadState();
    st.processes[appId] = {
      ...(st.processes[appId] || {}), pid:0, startedAt:Date.now(), appDir:dir,
      lang:runtimeInfo.lang, main:runtimeInfo.main, remoteProvider:'camposcloud',
      remoteAppId, remoteStopped:false, remoteReason:String(reason).slice(0,160)
    };
    saveState(st);
    try { fs.appendFileSync(path.join(dir,'runtime.log'), `\n[CAMPOSCLOUD] Aplicação enviada/iniciada remotamente (${reason}). ID remoto ${remoteAppId}.\n`); } catch {}
    return { ok:true, msg:'App ligado via CamposCloud.', pid:0, remoteProvider:'camposcloud', remoteAppId };
  } catch (error) {
    try { fs.appendFileSync(path.join(dir,'runtime.log'), `\n[CAMPOSCLOUD] Falha: ${String(error?.message || error).slice(0,300)}\n`); } catch {}
    return { ok:false, msg:`CamposCloud falhou: ${String(error?.message || error).slice(0,220)}` };
  }
}

async function startInternal(appId, options = {}) {
  let dir = appDir(appId);
  if (!fs.existsSync(dir)) {
    const recovery = await recoverMissingRuntime(appId);
    if (!recovery.ok) return { ok:false, msg:recovery.msg || 'Arquivos do app não encontrados.' };
    dir = appDir(appId);
  }
  let st = loadState();
  const prior = st.processes[appId] || {};
  const shardSettings = shardcloudControl.settings();
  // Astra Application é apenas o control plane: nenhum bot de cliente é iniciado neste host.
  // A pasta local existe somente para preservar dados e montar o deploy remoto.
  if (!shardcloudControl.isReady()) return { ok:false, msg:'Configure a API Key da CamposCloud antes de iniciar aplicações de clientes.' };
  return startOnShardCloud(appId, options.reason || 'lifecycle remoto Astra Application');
  // Se a aplicação já foi movida ao fallback, nunca crie uma cópia local em paralelo.
  if (prior.remoteProvider === 'shardcloud' && prior.remoteAppId) {
    if (shardSettings.token && shardSettings.enabled) return startOnShardCloud(appId, 'continuidade do fallback');
    // Fallback foi desativado: pare a cópia remota antes de voltar ao host local.
    if (shardSettings.token) await shardcloudApi.stop(prior.remoteAppId).catch(() => null);
    st = loadState();
    st.processes[appId] = { ...prior, pid:0, remoteProvider:null, remoteAppId:null, remoteStoppedAt:Date.now() };
    saveState(st);
  }
  const memBefore = cgroupMemoryPressure();
  if (shardcloudControl.isReady() && memBefore && memBefore.ratio >= shardSettings.memoryRatio) {
    const remote = await startOnShardCloud(appId, `memória local ${(memBefore.ratio*100).toFixed(1)}%`);
    if (remote.ok) return remote;
    // Se a API remota estiver indisponível, tente o runtime local em vez de derrubar o cliente.
  }
  await waitForMemoryHeadroom();
  st = loadState();

  // processes.json pode ter ficado atrasado após crash/redeploy. Antes de criar
  // uma nova cópia, reconcilia qualquer processo real com o mesmo cwd.
  const reconciled = reconcileManagedProcesses(appId);
  if (reconciled.pid) {
    void enforceChildBioFromRuntime(appId);
    return { ok: true, msg: reconciled.removed ? `App já estava online; ${reconciled.removed} processo(s) duplicado(s) foram encerrados.` : 'App já está online.', pid: reconciled.pid };
  }
  st = loadState();

  let zcloudPort = 0;
  let zcloudInfra = null;
  if (isOfficialZenyx(appId)) {
    try {
      zcloudPort = await allocateZcloudPort(appId, st);
      zcloudInfra = await ensureZcloudInfrastructure({ appId });
    } catch (error) {
      try { fs.appendFileSync(path.join(dir, 'runtime.log'), `\n[ZCLOUD] Infraestrutura automática ainda não ficou pronta: ${String(error?.message || error).slice(0, 220)}\n`); } catch {}
    }
  }

  if (isOfficialZenyx(appId)) {
    try { configureZcloudRuntime(appId, zcloudPort || 3000, zcloudInfra); }
    catch (error) {
      try { fs.appendFileSync(path.join(dir, 'runtime.log'), `\n[ZCLOUD] Não consegui gravar a configuração operacional: ${String(error?.message || error).slice(0, 220)}\n`); } catch {}
    }
  }

  const { lang, main } = detectRuntime(appId);
  if (lang === 'node') ensureNodeModuleCompatibility(appId, main);
  rotateLog(appId);
  const logFd = fs.openSync(path.join(dir, 'runtime.log'), 'a');
  fs.writeSync(logFd, `\n${ZENYX_ASCII}\n`);
  fs.writeSync(logFd, `============================================================\n`);
  fs.writeSync(logFd, ` ZENYX HOST • CHILD RUNTIME\n`);
  fs.writeSync(logFd, ` APP ID : ${appId}\n`);
  fs.writeSync(logFd, ` START  : ${new Date().toISOString()}\n`);
  fs.writeSync(logFd, ` RUNTIME: ${lang.toUpperCase()}\n`);
  fs.writeSync(logFd, ` MAIN   : ${main}\n`);
  fs.writeSync(logFd, `============================================================\n`);

  let cmd, args;
  if (lang === 'python') {
    cmd = process.env.HIDENCLOUD_PYTHON || 'python3';
    args = [main];
  } else {
    cmd = process.env.HIDENCLOUD_NODE || 'node';
    args = [main];
  }

  let child;
  try {
    child = spawn(cmd, args, {
      cwd: dir,
      env: childEnv(appId, zcloudPort, zcloudInfra),
      stdio: ['ignore', logFd, logFd],
      detached: true,
    });
  } catch (e) {
    fs.closeSync(logFd);
    if (shardcloudControl.isReady() && ['ENOMEM','ENOSPC','EAGAIN'].includes(String(e?.code || '').toUpperCase())) {
      const remote = await startOnShardCloud(appId, `falha de capacidade local ${e.code}`);
      if (remote.ok) return remote;
    }
    return { ok: false, msg: `Não consegui iniciar o processo: ${e.message}` };
  }
  fs.closeSync(logFd);
  let spawnError;
  child.once('error', error => { spawnError = error; });
  child.unref();

  // aguarda um instante para confirmar que não caiu na largada
  const requestedWait = Number(options?.bootWaitMs);
  const wait = Number.isFinite(requestedWait) ? Math.max(800, Math.min(15000, requestedWait)) : parseInt(process.env.HIDENCLOUD_BOOT_WAIT || '4000', 10);
  await sleep(wait);
  if (!spawnError && isAlive(child.pid)) {
    const latest = loadState();
    latest.processes[appId] = { pid: child.pid, startedAt: Date.now(), appDir: dir, lang, main, zcloudPort: zcloudPort || undefined };
    saveState(latest);
    // Não espere o próximo ciclo do watchdog: ao ligar/religar um bot filho,
    // a Bio canônica é reforçada imediatamente pelo Manager.
    void enforceChildBioFromRuntime(appId);
    return { ok: true, msg: 'App ligado!', pid: child.pid };
  }
  const latest = loadState();
  latest.processes[appId] = { pid: 0, startedAt: Date.now(), zcloudPort: zcloudPort || undefined };
  saveState(latest);
  return { ok: false, msg: 'O processo iniciou mas caiu logo depois. Verifique o código.', logs: readLogs(appId) };
}


async function start(appId, options = {}) {
  const key = String(appId);
  const existing = startInFlight.get(key);
  if (existing) return existing;
  const task = enqueueStart(() => startInternal(key, options)).finally(() => {
    if (startInFlight.get(key) === task) startInFlight.delete(key);
  });
  startInFlight.set(key, task);
  return task;
}

async function stop(appId) {
  const st = loadState();
  const cur = st.processes[appId] || {};
  if (['shardcloud','camposcloud'].includes(cur.remoteProvider) && cur.remoteAppId) {
    try { await shardcloudApi.stop(cur.remoteAppId); }
    catch (error) { return { ok:false, msg:`Não consegui desligar na CamposCloud: ${String(error?.message || error).slice(0,220)}` }; }
    st.processes[appId] = { ...cur, pid:0, stoppedAt:Date.now(), remoteStopped:true };
    saveState(st);
    return { ok:true, msg:'App desligado na CamposCloud.' };
  }
  const pids = discoverManagedPids(appId);
  if (isManagedProcessAlive(appId, cur.pid)) pids.add(Number(cur.pid));
  if (!pids.size) {
    st.processes[appId] = { ...cur, pid: 0, stoppedAt: Date.now() };
    saveState(st);
    return { ok: true, msg: 'App já estava desligado.' };
  }
  const failed = [];
  for (const pid of pids) if (!killManagedPid(pid)) failed.push(pid);
  st.processes[appId] = { ...cur, pid: 0, stoppedAt: Date.now(), stoppedPids: [...pids] };
  saveState(st);
  if (failed.length) return { ok: false, msg: `Não consegui desligar completamente os PID(s): ${failed.join(', ')}` };
  return { ok: true, msg: pids.size > 1 ? `App desligado; ${pids.size} processos duplicados foram encerrados.` : 'App desligado.' };
}

async function restart(appId, options = {}) {
  const st = loadState(); const cur = st.processes[appId] || {};
  if (['shardcloud','camposcloud'].includes(cur.remoteProvider) && cur.remoteAppId && shardcloudControl.settings().token) {
    // Reinício remoto também republica os arquivos locais mais recentes. Assim
    // rollout/commit não deixa a cópia da CamposCloud presa em uma versão antiga.
    try {
      await shardcloudApi.remove(cur.remoteAppId);
      const fresh = loadState();
      fresh.processes[appId] = { ...cur, pid:0, remoteProvider:null, remoteAppId:null, remoteStopped:true };
      saveState(fresh);
      return startOnShardCloud(appId, 'reinício/atualização remota');
    } catch (error) {
      try { await shardcloudApi.restart(cur.remoteAppId); return {ok:true,msg:'App reiniciado na CamposCloud.',remoteProvider:'camposcloud'}; }
      catch { return {ok:false,msg:String(error?.message || error)}; }
    }
  }
  await stop(appId);
  return start(appId, options);
}

async function remove(appId) {
  const before = loadState(); const cur = before.processes[appId] || {};
  await stop(appId);
  if (['shardcloud','camposcloud'].includes(cur.remoteProvider) && cur.remoteAppId && shardcloudControl.settings().token) {
    await shardcloudApi.remove(cur.remoteAppId).catch(error => {
      try { fs.appendFileSync(path.join(appDir(appId),'runtime.log'), `\n[CAMPOSCLOUD] Falha ao excluir app remoto: ${String(error?.message || error).slice(0,220)}\n`); } catch {}
    });
  }
  try {
    fs.rmSync(appDir(appId), { recursive: true, force: true });
    const prefix = `.persist-${appId}-`;
    for (const entry of fs.readdirSync(RUNTIME_ROOT, { withFileTypes: true })) {
      if (entry.isDirectory() && entry.name.startsWith(prefix)) fs.rmSync(path.join(RUNTIME_ROOT, entry.name), { recursive: true, force: true });
    }
  } catch (e) { return { ok: false, msg: `Não consegui excluir: ${e.message}` }; }
  const st = loadState(); delete st.processes[appId]; saveState(st);
  return { ok: true, msg: 'App excluído.' };
}

function status(appId) {
  const st = loadState();
  const cur = st.processes[appId] || {};
  if (['shardcloud','camposcloud'].includes(cur.remoteProvider) && cur.remoteAppId && !cur.remoteStopped) {
    return { status:'Online (CamposCloud)', pid:0, remoteProvider:'camposcloud', remoteAppId:cur.remoteAppId,
      usage:{cpu:'remoto',ram:'remoto',storage:'remoto',network:{total:'0',now:'0'}}, requests:0,
      uptimeTimestamp:cur.startedAt || Date.now(), logs:readLogs(appId,800).toLowerCase() };
  }
  const pid = cur.pid || 0;
  const alive = isManagedProcessAlive(appId, pid);
  const logs = readLogs(appId, 800).toLowerCase();
  let label = 'Desligado';
  if (alive) label = logs.includes('traceback') || logs.includes('error:') ? 'Rodando (com erros)' : 'Online';
  return { status:label, pid:alive?pid:0, usage:{cpu:'0%',ram:'0 MB',storage:'0 MB',network:{total:'0',now:'0'}}, requests:0,
    uptimeTimestamp:alive?(cur.startedAt||Date.now()):Date.now(), logs };
}

function readJsonObject(file) {
  try {
    const value = JSON.parse(fs.readFileSync(file, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch { return {}; }
}

function mergeObjects(base, preserved) {
  const out = base && typeof base === 'object' && !Array.isArray(base) ? { ...base } : {};
  for (const [key, value] of Object.entries(preserved && typeof preserved === 'object' ? preserved : {})) {
    if (value && typeof value === 'object' && !Array.isArray(value) && out[key] && typeof out[key] === 'object' && !Array.isArray(out[key])) {
      out[key] = mergeObjects(out[key], value);
    } else {
      out[key] = value;
    }
  }
  return out;
}

function writeJsonAtomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2) + '\n', 'utf8');
  fs.renameSync(tmp, file);
}

function copyPreservedPath(src, dest) {
  if (!fs.existsSync(src)) return false;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.cpSync(src, dest, { recursive: true, force: true });
  return true;
}

function usableTokenFromFile(file) {
  try {
    const token = String(JSON.parse(fs.readFileSync(file, 'utf8'))?.token || '').trim();
    if (!token) return '';
    if (/^(token|seu[_ -]?token|coloque|placeholder|example|exemplo)$/i.test(token)) return '';
    return token;
  } catch { return ''; }
}

function snapshotPersistentRuntime(appId) {
  const dir = appDir(appId);
  const backup = path.join(RUNTIME_ROOT, `.persist-${appId}-${Date.now()}-${process.pid}`);
  fs.mkdirSync(backup, { recursive: true });
  const paths = [
    'database',
    'storage',
    'uploads',
    'runtime.log',
    '.env',
    'config.json',
    'token.json',
    'Token.json',
    'config/runtime.json',
    'config/private-credentials.json'
  ];
  for (const rel of paths) copyPreservedPath(path.join(dir, rel), path.join(backup, rel));
  return backup;
}

function restorePersistentRuntime(appId, backup) {
  const dir = appDir(appId);

  // Bancos e uploads são sobrepostos sobre o template novo. Assim arquivos
  // novos do template continuam existindo, enquanto tickets, automações,
  // produtos, ZCloud, invites e demais configurações do cliente permanecem.
  for (const rel of ['database', 'storage', 'uploads']) {
    copyPreservedPath(path.join(backup, rel), path.join(dir, rel));
  }

  // Mantém histórico e arquivos de configuração privados que já existiam.
  copyPreservedPath(path.join(backup, 'runtime.log'), path.join(dir, 'runtime.log'));
  copyPreservedPath(path.join(backup, '.env'), path.join(dir, '.env'));

  // JSONs de raiz recebem chaves novas do template sem apagar preferências/token
  // já configurados pelo cliente.
  for (const rel of ['config.json', 'token.json']) {
    const oldFile = path.join(backup, rel);
    if (!fs.existsSync(oldFile)) continue;
    const newFile = path.join(dir, rel);
    const merged = mergeObjects(readJsonObject(newFile), readJsonObject(oldFile));
    writeJsonAtomic(newFile, merged);
  }

  // runtime.json e private-credentials recebem chaves novas do template sem
  // perder valores já configurados. O estado antigo tem precedência.
  for (const rel of ['config/runtime.json', 'config/private-credentials.json']) {
    const oldFile = path.join(backup, rel);
    if (!fs.existsSync(oldFile)) continue;
    const newFile = path.join(dir, rel);
    const merged = mergeObjects(readJsonObject(newFile), readJsonObject(oldFile));
    writeJsonAtomic(newFile, merged);
  }

  // Em atualização comum, o template contém Token.json vazio: preserve o token
  // existente. Em uma troca explícita de token, o ZIP recebido já contém um
  // token válido e ele deve vencer o antigo.
  const oldTokenFile = path.join(backup, 'Token.json');
  const newTokenFile = path.join(dir, 'Token.json');
  if (fs.existsSync(oldTokenFile) && !usableTokenFromFile(newTokenFile)) {
    copyPreservedPath(oldTokenFile, newTokenFile);
  }
}

/**
 * Substitui o código do app por um ZIP sem apagar o estado persistente das
 * instâncias oficiais ZENYX. Isso cobre commit, atualização em massa, troca de
 * build e reinício: configurações de tickets/automação não precisam ser refeitas.
 */
async function replaceFiles(appId, zipInput, options = {}) {
  const dir = appDir(appId);
  const preserveState = options.preserveState !== false && isOfficialZenyx(appId);
  const backup = preserveState ? snapshotPersistentRuntime(appId) : null;
  try {
    if (options.stop !== false) stop(appId);
    if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    await extractZip(zipInput, appId);
    if (backup) {
      restorePersistentRuntime(appId, backup);
      try {
        fs.appendFileSync(path.join(dir, 'runtime.log'), `\n[ZENYX UPDATE] Código atualizado sem apagar database/tickets/automações/configuração persistente.\n`);
      } catch {}
    }
    return { ok: true, preserved: Boolean(backup) };
  } finally {
    if (backup) fs.rmSync(backup, { recursive: true, force: true });
  }
}

/**
 * Atualiza somente instâncias oficiais do Zenyx Sallers para o template que vem
 * dentro do Manager. Dados do cliente não são apagados: token, guild/owner,
 * credenciais privadas, banco JSON e runtime.log são preservados.
 */
async function maybeUpgradeZenyxPro(appId) {
  const dir = appDir(appId);
  const pkgPath = path.join(dir, 'package.json');
  const templatePath = path.join(__dirname, 'ZenyxPro.zip');
  if (!fs.existsSync(pkgPath) || !fs.existsSync(templatePath)) return { ok: true, upgraded: false };

  let current;
  try { current = JSON.parse(fs.readFileSync(pkgPath, 'utf8')); } catch { return { ok: true, upgraded: false }; }
  if (current?.name !== 'zenyx-pro-professional') return { ok: true, upgraded: false };

  const JSZip = require('jszip');
  const templateZip = await JSZip.loadAsync(fs.readFileSync(templatePath));
  const templatePkgFile = templateZip.file('package.json');
  if (!templatePkgFile) throw new Error('Template Zenyx Sallers sem package.json.');
  const templatePkg = JSON.parse(await templatePkgFile.async('string'));
  const currentVersion = String(current.version || '0.0.0');
  const templateVersion = String(templatePkg.version || '0.0.0');
  const currentBuild = String(current.zenyxBuild || '');
  const templateBuild = String(templatePkg.zenyxBuild || '');
  if (currentVersion === templateVersion && currentBuild && currentBuild === templateBuild) {
    return { ok: true, upgraded: false, version: currentVersion, build: currentBuild };
  }

  // Se as dependências de runtime são idênticas, não rode npm install/build em
  // cada uma das dezenas de aplicações. O template já leva dist/ compilado;
  // reutilizamos node_modules da instância atual por rename atômico. Isso reduz
  // brutalmente CPU/RAM/disco e faz o rollout visual chegar aos clientes logo.
  const dependencySignature = (pkg) => JSON.stringify(Object.fromEntries(
    Object.entries(pkg?.dependencies || {}).sort(([a], [b]) => a.localeCompare(b))
  ));
  const canReuseNodeModules = dependencySignature(current) === dependencySignature(templatePkg)
    && nodeModulesSatisfyPackage(dir, current);

  const stamp = `${process.pid}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const stageId = `stage_${stamp}`;
  const stageDir = appDir(stageId);
  const rollbackDir = path.join(RUNTIME_ROOT, `.rollback-${appId}-${stamp}`);
  let persistBackup = null;
  let liveMoved = false;
  let nodeModulesMoved = false;

  try {
    await waitForMemoryHeadroom();
    fs.rmSync(stageDir, { recursive: true, force: true });
    await extractZip(templatePath, stageId);

    const stageEntry = path.join(stageDir, 'dist', 'index.js');
    if (!fs.existsSync(stageEntry)) throw new Error('Template Zenyx Sallers sem dist/index.js pré-compilado.');

    // Builds antigas ou com dependências diferentes ainda passam pela preparação
    // completa em staging enquanto o bot antigo continua online.
    if (!canReuseNodeModules) await prepare(stageId);

    persistBackup = snapshotPersistentRuntime(appId);
    stop(appId);
    fs.rmSync(rollbackDir, { recursive: true, force: true });
    fs.renameSync(dir, rollbackDir);
    liveMoved = true;
    fs.renameSync(stageDir, dir);

    if (canReuseNodeModules) {
      const oldModules = path.join(rollbackDir, 'node_modules');
      const newModules = path.join(dir, 'node_modules');
      if (!fs.existsSync(oldModules)) throw new Error('node_modules antigo desapareceu durante a atualização rápida.');
      fs.renameSync(oldModules, newModules);
      nodeModulesMoved = true;
    }

    restorePersistentRuntime(appId, persistBackup);

    try {
      fs.appendFileSync(path.join(dir, 'runtime.log'), `\n[ZENYX UPDATE] ${currentVersion}${currentBuild ? ` (${currentBuild})` : ''} -> ${templateVersion}${templateBuild ? ` (${templateBuild})` : ''} • ${canReuseNodeModules ? 'rollout rápido com dependências reutilizadas' : 'staging completo'} • estado persistente preservado.\n`);
    } catch {}

    fs.rmSync(rollbackDir, { recursive: true, force: true });
    liveMoved = false;
    nodeModulesMoved = false;
    return { ok: true, upgraded: true, from: currentVersion, to: templateVersion, build: templateBuild, fastPath: canReuseNodeModules };
  } catch (error) {
    if (liveMoved && fs.existsSync(rollbackDir)) {
      try {
        // No fast-path, node_modules foi movido para o diretório novo. Devolva-o
        // antes de restaurar o runtime antigo.
        if (nodeModulesMoved) {
          const currentModules = path.join(dir, 'node_modules');
          const rollbackModules = path.join(rollbackDir, 'node_modules');
          if (fs.existsSync(currentModules) && !fs.existsSync(rollbackModules)) fs.renameSync(currentModules, rollbackModules);
          nodeModulesMoved = false;
        }
        fs.rmSync(dir, { recursive: true, force: true });
        fs.renameSync(rollbackDir, dir);
        liveMoved = false;
        fs.appendFileSync(path.join(dir, 'runtime.log'), `\n[ZENYX UPDATE] Rollback automático: atualização ${templateVersion} falhou e a versão anterior foi restaurada. Motivo: ${String(error?.message || error).slice(0, 300)}\n`);
      } catch (rollbackError) {
        throw new Error(`Atualização falhou e o rollback também falhou: ${String(rollbackError?.message || rollbackError).slice(0, 220)}. Erro original: ${String(error?.message || error).slice(0, 220)}`);
      }
    }
    throw error;
  } finally {
    try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch {}
    if (persistBackup) { try { fs.rmSync(persistBackup, { recursive: true, force: true }); } catch {} }
    if (!liveMoved) { try { fs.rmSync(rollbackDir, { recursive: true, force: true }); } catch {} }
  }
}


function logs(appId, limit = 1800) {
  return readLogs(appId, limit);
}

/** Propaga o estado global do ZCloud para todas as instâncias oficiais sem
 * compartilhar membros, tokens ou banco entre assinantes. */
async function syncZcloudFeatureForAll() {
  const st = loadState();
  const results = [];
  for (const appId of Object.keys(st.processes || {})) {
    if (!isOfficialZenyx(appId)) continue;
    try {
      const port = Number(st.processes?.[appId]?.zcloudPort || 0) || await allocateZcloudPort(appId, st);
      const infra = await ensureZcloudInfrastructure({ appId });
      configureZcloudRuntime(appId, port, infra);
      results.push({ appId, ok: true });
    } catch (error) {
      results.push({ appId, ok: false, error: String(error?.message || error).slice(0, 180) });
    }
  }
  return results;
}

async function syncWalletFeatureForAll(options = {}) {
  const st = loadState();
  const results = [];
  const restartOnline = options?.restartOnline === true;
  for (const appId of Object.keys(st.processes || {})) {
    if (!isOfficialZenyx(appId)) continue;
    try {
      const changed = configureWalletRuntime(appId);
      // No boot do Manager, não reinicie todos os bots só para sincronizar uma
      // flag. Isso evita derrubar várias aplicações simultaneamente. Reinício
      // só acontece quando uma ação administrativa pedir explicitamente.
      const entry = st.processes?.[appId] || {};
      let restarted = false;
      if (restartOnline && changed?.changed && isManagedProcessAlive(appId, entry.pid)) {
        await restart(appId);
        restarted = true;
      }
      results.push({ appId, ok: true, changed: Boolean(changed?.changed), restarted });
    } catch (error) {
      results.push({ appId, ok: false, error: String(error?.message || error).slice(0, 180) });
    }
  }
  return results;
}

async function syncMagnusFeatureForAll(options = {}) {
  const st = loadState();
  const results = [];
  const restartOnline = options?.restartOnline === true;
  for (const appId of Object.keys(st.processes || {})) {
    if (!isOfficialZenyx(appId)) continue;
    try {
      const changed = configureMagnusRuntime(appId);
      const entry = st.processes?.[appId] || {};
      let restarted = false;
      if (restartOnline && changed?.changed && isManagedProcessAlive(appId, entry.pid)) {
        await restart(appId);
        restarted = true;
      }
      results.push({ appId, ok:true, changed:Boolean(changed?.changed), restarted });
    } catch (error) { results.push({ appId, ok:false, error:String(error?.message || error).slice(0,180) }); }
  }
  return results;
}

module.exports = {
  childEnv, allocateZcloudPort, configureZcloudRuntime, isOfficialZenyx, appDir, extractZip, recoverMissingRuntime, prepare, start, stop, restart, remove, status, logs, replaceFiles, maybeUpgradeZenyxPro, detectRuntime, isAlive, isManagedProcessAlive, discoverManagedPids, reconcileManagedProcesses, ensureNodeModuleCompatibility, syncZcloudFeatureForAll, syncWalletFeatureForAll, syncMagnusFeatureForAll, configureWalletRuntime, configureMagnusRuntime, enforceChildBioFromRuntime, packageLockMatchesPackage, cgroupMemoryPressure,
};
