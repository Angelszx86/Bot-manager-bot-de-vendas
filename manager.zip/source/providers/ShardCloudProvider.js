const ProviderBase = require('./ProviderBase');
const api = require('../shardcloud_api');
class ShardCloudProvider extends ProviderBase {
  async create(input) { return api.createFromDirectory(input.directory, input); }
  async start(id) { return api.run(id); }
  async stop(id) { return api.stop(id); }
  async restart(id) { return api.restart(id); }
  async status(id) { return api.status(id); }
  async remove(id) { return api.remove(id); }
  async validate() { return api.testToken(); }
}
module.exports = ShardCloudProvider;
