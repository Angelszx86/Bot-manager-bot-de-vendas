const ShardCloudProvider = require('./ShardCloudProvider');
const camposCloud = new ShardCloudProvider();
const providers = new Map([['camposcloud', camposCloud], ['shardcloud', camposCloud]]);
function get(name='camposcloud') { const provider=providers.get(String(name).toLowerCase()); if (!provider) throw new Error(`Provider indisponível: ${name}`); return provider; }
module.exports = { get };
