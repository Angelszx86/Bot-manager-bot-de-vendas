class ProviderBase {
  async create() { throw new Error('Provider não implementa create.'); }
  async start() { throw new Error('Provider não implementa start.'); }
  async stop() { throw new Error('Provider não implementa stop.'); }
  async restart() { throw new Error('Provider não implementa restart.'); }
  async status() { throw new Error('Provider não implementa status.'); }
  async remove() { throw new Error('Provider não implementa remove.'); }
}
module.exports = ProviderBase;
