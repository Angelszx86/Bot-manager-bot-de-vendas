/**
 * HidenCloud API (drop-in no lugar do @squarecloud/api).
 *
 * Expõe a MESMA interface que o SquareCloudAPI usava, mas por baixo usa:
 *   - source/runtime.js  -> roda o bot como processo LOCAL (mantém online);
 *   - source/sftp.js     -> envia os arquivos para a HidenCloud via SFTP
 *                           (sem API key).
 *
 * Assim os arquivos que chamavam `new SquareCloudAPI(...)`, `.applications`,
 * `.start()/.stop()/.restart()/.delete()/.commit()/.getStatus()/.getLogs()`
 * continuam funcionando sem mudanças no fluxo.
 */
const crypto = require('crypto');
const runtime = require('./runtime');
const sftp = require('./sftp');

class Application {
  constructor(id) {
    this.id = id;
  }

  async start() {
    // Uptime primeiro: iniciar/religar nunca deve forçar npm install/upgrade.
    // Upgrade automático só ocorre quando explicitamente habilitado por env.
    if (String(process.env.ZENYX_AUTO_UPGRADE_ON_START || '').toLowerCase() === 'true') {
      await runtime.maybeUpgradeZenyxPro(this.id);
    }
    const r = await runtime.start(this.id);
    if (!r.ok) throw new Error(r.msg);
    return r;
  }

  async stop() {
    return await runtime.stop(this.id);
  }

  async restart() {
    if (String(process.env.ZENYX_AUTO_UPGRADE_ON_START || '').toLowerCase() === 'true') {
      await runtime.maybeUpgradeZenyxPro(this.id);
    }
    return await runtime.restart(this.id);
  }

  async delete() {
    const result = await runtime.remove(this.id);
    if (result?.ok !== false) await sftp.removeApp(this.id).catch(() => null);
    return result;
  }

  async getStatus() {
    return runtime.status(this.id);
  }

  async getLogs() {
    return runtime.logs(this.id);
  }

  async commit(zipPath, name, restart) {
    await runtime.replaceFiles(this.id, zipPath);
    await runtime.prepare(this.id);
    if (restart !== false) await runtime.restart(this.id);
    // reenvia para a HidenCloud via SFTP (best-effort, só quando é caminho de arquivo)
    if (typeof zipPath === 'string') sftp.uploadZip(zipPath, this.id).catch(() => {});
    return { ok: true };
  }
}

class Applications {
  async create(filePath) {
    const id = 'sh_' + crypto.randomBytes(6).toString('hex');
    await runtime.extractZip(filePath, id);
    await runtime.prepare(id);
    const r = await runtime.start(id);
    if (!r.ok) {
      // Preserve the generated application id and logs on the error so callers can
      // diagnose a failed boot without exposing credentials. The runtime directory
      // stays available for the manager's console/log inspection.
      const error = new Error(r.msg + '\n' + (r.logs || runtime.logs(id)));
      error.applicationId = id;
      error.runtimeLogs = r.logs || runtime.logs(id);
      throw error;
    }
    // upload SFTP em segundo plano (não bloqueia a entrega)
    await sftp.uploadZip(filePath, id).catch(() => {});
    return { id };
  }

  async get(id) {
    return new Application(id);
  }
}

class Users {
  /** Validação: retorna truthy se o runtime local está OK (não depende de SquareCloud). */
  async get() {
    return { id: 'hidencloud', username: 'HidenCloud (SFTP + runtime local)', email: null };
  }
}

class SquareCloudAPI {
  constructor(config) {
    // `config` era { token, subdomain } da SquareCloud — agora é ignorado:
    // as credenciais vêm do .env (HIDENCLOUD_*).
    this.config = config;
    this.applications = new Applications();
    this.users = new Users();
  }
}

module.exports = { SquareCloudAPI };
