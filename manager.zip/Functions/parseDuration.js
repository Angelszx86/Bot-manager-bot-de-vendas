// Functions/parseDuration.js
module.exports = function parseDuration(input) {
  // aceita: 10m, 2h, 1d, 30s
  if (!input) return null;
  input = input.trim().toLowerCase();
  const match = input.match(/^(\d+)\s*(s|m|h|d)$/);
  if (!match) return null;
  const n = parseInt(match[1], 10);
  const unit = match[2];
  const multipliers = { s: 1000, m: 60 * 1000, h: 60 * 60 * 1000, d: 24 * 60 * 60 * 1000 };
  return n * (multipliers[unit] || 0);
};
