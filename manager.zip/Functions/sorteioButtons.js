const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { getSorteioTemp, atualizarCampo } = require('./salvarSorteio');
const parseTempo = require('./conversorTempo');

module.exports = async (client, interaction) => {
  if (!interaction.isButton()) return;

  const [prefixo, acao, userId] = interaction.customId.split('_');
  if (prefixo !== 'sorteio') return;
  if (interaction.user.id !== userId) {
    return interaction.reply({ content: '❌ Você não tem permissão para editar este sorteio.', ephemeral: true });
  }

  const sorteio = getSorteioTemp(userId);
  if (!sorteio) return interaction.reply({ content: '❌ Sorteio não encontrado.', ephemeral: true });

  if (['title', 'description', 'footer', 'author', 'tempo'].includes(acao)) {
    const modal = new ModalBuilder()
      .setCustomId(`sorteiomodal_${acao}_${userId}`)
      .setTitle(`Definir ${acao}`)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('valor')
            .setLabel(acao === 'tempo' ? 'Ex: 1h, 30m, 2d' : `Novo valor para ${acao}`)
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );

    return interaction.showModal(modal);
  }

  if (acao === 'preview') {
    const embed = new EmbedBuilder()
      .setTitle(sorteio.title || 'Sem título')
      .setDescription(
        (sorteio.description || 'Sem descrição') +
        (sorteio.tempo ? `\n\n⏰ Termina em: <t:${Math.floor(sorteio.tempo.timestamp / 1000)}:R>` : '')
      )
      .setFooter({ text: sorteio.footer || '' })
      .setAuthor(sorteio.author ? { name: sorteio.author } : null)
      .setColor('Random');

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (acao === 'enviar') {
    const embed = new EmbedBuilder()
      .setTitle(sorteio.title || '🎉 Sorteio')
      .setDescription(
        (sorteio.description || 'Clique no botão para participar!') +
        (sorteio.tempo ? `\n\n⏰ Termina em: <t:${Math.floor(sorteio.tempo.timestamp / 1000)}:R>` : '')
      )
      .setFooter({ text: sorteio.footer || '' })
      .setAuthor(sorteio.author ? { name: sorteio.author } : null)
      .setColor('Random');

    await interaction.channel.send({
      content: '🎁 **Novo Sorteio!**',
      embeds: [embed],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(`participar_${Date.now()}`)
            .setLabel('🎉 Participar')
            .setStyle(ButtonStyle.Success)
        )
      ]
    });

    return interaction.reply({ content: '✅ Sorteio enviado com sucesso!', ephemeral: true });
  }
};