module.exports = function parseTempo(str) {
  const match = str.match(/^(\d+)([smhd])$/i);
  if (!match) return null;

  const valor = parseInt(match[1]);
  const tipo = match[2].toLowerCase();

  switch (tipo) {
    case 's': return valor * 1000;
    case 'm': return valor * 60 * 1000;
    case 'h': return valor * 60 * 60 * 1000;
    case 'd': return valor * 24 * 60 * 60 * 1000;
    default: return null;
  }
};