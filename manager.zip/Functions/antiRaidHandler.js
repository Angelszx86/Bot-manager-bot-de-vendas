const { AuditLogEvent, PermissionFlagsBits } = require('discord.js');
const axios = require('axios');

const webhookURL = 'https://discord.com/api/webhooks/SEU_WEBHOOK';
const warningAt = new Map();
function warnOnce(guildId, key, message) {
  const id = `${guildId}:${key}`;
  const now = Date.now();
  if (now - Number(warningAt.get(id) || 0) < 5 * 60_000) return;
  warningAt.set(id, now);
  console.warn(`[ANTI RAID] ${message}`);
}

async function antiRaidHandler(guild, type) {
  try {
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    if (!me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
      warnOnce(guild.id, 'audit', 'Sem permissão Ver Registro de Auditoria; ação ignorada.');
      return;
    }
    const auditLogs = await guild.fetchAuditLogs({
      type: type === 'create' ? AuditLogEvent.ChannelCreate : AuditLogEvent.ChannelDelete,
      limit: 1
    });
    const entry = auditLogs.entries.first();
    const executor = entry?.executor;
    if (!executor?.bot) return;
    const botMember = await guild.members.fetch(executor.id).catch(() => null);
    if (!botMember) return;
    if (!me.permissions.has(PermissionFlagsBits.BanMembers) || !botMember.bannable) {
      warnOnce(guild.id, `ban:${executor.id}`, `Não foi possível punir ${executor.tag || executor.id}: falta Banir Membros ou hierarquia de cargos.`);
      return;
    }
    await botMember.ban({ reason: `Anti-Raid: Bot ${type} canal` });
    if (/^https:\/\/discord(?:app)?\.com\/api\/webhooks\/\d+\/.+/i.test(webhookURL)) {
      await axios.post(webhookURL, { embeds: [{
        title: '🛡️ Bot banido pelo Anti-Raid',
        description: `O bot **${executor.tag || executor.username}** foi removido por atividade de canal detectada.`,
        color: 0xFF0000, timestamp: new Date().toISOString(),
        footer: { text: `Servidor: ${guild.name}`, icon_url: guild.iconURL() }
      }] }, { timeout: 10000 }).catch(() => null);
    }
  } catch (error) {
    if (Number(error?.code) === 50013) {
      warnOnce(guild.id, '50013', 'Discord recusou uma ação por Missing Permissions; o Anti-Raid continuará ativo sem repetir o erro.');
      return;
    }
    warnOnce(guild.id, `error:${error?.code || 'generic'}`, `Falha tratada: ${String(error?.message || error).slice(0, 220)}`);
  }
}
module.exports = antiRaidHandler;
