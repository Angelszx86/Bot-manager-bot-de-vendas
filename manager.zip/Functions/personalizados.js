/**
 * Compatibilidade com a rotina legacy de mensagens personalizadas.
 * A implementação antiga foi removida do Manager, mas o evento ready ainda
 * importa esta função. Mantemos um no-op assíncrono para que o boot nunca
 * quebre com "is not a function".
 */
module.exports = async function enviarMensagemPersonalizados() {
  return true;
};
