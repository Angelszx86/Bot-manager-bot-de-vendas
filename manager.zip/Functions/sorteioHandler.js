// Functions/sorteioHandler.js
const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

const DB_PATH = path.join(__dirname, "..", "database");
const FILE = path.join(DB_PATH, "sorteios.json");

// garante pasta e arquivo
if (!fs.existsSync(DB_PATH)) fs.mkdirSync(DB_PATH, { recursive: true });
if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify({ drafts: {}, giveaways: {} }, null, 2));

function readDB() {
  try {
    return JSON.parse(fs.readFileSync(FILE, "utf8"));
  } catch (e) {
    return { drafts: {}, giveaways: {} };
  }
}

function writeDB(data) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

module.exports = {
  // Drafts por usuário (temporário)
  initDraft(userId) {
    const db = readDB();
    db.drafts[userId] = db.drafts[userId] || {};
    writeDB(db);
  },

  getDraft(userId) {
    const db = readDB();
    return db.drafts[userId] || {};
  },

  updateDraft(userId, partial) {
    const db = readDB();
    db.drafts[userId] = db.drafts[userId] || {};
    db.drafts[userId] = { ...db.drafts[userId], ...partial };
    writeDB(db);
  },

  saveDraft(userId, draft) {
    const db = readDB();
    db.drafts[userId] = draft;
    writeDB(db);
  },

  // criar giveaway público
  createGiveaway(obj) {
    const db = readDB();
    const id = uuidv4();
    db.giveaways[id] = {
      id,
      titulo: obj.titulo,
      descricao: obj.descricao,
      tempo: obj.tempo,
      cargoGanhador: obj.cargoGanhador || null,
      authorId: obj.authorId,
      guildId: obj.guildId,
      channelId: obj.channelId,
      messageId: null,
      serverJoins: 0,
      participants: [],
      createdAt: Date.now(),
      ended: false
    };
    writeDB(db);
    return db.giveaways[id];
  },

  linkMessage(giveawayId, messageId) {
    const db = readDB();
    if (!db.giveaways[giveawayId]) return;
    db.giveaways[giveawayId].messageId = messageId;
    writeDB(db);
  },

  getGiveaway(id) {
    const db = readDB();
    return db.giveaways[id];
  },

  saveGiveaway(obj) {
    const db = readDB();
    db.giveaways[obj.id] = obj;
    writeDB(db);
  },

  markEnded(id) {
    const db = readDB();
    if (!db.giveaways[id]) return;
    db.giveaways[id].ended = true;
    writeDB(db);
  },

  get(userId) { // compatibilidade com código anterior (pegar draft)
    return this.getDraft(userId);
  }
};
