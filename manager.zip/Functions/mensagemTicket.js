const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder
} = require("discord.js");

function getTicketContainer() {
    const embed = new EmbedBuilder()
        .setTitle("✨ Atendimento — Zenyx Applications")
        .setDescription(
            "O Sistema de **Atendimento** da **Zenyx Applications** foi criado para trazer **organização, agilidade e profissionalismo** ao nosso servidor. Tenha um suporte estruturado, rápido e eficiente — ideal para comunicação rapida, equipes de staff, vendas, ajuda técnica ou atendimento personalizada.\n\n" +
            "### Recursos Exclusivos do Sistema de Atendimentos\n" +
            "- Suporte Personalizadas — Suporte, dúvidas, denúncias e muito mais.\n" +
            "- Sistema de Gerenciamento — Gerencie seu ticket você mesmo.\n" +
            "- Controles Avançados — Fechar, adicionar membros, transcrição e logs.\n" +
            "- Mensagens Automáticas — Textos editáveis que se adaptam ao seu servidor.\n" +
            "- Permissões Inteligentes — Canais privados automáticos com cargos configuráveis.\n" +
            "- Interface Intuitiva — Totalmente visual e amigável.\n" +
            "- Sistema de IA — Converse com alguma IA enquanto algum staff não assume seu ticket.\n\n" +
            "### Experimente o Sistema de Atendimento\n" +
            "Veja a interface, as funcionalidades e o fluxo completo de atendimento. Clique abaixo para assistir ao tutorial e entender como tudo funciona na prática."
        )
        .setColor("Blurple")
        .setImage("https://cdn.discordapp.com/attachments/1442206706271780894/1444563225508188273/1764080959930.jpg?ex=692d29d7&is=692bd857&hm=12016207ea893f7686f757462e3262c8c97c9f8caae6137c496b6b9632a9c18b&")
        .setFooter({ text: "Zenyx Applications — Desenvolvendo o futuro." });

    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setStyle(ButtonStyle.Link)
            .setLabel("Ver Tutorial Completo (Prévia)")
            .setURL("https://youtube.com/@virtusapplications")
    );

    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("tickettopen")
            .setLabel('Suporte')
            .setEmoji("📊")
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId("ver_horario")
            .setLabel('Ver horarios')
            .setEmoji("⏰")
            .setStyle(ButtonStyle.Secondary)
    );

    return { embeds: [embed], components: [row1, row2] };
}

module.exports = { getTicketContainer };
