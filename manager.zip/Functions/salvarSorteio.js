const fs = require('fs');
const path = './databases/sorteiosTemp.json';

function carregar() {
  if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));
  return JSON.parse(fs.readFileSync(path, 'utf-8'));
}

function salvar(dados) {
  fs.writeFileSync(path, JSON.stringify(dados, null, 2));
}

function salvarSorteioTemp(userId, info) {
  const atual = carregar();
  atual[userId] = info;
  salvar(atual);
}

function getSorteioTemp(userId) {
  const atual = carregar();
  return atual[userId] || null;
}

function atualizarCampo(userId, campo, valor) {
  const atual = carregar();
  if (!atual[userId]) return;
  atual[userId][campo] = valor;
  salvar(atual);
}

module.exports = {
  salvarSorteioTemp,
  getSorteioTemp,
  atualizarCampo
};