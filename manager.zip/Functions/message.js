const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");

module.exports = function criarMensagem(client, guildId) {
  const guild = client.guilds.cache.get(guildId);

  const embed = new EmbedBuilder()
    .setColor(0xF8F8FF) // ou "#800080"
    .setTitle('💎✨👑 — Painel de Controle')
    .setDescription([
      'Gerencie todos os seus bots de forma simples e segura diretamente pelo Discord.',
      'Nosso sistema permite que você configure proteção por e-mail, monitore atividades e recupere acesso em poucos segundos.',
      'Todos os processos são feitos por comandos interativos, sem necessidade de painel externo.',
      'Você será guiado passo a passo dentro do Discord, com mensagens intuitivas e respostas automáticas.',
      'A segurança é prioridade: cada ação exige validação e só você pode alterar seus dados.',
      'Caso perca o controle de algum bot, nosso sistema identifica e recupera para você rapidamente.',
      'Você não precisa saber programar — o sistema faz tudo por você.',
      'O canal é limpo automaticamente a cada 2 minutos para manter tudo organizado.',
      'Fique atento às mensagens de confirmação após cada ação.',
      'Em caso de dúvidas, fale com a equipe de suporte no canal indicado.'
    ].join('\n'))
    .setAuthor({ name: 'Gerenciamento Dream', iconURL: 'https://public-blob.squarecloud.dev/883ccc8e0eadb79956c196c88cb8d55802c30700/Img/logo_dreamgif_mf0343dn-49db.gif' })
    .setImage('https://public-blob.squarecloud.dev/883ccc8e0eadb79956c196c88cb8d55802c30700/img/dream_meyi5962-da51.png')
    .setFooter({ text: 'Dream — Tecnologia que descomplica', iconURL: 'https://public-blob.squarecloud.dev/883ccc8e0eadb79956c196c88cb8d55802c30700/Img/logo_dreamgif_mf0343dn-49db.gif' })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('appls')
      .setLabel('Applicativos')
      .setStyle(ButtonStyle.Primary)
      .setEmoji(global.emojis?.robo || "🤖"),
    new ButtonBuilder()
      .setCustomId('abrir_gerenciar')
      .setLabel('Mais Funções')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji(global.emojis?.funcao || "➕"),
    new ButtonBuilder()
      .setLabel('Ajuda')
      .setStyle(ButtonStyle.Link)
      .setEmoji(global.emojis?.helpp || "🤕")
      .setURL('https://discord.com/channels/1312428786591076463/1399744766350065706')
  );

  return { embed, buttons: row };
};