const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

// Armazenamento temporário dos votos (pode substituir por banco depois)
const votos = new Map();

module.exports = async function handleSugestaoVote(interaction) {
  const { customId, message, user } = interaction;

  if (!['sugestao_concordo', 'sugestao_discordo'].includes(customId)) return;

  // Se o usuário já votou
  const key = `${message.id}_${user.id}`;
  if (votos.has(key)) {
    // Checa se já respondeu
    if (!interaction.replied && !interaction.deferred) {
      return interaction.reply({ content: '❌ Você já votou nessa sugestão.', ephemeral: true });
    } else {
      return interaction.followUp({ content: '❌ Você já votou nessa sugestão.', ephemeral: true });
    }
  }

  // Marcar que o usuário votou
  votos.set(key, customId);

  // Defer para evitar timeout se houver processamento longo
  if (!interaction.deferred) {
    await interaction.deferUpdate();
  }

  // Contagem atual
  const concordoCount = message.components[0].components[0].label
    ? parseInt(message.components[0].components[0].label.split(' ')[1]) || 0
    : 0;
  const discordoCount = message.components[0].components[1].label
    ? parseInt(message.components[0].components[1].label.split(' ')[1]) || 0
    : 0;

  // Incrementa voto
  const newConcordo = customId === 'sugestao_concordo' ? concordoCount + 1 : concordoCount;
  const newDiscordo = customId === 'sugestao_discordo' ? discordoCount + 1 : discordoCount;

  // Atualiza botões
  const newRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('sugestao_concordo')
      .setEmoji("👍")
      .setLabel(`Concordo ${newConcordo}`)
      .setStyle(ButtonStyle.Secondary),

    new ButtonBuilder()
      .setCustomId('sugestao_discordo')
      .setEmoji("👎")
      .setLabel(`Discordo ${newDiscordo}`)
      .setStyle(ButtonStyle.Secondary)
  );

  try {
    await interaction.editReply({ components: [newRow] });
  } catch (err) {
    console.error('Erro ao atualizar a interação:', err);
  }
};