const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = async function sugestoesHandler(message) {
  if (message.author.bot || message.channel.id !== '1442208369275310120') return;

  try {
    await message.delete();

    const embed = new EmbedBuilder()
      .setAuthor({ name: 'Zenyx Suggestions', iconURL: 'https://cdn.discordapp.com/icons/1442167373934366934/a6662da4b31988f2d05fa2a0401c97ca.png?size=2048' })
      .setTitle(`## Nova sugestão!\n\nSugestão: ${message.content}`)
      .setDescription(`Enviada Por <@${message.author.id}>\n\n✨ - Muito obrigado por dar uma sugestão, com isso nosso servidor pode evoluir com suas Sugestões!\n\n`)
      .setColor(0xF8F8FF) // ou "#800080"
      .setThumbnail(message.guild.iconURL())
      //.setImage("https://public-blob.squarecloud.dev/883ccc8e0eadb79956c196c88cb8d55802c30700/img/dream_meyi5962-da51.png")
      .setFooter({ text: 'Vote usando os botões abaixo.' })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('sugestao_concordo')
        .setEmoji("👍")
        .setStyle(ButtonStyle.Success),

      new ButtonBuilder()
        .setCustomId('sugestao_discordo')
        .setEmoji("👎")
        .setStyle(ButtonStyle.Secondary)
    );

    const suggestionMessage = await message.channel.send({ embeds: [embed], components: [row] });

    // Envia DM agradecendo
    message.author.send({
      content: '`✅` Obrigado por enviar sua sugestão! Ela será avaliada pela equipe em breve.'
    }).catch(() => {});
  } catch (err) {
    console.error('[ERRO NO sugestoes.js]', err);
  }
};