process.chdir(__dirname);
require('dotenv').config();
require('./Lib/visual').install();
require('./Lib/interactions').installLogging();
let config = {}; try { config = require('./config.json'); } catch { console.warn('[ASTRO] config.json ausente; usando apenas variáveis de ambiente.'); }
const { logs, db, db2 } = require('./databases/index');
const moment = require('moment-timezone');
const fs = require("fs");
const path = require("path");
const axios = require("axios");

// R18.9.80+: inicialização direta na HidenCloud; sem lock/handover por PID.
const { ensureInfrastructure: ensureZcloudInfrastructure } = require('./Lib/zcloudGateway');
const zcloudHost = require('./Lib/zcloudHost');
const brandEnforcer = require('./Lib/brandEnforcer');
const childTemplateGuard = require('./Lib/childTemplateGuard');
const childRuntimeConverger = require('./Lib/childRuntimeConverger');

console.clear();
// Compatibility baseline retained: ASTRA APPLICATION MANAGER R18.9.56
// Current build: ASTRA APPLICATION MANAGER R18.9.81
console.log('===== ASTRA APPLICATION MANAGER • ASSISTED SALES + MAGNUSPAY =====');

const token = process.env.DISCORD_TOKEN || config.token;
const ownerIds = [...new Set([
  process.env.OWNER_IDS,
  process.env.OWNER_ID,
  ...(Array.isArray(config.owners) ? config.owners : []),
  config.owner
].flatMap(value => String(value || '').split(/[\s,;]+/)).map(value => value.trim()).filter(value => /^\d{15,22}$/.test(value)))];
const ownerId = ownerIds[0] || '';
const avisos = config.avisos;
const uptime = config.uptime;

if (!token) {
  console.error("\x1b[31m[ERRO]\x1b[0m Defina DISCORD_TOKEN no arquivo .env");
  process.exit(1);
}

if (!ownerIds.length) {
  console.error("\x1b[31m[ERRO]\x1b[0m Defina OWNER_ID/OWNER_IDS no arquivo .env ou configure owners no config.json");
  process.exit(1);
}

const { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, Events, Options } = require('discord.js');

// R18.9.104 • perfil de capacidade para hosts com muitos bots filhos.
// Evita picos de boot e limita o teto de heap de novos processos sem reservar RAM.
if (!process.env.HIDENCLOUD_START_CONCURRENCY) process.env.HIDENCLOUD_START_CONCURRENCY = '1';
if (!process.env.HIDENCLOUD_CHILD_MAX_OLD_SPACE_MB) process.env.HIDENCLOUD_CHILD_MAX_OLD_SPACE_MB = '192';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping
  ],
  partials: [Partials.Message, Partials.Channel],
  makeCache: Options.cacheWithLimits({
    ...Options.DefaultMakeCacheSettings,
    MessageManager: 40,
    ReactionManager: 20,
    PresenceManager: 0,
    GuildScheduledEventManager: 10,
    ThreadMemberManager: 0
  }),
  sweepers: {
    ...Options.DefaultSweeperSettings,
    messages: { interval: 300, lifetime: 900 }
  }
});

global.client = client;
module.exports = client;
client.slashCommands = new Collection();

// O site ZCloud é servido pelo próprio Manager. Na HidenCloud, o Reverse Proxy
// HTTPS aponta para esta porta; os bots filhos continuam em portas locais e são
// roteados por appId sem compartilhar banco, membros ou tokens.
zcloudHost.start();


function verificarIntents(client) {
  const todasIntents = GatewayIntentBits;
  const intentsAtivasBitfield = client.options.intents;

  const intentsAtivas = [];
  const intentsFaltantes = [];

  for (const [nome, valor] of Object.entries(todasIntents)) {
    if ((intentsAtivasBitfield & valor) === valor) {
      intentsAtivas.push(nome);
    } else {
      intentsFaltantes.push(nome);
    }
  }

  if (intentsFaltantes.length > 0) {
    console.log(`\x1b[33m[AVISO]\x1b[0m Ainda tem intents não ativadas`);
  } else {
    console.log("\x1b[32m[SUCESSO]\x1b[0m Todas as intents necessárias estão ativadas.");
  }
}

function mostrarUptime() {
  const tempo = process.uptime();
  const horas = Math.floor(tempo / 3600);
  const minutos = Math.floor((tempo % 3600) / 60);
  const segundos = Math.floor(tempo % 60);

  console.log(`\x1b[36m[UPTIME]\x1b[0m Bot online há: ${horas}h ${minutos}m ${segundos}s`);
}


async function rolloutOfficialChildTemplate() {
  console.log('[ZENYX R18.9.84] Rollout do template oficial dos bots filhos iniciado; atualização sequencial com preservação de dados.');
  if (String(process.env.ZENYX_CHILD_ROLLOUT || 'true').toLowerCase() === 'false') return;
  const runtime = require('./source/runtime');
  const candidates = db2.all().map(row => ({ appId: String(row?.ID || ''), data: row?.data || {} }))
    .filter(({ appId, data }) => appId && !['expired','removed','suspended','revoked','recoverable','expiration_stop_failed'].includes(String(data.status || '').toLowerCase()))
    // Atualize primeiro quem já deveria estar online. Assim o painel/handlers novos
    // chegam aos bots em uso antes de runtimes parados/ociosos.
    .sort((a, b) => Number(String(b.data.status || '').toLowerCase() === 'online') - Number(String(a.data.status || '').toLowerCase() === 'online'));
  for (const { appId, data } of candidates) {
    try {
      if (!fs.existsSync(runtime.appDir(appId)) || !runtime.isOfficialZenyx(appId)) continue;
      const wasRunning = String(data.desiredState || '').toLowerCase() !== 'stopped' && data.userStopped !== true;
      const upgraded = await runtime.maybeUpgradeZenyxPro(appId);
      if (upgraded?.upgraded && wasRunning) {
        const started = await runtime.start(appId, { bootWaitMs: 2200 });
        if (started?.ok) {
          db2.set(`${appId}.status`, 'online');
          db2.set(`${appId}.desiredState`, 'running');
          db2.delete(`${appId}.lastStartError`);
        } else {
          db2.set(`${appId}.status`, 'offline');
          db2.set(`${appId}.desiredState`, 'running');
          db2.set(`${appId}.lastStartError`, String(started?.msg || 'Falha após atualização').slice(0, 500));
        }
      }
      if (upgraded?.upgraded) console.log(`[CHILD ROLLOUT] ${appId}: atualizado para ${upgraded.to || 'template atual'}.`);
    } catch (error) {
      console.log(`[CHILD ROLLOUT] ${appId}: ${String(error?.message || error).slice(0, 300)}`);
      // Falha de atualização nunca muda a intenção do usuário para stopped.
      if (String(data.desiredState || '').toLowerCase() !== 'stopped' && data.userStopped !== true) db2.set(`${appId}.desiredState`, 'running');
    }
    // Continua estritamente um bot por vez. O runtime já possui controle de
    // memória/CPU; não acrescente 8s artificiais entre aplicações, pois isso
    // deixava clientes por vários minutos presos na build antiga.
    await new Promise(resolve => setTimeout(resolve, 1200));
  }
}

async function restoreActiveChildRuntimes(reason = 'boot') {
  const runtime = require('./source/runtime');
  const rows = db2.all();
  let resumed = 0;
  let alreadyOnline = 0;
  let skipped = 0;
  let failed = 0;

  for (const row of rows) {
    const data = row?.data || {};
    const appId = String(row?.ID || data.idapp || '').trim();
    if (!appId) { skipped++; continue; }

    const savedStatus = String(data.status || '').toLowerCase();
    const desiredState = String(data.desiredState || '').toLowerCase();
    const expiresAt = Date.parse(data.dataExpiracao || '');
    const expiredByDate = Number.isFinite(expiresAt) && Date.now() >= expiresAt;
    const blockedStatus = ['removed','suspended','revoked','expired','expiration_stop_failed','recoverable'].includes(savedStatus);
    const explicitlyStopped = desiredState === 'stopped' || data.autostart === false || data.userStopped === true || Boolean(data.userStoppedAt);

    // Uma aplicação válida que estava online/offline por queda de processo deve
    // voltar sozinha. Em versões antigas, 'stopped' nem sempre distinguia uma
    // parada real do usuário de um restart quebrado; por isso só tratamos como
    // parada explícita quando existe desiredState/userStopped/userStoppedAt.
    // Suspensão, remoção, recuperação pendente e expiração continuam bloqueadas.
    if (expiredByDate || blockedStatus || explicitlyStopped) { skipped++; continue; }

    if (!fs.existsSync(runtime.appDir(appId))) {
      const recovery = typeof runtime.recoverMissingRuntime === 'function'
        ? await runtime.recoverMissingRuntime(appId).catch(error => ({ ok:false, msg:String(error?.message || error) }))
        : { ok:false, msg:'recuperação automática indisponível' };
      if (!recovery?.ok) {
        failed++;
        const message = `Arquivos do runtime não encontrados. ${String(recovery?.msg || '').trim()}`.trim().slice(0,500);
        db2.set(`${appId}.lastStartError`, message);
        console.log(`[RUNTIME RESTORE:${reason}] ${appId}: ${message}`);
        continue;
      }
      db2.set(`${appId}.lastRecoveryAt`, new Date().toISOString());
      console.log(`[RUNTIME RESTORE:${reason}] ${appId}: arquivos recuperados automaticamente do backup local.`);
    }

    // Migração segura: estados antigos online/offline/starting passam a declarar
    // explicitamente a intenção de permanecer rodando após restart/redeploy.
    if (desiredState !== 'running') db2.set(`${appId}.desiredState`, 'running');

    try {
      if (typeof runtime.reconcileManagedProcesses === 'function') runtime.reconcileManagedProcesses(appId);
      const current = runtime.status(appId);
      if (current.pid && runtime.isManagedProcessAlive(appId, current.pid)) {
        db2.set(`${appId}.status`, 'online');
        db2.set(`${appId}.desiredState`, 'running');
        db2.delete(`${appId}.lastStartError`);
        alreadyOnline++;
        continue;
      }

      // IMPORTANTE: no boot não fazemos upgrade do template antes de religar.
      // Upgrade pode instalar dependências e derrubar dezenas de instâncias de
      // uma vez. Primeiro restauramos o código que já funcionava; atualização
      // continua disponível nas rotas explícitas de commit/upgrade.
      let result = null;
      let lastStartError = null;
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          result = await runtime.start(appId, { bootWaitMs: 2200 });
          if (result?.ok) break;
          lastStartError = new Error(result?.msg || 'runtime não confirmou o boot');
        } catch (startError) { lastStartError = startError; }
        if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1200));
      }
      if (!result?.ok) throw (lastStartError || new Error('runtime não confirmou o boot'));

      db2.set(`${appId}.status`, 'online');
      db2.set(`${appId}.desiredState`, 'running');
      db2.set(`${appId}.recoverable`, false);
      db2.delete(`${appId}.lastStartError`);
      db2.set(`${appId}.lastAutoStartAt`, new Date().toISOString());
      resumed++;
      console.log(`[RUNTIME RESTORE:${reason}] ${appId}: restaurado automaticamente.`);
    } catch (error) {
      failed++;
      const message = String(error?.message || error).slice(0, 500);
      // Falha transitória NÃO muda a intenção para stopped. Assim as passagens
      // tardias podem tentar novamente sem o dono precisar apertar Ligar.
      db2.set(`${appId}.status`, 'offline');
      db2.set(`${appId}.desiredState`, 'running');
      db2.set(`${appId}.lastStartError`, message);
      console.log(`[RUNTIME RESTORE:${reason}] ${appId}: falha ao restaurar: ${message}`);
    }
  }
  console.log(`[RUNTIME RESTORE:${reason}] restaurados=${resumed} • já online=${alreadyOnline} • ignorados=${skipped} • falhas=${failed}`);
  return { resumed, alreadyOnline, skipped, failed };
}


// R18.9.96: supervisor contínuo dos bots filhos.
// O restore de boot resolve redeploy/restart do Manager, mas um processo filho
// também pode cair horas depois por OOM, I/O ou erro transitório. Este guardião
// respeita desiredState/userStopped/expiração e religa somente aplicações que
// deveriam continuar online, com backoff para não criar loops de crash.
const runtimeGuardianFailures = new Map();
let runtimeGuardianBusy = false;
let runtimeGuardianTimer = null;
function runtimeGuardianDelay(attempt, permanent = false) {
  if (permanent) return 30 * 60 * 1000;
  const steps = [30_000, 60_000, 120_000, 300_000, 600_000, 900_000];
  return steps[Math.min(Math.max(0, attempt - 1), steps.length - 1)];
}
function runtimeGuardianShouldRun(data = {}) {
  const status = String(data.status || '').toLowerCase();
  const desiredState = String(data.desiredState || '').toLowerCase();
  const blocked = ['removed','suspended','revoked','expired','expiration_stop_failed','recoverable'].includes(status);
  const expiresAt = Date.parse(data.dataExpiracao || '');
  const expired = Number.isFinite(expiresAt) && Date.now() >= expiresAt;
  const explicitlyStopped = desiredState === 'stopped' || data.autostart === false || data.userStopped === true || Boolean(data.userStoppedAt);
  return desiredState === 'running' && !blocked && !expired && !explicitlyStopped;
}
async function runtimeGuardianPass(reason = 'watchdog') {
  if (runtimeGuardianBusy) return;
  runtimeGuardianBusy = true;
  const runtime = require('./source/runtime');
  let checked = 0, recovered = 0, restarted = 0, failed = 0;
  const maxRestarts = Math.max(1, Math.min(6, parseInt(process.env.ZENYX_RUNTIME_GUARD_MAX_RESTARTS || '3', 10) || 3));
  try {
    for (const row of db2.all()) {
      const data = row?.data || {};
      const appId = String(row?.ID || data.idapp || '').trim();
      if (!appId || !runtimeGuardianShouldRun(data)) continue;
      checked++;

      try {
        try { if (typeof runtime.reconcileManagedProcesses === 'function') runtime.reconcileManagedProcesses(appId); } catch {}
        let current = null;
        try { current = runtime.status(appId); } catch {}
        const alive = Boolean(current?.remoteProvider === 'shardcloud' || (current?.pid && runtime.isManagedProcessAlive(appId, current.pid)));
        if (alive) {
          runtimeGuardianFailures.delete(appId);
          if (String(data.status || '').toLowerCase() !== 'online') db2.set(`${appId}.status`, 'online');
          db2.set(`${appId}.desiredState`, 'running');
          db2.delete(`${appId}.lastStartError`);
          db2.set(`${appId}.autoRestartFailures`, 0);
          db2.delete(`${appId}.nextAutoRestartAt`);
          continue;
        }

        const previous = runtimeGuardianFailures.get(appId) || {
          attempt: Number(data.autoRestartFailures || 0),
          nextAt: Date.parse(data.nextAutoRestartAt || '') || 0
        };
        if (Date.now() < Number(previous.nextAt || 0)) continue;
        if (restarted >= maxRestarts) continue;

        if (!fs.existsSync(runtime.appDir(appId))) {
          const recovery = typeof runtime.recoverMissingRuntime === 'function'
            ? await runtime.recoverMissingRuntime(appId, { prepare: true }).catch(error => ({ ok:false, msg:String(error?.message || error) }))
            : { ok:false, msg:'recuperação automática indisponível' };
          if (!recovery?.ok) throw new Error(`Runtime ausente: ${String(recovery?.msg || '').trim()}`.trim());
          recovered++;
          db2.set(`${appId}.lastRecoveryAt`, new Date().toISOString());
        }

        restarted++;
        const result = await runtime.start(appId, { bootWaitMs: 4200 });
        if (!result?.ok) throw new Error(result?.msg || 'O runtime não permaneceu online após a tentativa automática.');

        runtimeGuardianFailures.delete(appId);
        db2.set(`${appId}.status`, 'online');
        db2.set(`${appId}.desiredState`, 'running');
        db2.set(`${appId}.lastAutoRestartAt`, new Date().toISOString());
        db2.set(`${appId}.autoRestartFailures`, 0);
        db2.delete(`${appId}.nextAutoRestartAt`);
        db2.delete(`${appId}.lastStartError`);
        console.log(`[RUNTIME GUARD:${reason}] ${appId}: religado automaticamente.`);
      } catch (error) {
        const previous = runtimeGuardianFailures.get(appId) || { attempt: Number(data.autoRestartFailures || 0) };
        const attempt = Math.max(1, Number(previous.attempt || 0) + 1);
        const message = String(error?.message || error).slice(0, 500);
        let recentLogs = '';
        try { recentLogs = String(runtime.logs?.(appId, 1400) || ''); } catch {}
        const permanent = /invalid token|tokeninvalid|401 unauthorized|disallowed intents|token.*recusado/i.test(`${message}\n${recentLogs}`);
        const nextAt = Date.now() + runtimeGuardianDelay(attempt, permanent);
        runtimeGuardianFailures.set(appId, { attempt, nextAt });
        db2.set(`${appId}.status`, 'offline');
        db2.set(`${appId}.desiredState`, 'running');
        db2.set(`${appId}.lastStartError`, message);
        db2.set(`${appId}.autoRestartFailures`, attempt);
        db2.set(`${appId}.nextAutoRestartAt`, new Date(nextAt).toISOString());
        failed++;
        console.log(`[RUNTIME GUARD:${reason}] ${appId}: tentativa ${attempt} falhou; retry em ${Math.round((nextAt-Date.now())/1000)}s • ${message}`);
      }
    }
  } finally {
    runtimeGuardianBusy = false;
    const verboseGuard = String(process.env.ZENYX_RUNTIME_GUARD_VERBOSE || '').toLowerCase() === 'true';
    if (verboseGuard || recovered || restarted || failed) console.log(`[RUNTIME GUARD:${reason}] verificados=${checked} • recuperados=${recovered} • tentativas=${restarted} • falhas=${failed}`);
  }
}
function startRuntimeGuardian() {
  if (runtimeGuardianTimer) return runtimeGuardianTimer;
  const interval = Math.max(30_000, Math.min(5 * 60_000, parseInt(process.env.ZENYX_RUNTIME_GUARD_INTERVAL_MS || '60000', 10) || 60_000));
  setTimeout(() => void runtimeGuardianPass('startup').catch(() => null), 120_000).unref?.();
  runtimeGuardianTimer = setInterval(() => void runtimeGuardianPass('interval').catch(() => null), interval);
  runtimeGuardianTimer.unref?.();
  console.log(`[RUNTIME GUARD] supervisor contínuo ativo • intervalo=${Math.round(interval/1000)}s.`);
  return runtimeGuardianTimer;
}


client.once(Events.ClientReady, async () => {
  console.log(`\x1b[36m[INFO]\x1b[0m Bot logado como ${client.user.tag}`);
  console.log('[ZENYX R18.9.48] Renovação em tópico + restauração automática carregadas.');
  console.log('[ZENYX R18.9.49] Renovação visual + Banco IMAP genérico + sorteios corrigidos.');
  console.log('[ZENYX R18.9.50] IMAP Gmail estabilizado + diagnóstico de autenticação + ativação protegida.');
  console.log('[ZENYX R18.9.51] IMAP do Manager padronizado para Banco Inter sem branding Nubank no fluxo.');
  console.log('[ZENYX R18.9.52] Auto-start resiliente + Inter IMAP pré-configurado por domínio oficial.');
  console.log('[ZENYX R18.9.83] Patch de estabilidade de interações e UI dos bots filhos carregado.');
  console.log('[ZENYX R18.9.53] Interações rápidas + fila de runtimes + voz persistente + retenção de 10 dias.');
  // O Manager nunca altera a própria Bio aqui. Nos bots FILHOS, somente a Bio
  // institucional ZENYX é reforçada; username, avatar e banner continuam livres.
  console.log('[PERFIL] Bio institucional dos bots filhos protegida; perfil do Manager permanece livre.');
  brandEnforcer.start(client);
  verificarIntents(client);

  // R18.9.98: o template oficial precisa conter os arquivos mínimos antes de
  // qualquer trial/provisionamento. Builds anteriores podiam deixar
  // config/runtime.json fora do ZIP e o trial falhava antes da entrega.
  try {
    const templateCheck = await childTemplateGuard.ensureTemplateRequiredFiles();
    if (!templateCheck.ok) {
      console.log(`[CHILD TEMPLATE] validação falhou: ${String(templateCheck.message || 'erro desconhecido').slice(0, 260)}`);
    } else if (templateCheck.repaired) {
      console.log(`[CHILD TEMPLATE] reparado automaticamente: ${templateCheck.missing.join(', ')}.`);
    } else {
      console.log('[CHILD TEMPLATE] estrutura obrigatória validada.');
    }
  } catch (error) {
    console.log(`[CHILD TEMPLATE] falha ao validar/reparar: ${String(error?.message || error).slice(0, 260)}`);
  }

  // R18.9.105: converge runtimes parcialmente atualizados ANTES de religá-los.
  // Preserva Token.json, config/runtime.json, databases e credenciais privadas.
  try {
    const convergence = await childRuntimeConverger.convergeOfficialRuntimes();
    console.log(`[CHILD CONVERGE] verificados=${convergence.checked} • atualizados=${convergence.changed.length} • falhas=${convergence.errors.length} • versão=${convergence.version || 'n/a'}`);
    if (convergence.changed.length) {
      const runtime = require('./source/runtime');
      for (const appId of convergence.changed) {
        try {
          const status = runtime.status?.(appId);
          if (status?.pid && runtime.isManagedProcessAlive?.(appId, status.pid)) await runtime.stop(appId).catch(() => null);
        } catch {}
      }
    }
  } catch (error) {
    console.log(`[CHILD CONVERGE] falha: ${String(error?.message || error).slice(0, 300)}`);
  }

  // R18.9.60: restaura Managers parceiros limitados e ativa a limpeza por
  // inatividade (15 dias pausa; 20 dias remove apps) sem competir com a fila
  // de restauração dos bots filhos.
  try {
    const partnerManagers = require('./Lib/partnerManagers');
    partnerManagers.startSweep();
    setTimeout(() => {
      partnerManagers.restoreAll().then(items => {
        const ok = items.filter(x => x.ok).length;
        console.log(`[PARTNER MANAGER] restauração: ${ok}/${items.length} instância(s) ativa(s).`);
      }).catch(error => console.log(`[PARTNER MANAGER] restauração falhou: ${String(error?.message || error).slice(0,240)}`));
    }, 12000).unref?.();
  } catch (error) {
    console.log(`[PARTNER MANAGER] inicialização indisponível: ${String(error?.message || error).slice(0,240)}`);
  }

  // Em um novo deploy/container os PIDs antigos não sobrevivem. Reabre apenas
  // runtimes que estavam realmente marcados como online e ainda possuem
  // validade, preservando os bancos/configurações do bot filho.
  await restoreActiveChildRuntimes();
  // Segunda reconciliação curta: cobre falhas transitórias de boot (I/O, porta,
  // extração/upgrade ainda terminando) sem exigir que o dono clique em Ligar.
  // Apps explicitamente parados/expirados continuam sendo ignorados.
  setTimeout(() => {
    restoreActiveChildRuntimes('retry-20s').catch(error => console.log(`[RUNTIME RESTORE] retry 20s falhou: ${String(error?.message || error).slice(0, 280)}`));
  }, 20000).unref?.();
  setTimeout(() => {
    restoreActiveChildRuntimes('retry-90s').catch(error => console.log(`[RUNTIME RESTORE] retry 90s falhou: ${String(error?.message || error).slice(0, 280)}`));
  }, 90000).unref?.();
  startRuntimeGuardian();
  setTimeout(() => {
    rolloutOfficialChildTemplate().catch(error => console.log(`[CHILD ROLLOUT] falha geral: ${String(error?.message || error).slice(0, 280)}`));
  }, 2500).unref?.();
  // Segunda passagem: se uma instância estava ocupada/reiniciando na primeira,
  // ela recebe o mesmo template oficial sem depender de ação manual do cliente.
  setTimeout(() => {
    rolloutOfficialChildTemplate().catch(error => console.log(`[CHILD ROLLOUT:retry] falha geral: ${String(error?.message || error).slice(0, 280)}`));
  }, 45000).unref?.();

  // O ZCloud usa o Reverse Proxy HTTPS da própria HidenCloud apontando para
  // o servidor HTTP do Manager. Cada bot filho fica em uma rota/appId isolada.
  void ensureZcloudInfrastructure().then(async (result) => {
    if (result.ready) {
      console.log(`[ZCLOUD] Gateway HTTPS do Manager pronto em ${result.baseUrl}`);
    } else {
      console.log(`[ZCLOUD] Infraestrutura ainda não ficou pronta: ${result.reason || 'configure o Reverse Proxy HTTPS da HidenCloud'}`);
    }
    // Também atualiza instâncias que já estavam ligadas antes do Manager ser
    // reiniciado/atualizado. Cada runtime recebe somente a sua própria rota.
    const runtime = require('./source/runtime');
    const synced = await runtime.syncZcloudFeatureForAll();
    const failed = synced.filter((item) => !item.ok).length;
    console.log(`[ZCLOUD] Instâncias sincronizadas: ${synced.length - failed}/${synced.length}${failed ? ` • falhas: ${failed}` : ''}`);

    // R18.9.40: execute a sincronização da Zwallet DEPOIS do ZCloud. Como o
    // bridge da carteira reinicia instâncias oficiais online para atualizar a
    // credencial EvoPay do Znypay, essa ordem evita duas rotinas concorrentes
    // mexendo no mesmo runtime durante o boot.
    const walletSynced = await runtime.syncWalletFeatureForAll({ restartOnline: false });
    const walletFailed = walletSynced.filter((item) => !item.ok).length;
    console.log(`[ZWALLET] Instâncias sincronizadas: ${walletSynced.length - walletFailed}/${walletSynced.length}${walletFailed ? ` • falhas: ${walletFailed}` : ''}`);
  }).catch(async (error) => {
    console.log(`[ZCLOUD] Falha ao preparar a infraestrutura pública: ${String(error?.message || error).slice(0, 240)}`);
    // Mesmo que o gateway ZCloud falhe, o Znypay não deve perder a credencial
    // central depois de um restart/redeploy do Manager.
    try {
      const walletSynced = await require('./source/runtime').syncWalletFeatureForAll({ restartOnline: false });
      const walletFailed = walletSynced.filter((item) => !item.ok).length;
      console.log(`[ZWALLET] Instâncias sincronizadas: ${walletSynced.length - walletFailed}/${walletSynced.length}${walletFailed ? ` • falhas: ${walletFailed}` : ''}`);
    } catch (walletError) {
      console.log(`[ZWALLET] Falha ao sincronizar runtimes: ${String(walletError?.message || walletError).slice(0, 240)}`);
    }
  });

  const { startNubankImapWatcher } = require('./Lib/nubankImap');
  startNubankImapWatcher(client);

  for (const configuredOwnerId of ownerIds) {
    try {
      const dono = await client.users.fetch(configuredOwnerId);
      console.log(`\x1b[34m[INFO]\x1b[0m Dono do bot: ${dono.tag} (${configuredOwnerId})`);
    } catch {
      console.log(`\x1b[33m[AVISO]\x1b[0m Não foi possível obter o dono pelo ID: ${configuredOwnerId}`);
    }
  }

  if (avisos) {
    const hora = moment().tz("America/Sao_Paulo").format("HH:mm:ss");
    console.log(`\x1b[35m[AVISO]\x1b[0m Horário atual: ${hora}`);

    try {
      const appsRaw = fs.readFileSync('./databases/applications.json', 'utf8');  
      const apps = JSON.parse(appsRaw);  
      if (Array.isArray(apps) && apps.length > 0) {  
        console.log(`\x1b[32m[APPS]\x1b[0m ${apps.length} bots cadastrados:`);  
        apps.forEach((app, i) => {  
          console.log(`  ${i + 1}. ${app.nome || "Sem nome"} | ID: ${app.id || "sem id"}`);  
        });  
      } else {  
        console.log("\x1b[33m[AVISO]\x1b[0m Nenhum app encontrado em applications.json");  
      }  
    } catch {  
      console.log("\x1b[31m[ERRO]\x1b[0m Falha ao ler DataBaseJson/applications.json");  
    }
  }

  if (uptime) {
    console.log("\x1b[36m[UPTIME]\x1b[0m Verificando comandos para IDs...");

    const comandosDir = path.join(__dirname, "Comandos");  
    if (fs.existsSync(comandosDir)) {  
      const arquivos = fs.readdirSync(comandosDir).filter(a => a.endsWith('.js'));  

      arquivos.forEach(arquivo => {  
        const cmd = require(path.join(comandosDir, arquivo));  
        if (!cmd.id || typeof cmd.id !== 'string') {  
          console.log(`\x1b[33m[UPTIME]\x1b[0m Comando "${arquivo}" não possui ID definido.`);  
        }  
      });  
    } else {  
      console.log("\x1b[33m[UPTIME]\x1b[0m Pasta 'comandos' não encontrada para análise.");  
    }
  }
});

// SISTEMA ANTIGOLPISTAS
const cargosImunes = [
  "1443789153505509487",
  "1386722705977643237"
];
const cargosNaoImunes = [
  "1386722705965056178",
  "1386722705965056178"
];
const linksPerigosos = [
  ".ru", "free", "nitro", "airdrop", "steamgift",
  "discord.gift", "login", "token", "claim", "drop"
];

client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;
  // Pode ser ativado/desativado pelo /botconfig sem reiniciar o Manager.
  if (logs.get('antiScam.enabled') === false) return;

  const content = message.content.toLowerCase();
  const temLinkSuspeito = linksPerigosos.some(link => content.includes(link));
  if (!temLinkSuspeito) return;

  try {
    const membro = await message.guild.members.fetch(message.author.id);
    const idsCargos = membro.roles.cache.map(role => role.id);

    const ehImune = idsCargos.some(id => cargosImunes.includes(id));  
    const ehNaoImune = idsCargos.some(id => cargosNaoImunes.includes(id));  

    if (ehImune) return;  

    if (ehNaoImune || (!ehImune && !ehNaoImune)) {  
      console.log(`\x1b[31m[SEGURANÇA]\x1b[0m ⚠️ Mensagem suspeita de ${message.author.tag}:`);  
      // Não registrar conteúdo de mensagens, que pode conter credenciais.  

      await message.delete().catch(() => {});  
      await message.channel.send(`⚠️ ${message.author}, sua mensagem foi removida por conter conteúdo suspeito.`).catch(() => {});  
    }
  } catch (err) {
    console.log(`\x1b[31m[ANTIGOLPISTAS]\x1b[0m Erro ao verificar cargos do usuário:`, err);
  }
});

// HANDLERS
require("./handler/Events").run(client);
require("./handler/index")(client);

// GLOBAL ERROR HANDLING
process.on('unhandledRejection', (reason) => {
  console.log(`\x1b[31m[ERRO]\x1b[0m Unhandled Rejection:\n`, reason);
});
process.on('uncaughtException', (error) => {
  console.log(`\x1b[31m[ERRO]\x1b[0m Uncaught Exception:\n`, error);
});

// Exemplo de fetch de canal tratado para evitar crash de missing access
async function exemploFetchCanalTratado(idCanal) {
  try {
    const channel = await client.channels.fetch(idCanal);
    return channel;
  } catch (error) {
    if (error.code === 50001) {
      console.warn(`\x1b[33m[AVISO]\x1b[0m Sem acesso ao canal: ${idCanal}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

let autoMsgInterval = null;
let autoMsgDispatching = false;

async function startAutoMsgLoop() {
  if (autoMsgInterval) clearInterval(autoMsgInterval);
  const config = await logs.get('autoMsg');
  if (!config) return;
  const { canalId, mensagem, intervalo } = config;
  if (!canalId || !mensagem || !intervalo) return;
  const channel = client.channels.cache.get(canalId);
  if (!channel || !channel.send) return;
  const intervalMs = Math.max(1, Number(intervalo) || 1) * 60 * 1000;

  const sendAndDelete = async () => {
    if (autoMsgDispatching) return;
    autoMsgDispatching = true;
    try {
      const lastSentAt = Date.parse(String(await logs.get('autoMsgLastSentAt') || ''));
      if (Number.isFinite(lastSentAt) && Date.now() - lastSentAt < intervalMs - 1000) return;
      const lastMsgId = await logs.get('autoMsgLastId');
      if (lastMsgId) {
        try {
          const oldMsg = await channel.messages.fetch(lastMsgId);
          if (oldMsg) await oldMsg.delete();
        } catch {}
      }
      const sentMsg = await channel.send(mensagem).catch(() => null);
      if (sentMsg) {
        await logs.set('autoMsgLastId', sentMsg.id);
        await logs.set('autoMsgLastSentAt', new Date().toISOString());
      }
    } finally {
      autoMsgDispatching = false;
    }
  };

  await sendAndDelete();
  autoMsgInterval = setInterval(sendAndDelete, intervalMs);
  autoMsgInterval.unref?.();
}

client.on(Events.ClientReady, startAutoMsgLoop);

setInterval(async () => {
  const repostConfig = await logs.get('repost');
  if (!repostConfig || !repostConfig.on || !repostConfig.horario) return;

  const now = moment().tz('America/Sao_Paulo').format('HH:mm');  
  if (now !== repostConfig.horario) return;  

  const alugueis = db.all().filter(pd => pd.data.nomeproduto);  
  for (const aluguel of alugueis) {  
    const canalId = aluguel.data.canalId;  
    if (!canalId) continue;  
    const channel = client.channels.cache.get(canalId);  
    if (!channel) continue;  
    const lastMsgId = aluguel.data.lastMsgId;  
    if (lastMsgId) {  
      try {  
        const oldMsg = await channel.messages.fetch(lastMsgId);  
        if (oldMsg) await oldMsg.delete();  
      } catch (e) {}  
    }  
    let sentMsg;  
    if (['NexusPro','ZenyxPro'].includes(aluguel.data.nomeproduto)) {
      const { buildZenyxPanel } = require('./Lib/refreshSalesPanel');
      sentMsg = await channel.send(buildZenyxPanel(channel.guild, 'ZenyxPro'));
    } else if (aluguel.data.type === 'embed') {  
      const embed = new (require('discord.js').EmbedBuilder)()  
        .setDescription(aluguel.data.preco.embed.desc)  
        .setTitle(aluguel.data.preco.embed.titulo)  
        .setColor(aluguel.data.preco.embed.cor)  
        .setFooter({ text: channel.guild.name, iconURL: channel.guild.iconURL() })  
        .setTimestamp();  
      const banner = aluguel.data.banner;  
      if (banner && typeof banner === 'string' && banner.trim() !== '') {  
        embed.setImage(banner);  
      }  
      const row = new (require('discord.js').ActionRowBuilder)()  
        .addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setCustomId(`${aluguel.data.nomeproduto}_buy`)  
            .setLabel('Alugar')  
            .setEmoji('🛒')  
            .setStyle(3)  
        );  
      if (aluguel.data.link !== 'remover') {  
        row.addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setStyle(5)  
            .setURL(aluguel.data.link)  
            .setLabel('Tutorial/Preview')  
            .setEmoji('👀')  
        );  
      }  
      const saibaMaisText = aluguel.data.saibamais;  
      if (saibaMaisText && typeof saibaMaisText === 'string' && saibaMaisText.trim() !== '') {  
        row.addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setCustomId(`${aluguel.data.nomeproduto}_saibamais`)  
            .setLabel('Saiba Mais')  
            .setStyle(2)  
        );  
      }  
      sentMsg = await channel.send({ embeds: [embed], components: [row] });  
    } else {  
      const content1 = aluguel.data.preco.content.content;  
      const banner = aluguel.data.banner;  
      const row = new (require('discord.js').ActionRowBuilder)()  
        .addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setCustomId(`${aluguel.data.nomeproduto}_buy`)  
            .setLabel('Alugar')  
            .setEmoji('🛒')  
            .setStyle(3)  
        );  
      if (aluguel.data.link !== 'remover') {  
        row.addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setStyle(5)  
            .setURL(aluguel.data.link)  
            .setLabel('Tutorial/Preview')  
            .setEmoji('👀')  
        );  
      }  
      const saibaMaisText2 = aluguel.data.saibamais;  
      if (saibaMaisText2 && typeof saibaMaisText2 === 'string' && saibaMaisText2.trim() !== '') {  
        row.addComponents(  
          new (require('discord.js').ButtonBuilder)()  
            .setCustomId(`${aluguel.data.nomeproduto}_saibamais`)  
            .setLabel('Saiba Mais')  
            .setStyle(2)  
            .setEmoji("📧")  
        );  
      }  
      sentMsg = await channel.send({ content: content1, components: [row] });  
    }  
    if (sentMsg && sentMsg.id) {  
      await db.set(`${aluguel.data.nomeproduto}.lastMsgId`, sentMsg.id);  
    }  
  }
}, 60 * 1000);

async function startSugestion() {
  const channelId = '1395203261182509196'

  const canal = client.channels.cache.get(channelId);

  const embed = new EmbedBuilder()  
    .setAuthor({ name: 'Sky Sugestion System', iconURL: 'https://cdn.discordapp.com/icons/1442167373934366934/a6662da4b31988f2d05fa2a0401c97ca.png?size=2048' })  
    .setTitle(`📨 CANAL DE SUGESTÕES – Sky APPS`)  
    .setDescription(`\`✨\` Quer ver algo novo por aqui?\nEste é o lugar perfeito para deixar suas ideias, melhorias e novos recursos que você gostaria de ver na nossa Loja de Bots!\n\`💡\` Como sugerir:\n• Envie uma mensagem bem explicativa de sua ideia de forma clara\n• Se possível, diga como isso ajudaria outros usuários\n• Envie quantas sugestões quiser!\n\n\`🛠️\` Todas as sugestões são analisadas com carinho e podem se tornar novas funcionalidades no futuro. Sua opinião é MUITO importante para nós! \`❤️\`\n\nEnvie agora sua sugestão!!!`)  
    .setColor("#1c03fc")  
    .setTimestamp();  

  //await canal.send({ embeds: [embed], components: [], content: "" });
}

client.on(Events.ClientReady, startSugestion)

client.login(token).catch(err => {
  if (err.message.includes("token")) {
    console.error("\x1b[31m[ERRO]\x1b[0m Token inválido! Verifique o token no config.json");
    process.exit(1);
  } else {
    console.error(`\x1b[31m[ERRO]\x1b[0m Falha ao iniciar o bot: ${err}`);
  }
});
