const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const src = fs.readFileSync(path.join(root, "src/discord/router.ts"), "utf8");
const dist = fs.readFileSync(path.join(root, "dist/discord/router.js"), "utf8");

function ok(cond, msg) {
  if (!cond) {
    console.error("FAIL:", msg);
    process.exit(1);
  }
}

for (const text of [src, dist]) {
  ok(!text.includes("adminPage(gid, this.robuxAdminView(gid), false)"),
    "robuxAdminView não pode ser embrulhado novamente por adminPage");
  ok(text.includes("s.announcementChannelId || s.logChannelId"),
    "anúncio pós-compra deve aceitar o canal de logs como fallback");
  ok(text.includes("announcementEnabled: true, announcementChannelId"),
    "fallback do canal pós-compra precisa ser persistido");
}

ok(src.includes('return i.reply({ ...this.robuxAdminView(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);'),
  "respostas dos modais Robux devem devolver Components V2 diretamente");
ok(dist.includes('return i.reply({ ...this.robuxAdminView(gid), flags: discord_js_1.MessageFlags.Ephemeral | discord_js_1.MessageFlags.IsComponentsV2 });'),
  "build deve conter a resposta V2 direta");

const adminStart = src.indexOf("private robuxAdminView");
const adminEnd = src.indexOf("private robuxAdminAdvancedView", adminStart);
const admin = src.slice(adminStart, adminEnd);
const actionRows = [...admin.matchAll(/new ActionRowBuilder<ButtonBuilder>\(\)\.addComponents\(([\s\S]*?)\n\s*\)/g)];
for (const [idx, row] of actionRows.entries()) {
  const buttonCount = (row[1].match(/this\.views\.button\(/g) || []).length;
  ok(buttonCount <= 5, `ActionRow Robux ${idx + 1} excede 5 botões (${buttonCount})`);
}

console.log("R18.9.41 regression: OK");
