const fs=require('fs');const path=require('path');
const read=(p)=>fs.readFileSync(path.join(process.cwd(),p),'utf8');const must=(c,m)=>{if(!c)throw new Error(m)};
const v=read('src/discord/views.ts');
must(v.includes('fieldUnavailable = unavailable || (product.deliveryType === "STOCK"')&&v.includes('ButtonStyle.Secondary, fieldUnavailable'),'zero-stock disabled button missing');
const r=read('src/discord/router.ts');
must(r.includes('affectedProducts = [...new Set(order.items.filter((item) => item.deliveryType === "STOCK")'),'order-driven publication refresh missing');
must((r.match(/refreshProductPublications\(productId!\)/g)||[]).length>=4,'stock admin changes do not refresh published panels');
console.log('R18.9.40 child regression OK');
