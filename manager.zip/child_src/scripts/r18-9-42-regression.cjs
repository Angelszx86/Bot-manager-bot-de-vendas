const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const src = fs.readFileSync(path.join(root, "src/discord/router.ts"), "utf8");
const dist = fs.readFileSync(path.join(root, "dist/discord/router.js"), "utf8");
function ok(cond, msg) { if (!cond) { console.error("FAIL:", msg); process.exit(1); } }
for (const text of [src, dist]) {
  const start = text.indexOf('if (id.startsWith("robux:close:"))');
  const end = text.indexOf('if (id.startsWith("robux:back-gamepasses:"))', start);
  ok(start >= 0 && end > start, "handler robux:close precisa existir");
  const block = text.slice(start, end);
  ok(!block.includes("setTimeout("), "fechamento Robux não pode depender de setTimeout");
  ok(block.includes("setArchived(true"), "handler deve arquivar o tópico pelo discord.js");
  ok(block.includes("Routes.channel(thread.id)"), "handler deve ter fallback REST para arquivar o tópico");
  ok(block.includes("deferReply"), "interação deve ser reconhecida antes do fechamento");
  const lastDelete = block.lastIndexOf("robuxSessions.delete(sessionKey)");
  ok(lastDelete > block.indexOf("setArchived(true"), "sessão do tópico ativo só deve ser removida depois da tentativa de fechamento");
  ok(block.includes("O tópico foi arquivado"), "confirmação deve indicar fechamento concluído");
}
console.log("R18.9.42 regression: OK");
