const fs = require("fs");
const path = require("path");
const root = path.resolve(__dirname, "..");
const viewsSrc = fs.readFileSync(path.join(root, "src/discord/views.ts"), "utf8");
const viewsDist = fs.readFileSync(path.join(root, "dist/discord/views.js"), "utf8");
const routerSrc = fs.readFileSync(path.join(root, "src/discord/router.ts"), "utf8");
const routerDist = fs.readFileSync(path.join(root, "dist/discord/router.js"), "utf8");
function ok(cond, msg) { if (!cond) { console.error("FAIL:", msg); process.exit(1); } }
for (const text of [viewsSrc, viewsDist]) {
  ok(text.includes('product.deliveryType === "STOCK" || product.deliveryType === "MANUAL"'),
    "vitrine deve tratar STOCK e MANUAL como controlados por estoque");
  ok(text.includes('stockControlled && totalStock === 0'),
    "painel deve ficar indisponível quando estoque total controlado chegar a zero");
  ok(text.includes('stockControlled && this.products.stockCount(product.id, "AVAILABLE", single.id) === 0'),
    "botão de produto único deve ser desativado sem estoque também no manual");
  ok(text.includes('if (stockControlled)') && text.includes('descriptionParts.push(fieldStock > 0 ? `estoque ${fieldStock}` : "esgotado")'),
    "modo select deve refletir estoque/esgotado também para entrega manual");
}
for (const text of [routerSrc, routerDist]) {
  ok(text.includes('(product.deliveryType === "STOCK" || product.deliveryType === "MANUAL")') && text.includes('Esta opção está sem stock no momento.'),
    "handler de compra deve bloquear clique obsoleto sem estoque em manual e automático");
}
console.log("R18.9.43 regression: OK");
