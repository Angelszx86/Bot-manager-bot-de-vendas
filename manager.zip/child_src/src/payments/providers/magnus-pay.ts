import type { PaymentCharge } from "../../types.js";
import type { ChargeInput, PaymentProvider } from "../contracts.js";
import { GatewayHttpClient, objectAt, safeErrorText, textAt } from "../http-client.js";
import { pixQrDataUrl } from "../../services/pix.js";

function normalizeStatus(value: unknown): PaymentCharge["status"] {
  const status = textAt(value).toLowerCase();
  if (["paid", "approved", "completed", "success", "succeeded", "concluida", "concluído", "recebido", "pago"].includes(status)) return "paid";
  if (["expired", "timeout", "expirada", "expirado"].includes(status)) return "expired";
  if (["canceled", "cancelled", "refused", "failed", "rejected", "cancelado", "cancelada", "erro", "error", "refunded"].includes(status)) return "canceled";
  return "pending";
}

function firstObject(data: Record<string, unknown>): Record<string, unknown> {
  for (const key of ["data", "payment", "pix", "charge", "transaction"]) {
    const value = data[key];
    if (Array.isArray(value) && value.length && value[0] && typeof value[0] === "object") return value[0] as Record<string, unknown>;
    const obj = objectAt(data, key);
    if (Object.keys(obj).length) return obj;
  }
  return data;
}

function authHeaders(spec: string, token: string): Record<string, string> {
  const cleanSpec = textAt(spec) || "Authorization:Bearer";
  const idx = cleanSpec.indexOf(":");
  const header = (idx >= 0 ? cleanSpec.slice(0, idx) : cleanSpec).trim() || "Authorization";
  const prefix = (idx >= 0 ? cleanSpec.slice(idx + 1) : "Bearer").trim();
  return { [header]: `${prefix ? `${prefix} ` : ""}${token.trim()}`.trim() };
}

function statusPath(template: string, externalId: string): string {
  const raw = textAt(template) || "/pix/{id}";
  if (raw.includes("{id}")) return raw.replaceAll("{id}", encodeURIComponent(externalId));
  const sep = raw.includes("?") ? "&" : "?";
  return `${raw}${sep}id=${encodeURIComponent(externalId)}`;
}

export class MagnusPayProvider implements PaymentProvider {
  readonly name = "MAGNUS_PAY" as const;
  private readonly http: GatewayHttpClient;

  constructor(
    private readonly token: string,
    private readonly baseUrl: string,
    private readonly createPath: string,
    private readonly consultPath: string,
    private readonly authSpec = "Authorization:Bearer"
  ) {
    const url = textAt(baseUrl).replace(/\/+$/, "");
    if (!/^https:\/\//i.test(url)) throw new Error("MagnusPay exige uma URL base HTTPS válida.");
    if (!textAt(token)) throw new Error("Configure o token/API Key da MagnusPay.");
    if (!textAt(createPath) || !textAt(consultPath)) throw new Error("Configure as rotas de criação e consulta da MagnusPay.");
    this.http = new GatewayHttpClient("MagnusPay", url, authHeaders(authSpec, token));
  }

  async createCharge(input: ChargeInput): Promise<PaymentCharge> {
    const document = input.customer.document.replace(/\D/g, "").slice(0, 14);
    const payload: Record<string, unknown> = {
      amount: Number((input.amountCents / 100).toFixed(2)),
      value: Number((input.amountCents / 100).toFixed(2)),
      amountCents: input.amountCents,
      description: input.description.slice(0, 255),
      externalReference: input.orderId,
      clientReference: input.orderId,
      reference: input.orderId,
      expiresAt: input.expiresAt,
      customer: {
        name: input.customer.name.slice(0, 120),
        email: input.customer.email.slice(0, 200),
        document: document || undefined,
        discordId: input.customer.discordId
      }
    };
    const result = await this.http.request(textAt(this.createPath), { method: "POST", json: payload, retries: 1, idempotencyKey: input.orderId });
    return await this.toCharge(firstObject(result.data), input.expiresAt, input.orderId);
  }

  async getCharge(externalId: string): Promise<PaymentCharge> {
    if (!textAt(externalId)) throw new Error("Cobrança MagnusPay sem identificador externo.");
    const result = await this.http.request(statusPath(this.consultPath, externalId), { retries: 1 });
    return await this.toCharge(firstObject(result.data), undefined, undefined, externalId);
  }

  async test(): Promise<string> {
    const probe = statusPath(this.consultPath, `ZENYX-CHECK-${Date.now()}`);
    try {
      await this.http.request(probe, { retries: 0, timeoutMs: 15_000 });
      return "MagnusPay autenticada e API acessível";
    } catch (error) {
      const message = safeErrorText(error instanceof Error ? error.message : error, 300);
      if (/404|não encontr|not found/i.test(message)) return "MagnusPay autenticada; rota de consulta respondeu sem falha de credencial";
      throw error;
    }
  }

  private async toCharge(data: Record<string, unknown>, fallbackExpiresAt?: string, fallbackReference?: string, fallbackId?: string): Promise<PaymentCharge> {
    const externalId = textAt(data.id ?? data.paymentId ?? data.transactionId ?? data.txid ?? data.chargeId ?? fallbackId);
    if (!externalId) throw new Error("A MagnusPay não retornou o identificador da cobrança.");
    const pixCode = textAt(data.pixCode ?? data.qrCodeText ?? data.copyPaste ?? data.copy_and_paste ?? data.brCode ?? data.qrcode);
    const base64 = textAt(data.qrCodeBase64 ?? data.qrCodeImageBase64 ?? data.base64);
    const image = textAt(data.qrCodeUrl ?? data.qrCodeImage ?? data.imageUrl ?? data.qr_image);
    let qrCodeDataUrl: string | undefined;
    if (/^data:image\//i.test(base64)) qrCodeDataUrl = base64;
    else if (/^[A-Za-z0-9+/=\r\n]+$/.test(base64) && base64.length > 80) qrCodeDataUrl = `data:image/png;base64,${base64.replace(/\s+/g, "")}`;
    else if (/^https?:\/\//i.test(image)) qrCodeDataUrl = image;
    else if (pixCode) qrCodeDataUrl = await pixQrDataUrl(pixCode);
    return {
      externalId,
      status: normalizeStatus(data.status ?? data.state ?? data.paymentStatus ?? data.transactionStatus),
      pixCode: pixCode || undefined,
      qrCodeDataUrl,
      expiresAt: textAt(data.expiresAt ?? data.expiration ?? data.expirationDate) || fallbackExpiresAt,
      reference: textAt(data.externalReference ?? data.clientReference ?? data.reference ?? fallbackReference) || undefined,
      raw: data
    };
  }
}
