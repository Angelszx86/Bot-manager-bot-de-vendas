import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  ContainerBuilder,
  EmbedBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
  RoleSelectMenuBuilder,
  SectionBuilder,
  SeparatorBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder,
  escapeMarkdown
} from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { EmojiManager } from "../emojis/manager.js";
import type { BotMessageTemplate, ImapEmailProvider, Order, PaymentProviderName, Product, ProductField, SavedApplicationEmoji, StockRequest, TicketPanel, TicketPanelField } from "../types.js";
import { colorNumber, formatMoney, truncate } from "../core/utils.js";
import type { ProductService } from "../services/products.js";
import type { TicketService } from "../services/tickets.js";
import { bankProfile, IMAP_EMAIL_PRESETS } from "../services/imap-profiles.js";
import { checkedDiscordPayload } from "./payload-validator.js";

const bstyle = (name: Product["buttonStyle"]) => ({ PRIMARY: ButtonStyle.Primary, SECONDARY: ButtonStyle.Secondary, SUCCESS: ButtonStyle.Success, DANGER: ButtonStyle.Danger }[name]);
const smallText = (value: string, max = 3000) => truncate(String(value || ""), max).split("\n").map((line) => `-# ${line || " "}`).join("\n");

export class Views {
  private disabledButtonSequence = 0;
  constructor(private readonly db: JsonDatabase, private readonly emojis: EmojiManager, private readonly products: ProductService, private readonly tickets: TicketService) {}

  private automaticDeliveryEmojiSequence(guildId: string): { sequence: string; missing: string[] } {
    // A vitrine automática usa EXCLUSIVAMENTE os 7 Application Emojis enviados
    // para formar “ENTREGA AUTOMÁTICA”. Se algum deles estiver ausente, não
    // exibimos texto genérico no lugar: o EmojiManager sincroniza o asset correto.
    const wordSemantics = Array.from({ length: 7 }, (_, index) => `entrega${index}`);
    const missing = this.emojis.missing(wordSemantics, guildId);
    const words = wordSemantics.map((semantic) => this.emojis.text(semantic, guildId)).join("");
    return { sequence: missing.length ? "" : words, missing };
  }
  private productSales(productId: string, guildId: string): number {
    const paidStatuses = new Set(["PAID", "AWAITING_DELIVERY", "DELIVERED"]);
    return Object.values(this.db.state.orders)
      .filter((order) => order.guildId === guildId && paidStatuses.has(order.status))
      .flatMap((order) => order.items)
      .filter((item) => item.productId === productId)
      .reduce((sum, item) => sum + Math.max(0, Number(item.quantity) || 0), 0);
  }

  private base(title: string, description = "", guildId?: string) {
    const brand = guildId ? this.db.brand(guildId) : this.db.state.brand;
    const embed = new EmbedBuilder()
      .setTitle(truncate(title || "Minha Aplicação", 256))
      .setDescription(truncate(description || " ", 4096))
      .setFooter({ text: truncate(brand.footer || "Minha Aplicação", 2048) })
      .setTimestamp();
    if (brand.showAccentColors) embed.setColor(colorNumber(brand.color));
    if (brand.bannerUrl) embed.setImage(brand.bannerUrl);
    if (brand.logoUrl) embed.setThumbnail(brand.logoUrl);
    return embed;
  }

  /**
   * Converte qualquer tela administrativa antiga (embed + linhas de controles)
   * para um único Container V2. O painel inteiro passa a ter uma só moldura:
   * banner, textos, campos e componentes não se separam durante a navegação.
   */
  adminPage(guildId: string, payload: { content?: unknown; embeds?: unknown[]; components?: unknown[] }, includeDefaultBanner = true) {
    const brand = this.db.brand(guildId);
    const container = new ContainerBuilder();
    if (brand.showAccentColors) container.setAccentColor(colorNumber(brand.color));
    const bannerUrl = /^https?:\/\//i.test(brand.bannerUrl) ? brand.bannerUrl : includeDefaultBanner ? "attachment://panel-banner.png" : "";
    if (bannerUrl) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(bannerUrl).setDescription(truncate(`${brand.name} • painel administrativo`, 1000))
      ));
      container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    }

    const textBlocks: string[] = [];
    const directContent = String(payload.content ?? "").trim();
    if (directContent) textBlocks.push(directContent);
    const extraMedia: string[] = [];
    for (const source of payload.embeds ?? []) {
      const embed = source instanceof EmbedBuilder
        ? source.toJSON()
        : source && typeof source === "object" && "toJSON" in source && typeof (source as { toJSON?: unknown }).toJSON === "function"
          ? ((source as { toJSON(): Record<string, unknown> }).toJSON())
          : source as Record<string, unknown>;
      if (!embed || typeof embed !== "object") continue;
      const title = String(embed.title ?? "").trim();
      const description = String(embed.description ?? "").trim();
      if (title || description) textBlocks.push([title ? `## ${title}` : "", description].filter(Boolean).join("\n"));
      const fields = Array.isArray(embed.fields) ? embed.fields as Array<Record<string, unknown>> : [];
      const fieldBlocks: string[] = [];
      for (const field of fields) {
        const name = String(field.name ?? "Informação").trim();
        const value = String(field.value ?? "-").trim();
        fieldBlocks.push(`### ${name}\n${value}`);
      }
      // R18.9.46: campos de embed não viram mais um componente V2 por campo.
      // Um único bloco (fatiado abaixo em até 3900 chars) impede o painel de
      // gerenciamento de produtos de ultrapassar o teto recursivo do Discord.
      if (fieldBlocks.length) textBlocks.push(fieldBlocks.join("\n\n"));
      const footer = embed.footer && typeof embed.footer === "object" ? String((embed.footer as Record<string, unknown>).text ?? "").trim() : "";
      if (footer) textBlocks.push(`-# ${footer}`);
      const imageUrl = embed.image && typeof embed.image === "object" ? String((embed.image as Record<string, unknown>).url ?? "") : "";
      if (/^https?:\/\//i.test(imageUrl) && imageUrl !== brand.bannerUrl) extraMedia.push(imageUrl);
    }
    if (!textBlocks.length) textBlocks.push(`## ${brand.name}\nPainel administrativo`);
    for (const block of textBlocks) {
      for (let offset = 0; offset < block.length; offset += 3900) {
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(block.slice(offset, offset + 3900)));
      }
    }
    for (const url of [...new Set(extraMedia)].slice(0, 3)) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(url)));
    }
    const rows = payload.components ?? [];
    if (rows.length) container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    for (const row of rows) container.addActionRowComponents(row as never);
    return checkedDiscordPayload({
      flags: MessageFlags.IsComponentsV2 as const,
      components: [container]
    }, "painel administrativo Components V2");
  }

  adminPageEdit(guildId: string, payload: { content?: unknown; embeds?: unknown[]; components?: unknown[] }, includeDefaultBanner = true) {
    const rendered = this.adminPage(guildId, payload, includeDefaultBanner) as Record<string, unknown>;
    // Components V2 PRECISA manter IsComponentsV2 também em InteractionUpdateOptions.
    // Sem a flag, a API valida o primeiro Container (type 17) como se fosse uma
    // ActionRow legada e responde exatamente: `type must be one of (1)`.
    // A documentação atual do discord.js permite alterar IsComponentsV2 em edits.
    return checkedDiscordPayload({
      flags: MessageFlags.IsComponentsV2 as const,
      components: rendered.components
    }, "edição do painel administrativo Components V2");
  }
  button(guildId: string, id: string, label: string, semantic: string, style = ButtonStyle.Secondary, disabled = false) {
    if (!id.trim()) throw new Error("Um botão foi criado sem custom_id.");
    if (id.length > 100) throw new Error(`custom_id de botão excede 100 caracteres: ${id}`);
    // O Discord exige custom_id exclusivo até para botões desativados. Paginações
    // com uma única página costumavam gerar o mesmo ID para "Anterior" e
    // "Próxima". IDs de no-op tornam cada controle desativado inequivocamente
    // único sem alterar nenhuma rota clicável.
    const customId = disabled
      ? `noop:${(++this.disabledButtonSequence).toString(36)}:${id}`.slice(0, 100)
      : id;
    const button = new ButtonBuilder().setCustomId(customId).setLabel(truncate(label || "Ação", 80)).setStyle(style).setDisabled(disabled);
    if (semantic.trim()) {
      const emoji = this.emojis.component(semantic, guildId);
      // Alguns assets intencionalmente não possuem fallback Unicode (ex.: Robux).
      // Se ainda não foram sincronizados, omita o emoji em vez de mandar string
      // vazia ao Discord e provocar ValidationError/Invalid Form Body.
      if (typeof emoji !== "string" || emoji.trim()) button.setEmoji(emoji);
    }
    return button;
  }
  back(guildId: string, to = "admin:home") { return new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, to, "Voltar", "back")); }

  adminHome(guildId: string, username: string, zcloudAvailable = true) {
    const stats = this.db.stats(guildId);
    const guild = this.db.guild(guildId);
    const emoji = (semantic: string) => this.emojis.text(semantic, guildId);
    const paymentLabels: Record<string, string> = {
      MERCADO_PAGO: "Mercado Pago", EFI_BANK: "Efí Bank", STRIPE: "Stripe PIX",
      MISTIC_PAY: "MisticPay", PURIN_CASH: "Purin Cash", EVO_PAY: "EvoPay PIX",
      MAGNUS_PAY: "MagnusPay", ZNY_PAY: "Znypay", IMAP_PIX: "IMAP PIX", MANUAL_PIX: "PIX manual"
    };
    const configuredChannels = [guild.salesChannelId, guild.logChannelId, guild.ticketLogChannelId, guild.ticketCategoryId].filter(Boolean).length;
    const ticketPanels = Object.values(this.db.state.ticketPanels).filter((panel) => panel.guildId === guildId).length;
    const stockRequests = Object.values(this.db.state.stockRequests).filter((request) => request.guildId === guildId && request.status === "PENDING").length;
    const brand = this.db.brand(guildId);

    const embed = this.base(
      `${emoji("home")} Central de Controle • ${brand.name}`,
      `Olá, **${truncate(username, 80)}**.
-# Gerencie vendas, Robux, pagamentos, tickets e automações sem sair desta central.`,
      guildId
    ).addFields(
      {
        name: `${emoji("products")} Loja`,
        value: `**${stats.activeProducts}** produtos • **${stats.availableStock}** em estoque • **${stats.pendingOrders}** pedidos pendentes\n-# ${ticketPanels} painel(is) de ticket • ${stockRequests} solicitação(ões) de stock`,
        inline: false
      },
      {
        name: `${emoji("revenue")} Financeiro`,
        value: `Hoje **${formatMoney(stats.revenueToday)}** • 30 dias **${formatMoney(stats.revenue30d)}**\nGateway padrão: **${paymentLabels[this.db.payments(guildId).defaultProvider] ?? this.db.payments(guildId).defaultProvider}**`,
        inline: false
      },
      {
        name: `${emoji("settings")} Sistema`,
        value: `Equipe **${guild.staffRoleIds.length ? "pronta" : "pendente"}** • canais **${configuredChannels}/4** • emojis **${this.emojis.status.installed}/${this.emojis.status.total}**\n-# Use o menu abaixo para abrir configurações avançadas.`,
        inline: false
      }
    );
    if (!brand.bannerUrl) embed.setImage("attachment://panel-banner.png");

    const navigation = new StringSelectMenuBuilder()
      .setCustomId("admin:navigate")
      .setPlaceholder("Abrir uma área da central")
      .addOptions(
        new StringSelectMenuOptionBuilder().setLabel("Produtos e vendas").setDescription("Produtos, estoque e vitrines").setValue("products").setEmoji(this.emojis.component("products", guildId)),
        (() => { const option = new StringSelectMenuOptionBuilder().setLabel("Robux").setDescription("Venda, calculadora, gamepasses e entrega").setValue("robux"); const e=this.emojis.component("robux",guildId); if(typeof e!=="string"||e.trim()) option.setEmoji(e); return option; })(),
        new StringSelectMenuOptionBuilder().setLabel("Pedidos").setDescription("Acompanhar e gerenciar pedidos").setValue("orders").setEmoji(this.emojis.component("invoice", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Pagamentos").setDescription("Gateways PIX, credenciais e testes").setValue("payments").setEmoji(this.emojis.component("payment", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Zwallet").setDescription("Saldo, histórico, PIX e saques").setValue("wallet").setEmoji(this.emojis.component("wallet", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Tickets").setDescription("Painéis e atendimento").setValue("tickets").setEmoji(this.emojis.component("ticket", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Mensagens do bot").setDescription("Mensagens, banners, miniaturas e links").setValue("messages").setEmoji(this.emojis.component("message", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Pedir Stock").setDescription("Solicitações públicas de reposição").setValue("stock_requests").setEmoji(this.emojis.component("stock_request", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Rendimento").setDescription("Faturamento e desempenho").setValue("revenue").setEmoji(this.emojis.component("analytics", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Personalização").setDescription("Marca, banner, avatar e presença").setValue("personalize").setEmoji(this.emojis.component("customize", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Automações").setDescription("Mensagens, reações e boas-vindas").setValue("automations").setEmoji(this.emojis.component("automation", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Proteção").setDescription("Anti-link, anti-spam e registros").setValue("protection").setEmoji(this.emojis.component("protection", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Sorteios").setDescription("Criar e gerenciar sorteios").setValue("giveaways").setEmoji(this.emojis.component("giveaway", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Canais e cargos").setDescription("Permissões, categorias e destinos").setValue("channels").setEmoji(this.emojis.component("settings", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Cupons").setDescription("Descontos e usos").setValue("coupons").setEmoji(this.emojis.component("coupon", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Permissões").setDescription("Usuários, cargos e níveis de acesso").setValue("permissions").setEmoji(this.emojis.component("shield", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Emojis").setDescription("Instalação e mapeamento").setValue("emojis").setEmoji(this.emojis.component("emoji", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Salvar Emojis").setDescription("Biblioteca de emojis da aplicação").setValue("saved_emojis").setEmoji(this.emojis.component("saved_emoji", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Conectar em call").setDescription("Manter o bot em um canal de voz").setValue("voice").setEmoji(this.emojis.component("voice", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Comandos").setDescription("Lista de comandos Slash").setValue("commands").setEmoji(this.emojis.component("commands", guildId)),
        ...(zcloudAvailable ? [new StringSelectMenuOptionBuilder().setLabel("ZCloud").setDescription("OAuth2, verificação e recuperação").setValue("zcloud").setEmoji(this.emojis.component("zcloud", guildId))] : []),
        new StringSelectMenuOptionBuilder().setLabel("Invites").setDescription("Convites, entradas e ranking").setValue("invites").setEmoji(this.emojis.component("announcement", guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Backups do servidor").setDescription("Criar, listar e restaurar backups").setValue("backups").setEmoji(this.emojis.component("backup", guildId))
      );

    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:products", "Produtos", "products", ButtonStyle.Primary),
          this.button(guildId, "admin:robux", "Robux", "robux", ButtonStyle.Primary),
          this.button(guildId, "admin:orders", "Pedidos", "invoice", ButtonStyle.Primary),
          this.button(guildId, "admin:payments", "Pagamentos", "payment", ButtonStyle.Primary),
          this.button(guildId, "admin:tickets", "Tickets", "ticket", ButtonStyle.Primary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:wallet", "Zwallet", "wallet", ButtonStyle.Secondary),
          this.button(guildId, "admin:automations", "Automações", "automation", ButtonStyle.Secondary),
          this.button(guildId, "admin:messages", "Mensagens", "message", ButtonStyle.Secondary),
          this.button(guildId, "admin:personalize", "Visual", "customize", ButtonStyle.Secondary),
          this.button(guildId, "admin:channels", "Canais", "settings", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(navigation)
      ]
    };
  }

  productsHome(guildId: string, page = 0) {
    const all = this.products.list(false, guildId);
    const slice = all.slice(page * 25, page * 25 + 25);
    const embed = this.base(
      `${this.emojis.text("products", guildId)} Produtos e painéis de venda`,
      `Cada produto possui campos próprios. Com **1 campo**, o painel mostra um botão de compra. Com **2 ou mais campos**, o bot cria automaticamente um menu select com preço, descrição e emoji de cada opção.

**Produtos cadastrados:** ${all.length}`,
      guildId
    );
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:product:create", "Criar produto", "product_add", ButtonStyle.Success),
        this.button(guildId, "admin:restock", "Avisos de restock", "announcement", ButtonStyle.Primary),
        this.button(guildId, "admin:coupons", "Cupons", "coupon")
      )
    ];
    if (slice.length) {
      const select = new StringSelectMenuBuilder()
        .setCustomId(`admin:product:select:${page}`)
        .setPlaceholder("Selecione um produto para editar")
        .addOptions(slice.map((product) => {
          const activeFields = this.products.activeFields(product);
          return new StringSelectMenuOptionBuilder()
            .setLabel(truncate(product.name, 100))
            .setDescription(truncate(`${activeFields.length} campo(s) • estoque ${this.products.stockCount(product.id)} • ${product.publications.length} publicação(ões)`, 100))
            .setValue(product.id)
            .setEmoji(this.emojis.component(product.emojiSemantic, guildId));
        }));
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `admin:products:${Math.max(0, page - 1)}`, "Anterior", "back", ButtonStyle.Secondary, page === 0),
      this.button(guildId, `admin:products:${page + 1}`, "Próxima", "catalog", ButtonStyle.Secondary, (page + 1) * 25 >= all.length),
      this.button(guildId, "admin:home", "Início", "home")
    ));
    return { embeds: [embed], components };
  }

  restockSettings(guildId: string) {
    const settings = this.db.guild(guildId).restockAnnouncements;
    const history = Object.values(this.db.state.restockAnnouncements).filter((entry) => entry.guildId === guildId);
    const sent = history.filter((entry) => entry.status === "SENT").length;
    const failed = history.filter((entry) => entry.status === "FAILED").length;
    return {
      embeds: [this.base(
        `${this.emojis.text("announcement", guildId)} Avisos automáticos de restock`,
        "Escolha um canal e o bot anunciará cada reposição feita pelo painel, informando produto, opção, quantidade adicionada e estoque total.",
        guildId
      ).addFields(
        { name: "Status", value: settings.enabled ? "🟢 Ativado" : "⚫ Desativado", inline: true },
        { name: "Canal", value: settings.channelId ? `<#${settings.channelId}>` : "Não configurado", inline: true },
        { name: "Cargo mencionado", value: settings.mentionRoleId ? `<@&${settings.mentionRoleId}>` : "Nenhum", inline: true },
        { name: "Título", value: settings.title, inline: true },
        { name: "Histórico", value: `${sent} enviado(s) • ${failed} falha(s)`, inline: true },
        { name: "Banner do produto", value: settings.includeProductBanner ? "Incluído quando existir" : "Desativado", inline: true },
        { name: "Mensagem", value: truncate(settings.message, 1000), inline: false }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:restock:channel", "Escolher canal", "message", ButtonStyle.Primary),
          this.button(guildId, "admin:restock:role", "Cargo para mencionar", "role"),
          this.button(guildId, "admin:restock:edit", "Editar mensagem", "edit"),
          this.button(guildId, "admin:restock:toggle", settings.enabled ? "Desativar" : "Ativar", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:restock:banner", settings.includeProductBanner ? "Ocultar banner" : "Mostrar banner", "image"),
          this.button(guildId, "admin:products", "Voltar aos produtos", "back")
        )
      ]
    };
  }

  productDetail(guildId: string, product: Product) {
    const activeFields = this.products.activeFields(product);
    const mode = product.purchaseMode === "SELECT"
      ? `Menu select • ${activeFields.length} produto(s)/opção(ões)`
      : `Produto único • botão${activeFields.length > 1 ? " • usando o primeiro campo ativo" : ""}`;
    const demoStatus = product.demonstrationEnabled && product.demonstrationUrl ? `Ativa • ${product.demonstrationLabel}` : "Desativada";
    const deliveryMissing = product.deliveryType === "STOCK" ? this.emojis.missing(Array.from({ length: 7 }, (_, index) => `entrega${index}`), guildId) : [];
    const embed = this.base(`${this.emojis.text(product.emojiSemantic, guildId)} ${product.name}`, product.description, guildId)
      .addFields(
        { name: "ID", value: `\`${product.id}\``, inline: true },
        { name: "Campos", value: `${activeFields.length} ativo(s) • ${product.fields.length} total`, inline: true },
        { name: "Estoque total", value: String(this.products.stockCount(product.id)), inline: true },
        { name: "Publicações", value: `${product.publications.length} mensagem(ns)`, inline: true },
        { name: "Modo público", value: mode, inline: true },
        { name: "Demonstração", value: demoStatus, inline: true },
        { name: "Entrega", value: product.deliveryType === "STOCK" ? `${this.emojis.text("truck", guildId)} Automática` : product.deliveryType === "ROLE" ? `${this.emojis.text("role", guildId)} Cargo automático` : `${this.emojis.text("delivery", guildId)} Manual`, inline: true },
        { name: "Limites", value: `Mínimo: ${product.minQuantity} • Máximo: ${product.maxQuantity} • Por usuário: ${product.perUserLimit || "sem limite"}`, inline: false },
        { name: "Categoria/grupo de cupom", value: product.couponGroup || "Nenhum", inline: true },
        { name: "Status", value: product.active ? "Ativo" : "Inativo", inline: true },
        { name: "Layout público", value: `Ação ${product.purchasePlacement === "AFTER_DESCRIPTION" ? "após a descrição" : "na área inferior"} • descrições em subtexto`, inline: true },
        ...(product.deliveryType === "STOCK" ? [{ name: "Emojis ENTREGA AUTOMÁTICA", value: deliveryMissing.length ? `Ausentes: ${deliveryMissing.map((name) => `\`${name}\``).join(", ")}. Use **Emojis → Instalar/corrigir**.` : "Os 7 emojis originais do public.zip estão instalados na aplicação.", inline: false }] : [])
      );
    if (product.imageUrl) embed.setThumbnail(product.imageUrl);
    if (product.bannerUrl) embed.setImage(product.bannerUrl);
    if (product.deliveryType === "STOCK") {
      const deliveryVisual = this.automaticDeliveryEmojiSequence(guildId);
      if (deliveryVisual.sequence) {
        embed.addFields({ name: "\u200B", value: `## ${deliveryVisual.sequence}`, inline: false });
      }
    }
    return { embeds: [embed], attachments: [], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:basic:${product.id}`, "Descrição", "product_edit"),
        this.button(guildId, `admin:product:visual:${product.id}`, "Banner e visual", "image"),
        this.button(guildId, `admin:product:fields:${product.id}`, product.purchaseMode === "SELECT" ? "Produtos / Estoque" : "Campos / Estoque", "stock", ButtonStyle.Primary),
        this.button(guildId, `admin:product:mode:${product.id}`, product.purchaseMode === "SELECT" ? "Modo: Menu select" : "Modo: Produto único", "catalog", ButtonStyle.Primary),
        this.button(guildId, `admin:product:demo:${product.id}`, "Demonstração", "information", ButtonStyle.Primary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:purchase:${product.id}`, "Texto da compra", "cart", ButtonStyle.Primary),
        this.button(guildId, `admin:product:emoji:${product.id}:0`, "Emoji do produto", "emoji"),
        this.button(guildId, `admin:product:delivery:${product.id}`, "Entrega / Termos", "delivery"),
        this.button(guildId, `admin:product:publish:${product.id}`, "Publicar mensagem", "catalog", ButtonStyle.Success),
        this.button(guildId, `admin:product:update-message:${product.id}`, "Atualizar mensagem", "refresh", ButtonStyle.Success, product.publications.length === 0)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:toggle:${product.id}`, product.active ? "Desativar" : "Ativar", product.active ? "reject" : "approve", product.active ? ButtonStyle.Danger : ButtonStyle.Success),
        this.button(guildId, `admin:product:image-upload:${product.id}`, "Miniatura por link", "upload"),
        this.button(guildId, `admin:product:banner-upload:${product.id}`, "Banner por link", "image"),
        this.button(guildId, `admin:product:duplicate:${product.id}`, "Duplicar", "product_duplicate"),
        this.button(guildId, `admin:product:delete:${product.id}`, "Excluir", "product_delete", ButtonStyle.Danger)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:placement:${product.id}`, product.purchasePlacement === "AFTER_DESCRIPTION" ? "Ação: após descrição" : "Ação: abaixo do preço", "cart", ButtonStyle.Secondary),
        this.button(guildId, "admin:products", "Voltar", "back")
      )
    ] };
  }

  productModeView(guildId: string, product: Product) {
    const activeFields = this.products.activeFields(product);
    const select = new StringSelectMenuBuilder()
      .setCustomId(`admin:product:mode-select:${product.id}`)
      .setPlaceholder("Escolha como este painel será exibido")
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel("Produto único • botão")
          .setDescription("Compra diretamente o primeiro campo ativo")
          .setValue("BUTTON")
          .setDefault(product.purchaseMode === "BUTTON")
          .setEmoji(this.emojis.component("cart", guildId)),
        new StringSelectMenuOptionBuilder()
          .setLabel("Vários produtos • menu select")
          .setDescription("Cada campo ativo vira uma opção no mesmo painel")
          .setValue("SELECT")
          .setDefault(product.purchaseMode === "SELECT")
          .setEmoji(this.emojis.component("catalog", guildId))
      );
    return {
      embeds: [this.base(
        `${this.emojis.text("catalog", guildId)} Modo da vitrine • ${product.name}`,
        product.purchaseMode === "SELECT"
          ? `Este painel está em **Menu select**. Os **${activeFields.length}** campos ativos aparecem como produtos/opções no mesmo menu. Você pode adicionar até 25 em **Produtos / Estoque**.`
          : `Este painel está em **Produto único**. O botão compra diretamente o primeiro campo ativo.${activeFields.length > 1 ? ` Os outros **${activeFields.length - 1}** campos ficam preservados e voltam a aparecer se você mudar para Menu select.` : ""}`,
        guildId
      ).addFields(
        { name: "Produto único", value: "1 ação principal em botão. Ideal para uma oferta direta.", inline: true },
        { name: "Menu select", value: "Até 25 produtos/opções dentro do mesmo painel.", inline: true }
      )],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, `admin:product:fields:${product.id}`, product.purchaseMode === "SELECT" ? "Gerenciar produtos/opções" : "Gerenciar campos", "stock", ButtonStyle.Primary),
          this.button(guildId, `admin:product:${product.id}`, "Voltar ao produto", "back", ButtonStyle.Secondary)
        )
      ]
    };
  }

  productFieldsView(guildId: string, product: Product) {
    const fields = product.fields;
    const lines = fields.map((field, index) => {
      const stock = this.products.stockCount(product.id, "AVAILABLE", field.id);
      const mode = field.stockMode === "GHOST" ? "fantasma" : "individual";
      return `${index + 1}. ${this.emojis.text(field.emoji || "cart", guildId)} **${field.name}** — ${formatMoney(field.priceCents)} • stock ${stock} (${mode})${field.active ? "" : " • inativo"}`;
    });
    const embed = this.base(
      `${this.emojis.text("stock", guildId)} ${product.purchaseMode === "SELECT" ? "Produtos / opções" : "Campos"} • ${product.name}`,
      `${lines.join("\n") || (product.purchaseMode === "SELECT" ? "Nenhum produto/opção configurado." : "Nenhum campo configurado.")}

O modo da vitrine é escolhido em **Modo da vitrine**. Em **Produto único**, o botão compra o primeiro campo ativo. Em **Menu select**, cada campo ativo aparece como um produto/opção independente no mesmo painel.`,
      guildId
    );
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (fields.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`admin:product:field-select:${product.id}`)
          .setPlaceholder(product.purchaseMode === "SELECT" ? "Abrir produto/opção para editar preço e stock" : "Abrir campo para editar preço, emoji e stock")
          .addOptions(fields.slice(0, 25).map((field) => new StringSelectMenuOptionBuilder()
            .setLabel(truncate(field.name, 100))
            .setDescription(truncate(`${formatMoney(field.priceCents)} • stock ${this.products.stockCount(product.id, "AVAILABLE", field.id)} • ${field.stockMode === "GHOST" ? "fantasma" : "individual"}`, 100))
            .setValue(field.id)
            .setEmoji(this.emojis.component(field.emoji || "cart", guildId))))
      ));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `admin:product:field-add:${product.id}`, product.purchaseMode === "SELECT" ? "Adicionar produto/opção" : "Adicionar campo", "plus", ButtonStyle.Success, fields.length >= 25),
      this.button(guildId, `admin:product:${product.id}`, "Voltar ao produto", "back")
    ));
    return { embeds: [embed], components };
  }

  productFieldDetail(guildId: string, product: Product, field: ProductField) {
    const available = this.products.stockCount(product.id, "AVAILABLE", field.id);
    const reserved = this.products.stockCount(product.id, "RESERVED", field.id);
    const sold = this.products.stockCount(product.id, "SOLD", field.id);
    const embed = this.base(`${this.emojis.text(field.emoji || "cart", guildId)} ${field.name}`, field.description || "Sem descrição curta.", guildId)
      .addFields(
        { name: "Preço", value: formatMoney(field.priceCents), inline: true },
        { name: "Preço anterior", value: field.compareAtCents ? formatMoney(field.compareAtCents) : "Não definido", inline: true },
        { name: "Status", value: field.active ? "Ativo" : "Inativo", inline: true },
        { name: "Tipo de stock", value: field.stockMode === "GHOST" ? "Stock fantasma" : "Itens individuais", inline: true },
        { name: "Disponível", value: String(available), inline: true },
        { name: "Reservado / vendido", value: `${reserved} / ${sold}`, inline: true },
        { name: "Emoji", value: `\`${field.emoji || "cart"}\``, inline: false }
      );
    return { embeds: [embed], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:field-edit:${product.id}:${field.id}`, product.purchaseMode === "SELECT" ? "Editar produto/opção" : "Editar campo", "product_edit", ButtonStyle.Primary),
        this.button(guildId, `admin:product:field-emoji:${product.id}:${field.id}:0`, "Escolher emoji", "emoji", ButtonStyle.Primary),
        this.button(guildId, `admin:product:field-stock:${product.id}:${field.id}`, "Gerenciar stock", "stock", ButtonStyle.Success),
        this.button(guildId, `admin:product:field-toggle:${product.id}:${field.id}`, field.active ? "Desativar" : "Ativar", field.active ? "reject" : "approve", field.active ? ButtonStyle.Danger : ButtonStyle.Success)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:product:field-delete:${product.id}:${field.id}`, product.purchaseMode === "SELECT" ? "Excluir produto/opção" : "Excluir campo", "trash", ButtonStyle.Danger, product.fields.length <= 1),
        this.button(guildId, `admin:product:fields:${product.id}`, product.purchaseMode === "SELECT" ? "Voltar aos produtos" : "Voltar aos campos", "back")
      )
    ] };
  }

  stockView(guildId: string, product: Product, field?: ProductField) {
    const selected = field ?? this.products.getField(product.id);
    const available = this.products.stockCount(product.id, "AVAILABLE", selected.id);
    const reserved = this.products.stockCount(product.id, "RESERVED", selected.id);
    const sold = this.products.stockCount(product.id, "SOLD", selected.id);
    const description = selected.stockMode === "GHOST"
      ? `**Stock fantasma ativo**
Você salva um único conteúdo e define uma quantidade virtual. Todas as unidades entregam exatamente o mesmo conteúdo.

Disponível: **${available}**
Reservado: **${reserved}**
Vendido: **${sold}**`
      : `**Stock individual**
Cada linha adicionada é entregue uma única vez.

Disponível: **${available}**
Reservado: **${reserved}**
Vendido: **${sold}**`;
    return { embeds: [this.base(`${this.emojis.text("stock", guildId)} Stock • ${product.name} • ${selected.name}`, description, guildId)], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:stock:add:${product.id}:${selected.id}`, "Adicionar itens", "stock_add", ButtonStyle.Success, selected.stockMode === "GHOST"),
        this.button(guildId, `admin:stock:ghost:${product.id}:${selected.id}`, "Configurar stock fantasma", "automation", ButtonStyle.Primary),
        this.button(guildId, `admin:stock:unique:${product.id}:${selected.id}`, "Usar stock individual", "stock", ButtonStyle.Secondary, selected.stockMode === "UNIQUE"),
        this.button(guildId, `admin:stock:clear:${product.id}:${selected.id}`, "Limpar disponíveis", "stock_clear", ButtonStyle.Danger),
        this.button(guildId, `admin:product:field:${product.id}:${selected.id}`, "Voltar", "back")
      )
    ] };
  }

  storeCatalog(guildId: string, page = 0) {
    const all = this.products.list(true, guildId); const slice = all.slice(page * 25, page * 25 + 25);
    const embed = this.base(`${this.emojis.text("store", guildId)} ${this.db.brand(guildId).storeTitle}`, this.db.brand(guildId).storeDescription, guildId)
      .addFields({ name: "Produtos disponíveis", value: slice.length ? slice.map((p) => `**${p.name}** — ${formatMoney(p.priceCents)}${p.deliveryType === "STOCK" ? ` • ${this.products.stockCount(p.id)} em estoque` : ""}`).join("\n").slice(0, 1024) : "Nenhum produto disponível." });
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (slice.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId(`store:select:${page}`).setPlaceholder("Escolha um produto").addOptions(slice.map((p) => new StringSelectMenuOptionBuilder().setLabel(truncate(p.name, 100)).setDescription(truncate(`${formatMoney(this.products.getField(p.id).priceCents)} • ${this.products.activeFields(p).length} opção(ões)`, 100)).setValue(p.id).setEmoji(this.emojis.component(p.emojiSemantic, guildId))))));
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, "store:cart", "Meu carrinho", "cart", ButtonStyle.Primary),
      this.button(guildId, "store:orders", "Meus pedidos", "invoice"),
      this.button(guildId, `store:page:${Math.max(0, page - 1)}`, "Anterior", "back", ButtonStyle.Secondary, page === 0),
      this.button(guildId, `store:page:${page + 1}`, "Próxima", "catalog", ButtonStyle.Secondary, (page + 1) * 25 >= all.length)
    ));
    return { embeds: [embed], components };
  }

  publicProduct(guildId: string, product: Product) {
    const fields = this.products.activeFields(product);
    const selectMode = product.purchaseMode === "SELECT";
    const single = !selectMode ? fields[0] : undefined;
    const totalStock = fields.reduce((sum, field) => sum + this.products.stockCount(product.id, "AVAILABLE", field.id), 0);
    const sales = this.productSales(product.id, guildId);
    // R18.9.43: produtos de entrega manual também respeitam o estoque
    // configurado. Se não houver nenhuma unidade disponível, o botão/menu
    // público fica indisponível; ao repor estoque, a publicação volta ao normal.
    const stockControlled = product.deliveryType === "STOCK" || product.deliveryType === "MANUAL";
    const unavailable = !product.active || fields.length === 0 || (stockControlled && totalStock === 0);
    const brand = this.db.brand(guildId);
    const embed = new EmbedBuilder()
      .setTitle(truncate(product.name, 256))
      .setDescription(product.description.trim() ? smallText(product.description, 4000) : " ");
    if (brand.showAccentColors) embed.setColor(colorNumber(product.color));

    if (single) {
      const price = single.compareAtCents > single.priceCents
        ? `~~${formatMoney(single.compareAtCents)}~~  **${formatMoney(single.priceCents)}**`
        : `**${formatMoney(single.priceCents)}**`;
      const stock = product.deliveryType === "STOCK" ? this.products.stockCount(product.id, "AVAILABLE", single.id) : 0;
      const meta = [`1 opção`];
      if (stockControlled) meta.push(`Estoque: ${this.products.stockCount(product.id, "AVAILABLE", single.id)}`);
      const salesText = `${sales} venda${sales === 1 ? "" : "s"} realizada${sales === 1 ? "" : "s"}`;
      embed.addFields({ name: "\u200B", value: `${price}\n-# ${meta.join(" • ")}\n-# ${salesText}`, inline: false });
      if (single.name && single.name !== "Opção principal") embed.addFields({ name: "Opção", value: single.name, inline: true });
      const genericDeliveryDescription = /^(entrega\s+(manual|autom[aá]tica)|entrega\s+automatica)$/i.test(single.description.trim());
      if (single.description && !genericDeliveryDescription) embed.addFields({ name: "Informações", value: smallText(single.description, 1000), inline: false });
    } else if (selectMode && fields.length > 0) {
      const prices = fields.map((field) => field.priceCents);
      const from = Math.min(...prices); const to = Math.max(...prices);
      const price = from === to ? `**${formatMoney(from)}**` : `**${formatMoney(from)} – ${formatMoney(to)}**`;
      const meta = [`${fields.length} opções`];
      if (stockControlled) meta.push(`Estoque: ${totalStock}`);
      const salesText = `${sales} venda${sales === 1 ? "" : "s"} realizada${sales === 1 ? "" : "s"}`;
      embed.addFields({ name: "\u200B", value: `${price}\n-# ${meta.join(" • ")}\n-# ${salesText}`, inline: false });
    }

    // Entrega manual não recebe rótulo. No automático exibimos somente a
    // sequência verde personalizada configurada pela ZENYX.
    if (product.deliveryType === "STOCK") {
      const deliveryVisual = this.automaticDeliveryEmojiSequence(guildId);
      if (deliveryVisual.sequence) embed.addFields({ name: "\u200B", value: deliveryVisual.sequence, inline: false });
    }

    if (product.imageUrl) embed.setThumbnail(product.imageUrl);
    if (product.bannerUrl) embed.setImage(product.bannerUrl);
    if (brand.footer.trim()) embed.setFooter({ text: truncate(brand.footer, 2048) });

    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (selectMode && fields.length > 0) {
      const select = new StringSelectMenuBuilder()
        .setCustomId(truncate(`product:field-select:${product.id}`, 100))
        .setPlaceholder(truncate(product.selectPlaceholder || "Selecione uma opção para comprar...", 150))
        .setDisabled(unavailable)
        .addOptions(fields.slice(0, 25).map((field) => {
          const fieldStock = stockControlled ? this.products.stockCount(product.id, "AVAILABLE", field.id) : 1;
          const descriptionParts = [formatMoney(field.priceCents)];
          if (field.description && !/^(entrega\s+(manual|autom[aá]tica)|entrega\s+automatica)$/i.test(field.description.trim())) descriptionParts.push(field.description);
          if (stockControlled) descriptionParts.push(fieldStock > 0 ? `estoque ${fieldStock}` : "esgotado");
          return new StringSelectMenuOptionBuilder()
            .setLabel(truncate(field.name || "Opção", 100))
            .setDescription(truncate(descriptionParts.join(" • "), 100))
            .setValue(field.id)
            .setEmoji(this.emojis.component(field.emoji || product.emojiSemantic, guildId));
        }));
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
    } else if (single) {
      const fieldUnavailable = unavailable || (stockControlled && this.products.stockCount(product.id, "AVAILABLE", single.id) === 0);
      components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `product:buy:${product.id}:${single.id}`, product.buttonLabel || "Comprar agora", product.buttonEmoji || "cart", ButtonStyle.Secondary, fieldUnavailable)
      ));
    } else {
      components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `product:none:${product.id}`, "Produto indisponível", "reject", ButtonStyle.Secondary, true)
      ));
    }

    if (product.demonstrationEnabled && /^https?:\/\//i.test(product.demonstrationUrl)) {
      const link = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(product.demonstrationUrl).setLabel(truncate(product.demonstrationLabel || "Demonstração", 80));
      const emoji = this.emojis.component(product.demonstrationEmoji || "information", guildId); if (emoji) link.setEmoji(emoji);
      components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(link));
    }
    return { embeds: [embed], components, attachments: [] };
  }

  publishedProduct(guildId: string, product: Product) {
    const fields = this.products.activeFields(product);
    const selectMode = product.purchaseMode === "SELECT";
    const single = !selectMode ? fields[0] : undefined;
    const publicPayload = this.publicProduct(guildId, product);
    const brand = this.db.brand(guildId);
    const container = new ContainerBuilder();
    if (brand.showAccentColors) container.setAccentColor(colorNumber(product.color));
    const totalStock = fields.reduce((sum, field) => sum + this.products.stockCount(product.id, "AVAILABLE", field.id), 0);
    const sales = this.productSales(product.id, guildId);
    const stockControlled = product.deliveryType === "STOCK" || product.deliveryType === "MANUAL";

    const compactFooter = brand.footer.trim() && !/^Automa[cç][aã]o completa para Discord$/i.test(brand.footer.trim()) ? brand.footer.trim() : "";
    if (/^https?:\/\//i.test(product.bannerUrl)) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(product.bannerUrl).setDescription(truncate(`${product.name} • vitrine`, 1000))
      ));
      if (compactFooter) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(compactFooter, 500)}`));
    }

    // Referência R18.9.39: a faixa de entrega automática fica no topo, logo
    // abaixo do banner e antes do título. Entrega manual continua sem rótulo.
    if (product.deliveryType === "STOCK") {
      const deliveryVisual = this.automaticDeliveryEmojiSequence(guildId);
      if (deliveryVisual.sequence) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(deliveryVisual.sequence));
    }

    // O título fica em negrito simples; toda descrição informada pelo dono usa
    // subtexto (-#), seguindo o layout de referência enviado pelo usuário.
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`**${escapeMarkdown(truncate(product.name, 180))}**`));
    if (product.description.trim()) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(smallText(product.description, 3000)));

    if (product.purchasePlacement === "AFTER_DESCRIPTION") {
      for (const row of publicPayload.components) container.addActionRowComponents(row);
    }

    // Linha de separação entre apresentação e preço/opções.
    container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));

    const information: string[] = [];
    if (single) {
      if (single.name && single.name !== "Opção principal") information.push(`**${escapeMarkdown(single.name)}**`);
      if (single.description && !/^(entrega\s+(manual|autom[aá]tica)|entrega\s+automatica)$/i.test(single.description.trim())) information.push(smallText(single.description, 900));
      const price = single.compareAtCents > single.priceCents
        ? `~~${formatMoney(single.compareAtCents)}~~  **${formatMoney(single.priceCents)}**`
        : `**${formatMoney(single.priceCents)}**`;
      information.push(price);
      const meta = [`1 opção`];
      if (product.deliveryType === "STOCK") meta.push(`Estoque: ${this.products.stockCount(product.id, "AVAILABLE", single.id)}`);
      information.push(`-# ${meta.join(" • ")}`);
      information.push(`-# ${sales} venda${sales === 1 ? "" : "s"} realizada${sales === 1 ? "" : "s"}`);
    } else if (selectMode && fields.length > 0) {
      const prices = fields.map((field) => field.priceCents); const from = Math.min(...prices); const to = Math.max(...prices);
      information.push(`**${from === to ? formatMoney(from) : `${formatMoney(from)} – ${formatMoney(to)}`}**`);
      const meta = [`${fields.length} opções`];
      if (stockControlled) meta.push(`Estoque: ${totalStock}`);
      information.push(`-# ${meta.join(" • ")}`);
      information.push(`-# ${sales} venda${sales === 1 ? "" : "s"} realizada${sales === 1 ? "" : "s"}`);
    } else {
      information.push("**Produto indisponível no momento.**");
    }
    if (information.length) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(truncate(information.join("\n"), 3800)));
    if (selectMode && fields.length > 1) container.addTextDisplayComponents(new TextDisplayBuilder().setContent('-# Clique no botão **"Ver opções"** para ver as variações disponíveis.'));

    if (product.purchasePlacement !== "AFTER_DESCRIPTION") {
      for (const row of publicPayload.components) container.addActionRowComponents(row);
    }

    container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    if (!product.bannerUrl && compactFooter) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(compactFooter, 500)}`));

    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `produto publicado ${product.id}`);
  }

  publishedProductEdit(guildId: string, product: Product) {
    // Em Components V2, não envie content/embeds nem mesmo vazios.
    return { ...this.publishedProduct(guildId, product), attachments: [] };
  }

  cart(guildId: string, userId: string, userName = "Cliente", avatarUrl = "") {
    const session = this.products.getCartSession(guildId, userId);
    const items = session?.items ?? [];
    const validItems = items.flatMap((item) => {
      const product = this.db.state.products[item.productId];
      const field = product?.fields.find((entry) => entry.id === item.fieldId);
      return product && field && product.guildId === guildId ? [{ item, product, field }] : [];
    });
    const fallbackSubtotal = validItems.reduce((sum, entry) => sum + entry.field.priceCents * entry.item.quantity, 0);
    let totals = { subtotalCents: fallbackSubtotal, discountCents: 0, totalCents: fallbackSubtotal };
    let couponWarning = "";
    try { totals = this.products.cartTotals(guildId, userId); } catch (error) { couponWarning = error instanceof Error ? error.message : "O cupom aplicado não pôde ser validado."; }

    const itemLines = validItems.map(({ item, product, field }) => {
      const option = field.name && field.name !== "Opção principal" ? ` • ${field.name}` : "";
      return `**${item.quantity}× ${product.name}**${option}\n-# ${formatMoney(field.priceCents * item.quantity)}`;
    }).join("\n\n");
    const totalItems = validItems.reduce((sum, entry) => sum + entry.item.quantity, 0);
    const summary = [
      `Subtotal: **${formatMoney(totals.subtotalCents)}**`,
      ...(totals.discountCents > 0 ? [`Desconto: **− ${formatMoney(totals.discountCents)}**`] : []),
      `Total a pagar: **${formatMoney(totals.totalCents)}**`,
      `-# ${totalItems} ${totalItems === 1 ? "item" : "itens"}${session?.couponCode ? ` • Cupom ${session.couponCode}` : ""}`
    ].join("\n");

    const embed = new EmbedBuilder()
      .setTitle("Checkout privado")
      .setDescription(validItems.length
        ? `**${truncate(userName || "Cliente", 80)}**, confira sua compra antes de continuar. Edite quantidades, aplique cupom ou siga para o pagamento.`
        : "Seu carrinho está vazio.")
      .addFields(
        ...(validItems.length ? [{ name: "Produtos", value: truncate(itemLines, 2600), inline: false }] : []),
        { name: "Valores", value: summary, inline: false },
        ...(validItems.length ? [{ name: "Próxima etapa", value: "Escolha **Continuar para pagamento** quando estiver tudo certo.", inline: false }] : []),
        ...(couponWarning ? [{ name: "Aviso", value: truncate(couponWarning, 1024), inline: false }] : [])
      )
      .setFooter({ text: truncate(`${this.db.brand(guildId).name || "Loja"} • compra privada`, 2048) });
    if (this.db.brand(guildId).showAccentColors) embed.setColor(colorNumber(this.db.brand(guildId).color));
    if (avatarUrl) embed.setThumbnail(avatarUrl);

    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (validItems.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder().setCustomId("cart:item-manage").setPlaceholder("Editar itens do carrinho").addOptions(validItems.slice(0, 25).map(({ item, product, field }) => new StringSelectMenuOptionBuilder().setLabel(truncate(`${product.name} • ${field.name}`, 100)).setDescription(truncate(`Qtd. ${item.quantity} • ${formatMoney(field.priceCents * item.quantity)}`, 100)).setValue(`${product.id}|${field.id}`).setEmoji(this.emojis.component(field.emoji || "cart", guildId))))
    ));
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, "cart:payment-methods", "Continuar para pagamento", "payment", ButtonStyle.Success, !validItems.length),
      this.button(guildId, "cart:coupon-apply", "Cupom", "coupon", ButtonStyle.Primary, !validItems.length),
      this.button(guildId, "cart:return", "Voltar", "back", ButtonStyle.Secondary),
      this.button(guildId, "cart:cancel", "Cancelar", "trash", ButtonStyle.Danger)
    ));
    const feedbackChannelId = this.db.guild(guildId).feedbackChannelId;
    if (/^\d{15,22}$/.test(feedbackChannelId)) {
      components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${guildId}/${feedbackChannelId}`).setLabel("Canal de feedbacks")
      ));
    }
    return { embeds: [embed], components };
  }

  cartItemManage(guildId: string, userId: string, product: Product, field: ProductField) {
    const item = this.products.cart(userId, guildId).find((entry) => entry.productId === product.id && entry.fieldId === field.id);
    return { embeds: [this.base(`${this.emojis.text(field.emoji || "cart", guildId)} ${product.name} • ${field.name}`, `Quantidade atual: **${item?.quantity ?? 1}**
Disponível: **${this.products.quantityLimit(product, field)}**`, guildId)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `cart:qty-dec:${product.id}:${field.id}`, "-1", "minus", ButtonStyle.Secondary, (item?.quantity ?? 1) <= 1),
      this.button(guildId, `cart:qty-edit:${product.id}:${field.id}`, "Definir quantidade", "edit", ButtonStyle.Primary),
      this.button(guildId, `cart:qty-inc:${product.id}:${field.id}`, "+1", "plus", ButtonStyle.Success, (item?.quantity ?? 1) >= this.products.quantityLimit(product, field)),
      this.button(guildId, `cart:remove:${product.id}:${field.id}`, "Remover", "trash", ButtonStyle.Danger),
      this.button(guildId, "cart:review", "Voltar", "back")
    )] };
  }

  paymentMethods(guildId: string, methods: PaymentProviderName[]) {
    const imapBank = bankProfile(this.db.payments(guildId).imapPix.bank);
    const labels: Record<PaymentProviderName, [string, string]> = {
      MERCADO_PAGO: ["Pix • Mercado Pago", "mercado_pago"],
      EFI_BANK: ["Pix • Efí Bank", "efi_bank"],
      STRIPE: ["Pix • Stripe", "payment"],
      MISTIC_PAY: ["Pix • MisticPay", "pix"],
      PURIN_CASH: ["Pix • Purin Cash", "payment"],
      EVO_PAY: ["Pix automático", "pix"],
      MAGNUS_PAY: ["Pix • MagnusPay", "payment"],
      ZNY_PAY: ["Znypay", "wallet"],
      IMAP_PIX: [`Pix • ${imapBank.label}`, imapBank.emojiSemantic],
      MANUAL_PIX: ["Pix manual", "pix"]
    };
    const buttons = methods.map((method) => this.button(guildId, `cart:pay:${method}`, labels[method][0], labels[method][1], ButtonStyle.Primary));
    const rows = [] as Array<ActionRowBuilder<ButtonBuilder>>;
    for (let index = 0; index < buttons.length; index += 5) rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...buttons.slice(index, index + 5)));
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, "cart:review", "Voltar", "back"), this.button(guildId, "cart:cancel", "Cancelar", "trash", ButtonStyle.Danger)));
    return { embeds: [this.base(`${this.emojis.text("payment", guildId)} Forma de pagamento`, "Somente métodos ativos e configurados são exibidos. Selecione como deseja pagar.", guildId)], components: rows };
  }

  paymentPending(guildId: string, order: Order) {
    const manual = order.provider === "MANUAL_PIX";
    const approved = ["PAID", "AWAITING_DELIVERY", "DELIVERED"].includes(order.status);
    const ended = ["CANCELED", "EXPIRED", "REFUNDED"].includes(order.status);
    const paymentLabel = order.provider === "IMAP_PIX" && order.imapBank
      ? `IMAP • ${bankProfile(order.imapBank).label}`
      : order.provider === "EVO_PAY"
        ? "PIX automático"
        : order.provider === "MAGNUS_PAY"
          ? "MagnusPay"
        : order.provider === "ZNY_PAY"
          ? "Znypay"
          : order.provider === "MANUAL_PIX"
          ? "PIX manual"
          : order.provider.replaceAll("_", " ");
    const statusText = order.status === "DELIVERED"
      ? "**Compra concluída.** O pagamento e a entrega já foram confirmados."
      : order.status === "AWAITING_DELIVERY"
        ? "**Pagamento confirmado.** Agora a equipe fará a entrega do produto."
        : ended
          ? (order.status === "EXPIRED" ? "**Cobrança expirada.** Gere uma nova compra para continuar." : "**Compra encerrada.** Nenhuma entrega será realizada.")
          : order.provider === "IMAP_PIX"
            ? `Faça o PIX e aguarde a verificação pelo aviso de **${bankProfile(order.imapBank || this.db.payments(guildId).imapPix.bank).label}**.`
            : manual
              ? "Faça o PIX e use **Já paguei**. A confirmação final continua restrita à equipe."
              : "Faça o PIX. A confirmação será atualizada automaticamente assim que o provedor aprovar.";
    const itemLines = order.items.map((item) => `**${item.quantity}× ${item.productName}**${item.fieldName && item.fieldName !== "Opção principal" ? ` • ${item.fieldName}` : ""}`).join("\n");
    const embed = new EmbedBuilder()
      .setTitle(order.status === "DELIVERED" ? "Compra concluída" : order.status === "AWAITING_DELIVERY" ? "Pagamento confirmado" : "Checkout • pagamento")
      .setDescription(`${statusText}\n\n${truncate(itemLines, 1200)}\n\n### ${formatMoney(order.totalCents)}`)
      .addFields(
        { name: "Pagamento", value: paymentLabel, inline: true },
        { name: "Pedido", value: `\`${order.id}\``, inline: true },
        { name: "Etapa", value: order.status === "PENDING" ? "Aguardando pagamento" : order.status === "AWAITING_DELIVERY" ? "Aguardando entrega" : order.status === "DELIVERED" ? "Concluído" : order.status.replaceAll("_", " "), inline: true }
      )
      .setFooter({ text: truncate(`${this.db.brand(guildId).name || "Loja"} • checkout privado`, 2048) });
    if (this.db.brand(guildId).showAccentColors) {
      embed.setColor(order.status === "DELIVERED" ? 0x22c55e : ended ? 0xef4444 : order.status === "AWAITING_DELIVERY" ? 0xf59e0b : 0x3155ff);
    }
    if (order.status === "PENDING" && order.pixCode) embed.addFields({ name: "PIX copia e cola", value: `\`\`\`\n${truncate(order.pixCode, 900)}\n\`\`\`` });
    if (order.qrCodeDataUrl) embed.setImage("attachment://pix.png");

    const buttons: ButtonBuilder[] = [];
    if (order.status === "PENDING") {
      buttons.push(
        this.button(guildId, `payment:key:${order.id}`, "Copiar PIX", "copy", ButtonStyle.Primary, !order.pixCode),
        this.button(guildId, `payment:code:${order.id}`, "Copia e cola", "pix", ButtonStyle.Secondary, !order.pixCode)
      );
      if (order.provider === "IMAP_PIX") buttons.push(this.button(guildId, `payment:check:${order.id}`, "Verificar pagamento", "refresh", ButtonStyle.Success));
      if (manual) {
        buttons.push(this.button(guildId, `payment:paid-notify:${order.id}`, "Já paguei", "success", ButtonStyle.Secondary));
        buttons.push(this.button(guildId, `payment:staff:${order.id}`, "Ações da equipe", "shield", ButtonStyle.Secondary));
      }
      buttons.push(this.button(guildId, `payment:cancel:${order.id}`, "Cancelar compra", "trash", ButtonStyle.Danger));
    }
    if (order.status === "AWAITING_DELIVERY") buttons.push(this.button(guildId, `payment:staff:${order.id}`, "Ações da equipe", "shield", ButtonStyle.Secondary));
    if (approved || ended) buttons.push(this.button(guildId, `payment:close:${order.id}`, "Fechar compra", "trash", ButtonStyle.Secondary));
    const rows: ActionRowBuilder<ButtonBuilder>[] = [];
    for (let index = 0; index < buttons.length; index += 5) rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...buttons.slice(index, index + 5)));
    const feedbackChannelId = this.db.guild(guildId).feedbackChannelId;
    if (approved && /^\d{15,22}$/.test(feedbackChannelId) && rows.length < 5) {
      rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${guildId}/${feedbackChannelId}`).setLabel("Enviar feedback")
      ));
    }
    return { embeds: [embed], components: rows };
  }

  termsConfirmation(guildId: string, product: Product, field: ProductField) {
    const embed = this.base(`${this.emojis.text("terms", guildId)} Termos • ${product.name}`, product.termsText || "Ao continuar, você confirma que leu e aceita as condições deste produto.", guildId)
      .addFields(
        { name: "Produto", value: `${product.name} • ${field.name}`, inline: true },
        { name: "Valor", value: formatMoney(field.priceCents), inline: true },
        { name: "Ação", value: "Comprar agora", inline: true }
      );
    return { embeds: [embed], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `product:terms:buy:${product.id}:${field.id}`, "Li e aceito", "approve", ButtonStyle.Success),
      this.button(guildId, `product:cancel:${product.id}`, "Cancelar", "reject", ButtonStyle.Danger)
    )] };
  }

  orderView(guildId: string, order: Order) {
    const expiresUnix = Math.floor(Date.parse(order.expiresAt) / 1000);
    const paymentLabel = order.provider === "IMAP_PIX" && order.imapBank
      ? `IMAP • ${bankProfile(order.imapBank).label}`
      : order.provider === "EVO_PAY"
        ? "PIX automático"
        : order.provider.replaceAll("_", " ");
    const embed = this.base(`${this.emojis.text("invoice", guildId)} Pedido ${order.id}`, `Status: **${order.status}**`, guildId).addFields(
      { name: "Valor", value: formatMoney(order.totalCents), inline: true },
      { name: "Pagamento", value: paymentLabel, inline: true },
      { name: "Tempo restante", value: order.provider === "MANUAL_PIX" ? "Sem limite • aguarda a equipe" : `<t:${expiresUnix}:R>`, inline: true },
      { name: "Identificador da compra", value: `\`${order.id}\``, inline: true },
      { name: "Referência PIX", value: `\`${order.paymentReference || order.id}\``, inline: true },
      { name: "Criação", value: `<t:${Math.floor(Date.parse(order.createdAt) / 1000)}:f>`, inline: true },
      { name: "Itens", value: order.items.map((item) => `${item.quantity}× ${item.productName} • ${item.fieldName}`).join("\n").slice(0, 1024) }
    );
    if (order.provider === "IMAP_PIX" && order.payerFullName) embed.addFields({ name: "Nome informado para verificação", value: truncate(order.payerFullName, 120), inline: false });
    if (order.status === "PENDING" && order.pixCode) embed.addFields({ name: "PIX copia e cola", value: `\`\`\`\n${truncate(order.pixCode, 900)}\n\`\`\`` });
    if (order.qrCodeDataUrl) embed.setImage("attachment://pix.png");
    return embed;
  }

  paymentsHome(guildId: string) {
    const settings = this.db.payments(guildId);
    const status = (enabled: boolean) => enabled ? "🟢 Ativo" : "⚫ Desativado";
    const imapBank = bankProfile(settings.imapPix.bank);
    const description = [
      `Provedor padrão: **${settings.defaultProvider.replaceAll("_", " ")}**`,
      `Expiração: **${settings.orderExpiresMinutes} min** • consulta: **${settings.pollIntervalSeconds}s**`,
      "",
      `**Mercado Pago** — ${status(settings.mercadoPago.enabled)}`,
      `**Efí Bank** — ${status(settings.efiBank.enabled)}`,
      `**Stripe PIX** — ${status(settings.stripe.enabled)}`,
      `**MisticPay** — ${status(settings.misticPay.enabled)}`,
      `**Purin Cash** — ${status(settings.purinCash.enabled)}`,
      `**EvoPay PIX** — ${status(settings.evoPay.enabled)} • validade ${settings.evoPay.expiresIn}s`,
      `**MagnusPay** — ${settings.magnusPay.enabled ? "🟢 Ativo" : "⚫ Desativado"}`,
      `**Znypay** — ${status(settings.znyPay.enabled)} • mínimo ${formatMoney(settings.znyPay.minOrderCents)} • taxa ${formatMoney(settings.znyPay.purchaseFeeCents)}`,
      `**IMAP PIX** — ${status(settings.imapPix.enabled)} • ${imapBank.label}`,
      `**PIX manual** — ${settings.manualPixEnabled !== false ? "🟢 Ativado" : "🔴 Desativado"} • ${settings.manualPixKey.trim() ? "chave configurada" : "sem chave"}`
    ].join("\n");
    return {
      embeds: [this.base(
        `${this.emojis.text("payment", guildId)} Pagamentos`,
        description,
        guildId
      )],
      // R18.9.39: a tela antiga estourava o limite global de 40 componentes
      // quando era convertida para Components V2. Mantemos todos os métodos,
      // mas removemos os atalhos de toggle duplicados: cada método já possui
      // sua própria tela com ativar/desativar e configuração.
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:mp", "Mercado Pago", "mercadopago"),
          this.button(guildId, "admin:payment:efi", "Efí Bank", "efibank"),
          this.button(guildId, "admin:payment:stripe", "Stripe PIX", "payment"),
          this.button(guildId, "admin:payment:mistic", "MisticPay", "pix"),
          this.button(guildId, "admin:payment:purin", "Purin Cash", "payment")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:evopay", "EvoPay PIX", "pix", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:znypay", "Znypay", "wallet", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:imap", "IMAP PIX", imapBank.emojiSemantic, ButtonStyle.Primary),
          this.button(guildId, "admin:payment:manual", "Configurar PIX manual", "manual"),
          this.button(guildId, "admin:payment:manual-toggle", settings.manualPixEnabled !== false ? "Desativar PIX manual" : "Ativar PIX manual", settings.manualPixEnabled !== false ? "reject" : "approve", settings.manualPixEnabled !== false ? ButtonStyle.Danger : ButtonStyle.Success)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:magnus", "MagnusPay", "payment", ButtonStyle.Primary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:provider", "Método padrão", "payment", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:general", "Prazos", "settings"),
          this.button(guildId, "admin:payment:test-api", "Testar gateways", "refresh", ButtonStyle.Success),
          this.button(guildId, "admin:payment:imap-test", "Testar IMAP", "refresh", ButtonStyle.Success),
          this.button(guildId, "admin:home", "Voltar", "back")
        )
      ]
    };
  }

  paymentProviderSettings(guildId: string, provider: "MERCADO_PAGO" | "EFI_BANK" | "STRIPE" | "MISTIC_PAY" | "PURIN_CASH") {
    const all = this.db.payments(guildId);
    const defs = {
      MERCADO_PAGO: { label: "Mercado Pago", key: "mp", cfg: all.mercadoPago, ready: Boolean(all.mercadoPago.pixKey.trim() && this.db.getSecret("mp_access_token", guildId)) },
      EFI_BANK: { label: "Efí Bank", key: "efi", cfg: all.efiBank, ready: Boolean(all.efiBank.pixKey.trim() && this.db.getSecret("efi_client_id", guildId) && this.db.getSecret("efi_client_secret", guildId) && this.db.getSecret("efi_certificate_base64", guildId)) },
      STRIPE: { label: "Stripe PIX", key: "stripe", cfg: all.stripe, ready: Boolean(this.db.getSecret("stripe_secret_key", guildId)) },
      MISTIC_PAY: { label: "MisticPay", key: "mistic", cfg: all.misticPay, ready: Boolean(this.db.getSecret("mistic_client_id", guildId) && this.db.getSecret("mistic_client_secret", guildId)) },
      PURIN_CASH: { label: "Purin Cash", key: "purin", cfg: all.purinCash, ready: Boolean(this.db.getSecret("purin_api_key", guildId)) }
    } as const;
    const def = defs[provider];
    const enabled = Boolean(def.cfg.enabled);
    const detail = provider === "EFI_BANK"
      ? `Certificado: **${this.db.getSecret("efi_certificate_base64", guildId) ? "configurado" : "pendente"}** • Ambiente: **${all.efiBank.sandbox ? "Sandbox" : "Produção"}**`
      : "As credenciais privadas ficam no cofre do bot e não são exibidas aqui.";
    const embed = this.base(`${this.emojis.text("payment", guildId)} ${def.label}`, "Configure, confira os requisitos e ative o provedor nesta mesma tela.", guildId).addFields(
      { name: "Status", value: enabled ? "🟢 Ativo" : "⚫ Desativado", inline: true },
      { name: "Configuração", value: def.ready ? "✅ Pronta para ativar" : "⚠️ Incompleta", inline: true },
      { name: "Detalhes", value: detail, inline: false }
    );
    const rows: ActionRowBuilder<ButtonBuilder>[] = [new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `admin:payment:${def.key}-configure`, "Configurar credenciais", "settings", ButtonStyle.Primary),
      this.button(guildId, `admin:payment:${def.key}-toggle`, enabled ? "Desativar" : "Ativar", enabled ? "off" : "on", enabled ? ButtonStyle.Danger : ButtonStyle.Success, !enabled && !def.ready)
    )];
    if (provider === "EFI_BANK") rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, "admin:payment:efi-cert", "Enviar certificado P12/PFX", "upload", ButtonStyle.Primary),
      this.button(guildId, "admin:payment:efi-environment", all.efiBank.sandbox ? "Usar Produção" : "Usar Sandbox", "refresh"),
      this.button(guildId, "admin:payment:efi-certpass", "Senha do certificado", "settings")
    ));
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, "admin:payments", "Voltar", "back")));
    return { embeds: [embed], components: rows };
  }

  magnusPaySettingsHome(guildId: string) {
    const settings = this.db.payments(guildId).magnusPay;
    const tokenConfigured = Boolean(this.db.getSecret("magnus_token", guildId));
    const managerAllowed = (() => {
      try {
        const runtime = JSON.parse(readFileSync(resolve(process.cwd(), "config/runtime.json"), "utf8")) as { magnusManagerEnabled?: unknown };
        return runtime.magnusManagerEnabled !== false;
      } catch { return true; }
    })();
    const complete = Boolean(settings.baseUrl && settings.createPath && settings.statusPath && tokenConfigured);
    return {
      embeds: [this.base(
        `${this.emojis.text("payment", guildId)} MagnusPay`,
        managerAllowed
          ? "PIX automático pela MagnusPay. Configure a API da sua conta e teste antes de ativar. O Manager pode desligar globalmente este método durante indisponibilidades do gateway."
          : "MagnusPay está temporariamente desativada pelo ZENYX Manager. Suas configurações continuam salvas para quando o gateway for liberado novamente.",
        guildId
      ).addFields(
        { name: "Disponibilidade global", value: managerAllowed ? "🟢 Liberada" : "🔴 Pausada pelo Manager", inline: true },
        { name: "Status da loja", value: settings.enabled ? "🟢 Ativada" : "⚫ Desativada", inline: true },
        { name: "Configuração", value: complete ? "✅ Completa" : "⚠️ Incompleta", inline: true },
        { name: "API", value: settings.baseUrl ? `\`${settings.baseUrl.slice(0, 180)}\`` : "Não configurada", inline: false },
        { name: "Rotas", value: `Criar: \`${settings.createPath || "—"}\`\nConsultar: \`${settings.statusPath || "—"}\``, inline: false }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:magnus-configure", "Configurar API", "settings", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:magnus-toggle", settings.enabled ? "Desativar" : "Ativar", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success, !managerAllowed || (!settings.enabled && !complete)),
          this.button(guildId, "admin:payment:magnus-test", "Testar conexão", "refresh", ButtonStyle.Secondary, !complete)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, "admin:payments", "Voltar", "back"))
      ]
    };
  }

  evoPaySettingsHome(guildId: string) {
    const settings = this.db.payments(guildId).evoPay;
    const tokenConfigured = Boolean(this.db.getSecret("evopay_token", guildId));
    const ready = settings.enabled && tokenConfigured;
    return {
      embeds: [this.base(
        `${this.emojis.text("pix", guildId)} EvoPay PIX`,
        "Cobrança PIX automática com confirmação por API. A credencial é armazenada no cofre privado e nunca aparece em embeds, logs ou mensagens.",
        guildId
      ).addFields(
        { name: "Status", value: settings.enabled ? "Ativada" : "Desativada", inline: true },
        { name: "Credencial", value: tokenConfigured ? "Configurada" : "Não configurada", inline: true },
        { name: "Validade da cobrança", value: `${settings.expiresIn} segundos`, inline: true },
        { name: "Fluxo", value: "Criar PIX → acompanhar status → confirmar uma única vez → entregar automaticamente/aguardar equipe." }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:evopay-token", "Configurar token", "settings", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:evopay-toggle", settings.enabled ? "Desativar" : "Ativar", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
          this.button(guildId, "admin:payment:evopay-test", "Testar conexão", "refresh", ButtonStyle.Secondary, !tokenConfigured),
          this.button(guildId, "admin:payment:evopay-expiry", "Tempo do PIX", "clock", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, "admin:payments", "Voltar", "back"))
      ]
    };
  }

  znyPaySettingsHome(guildId: string) {
    const settings = this.db.payments(guildId).znyPay;
    return {
      embeds: [this.base(
        `${this.emojis.text("wallet", guildId)} Znypay`,
        "Método próprio da ZENYX. O QR Code e a confirmação são processados pela EvoPay central do Manager; o valor líquido entra na Zwallet da loja.",
        guildId
      ).addFields(
        { name: "Status", value: settings.enabled ? "Ativado" : "Desativado", inline: true },
        { name: "Compra mínima", value: formatMoney(settings.minOrderCents), inline: true },
        { name: "Taxa por venda", value: formatMoney(settings.purchaseFeeCents), inline: true },
        { name: "Saque mínimo", value: formatMoney(settings.minWithdrawalCents), inline: true },
        { name: "Taxa de saque", value: formatMoney(settings.withdrawalFeeCents), inline: true },
        { name: "Gateway", value: "EvoPay central • credencial administrada pelo ZENYX Manager", inline: false }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:znypay-toggle", settings.enabled ? "Desativar Znypay" : "Ativar Znypay", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
          this.button(guildId, "admin:wallet", "Abrir Zwallet", "wallet", ButtonStyle.Primary),
          this.button(guildId, "admin:payments", "Voltar", "back")
        )
      ]
    };
  }

  walletHome(guildId: string) {
    const account = this.db.wallet(guildId, false);
    const settings = this.db.payments(guildId).znyPay;
    const recent = account.transactions.slice(0, 8);
    const history = recent.length
      ? recent.map((tx) => {
          const label = tx.type === "SALE_CREDIT" ? "Venda" : tx.type === "WITHDRAWAL" ? "Saque" : "Ajuste";
          const sign = tx.type === "WITHDRAWAL" ? "-" : "+";
          return `-# ${label} • ${sign}${formatMoney(Math.abs(tx.netCents))}${tx.orderId ? ` • ${tx.orderId}` : ""} • <t:${Math.floor(Date.parse(tx.createdAt) / 1000)}:R>`;
        }).join("\n")
      : "-# Nenhuma movimentação ainda.";
    const pix = account.pixKey ? `${account.pixKey.slice(0, 4)}••••${account.pixKey.slice(-4)}` : "Não cadastrada";
    return {
      embeds: [this.base(
        `${this.emojis.text("wallet", guildId)} Zwallet`,
        `Carteira da loja para recebimentos feitos via **Znypay**.\n\n### Saldo disponível\n**${formatMoney(account.balanceCents)}**`,
        guildId
      ).addFields(
        { name: "Chave PIX para saque", value: pix, inline: true },
        { name: "Saque mínimo", value: formatMoney(settings.minWithdrawalCents), inline: true },
        { name: "Taxa de saque", value: formatMoney(settings.withdrawalFeeCents), inline: true },
        { name: "Histórico recente", value: history, inline: false }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:wallet:pix", account.pixKey ? "Alterar chave PIX" : "Cadastrar chave PIX", "pix", ButtonStyle.Primary),
          this.button(guildId, "admin:wallet:withdraw", "Sacar", "wallet", ButtonStyle.Success, account.balanceCents < settings.minWithdrawalCents || !account.pixKey),
          this.button(guildId, "admin:wallet:refresh", "Atualizar", "refresh"),
          this.button(guildId, "admin:payments", "Pagamentos", "payment"),
          this.button(guildId, "admin:home", "Voltar", "back")
        )
      ]
    };
  }

  imapSettingsHome(guildId: string) {
    const settings = this.db.payments(guildId).imapPix;
    const bank = bankProfile(settings.bank);
    const providerLabel = settings.emailProvider === "CUSTOM"
      ? "Servidor personalizado"
      : IMAP_EMAIL_PRESETS[settings.emailProvider as Exclude<ImapEmailProvider, "CUSTOM">]?.label ?? settings.emailProvider;
    const passwordConfigured = Boolean(this.db.getSecret("imap_password", guildId));
    const complete = Boolean(settings.username && settings.host && settings.pixKey && passwordConfigured);
    const bankSelect = new StringSelectMenuBuilder()
      .setCustomId("admin:payment:imap-bank-select")
      .setPlaceholder("Escolha o banco que envia os avisos de Pix")
      .addOptions(
        new StringSelectMenuOptionBuilder().setLabel("Banco Inter").setDescription("Buscar avisos recentes do Banco Inter").setValue("INTER").setEmoji(this.emojis.component("inter", guildId)).setDefault(settings.bank === "INTER"),
        new StringSelectMenuOptionBuilder().setLabel("PicPay").setDescription("Buscar avisos recentes do PicPay").setValue("PICPAY").setEmoji(this.emojis.component("picpay", guildId)).setDefault(settings.bank === "PICPAY"),
        new StringSelectMenuOptionBuilder().setLabel("Nubank").setDescription("Buscar avisos recentes do Nubank").setValue("NUBANK").setEmoji(this.emojis.component("nubank", guildId)).setDefault(settings.bank === "NUBANK")
      );
    const emailProviderSelect = new StringSelectMenuBuilder()
      .setCustomId("admin:payment:imap-email-provider-select")
      .setPlaceholder("Escolha onde sua caixa de e-mail está hospedada")
      .addOptions(
        new StringSelectMenuOptionBuilder().setLabel("Gmail").setDescription("imap.gmail.com • porta 993").setValue("GMAIL").setDefault(settings.emailProvider === "GMAIL"),
        new StringSelectMenuOptionBuilder().setLabel("Outlook / Hotmail").setDescription("outlook.office365.com • porta 993").setValue("OUTLOOK").setDefault(settings.emailProvider === "OUTLOOK"),
        new StringSelectMenuOptionBuilder().setLabel("Yahoo Mail").setDescription("imap.mail.yahoo.com • porta 993").setValue("YAHOO").setDefault(settings.emailProvider === "YAHOO"),
        new StringSelectMenuOptionBuilder().setLabel("Outro servidor").setDescription("Definir host e porta manualmente").setValue("CUSTOM").setDefault(settings.emailProvider === "CUSTOM")
      );
    return {
      embeds: [this.base(
        `${this.emojis.text(bank.emojiSemantic, guildId)} IMAP PIX • configuração simples`,
        `O bot procura um e-mail recente de **${bank.label}** e só aprova quando encontrar o **mesmo valor** e o **nome completo do pagador** informado durante a compra.

O e-mail informado na conta IMAP também será usado como chave PIX. O bot gera sozinho o código copia e cola de cada pedido, com valor e referência corretos.`,
        guildId
      ).addFields(
        { name: "Status", value: settings.enabled ? "🟢 Ativo" : "⚫ Desativado", inline: true },
        { name: "Banco monitorado", value: bank.label, inline: true },
        { name: "Caixa de e-mail", value: settings.username ? `${settings.username}
${providerLabel}` : "Ainda não configurada", inline: true },
        { name: "Chave PIX", value: settings.pixKey ? `Configurada • tipo ${settings.pixKeyType}` : "Ainda não configurada", inline: true },
        { name: "Senha de aplicativo", value: passwordConfigured ? "Carregada" : "Não carregada", inline: true },
        { name: "Configuração", value: complete ? "✅ Completa" : "⚠️ Incompleta", inline: true }
      )],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(bankSelect),
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(emailProviderSelect),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:imap-account", "E-mail, senha e chave PIX", "mail2", ButtonStyle.Primary),
          this.button(guildId, "admin:payment:imap-timing", "Tempo de busca", "clock"),
          this.button(guildId, "admin:payment:imap-custom-server", "Servidor personalizado", "settings", ButtonStyle.Secondary, settings.emailProvider !== "CUSTOM")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.button(guildId, "admin:payment:imap-toggle", settings.enabled ? "Desativar IMAP" : "Ativar IMAP", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
          this.button(guildId, "admin:payment:imap-seen-toggle", settings.markSeen ? "Não marcar como lido" : "Marcar como lido", "mail2"),
          this.button(guildId, "admin:payment:imap-test", "Testar conexão", "refresh", ButtonStyle.Success),
          this.button(guildId, "admin:payments", "Voltar", "back")
        )
      ]
    };
  }

  emojisHome(guildId: string) {
    const status = this.emojis.status; const guild = this.db.guild(guildId);
    const description = [
      `Pacote ativo: **${this.emojis.packName()}**`,
      `Arquivos do usuário: **${this.emojis.manifestCount()} emojis**`,
      `Instalados na aplicação: **${status.installed}/${status.total}**`,
      `Funções remapeadas: **${Object.keys(guild.emojiOverrides).length}**`,
      `Instalação automática: **${status.syncing ? `em andamento (${status.completed}/${status.total})` : "pronta"}**`,
      status.lastError ? `\nÚltimo erro: ${truncate(status.lastError, 500)}` : ""
    ].filter(Boolean).join("\n");
    return { embeds: [this.base(`${this.emojis.text("emoji", guildId)} Pacote de emojis do bot`, description, guildId)], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:emoji:sync", "Instalar / corrigir", "refresh", ButtonStyle.Success),
        this.button(guildId, "admin:emoji:mapping:0", "Personalizar funções", "customize", ButtonStyle.Primary),
        this.button(guildId, "admin:emoji:catalog:0", "Ver catálogo", "reaction", ButtonStyle.Primary),
        this.button(guildId, "admin:emoji:remove", "Remover pacote", "trash", ButtonStyle.Danger),
        this.button(guildId, "admin:home", "Voltar", "back")
      )
    ] };
  }

  stockRequestsHome(guildId: string) {
    const settings = this.db.guild(guildId).stockRequest;
    const requests = Object.values(this.db.state.stockRequests).filter((request) => request.guildId === guildId);
    const pending = requests.filter((request) => request.status === "PENDING").length;
    const claimed = requests.filter((request) => request.status === "CLAIMED").length;
    const published = settings.panelChannelId && settings.panelMessageId ? `<#${settings.panelChannelId}>` : "Não publicado";
    const destination = settings.requestChannelId ? `<#${settings.requestChannelId}>` : "Não configurado";
    const container = (() => { const c = new ContainerBuilder(); if (this.db.brand(guildId).showAccentColors) c.setAccentColor(colorNumber(settings.color)); return c; })();
    if (/^https?:\/\//i.test(settings.imageUrl)) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(settings.imageUrl).setDescription("Painel Pedir Stock")));
    }
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${this.emojis.text("stock_request", guildId)} Pedir Stock`),
      new TextDisplayBuilder().setContent(`Configure o painel público e acompanhe as solicitações sem sair desta tela.

**Status:** ${settings.enabled ? "Ativo" : "Desativado"}
**Publicado em:** ${published}
**Pedidos enviados para:** ${destination}
**Pendentes:** ${pending} • **Em atendimento:** ${claimed} • **Total:** ${requests.length}`),
      new TextDisplayBuilder().setContent(`-# Botão público: ${settings.buttonLabel} • confirmação personalizada: ${settings.confirmationMessage ? "sim" : "padrão"}`)
    );
    container.addActionRowComponents(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:stock-request:edit", "Editar mensagem", "edit", ButtonStyle.Primary),
        this.button(guildId, "admin:stock-request:appearance", "Aparência", "customize"),
        this.button(guildId, "admin:stock-request:image-upload", "Imagem", "image"),
        this.button(guildId, "admin:stock-request:confirmation", "Confirmação", "message")
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:stock-request:destination", "Canal dos pedidos", "message"),
        this.button(guildId, "admin:stock-request:roles", "Cargos notificados", "role"),
        this.button(guildId, "admin:stock-request:publish", settings.panelMessageId ? "Republicar / atualizar" : "Publicar painel", "announcement", ButtonStyle.Success),
        this.button(guildId, "admin:stock-request:preview", "Prévia", "search", ButtonStyle.Primary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:stock-request:list", "Ver solicitações", "stock_request_pending", ButtonStyle.Primary),
        this.button(guildId, "admin:stock-request:toggle", settings.enabled ? "Desativar" : "Ativar", settings.enabled ? "off" : "on", settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.button(guildId, "admin:home", "Voltar", "back")
      )
    );
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, "Pedir Stock Components V2");
  }

  publicStockRequestPanel(guildId: string, withBack = false) {
    const settings = this.db.guild(guildId).stockRequest;
    const container = new ContainerBuilder();
    if (this.db.brand(guildId).showAccentColors) container.setAccentColor(colorNumber(settings.color));
    if (/^https?:\/\//i.test(settings.imageUrl)) container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(settings.imageUrl).setDescription(truncate(settings.title, 1000))));
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${this.emojis.text(settings.emojiSemantic, guildId)} ${truncate(settings.title, 180)}`),
      new TextDisplayBuilder().setContent(truncate(settings.description, 3000))
    );
    container.addActionRowComponents(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, "stock-request:open", settings.buttonLabel || "Pedir Stock", settings.emojiSemantic, bstyle(settings.buttonStyle))
    ));
    if (settings.footer?.trim()) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(settings.footer, 1800)}`));
    if (withBack) container.addActionRowComponents(new ActionRowBuilder<ButtonBuilder>().addComponents(this.button(guildId, "admin:stock-requests", "Voltar", "back", ButtonStyle.Secondary)));
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, "painel público Pedir Stock");
  }

  stockRequestQueue(guildId: string) {
    const requests = Object.values(this.db.state.stockRequests)
      .filter((request) => request.guildId === guildId)
      .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    const embed = this.base(`${this.emojis.text("stock_request_pending", guildId)} Solicitações de stock`, requests.length ? "Selecione uma solicitação para visualizar e gerenciar." : "Nenhuma solicitação registrada.", guildId);
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (requests.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder().setCustomId("admin:stock-request:select").setPlaceholder("Selecionar solicitação").addOptions(
          requests.slice(0, 25).map((request) => new StringSelectMenuOptionBuilder()
            .setLabel(`${request.productName} • ${request.username}`.slice(0, 100))
            .setDescription(`${request.status} • quantidade ${request.quantity}`.slice(0, 100))
            .setValue(request.id)
            .setEmoji(this.emojis.component(request.status === "AVAILABLE" ? "stock_request_available" : request.status === "REJECTED" ? "stock_request_reject" : "stock_request_pending", guildId)))
        )
      ));
    }
    components.push(this.back(guildId, "admin:stock-requests"));
    return { embeds: [embed], components };
  }

  stockRequestDetail(guildId: string, request: StockRequest, staff = false) {
    const statusLabels: Record<StockRequest["status"], string> = { PENDING: "Pendente", CLAIMED: "Em atendimento", AVAILABLE: "Disponível", REJECTED: "Recusado" };
    const statusEmoji = request.status === "AVAILABLE" ? "stock_request_available" : request.status === "REJECTED" ? "stock_request_reject" : request.status === "CLAIMED" ? "stock_request_claim" : "stock_request_pending";
    const embed = new EmbedBuilder()
      .setTitle(`${this.emojis.text(statusEmoji, guildId)} Pedido de Stock • ${request.id}`)
      .setDescription(request.details || "Nenhum detalhe adicional informado.")
      .addFields(
        { name: "Cliente", value: `<@${request.userId}> • ${request.username}`, inline: true },
        { name: "Produto", value: request.productName, inline: true },
        { name: "Quantidade", value: String(request.quantity), inline: true },
        { name: "Status", value: statusLabels[request.status], inline: true },
        { name: "Responsável", value: request.claimedBy ? `<@${request.claimedBy}>` : "Não assumido", inline: true },
        { name: "Criado", value: `<t:${Math.floor(Date.parse(request.createdAt) / 1000)}:R>`, inline: true }
      )
      .setFooter({ text: "Controle de stock" })
      .setTimestamp(new Date(request.updatedAt));
    if (this.db.brand(guildId).showAccentColors) {
      embed.setColor(request.status === "AVAILABLE" ? 0x22c55e : request.status === "REJECTED" ? 0xef4444 : request.status === "CLAIMED" ? 0x3b82f6 : 0xf59e0b);
    }
    const buttons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `stock-request:claim:${request.id}`, "Assumir", "stock_request_claim", ButtonStyle.Primary, request.status === "AVAILABLE" || request.status === "REJECTED"),
      this.button(guildId, `stock-request:available:${request.id}`, "Marcar disponível", "stock_request_available", ButtonStyle.Success, request.status === "AVAILABLE"),
      this.button(guildId, `stock-request:reject:${request.id}`, "Recusar", "stock_request_reject", ButtonStyle.Danger, request.status === "REJECTED")
    );
    if (staff) buttons.addComponents(this.button(guildId, "admin:stock-request:list", "Voltar", "back"));
    return { embeds: [embed], components: [buttons] };
  }

  savedEmojisHome(guildId: string, page = 0) {
    const settings = this.db.guild(guildId).emojiLibrary;
    const all = this.emojis.listSaved(undefined, guildId);
    const pageSize = 10;
    const maxPage = Math.max(0, Math.ceil(all.length / pageSize) - 1);
    const safePage = Math.max(0, Math.min(maxPage, Math.trunc(page) || 0));
    const slice = all.slice(safePage * pageSize, safePage * pageSize + pageSize);
    const lines = slice.map((item, index) => `${safePage * pageSize + index + 1}. ${this.emojis.mentionSaved(item)} **${item.name}** — \`${item.id}\` — <@${item.ownerId}>`);
    const embed = this.base(
      `${this.emojis.text("saved_emoji", guildId)} Salvar Emojis`,
      [
        "Envie uma imagem ou GIF e o bot salvará o arquivo diretamente nos emojis da aplicação.",
        "Depois, use o código retornado em descrições, produtos, embeds e mensagens do próprio bot.",
        "",
        `Emojis salvos neste servidor: **${all.length}**`,
        `Membros podem salvar: **${settings.allowMembers ? "sim" : "não"}**`,
        `Limite por membro: **${settings.maxPerUser}**`,
        `Página: **${safePage + 1}/${maxPage + 1}**`,
        "",
        lines.join("\n") || "Nenhum emoji salvo ainda."
      ].join("\n"),
      guildId
    );
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:saved-emoji:add", "Adicionar Emoji/GIF", "saved_emoji", ButtonStyle.Success),
        this.button(guildId, "admin:saved-emoji:settings", "Permissões e limite", "settings"),
        this.button(guildId, "admin:saved-emoji:refresh", "Atualizar lista", "refresh"),
        this.button(guildId, "admin:home", "Voltar", "back")
      )
    ];
    if (slice.length) {
      components.unshift(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder().setCustomId(`admin:saved-emoji:select:${safePage}`).setPlaceholder("Ver ID, código ou remover emoji").addOptions(
          slice.map((item) => new StringSelectMenuOptionBuilder().setLabel(item.name).setDescription(`${item.animated ? "GIF animado" : "Imagem"} • ID ${item.id}`).setValue(item.id).setEmoji({ id: item.id, name: item.name, animated: item.animated }))
        )
      ));
    }
    if (maxPage > 0) components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `admin:saved-emojis:${Math.max(0, safePage - 1)}`, "Anterior", "back", ButtonStyle.Secondary, safePage === 0),
      this.button(guildId, `admin:saved-emojis:${Math.min(maxPage, safePage + 1)}`, "Próxima", "arrow", ButtonStyle.Secondary, safePage === maxPage)
    ));
    return { embeds: [embed], components };
  }

  savedEmojiDetail(guildId: string, item: SavedApplicationEmoji) {
    const mention = this.emojis.mentionSaved(item);
    return {
      embeds: [this.base(`${mention} ${item.name}`, `**Código pronto para copiar:**\n\`\`\`\n${mention}\n\`\`\`\n**ID:** \`${item.id}\`\n**Nome:** \`${item.name}\`\n**Tipo:** ${item.animated ? "GIF animado" : "Imagem estática"}\n**Salvo por:** <@${item.ownerId}>`, guildId)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:saved-emoji:copy:${item.id}`, "Mostrar código", "saved_emoji_copy", ButtonStyle.Primary),
        this.button(guildId, `admin:saved-emoji:remove:${item.id}`, "Remover", "saved_emoji_remove", ButtonStyle.Danger),
        this.button(guildId, "admin:saved-emojis", "Voltar", "back")
      )]
    };
  }

  ticketPanelsHome(guildId: string) {
    const panels = this.tickets.listPanels(guildId);
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:ticket:create", "Criar painel", "ticket_add", ButtonStyle.Success),
        this.button(guildId, "admin:channels", "Categorias e equipe", "settings"),
        this.button(guildId, "admin:home", "Voltar", "back")
      )
    ];
    if (panels.length) components.unshift(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("admin:ticket:select")
        .setPlaceholder("Selecione um painel para configurar")
        .addOptions(panels.slice(0, 25).map((panel) => new StringSelectMenuOptionBuilder()
          .setLabel(truncate(panel.name, 100))
          .setDescription(truncate(`${panel.options.length} opções • ${panel.fields.length} campos • ${panel.mode === "SELECT" ? "menu" : "botões"}`, 100))
          .setValue(panel.id)
          .setEmoji(this.emojis.component(panel.emojiSemantic, guildId))))
    ));
    return {
      embeds: [this.base(
        `${this.emojis.text("ticket", guildId)} Central de tickets`,
        `Configure a mensagem pública, campos informativos, opções de atendimento, cargos, categorias e mensagens de abertura.

Ao abrir um ticket, clientes com compras registradas precisam selecionar uma compra ou informar que o assunto é diferente antes de enviar mensagens.

**Painéis configurados:** ${panels.length}`,
        guildId
      )],
      components
    };
  }

  ticketPanelDetail(guildId: string, panel: TicketPanel) {
    const panelEmoji = panel.emojiSemantic.trim() ? `${this.emojis.text(panel.emojiSemantic, guildId)} ` : "";
    const embed = this.base(`${panelEmoji}${panel.title}`, panel.description, guildId)
      .addFields(
        { name: "Formato", value: panel.mode === "SELECT" ? "Menu de seleção" : "Botões", inline: true },
        { name: "Opções", value: `${panel.options.length}/25`, inline: true },
        { name: "Campos informativos", value: `${panel.fields.length}/25`, inline: true },
        { name: "Publicação", value: panel.channelId ? `<#${panel.channelId}>` : "Ainda não publicado", inline: true },
        { name: "Texto do menu", value: truncate(panel.buttonLabel || "Selecione o atendimento", 1024), inline: true },
        { name: "Emoji principal", value: `\`${panel.emojiSemantic}\``, inline: true }
      );
    if (panel.imageUrl) embed.setImage(panel.imageUrl);
    if (panel.thumbnailUrl) embed.setThumbnail(panel.thumbnailUrl);
    return { embeds: [embed], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:ticket:basic:${panel.id}`, "Mensagem e visual", "edit", ButtonStyle.Primary),
        this.button(guildId, `admin:ticket:fields:${panel.id}`, "Campos do painel", "embed", ButtonStyle.Primary),
        this.button(guildId, `admin:ticket:options:${panel.id}`, "Opções de atendimento", "support", ButtonStyle.Primary),
        this.button(guildId, `admin:ticket:publish:${panel.id}`, "Publicar / atualizar", "announcement", ButtonStyle.Success)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:ticket:mode-toggle:${panel.id}`, panel.mode === "SELECT" ? "Usar botões" : "Usar menu", panel.mode === "SELECT" ? "commands" : "listening_music"),
        this.button(guildId, `admin:ticket:emoji:${panel.id}:0`, "Trocar emoji", "emoji"),
        this.button(guildId, `admin:ticket:emoji-remove:${panel.id}`, "Remover emoji", "trash", ButtonStyle.Secondary, !panel.emojiSemantic.trim()),
        this.button(guildId, `admin:ticket:image-upload:${panel.id}`, "Banner por link", "upload"),
        this.button(guildId, `admin:ticket:thumb-upload:${panel.id}`, "Miniatura por link", "image")
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:ticket:delete-request:${panel.id}`, "Excluir painel", "trash", ButtonStyle.Danger),
        this.button(guildId, "admin:tickets", "Voltar", "back")
      )
    ] };
  }

  ticketPanelFieldsView(guildId: string, panel: TicketPanel) {
    const lines = panel.fields.map((field, index) => `${index + 1}. **${field.name}** — ${field.inline ? "linha compacta" : "linha completa"}`);
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (panel.fields.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`admin:ticket:field-select:${panel.id}`)
        .setPlaceholder("Selecione um campo para editar")
        .addOptions(panel.fields.slice(0, 25).map((field) => new StringSelectMenuOptionBuilder()
          .setLabel(truncate(field.name, 100))
          .setDescription(truncate(`${field.inline ? "Compacto" : "Completo"} • ${field.value}`, 100))
          .setValue(field.id)
          .setEmoji(this.emojis.component("embed", guildId))))
    ));
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.button(guildId, `admin:ticket:field-add:${panel.id}`, "Adicionar campo", "plus", ButtonStyle.Success, panel.fields.length >= 25),
      this.button(guildId, `admin:ticket:${panel.id}`, "Voltar ao painel", "back")
    ));
    return {
      embeds: [this.base(`${this.emojis.text("embed", guildId)} Campos • ${panel.name}`, `${lines.join("\n") || "Nenhum campo configurado."}

Os campos aparecem na mensagem pública do painel e também podem usar **{user}** e **{subject}** na abertura do ticket.`, guildId)],
      components
    };
  }

  ticketPanelFieldDetail(guildId: string, panel: TicketPanel, field: TicketPanelField) {
    return {
      embeds: [this.base(`${this.emojis.text("embed", guildId)} ${field.name}`, field.value, guildId).addFields(
        { name: "Exibição", value: field.inline ? "Compacta / inline" : "Linha completa", inline: true },
        { name: "ID", value: `\`${field.id}\``, inline: true }
      )],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, `admin:ticket:field-edit:${panel.id}:${field.id}`, "Editar", "edit", ButtonStyle.Primary),
        this.button(guildId, `admin:ticket:field-inline:${panel.id}:${field.id}`, field.inline ? "Usar linha completa" : "Usar modo compacto", "embed", ButtonStyle.Secondary),
        this.button(guildId, `admin:ticket:field-delete:${panel.id}:${field.id}`, "Remover", "trash", ButtonStyle.Danger),
        this.button(guildId, `admin:ticket:fields:${panel.id}`, "Voltar", "back")
      )]
    };
  }

  publicTicketPanel(guildId: string, panel: TicketPanel) {
    const titlePrefix = panel.emojiSemantic.trim() ? `${this.emojis.text(panel.emojiSemantic, guildId)} ` : "";
    const container = (() => { const c = new ContainerBuilder(); if (this.db.brand(guildId).showAccentColors) c.setAccentColor(colorNumber(panel.color)); return c; })();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${titlePrefix}${truncate(panel.title || "Central de atendimento", 300)}`)
    );
    if (panel.description.trim()) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(truncate(panel.description, 4000)));
    }
    if (panel.fields.length) {
      container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
      for (const field of panel.fields.slice(0, 25)) {
        container.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`### ${truncate(field.name || "Informação", 300)}\n${truncate(field.value || "-", 3600)}`)
        );
      }
    }
    // A galeria pertence ao Container V2. Assim o banner deixa de ser um anexo
    // visual solto e passa a integrar o mesmo bloco que título, campos e select.
    if (/^https?:\/\//i.test(panel.imageUrl)) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(panel.imageUrl).setDescription(truncate(panel.title, 1000))
        )
      );
    }
    if (panel.footer.trim()) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(panel.footer, 1900)}`));
    }
    const options = panel.options.filter((option) => option.active).sort((a, b) => a.position - b.position).slice(0, 25);
    if (!options.length) {
      return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `painel de ticket ${panel.id}`);
    }

    container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));

    if (panel.mode === "BUTTONS") {
      for (let index = 0; index < options.length; index += 5) {
        container.addActionRowComponents(new ActionRowBuilder<ButtonBuilder>().addComponents(
          options.slice(index, index + 5).map((option) => this.button(guildId, `ticket:open:${panel.id}:${option.id}`, option.name, option.emojiSemantic, bstyle(panel.buttonStyle)))
        ));
      }
      return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `painel de ticket ${panel.id}`);
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId(`ticket:open-select:${panel.id}`)
      .setPlaceholder(truncate(panel.buttonLabel || "Selecione o tipo de atendimento", 150));
    for (const option of options) {
      const menuOption = new StringSelectMenuOptionBuilder()
        .setLabel(truncate(option.name, 100))
        .setDescription(truncate(option.description || "Abrir atendimento", 100))
        .setValue(option.id);
      if (option.emojiSemantic.trim()) menuOption.setEmoji(this.emojis.component(option.emojiSemantic, guildId));
      select.addOptions(menuOption);
    }
    container.addActionRowComponents(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `painel de ticket ${panel.id}`);
  }

  publicTicketPanelEdit(guildId: string, panel: TicketPanel) {
    // A API rejeita campos legados em qualquer edição V2, inclusive arrays vazios.
    return { ...this.publicTicketPanel(guildId, panel), attachments: [] };
  }

  botMessage(guildId: string, template: BotMessageTemplate) {
    const container = (() => { const c = new ContainerBuilder(); if (this.db.brand(guildId).showAccentColors) c.setAccentColor(colorNumber(template.color)); return c; })();
    if (template.content.trim()) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(truncate(template.content, 4000)));
    const heading = [template.title.trim() ? `## ${truncate(template.title, 300)}` : "", truncate(template.description, 3600)].filter(Boolean).join("\n");
    if (heading) {
      if (/^https?:\/\//i.test(template.thumbnailUrl)) {
        container.addSectionComponents(new SectionBuilder()
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(heading))
          .setThumbnailAccessory(new ThumbnailBuilder().setURL(template.thumbnailUrl).setDescription(truncate(template.title || template.name, 1000))));
      } else {
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(heading));
      }
    }
    if (/^https?:\/\//i.test(template.bannerUrl)) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(template.bannerUrl).setDescription(truncate(template.title || template.name, 1000))
      ));
    }
    if (template.footer.trim()) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(template.footer, 1900)}`));
    if (template.links.length) {
      container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
      container.addActionRowComponents(new ActionRowBuilder<ButtonBuilder>().addComponents(template.links.slice(0, 5).map((link) => {
        const button = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(link.url).setLabel(truncate(link.label || "Abrir link", 80));
        if (link.emoji.trim()) button.setEmoji(this.emojis.component(link.emoji, guildId));
        return button;
      })));
    }
    if (!template.content.trim() && !heading && !template.bannerUrl && !template.footer.trim()) {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent("Mensagem sem conteúdo. Edite o modelo antes de publicar."));
    }
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `mensagem personalizada ${template.id}`);
  }

  botMessageEdit(guildId: string, template: BotMessageTemplate) {
    return { ...this.botMessage(guildId, template), attachments: [] };
  }

  channelSettings(guildId: string) {
    const g = this.db.guild(guildId);
    return { embeds: [this.base(`${this.emojis.text("settings", guildId)} Canais, categorias e cargos`, `Vendas: ${g.salesChannelId ? `<#${g.salesChannelId}>` : "não definido"}
Aviso de venda concluída: **${g.salesReceiptEnabled ? "ativado" : "desativado"}** • formato: **${g.salesReceiptMode === "IMAGE" ? "imagem" : "embed"}**
Logs gerais: ${g.logChannelId ? `<#${g.logChannelId}>` : "não definido"}
Logs de tickets: ${g.ticketLogChannelId ? `<#${g.ticketLogChannelId}>` : "não definido"}
Boas-vindas: ${g.welcomeChannelId ? `<#${g.welcomeChannelId}>` : "não definido"}
Feedbacks: ${g.feedbackChannelId ? `<#${g.feedbackChannelId}>` : "não definido"}
Saídas: ${g.goodbyeChannelId ? `<#${g.goodbyeChannelId}>` : "não definido"}
Tickets abertos: ${g.ticketCategoryId ? `<#${g.ticketCategoryId}>` : "não definido"}
Fechados: ${g.closedTicketCategoryId ? `<#${g.closedTicketCategoryId}>` : "não definido"}
Arquivados: ${g.archiveTicketCategoryId ? `<#${g.archiveTicketCategoryId}>` : "não definido"}
Compras privadas: ${g.purchaseCategoryId ? `<#${g.purchaseCategoryId}>` : "não definido"}
Equipe: ${g.staffRoleIds.length ? g.staffRoleIds.map((id) => `<@&${id}>`).join(" ") : "não definido"}
Administradores: ${g.adminRoleIds.length ? g.adminRoleIds.map((id) => `<@&${id}>`).join(" ") : "não definido"}
Cliente: ${g.customerRoleId ? `<@&${g.customerRoleId}>` : "não definido"}
Autorole: ${g.autoRoleId ? `<@&${g.autoRoleId}>` : "não definido"}`, guildId)], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:channel:sales", "Vendas", "store"),
        this.button(guildId, "admin:channel:logs", "Logs gerais", "invoice"),
        this.button(guildId, "admin:channel:ticket-logs", "Logs tickets", "transcript"),
        this.button(guildId, "admin:channel:welcome", "Boas-vindas", "message"),
        this.button(guildId, "admin:channel:goodbye", "Saídas", "minus")
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:channel:feedback", "Feedbacks", "message"),
        this.button(guildId, "admin:category:open", "Tickets abertos", "ticket"),
        this.button(guildId, "admin:category:closed", "Tickets fechados", "ticket_close"),
        this.button(guildId, "admin:category:archive", "Tickets arquivados", "ticket_archive"),
        this.button(guildId, "admin:category:purchases", "Compras privadas", "cart")
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:sales-receipt:toggle", g.salesReceiptEnabled ? "Aviso de venda: ON" : "Aviso de venda: OFF", g.salesReceiptEnabled ? "on" : "off", g.salesReceiptEnabled ? ButtonStyle.Success : ButtonStyle.Secondary),
        this.button(guildId, "admin:sales-receipt:mode", `Formato: ${g.salesReceiptMode === "IMAGE" ? "Imagem" : "Embed"}`, g.salesReceiptMode === "IMAGE" ? "image" : "message", ButtonStyle.Primary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.button(guildId, "admin:role:staff", "Equipe", "support"),
        this.button(guildId, "admin:role:admin", "Administradores", "settings"),
        this.button(guildId, "admin:role:customer", "Cliente", "customer"),
        this.button(guildId, "admin:role:auto", "Autorole", "users"),
        this.button(guildId, "admin:home", "Voltar", "back")
      )
    ] };
  }

  channelPicker(guildId: string, id: string, title: string, category = false) {
    const select = new ChannelSelectMenuBuilder().setCustomId(id).setPlaceholder(title).setChannelTypes(category ? ChannelType.GuildCategory : ChannelType.GuildText).setMinValues(1).setMaxValues(1);
    return { embeds: [this.base(title, "Selecione abaixo. A alteração será salva imediatamente.", guildId)], components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select), this.back(guildId, "admin:channels")] };
  }
  rolePicker(guildId: string, id: string, title: string, maxValues = 1) { return { embeds: [this.base(title, "Selecione o cargo. A alteração será salva imediatamente.", guildId)], components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId(id).setPlaceholder(title).setMinValues(1).setMaxValues(Math.max(1, Math.min(10, maxValues)))), this.back(guildId, "admin:channels")] }; }
}
