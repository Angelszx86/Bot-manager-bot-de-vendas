const fs = require('fs');
const path = require('path');

module.exports = {
  run: (client) => {

    client.setMaxListeners(99);

    const eventosDir = path.join(__dirname, '..', 'Eventos');
    if (!fs.existsSync(eventosDir)) return console.warn('[AVISO] Pasta Eventos não encontrada.');

    fs.readdirSync(eventosDir).forEach(pasta => {
      const pastaPath = path.join(eventosDir, pasta);
      if (!fs.statSync(pastaPath).isDirectory()) return;
      const arquivosEvent = fs.readdirSync(pastaPath).filter(file => file.endsWith('.js'));

      for (const arquivo of arquivosEvent) {
        const evento = require(path.join(__dirname, '..', 'Eventos', pasta, arquivo));

        if (typeof evento.run !== 'function') {
          console.warn(`[WARN] Evento ${arquivo} não exporta a função run.`);
          continue;
        }

        if (evento.once) {
          client.once(evento.name, (...args) => Promise.resolve().then(() => evento.run(...args, client)).catch(error => require('../Lib/interactions').logError(error, arquivo)));
        } else {
          client.on(evento.name, (...args) => Promise.resolve().then(() => evento.run(...args, client)).catch(error => evento.name === 'interactionCreate' ? require('../Lib/interactions').fail(args[0], error) : require('../Lib/interactions').logError(error, arquivo)));
        }
      }
    });
  }
}
