const fs = require("fs");
const path = require("path");

function stripKeyboardEmoji(value) {
  return String(value ?? '')
    .replace(/[\p{Extended_Pictographic}\p{Emoji_Presentation}\uFE0F\u200D\u20E3]+/gu, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function sanitizeCommandMetadata(command) {
  if (typeof command.description === 'string') command.description = stripKeyboardEmoji(command.description) || 'Comando do Manager';
  const visit = options => {
    for (const option of options || []) {
      if (typeof option.description === 'string') option.description = stripKeyboardEmoji(option.description) || 'Opção';
      if (Array.isArray(option.options)) visit(option.options);
    }
  };
  visit(command.options);
  return command;
}

module.exports = (client) => {
  const commands = [];
  const commandNames = new Set();
  const commandsDir = path.join(__dirname, "..", "Comandos");

  if (!fs.existsSync(commandsDir)) {
    console.warn("[AVISO] Pasta Comandos não encontrada.");
    return;
  }

  for (const entry of fs.readdirSync(commandsDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const folder = path.join(commandsDir, entry.name);

    for (const file of fs.readdirSync(folder).filter(name => name.endsWith(".js"))) {
      try {
        const command = sanitizeCommandMetadata(require(path.join(folder, file)));
        if (!command?.name || typeof command.run !== "function") {
          console.warn(`[AVISO] Comando inválido ignorado: ${entry.name}/${file}`);
          continue;
        }
        if (entry.name === 'config') Object.defineProperty(command, '__ownerOnly', { value: true, enumerable: false, configurable: false });
        if (commandNames.has(command.name)) {
          console.warn(`[AVISO] Comando duplicado ignorado: /${command.name} em ${entry.name}/${file}`);
          continue;
        }
        commandNames.add(command.name);
        client.slashCommands.set(command.name, command);
        commands.push(command);
      } catch (error) {
        console.error(`[ERRO] Falha ao carregar ${entry.name}/${file}:`, error);
      }
    }
  }

  async function clearGuildCommands(guild, attempt = 1) {
    try {
      const existing = await guild.commands.fetch().catch(() => null);
      if (!existing || existing.size === 0) return 0;
      await guild.commands.set([]);
      const remaining = await guild.commands.fetch().catch(() => null);
      const left = remaining?.size || 0;
      if (left > 0 && attempt < 3) {
        await new Promise(resolve => setTimeout(resolve, 1500 * attempt));
        return clearGuildCommands(guild, attempt + 1);
      }
      console.log(`[COMANDOS] ${existing.size} registro(s) antigo(s) por servidor removido(s) em ${guild.id}; restantes=${left}.`);
      return left;
    } catch (error) {
      console.warn(`[COMANDOS] Não foi possível limpar comandos por servidor em ${guild.id}:`, error?.message || error);
      return -1;
    }
  }

  async function reconcileCommandScopes() {
    let remaining = 0;
    for (const guild of client.guilds.cache.values()) {
      const left = await clearGuildCommands(guild);
      if (left > 0) remaining += left;
    }
    console.log(`[COMANDOS] Reconciliação de escopo: Manager=global único; guild leftovers=${remaining}; bots filhos não são tocados.`);
  }

  client.once("clientReady", async () => {
    try {
      // O Manager usa UM único escopo: global. Versões anteriores registravam
      // global + guild, e o Discord mostrava o mesmo slash command duas vezes.
      // application.commands.set substitui somente os comandos DESTA aplicação;
      // bots filhos possuem outro Application ID e não são tocados aqui.
      await client.application.commands.set(commands);
      console.log(`[COMANDOS] Manager ${client.application.id}: ${commands.length} comando(s) globais únicos publicados.`);
    } catch (error) {
      console.error('[ERRO] Falha ao publicar comandos globais do Manager:', error);
    }

    // Remove imediatamente a segunda cópia que versões antigas deixaram como
    // comandos de guild. Depois disso existe só a cópia global do Manager.
    await reconcileCommandScopes();
    console.log('[COMANDOS] Isolamento concluído: Manager=global; bots filhos=guild da própria aplicação.');

    // O Discord pode manter visualmente comandos antigos por alguns segundos.
    // Reconciliamos novamente após a propagação para eliminar registros de guild
    // remanescentes sem jamais tocar nas Application IDs dos bots filhos.
    const retry15 = setTimeout(() => void reconcileCommandScopes(), 15_000);
    retry15.unref?.();
    const retry60 = setTimeout(() => void reconcileCommandScopes(), 60_000);
    retry60.unref?.();
  });

  client.on('guildCreate', guild => { void clearGuildCommands(guild); });
};
