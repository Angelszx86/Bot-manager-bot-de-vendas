const mp = require("mercadopago");

module.exports = {
  id: "gerar_pagamento",

  async run(interaction) {
    const accessToken = process.env.MP_TOKEN;
    if (!accessToken) {
      return interaction.reply({
        content: "❌ O Mercado Pago não está configurado. Defina MP_TOKEN no arquivo .env.",
        ephemeral: true
      });
    }

    try {
      mp.configure({ access_token: accessToken });
      const preference = await mp.preferences.create({
        items: [{
          title: "Doação para o servidor",
          quantity: 1,
          currency_id: "BRL",
          unit_price: 5
        }],
        payer: { email: "pagamento@exemplo.com" },
        notification_url: process.env.WEBHOOK_MP || undefined
      });

      const paymentUrl = preference?.body?.init_point;
      if (!paymentUrl) throw new Error("Mercado Pago não retornou o link de pagamento");

      return interaction.reply({
        content: `🔗 **Seu link de pagamento:**\n${paymentUrl}`,
        ephemeral: true
      });
    } catch (error) {
      console.error("[MERCADO PAGO]", error);
      const payload = { content: "❌ Não foi possível gerar o pagamento agora.", ephemeral: true };
      return interaction.replied || interaction.deferred
        ? interaction.followUp(payload)
        : interaction.reply(payload);
    }
  }
};
