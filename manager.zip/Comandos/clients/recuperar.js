const {
  EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ApplicationCommandType
} = require('discord.js');
const { db2, auto } = require('../../databases/index');
const supabase = require('../../Lib/supabaseRecovery');

const stateByUser = new Map();
const SESSION_MS = 12 * 60 * 1000;

function state(userId) {
  const key = String(userId);
  const current = stateByUser.get(key);
  if (!current || Date.now() - current.updatedAt > SESSION_MS) {
    const fresh = { email: '', updatedAt: Date.now() };
    stateByUser.set(key, fresh);
    return fresh;
  }
  return current;
}
function panel(email = '', color = '#3155ff') {
  return new EmbedBuilder()
    .setColor(color)
    .setTitle('ASTRA APPLICATION • Recuperar seus bots')
    .setDescription('Informe o **mesmo e-mail que foi vinculado aos seus bots**. Enviaremos um código temporário pelo Supabase. Só depois da confirmação os bots serão transferidos para esta conta do Discord.\n\n**Aceitos:** Gmail (`@gmail.com`), Outlook (`@outlook.com`) e Yahoo (`@yahoo.com`). E-mails temporários e outros domínios são bloqueados.')
    .addFields(
      { name: 'E-mail de recuperação', value: email ? `**${email}**` : 'Não informado' },
      { name: 'Depois da confirmação', value: 'Os bots encontrados passam para esta conta e voltam a aparecer em **/apps**, **/app** e na Central de Gerenciamento.' }
    )
    .setFooter({ text: 'Astra Application • recuperação segura' });
}
function controls(hasEmail) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('recuperar_select_email').setLabel(hasEmail ? 'Alterar e-mail' : 'Informar e-mail').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('recuperar_send_code').setLabel('Enviar código').setStyle(ButtonStyle.Success).setDisabled(!hasEmail)
  );
}
function emailModal() {
  return new ModalBuilder().setCustomId('recuperar_email_modal').setTitle('ASTRA APPLICATION • Recuperação').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('email_input').setLabel('E-MAIL VINCULADO').setPlaceholder('nome@gmail.com • @outlook.com • @yahoo.com').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(254))
  );
}
function codeModal() {
  return new ModalBuilder().setCustomId('recuperar_code_modal').setTitle('ASTRA APPLICATION • Código de recuperação').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code_input').setLabel('CÓDIGO RECEBIDO').setPlaceholder('000000').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(6).setMaxLength(8))
  );
}
function matchingRows(email) {
  const normalized = String(email).toLowerCase();
  return db2.all().filter(row => String(row?.data?.email || '').trim().toLowerCase() === normalized);
}
function cleanOldOwnerCache(appId, oldOwner) {
  if (!oldOwner) return;
  const key = `${oldOwner}_owner`;
  const record = auto.get(key);
  if (!record || !Array.isArray(record.butecos)) return;
  record.butecos = record.butecos.filter(item => String(item?.idapp || item?.id) !== String(appId));
  auto.set(key, record);
}
function addNewOwnerCache(row, newOwner) {
  const key = `${newOwner}_owner`;
  const record = auto.get(key) || { butecos: [] };
  if (!Array.isArray(record.butecos)) record.butecos = [];
  const data = { ...(row.data || {}), owner: String(newOwner), idapp: String(row.data?.idapp || row.id) };
  record.butecos = record.butecos.filter(item => String(item?.idapp || item?.id) !== String(data.idapp));
  record.butecos.push(data);
  auto.set(key, record);
}

module.exports = {
  name: 'recuperar',
  description: 'Recupere bots vinculados ao seu e-mail verificado.',
  type: ApplicationCommandType.ChatInput,
  options: [],
  run: async (client, interaction) => {
    stateByUser.set(String(interaction.user.id), { email: '', updatedAt: Date.now() });
    return interaction.reply({ embeds: [panel()], components: [controls(false)], flags: 64 });
  },
  button: async (client, interaction) => {
    const current = state(interaction.user.id);
    if (interaction.customId === 'recuperar_select_email') return interaction.showModal(emailModal());
    if (interaction.customId === 'recuperar_verify_open') return interaction.showModal(codeModal());
    if (interaction.customId !== 'recuperar_send_code') return;
    if (!current.email) return interaction.reply({ content: 'Informe o e-mail vinculado primeiro.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    try {
      await supabase.sendOtp(current.email);
      current.updatedAt = Date.now();
      stateByUser.set(String(interaction.user.id), current);
      return interaction.editReply({
        embeds: [panel(current.email, '#57F287').setDescription('Código enviado. Digite o código recebido para confirmar a recuperação.')],
        components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('recuperar_verify_open').setLabel('Digitar código').setStyle(ButtonStyle.Success))]
      });
    } catch (error) {
      return interaction.editReply(`Não foi possível enviar o código: ${String(error?.message || error).slice(0, 800)}`);
    }
  },
  modalSubmit: async (client, interaction) => {
    if (interaction.customId === 'recuperar_email_modal') {
      let email;
      try { email = supabase.normalizeEmail(interaction.fields.getTextInputValue('email_input')); }
      catch (error) { return interaction.reply({ content: String(error.message || error), flags: 64 }); }
      stateByUser.set(String(interaction.user.id), { email, updatedAt: Date.now() });
      return interaction.reply({ embeds: [panel(email)], components: [controls(true)], flags: 64 });
    }
    if (interaction.customId !== 'recuperar_code_modal') return;
    const current = state(interaction.user.id);
    if (!current.email) return interaction.reply({ content: 'Sua sessão de recuperação expirou. Use /recuperar novamente.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    let valid = false;
    try { valid = await supabase.verifyOtp(current.email, interaction.fields.getTextInputValue('code_input')); }
    catch (error) { return interaction.editReply(`Falha ao validar o código: ${String(error?.message || error).slice(0, 700)}`); }
    if (!valid) return interaction.editReply('Código inválido ou expirado. Solicite outro código.');

    const rows = matchingRows(current.email);
    if (!rows.length) {
      stateByUser.delete(String(interaction.user.id));
      return interaction.editReply('E-mail confirmado, mas nenhum bot vinculado a esse endereço foi encontrado.');
    }
    const newOwner = String(interaction.user.id);
    for (const row of rows) {
      const appId = String(row.data?.idapp || row.id);
      const oldOwner = String(row.data?.owner || '');
      cleanOldOwnerCache(appId, oldOwner);
      db2.set(`${row.id}.previousOwner`, oldOwner || null);
      db2.set(`${row.id}.owner`, newOwner);
      db2.set(`${row.id}.recoveredAt`, new Date().toISOString());
      db2.set(`${row.id}.recoveryEmail`, current.email);
      addNewOwnerCache({ ...row, data: { ...(row.data || {}), owner: newOwner } }, newOwner);
    }
    stateByUser.delete(newOwner);
    return interaction.editReply({
      embeds: [panel(current.email, '#57F287').setTitle('Recuperação concluída').setDescription(`**${rows.length} bot(s)** foram vinculados à sua conta atual. Eles já podem aparecer em **/apps**, **/app** e na Central de Gerenciamento.`)],
      components: []
    });
  }
};
