const { ApplicationCommandType } = require('discord.js');
const center = require('../../Lib/clientCenter');

module.exports = {
  name: 'apps',
  description: 'Veja e gerencie todas as suas aplicações alugadas.',
  type: ApplicationCommandType.ChatInput,
  options: [],
  run: async (client, interaction) => {
    const payload = center.appSelectPayload(interaction.user.id, 'manage');
    return interaction.reply(payload);
  }
};
