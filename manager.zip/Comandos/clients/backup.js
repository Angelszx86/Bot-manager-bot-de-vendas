const command = require('./recuperar');
module.exports = { ...command, name: 'backup', description: 'Alias de /recuperar para recuperar bots por e-mail.' };
