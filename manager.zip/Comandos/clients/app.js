const apps = require('./apps');
module.exports = { ...apps, name: 'app', description: 'Alias de /apps para gerenciar seus bots.' };
