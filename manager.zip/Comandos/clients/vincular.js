const {
  EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ApplicationCommandType
} = require('discord.js');
const { db2 } = require('../../databases/index');
const supabase = require('../../Lib/supabaseRecovery');

const stateByUser = new Map();
const CODE_TTL_MS = 12 * 60 * 1000;

function ownedRows(userId) {
  return db2.all().filter(row => String(row?.data?.owner) === String(userId));
}
function state(userId) {
  const current = stateByUser.get(String(userId));
  if (!current || Date.now() - current.updatedAt > CODE_TTL_MS) {
    const fresh = { email: '', updatedAt: Date.now() };
    stateByUser.set(String(userId), fresh);
    return fresh;
  }
  return current;
}
function panel(email = '', tone = '#3155ff') {
  return new EmbedBuilder()
    .setColor(tone)
    .setTitle('ASTRA APPLICATION • Vincular e-mail de recuperação')
    .setDescription('Vincule um e-mail aos seus bots. A confirmação usa um **código temporário do Supabase Auth**; o e-mail só é salvo depois que o código for validado.\n\n**Aceitos:** Gmail (`@gmail.com`), Outlook (`@outlook.com`) e Yahoo (`@yahoo.com`). E-mails temporários e outros domínios são bloqueados.')
    .addFields(
      { name: 'E-mail', value: email ? `**${email}**` : 'Não informado', inline: false },
      { name: 'Segurança', value: 'O código não transfere nenhum bot sozinho. Ele apenas confirma que você controla o endereço informado.', inline: false }
    )
    .setFooter({ text: 'Astra Application • recuperação de acesso' });
}
function controls(hasEmail) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('vincular_select_email').setLabel(hasEmail ? 'Alterar e-mail' : 'Informar e-mail').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('vincular_send_code').setLabel('Enviar código').setStyle(ButtonStyle.Success).setDisabled(!hasEmail)
  );
}
function emailModal() {
  return new ModalBuilder().setCustomId('vincular_email_modal').setTitle('ASTRA APPLICATION • E-mail de recuperação').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('email_input').setLabel('E-MAIL').setPlaceholder('nome@gmail.com • @outlook.com • @yahoo.com').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(254))
  );
}
function codeModal() {
  return new ModalBuilder().setCustomId('vincular_code_modal').setTitle('ASTRA APPLICATION • Confirmar código').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code_input').setLabel('CÓDIGO RECEBIDO NO E-MAIL').setPlaceholder('000000').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(6).setMaxLength(8))
  );
}

module.exports = {
  name: 'vincular',
  description: 'Vincule um e-mail para recuperação segura dos seus bots.',
  type: ApplicationCommandType.ChatInput,
  options: [],
  run: async (client, interaction) => {
    const apps = ownedRows(interaction.user.id);
    if (!apps.length) return interaction.reply({ content: 'Você ainda não possui nenhum bot para vincular.', flags: 64 });
    stateByUser.set(String(interaction.user.id), { email: '', updatedAt: Date.now() });
    return interaction.reply({ embeds: [panel()], components: [controls(false)], flags: 64 });
  },
  button: async (client, interaction) => {
    const current = state(interaction.user.id);
    if (interaction.customId === 'vincular_select_email') return interaction.showModal(emailModal());
    if (interaction.customId === 'vincular_verify_open') return interaction.showModal(codeModal());
    if (interaction.customId !== 'vincular_send_code') return;
    if (!current.email) return interaction.reply({ content: 'Informe seu e-mail primeiro.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    try {
      await supabase.sendOtp(current.email);
      current.updatedAt = Date.now();
      stateByUser.set(String(interaction.user.id), current);
      await interaction.editReply({
        embeds: [panel(current.email, '#57F287').setDescription('Código enviado. Abra seu e-mail, copie o código temporário e confirme abaixo.')],
        components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('vincular_verify_open').setLabel('Digitar código').setStyle(ButtonStyle.Success))]
      });
    } catch (error) {
      return interaction.editReply({ content: `Não foi possível enviar o código: ${String(error?.message || error).slice(0, 800)}` });
    }
  },
  modalSubmit: async (client, interaction) => {
    if (interaction.customId === 'vincular_email_modal') {
      let email;
      try { email = supabase.normalizeEmail(interaction.fields.getTextInputValue('email_input')); }
      catch (error) { return interaction.reply({ content: String(error.message || error), flags: 64 }); }
      stateByUser.set(String(interaction.user.id), { email, updatedAt: Date.now() });
      return interaction.reply({ embeds: [panel(email)], components: [controls(true)], flags: 64 });
    }
    if (interaction.customId !== 'vincular_code_modal') return;
    const current = state(interaction.user.id);
    if (!current.email) return interaction.reply({ content: 'A sessão expirou. Use /vincular novamente.', flags: 64 });
    await interaction.deferReply({ flags: 64 });
    let valid = false;
    try { valid = await supabase.verifyOtp(current.email, interaction.fields.getTextInputValue('code_input')); }
    catch (error) { return interaction.editReply(`Falha ao validar o código: ${String(error?.message || error).slice(0, 700)}`); }
    if (!valid) return interaction.editReply('Código inválido ou expirado. Solicite outro código e tente novamente.');
    const rows = ownedRows(interaction.user.id);
    for (const row of rows) {
      db2.set(`${row.id}.email`, current.email);
      db2.set(`${row.id}.emailVerifiedAt`, new Date().toISOString());
    }
    stateByUser.delete(String(interaction.user.id));
    return interaction.editReply({ embeds: [panel(current.email, '#57F287').setTitle('E-mail vinculado com sucesso').setDescription(`O endereço foi vinculado a **${rows.length} bot(s)** da sua conta. Se perder sua conta do Discord, use **/recuperar** na nova conta.`)], components: [] });
  }
};

// O botão de verificação é tratado pelo dispatcher de botões do próprio comando.
module.exports.buttonVerify = codeModal;
