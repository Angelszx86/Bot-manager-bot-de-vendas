const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const keys = require('../../Lib/keys');
const { isOwner } = require('../../Lib/permissions');
const { readCache, fmt } = require('../../Lib/managerEmojis');

function date(value) { return value ? `<t:${Math.floor(new Date(value).getTime()/1000)}:F>` : 'Sem expiração'; }
function ownerOnly(interaction) {
  if (isOwner(interaction.user.id)) return false;
  interaction.reply({ content: 'Esta opção é exclusiva do proprietário do Manager.', flags: 64 });
  return true;
}
module.exports = {
  name: 'key',
  description: 'Resgatar uma Key ZENYX ou administrar Keys.',
  type: ApplicationCommandType.ChatInput,
  options: [
    { name:'resgatar', description:'Resgatar uma Key ZENYX.', type:ApplicationCommandOptionType.Subcommand, options:[{ name:'codigo', description:'Código da Key.', type:ApplicationCommandOptionType.String, required:true }] },
    { name:'status', description:'Ver seus planos ativos por Key.', type:ApplicationCommandOptionType.Subcommand },
    { name:'gerar', description:'Gerar uma nova Key. Proprietário.', type:ApplicationCommandOptionType.Subcommand, options:[
      { name:'plano', description:'Plano liberado pela Key.', type:ApplicationCommandOptionType.String, required:true, choices:[{name:'Starter',value:'STARTER'},{name:'Pro',value:'PRO'},{name:'Premium',value:'PREMIUM'},{name:'Enterprise',value:'ENTERPRISE'}] },
      { name:'expiracao', description:'DD/MM/AAAA ou AAAA-MM-DD.', type:ApplicationCommandOptionType.String, required:true },
      { name:'usuarios', description:'Máximo de usuários que podem resgatar.', type:ApplicationCommandOptionType.Integer, required:true, min_value:1, max_value:10000 },
      { name:'nota', description:'Nota administrativa opcional.', type:ApplicationCommandOptionType.String, required:false }
    ]},
    { name:'listar', description:'Listar Keys recentes. Proprietário.', type:ApplicationCommandOptionType.Subcommand },
    { name:'revogar', description:'Revogar uma Key. Proprietário.', type:ApplicationCommandOptionType.Subcommand, options:[{ name:'codigo', description:'Código da Key.', type:ApplicationCommandOptionType.String, required:true }] }
  ],
  run: async (client, interaction) => {
    const sub = interaction.options.getSubcommand();
    const emojis = readCache(interaction.guildId);
    try {
      if (sub === 'resgatar') {
        const r = keys.redeemKey(interaction.options.getString('codigo'), interaction.user.id);
        return interaction.reply({ embeds:[new EmbedBuilder().setTitle(`${fmt(emojis,'success')} Key ativada`).setDescription(`Plano: **${r.plan}**\nValidade: ${date(r.expiresAt)}\nUso: **${r.uses.length}/${r.maxUses}**`).setColor('#5865F2')], flags:64 });
      }
      if (sub === 'status') {
        const grants = keys.getUserEntitlements(interaction.user.id);
        const text = grants.length ? grants.map((g,i)=>`**${i+1}. ${g.plan}**\nValidade: ${date(g.expiresAt)}\nKey: \`${g.key.slice(0,10)}••••••••\``).join('\n\n') : 'Nenhum plano ativo por Key.';
        return interaction.reply({ embeds:[new EmbedBuilder().setTitle(`${fmt(emojis,'key')} Minhas Keys`).setDescription(text).setColor('#5865F2')], flags:64 });
      }
      if (ownerOnly(interaction)) return;
      if (sub === 'gerar') {
        const r = keys.createKey({ plan: interaction.options.getString('plano'), expiresAt: interaction.options.getString('expiracao'), maxUses: interaction.options.getInteger('usuarios'), note: interaction.options.getString('nota') || '', createdBy: interaction.user.id });
        return interaction.reply({ embeds:[new EmbedBuilder().setTitle(`${fmt(emojis,'key')} Key ZENYX gerada`).setDescription(`Código: \`${r.code}\`\nPlano: **${r.plan}**\nExpira: ${date(r.expiresAt)}\nLimite: **${r.maxUses} usuário(s)**${r.note ? `\nNota: ${r.note}` : ''}`).setColor('#5865F2')], flags:64 });
      }
      if (sub === 'listar') {
        const rows = keys.listKeys().slice(0,15).map(k => `\`${k.code}\` • **${k.plan}** • ${k.uses?.length || 0}/${k.maxUses} • ${k.revokedAt ? 'revogada' : keys.isExpired(k) ? 'expirada' : 'ativa'}`);
        return interaction.reply({ embeds:[new EmbedBuilder().setTitle(`${fmt(emojis,'database')} Keys ZENYX`).setDescription(rows.join('\n') || 'Nenhuma Key criada.').setColor('#5865F2')], flags:64 });
      }
      if (sub === 'revogar') {
        const r = keys.revokeKey(interaction.options.getString('codigo'), interaction.user.id);
        return interaction.reply({ content: `${fmt(emojis,'success')} Key \`${r.code}\` revogada.`, flags:64 });
      }
    } catch (error) {
      return interaction.reply({ content: `${fmt(emojis,'wrong')} ${error.message || 'Não foi possível processar a Key.'}`, flags:64 });
    }
  }
};
