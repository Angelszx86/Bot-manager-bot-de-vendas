const {
  ApplicationCommandOptionType,
} = require("discord.js");

module.exports = {
  name: 'limpardm',
  description: 'Apaga as mensagens que eu enviei na sua DM.',
  options: [],

  run: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: true }); // adianta a resposta para o Discord

      const dm = await interaction.user.createDM();
      const messages = await dm.messages.fetch({ limit: 100 });
      const botMessages = messages.filter(m => m.author.id === client.user.id);

      if (botMessages.size === 0) {
        return interaction.editReply('ℹ️ Não encontrei mensagens minhas para apagar na sua DM.');
      }

      for (const msg of botMessages.values()) {
        await msg.delete();
      }

      return interaction.editReply(`✅ Apaguei ${botMessages.size} mensagens minhas na sua DM.`);
    } catch (error) {
      console.error('Erro ao apagar mensagens na DM:', error);
      if (!interaction.replied) {
        return interaction.editReply('❌ Não consegui apagar as mensagens na DM.');
      }
    }
  }
};