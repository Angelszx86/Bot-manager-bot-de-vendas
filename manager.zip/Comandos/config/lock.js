const { ApplicationCommandType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { logs } = require('../../databases');
const { isAdmin } = require('../../Lib/permissions');
const NAV_KEY='astroSolution.navigation';
function navigationButtons(){
 const nav=logs.get(NAV_KEY)||{};
 return new ActionRowBuilder().addComponents(...[['Feedbacks',nav.feedback],['Astra Application',nav.sellers],['Suporte',nav.support]].map(([label,url])=>{
  const b=new ButtonBuilder().setLabel(label).setStyle(url ? ButtonStyle.Link : ButtonStyle.Secondary);
  return url ? b.setURL(url) : b.setDisabled(true);
 }));
}
module.exports={name:'lock',description:'Bloqueia o canal atual e envia a central Astra Application',type:ApplicationCommandType.ChatInput,run:async(client,i)=>{
 if(!i.guild||(!i.memberPermissions?.has(PermissionFlagsBits.ManageChannels)&&!isAdmin(i.user.id))) return i.reply({content:'Você não tem permissão para bloquear este canal.',ephemeral:true});
 await i.deferReply({ephemeral:true}); const channel=i.channel; const everyone=i.guild.roles.everyone;
 const key=`astroSolution.locks.${channel.id}`;
 if(!logs.get(key)) logs.set(key,{sendMessages:channel.permissionOverwrites.cache.get(everyone.id)?.allow?.has('SendMessages') ? true : null,lockedAt:Date.now(),lockedBy:i.user.id});
 await channel.permissionOverwrites.edit(everyone,{SendMessages:false},{reason:`Astra Application • /lock por ${i.user.tag}`});
 const branding=logs.get('astroSolution.branding')||{};
 const embed=new EmbedBuilder().setColor(0x2b2d31).setTitle('ASTRO SOLUTION').setDescription('### Canal temporariamente bloqueado\nUse os atalhos abaixo para continuar navegando.').setFooter({text:'Astra Application'});
 if(/^https?:\/\//i.test(String(branding.lockBanner||''))) embed.setImage(branding.lockBanner);
 await channel.send({embeds:[embed],components:[navigationButtons()]}).catch(()=>null);
 return i.editReply('Canal bloqueado e central enviada.');
}};
