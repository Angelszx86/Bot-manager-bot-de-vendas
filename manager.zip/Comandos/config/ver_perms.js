module.exports = { ...require('./perms'), name: 'ver_perms', description: 'Ver e administrar permissões do manager.' };
