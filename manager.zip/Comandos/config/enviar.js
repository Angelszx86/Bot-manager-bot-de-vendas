const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder
} = require("discord.js");
//const { perms, db } = require("../../databases/index.js");
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");
const fs = require(`fs`)
const JSZip = require('jszip');
const { SquareCloudAPI } = require('../../source/hidencloud_api');


module.exports = {
  name: 'enviar-bot',
  description: '[👑] Envia um para algum membro o direito de usar nossos bots de graça por 1 mês',
  options: [
    {
      name: "user",
      description: "Usuário",
      type: ApplicationCommandOptionType.User,
      required: true,
    },
    {
      name: "aluguel",
      description: "Aplicação desejada",
      type: ApplicationCommandOptionType.String,
      required: true,
      autocomplete: true
    }
  ],
  async autocomplete(interaction) {
        const value = interaction.options.getFocused().toLowerCase();
        let choices = db.all().filter(pd => pd.data.nomeproduto)

        const filtered = choices.filter(choice => choice.data.nomeproduto.toLowerCase().includes(value)).slice(0, 25);

        if (!interaction) return;
        if (choices.length === 0) {
            await interaction.respond([
                { name: `Crie um BOT!`, value: `a29183912asd92384XASDASDSADASDSADASDASD12398212222` }
            ]);
        } else if (filtered.length === 0) {
            await interaction.respond([
                { name: `Não achei nenhum BOT`, value: `a29183912asd92384XASDASDSADASDSADASDASD1239821` }
            ]);
        } else {
            await interaction.respond(
                filtered.map(choice => ({ name: choice.data.nomeproduto, value: choice.data.nomeproduto }))
            );
        };
    },
  run: async (client, interaction) => {
       if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: `\`❌\` Você não tem permissão para usar este comando.`, ephemeral: true })
        };

        const id = interaction.options.getString(`aluguel`);
        if (id === `a29183912asd92384XASDASDSADASDSADASDASD1239821`) {
            interaction.reply({
                content: `\`❌\` Bot aluguel não encontrado.`,
                ephemeral: true
            })
            return;
        };

        if (id === `a29183912asd92384XASDASDSADASDSADASDASD12398212222`) {
            interaction.reply({
                content: `\`❌\` Não existe nenhum bot aluguel ainda.`,
                ephemeral: true
            })
            return;
        };

        if (id !== db.get(`${id}.nomeproduto`)) {
            interaction.reply({
                content: `\`❌\` Bot aluguel não encontrado.`,
                ephemeral: true
            })
            return;
        };

        const user = interaction.options.getUser("user");
        try {
              await user.send({ 
                content: `# 👤 Olá\n> Você recebeu um mês de do nosso bot grátis!`, 
                components: [
                new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`${id}_botfree`).setLabel(`Resgate`).setEmoji(`🎁`).setStyle(1),
                    )
                ],
              });
              await interaction.reply(`✅ Mensagem enviada para ${user.tag}.`);
        } catch (error) {
             console.error('Erro ao enviar DM:', error);
             await interaction.reply('❌ Não foi possível enviar a mensagem. O usuário pode estar com DMs fechadas.');
        }
  }
  
}