const {
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
  ApplicationCommandType,
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  TextDisplayBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  MessageFlags,
  resolveColor,
  AttachmentBuilder
} = require('discord.js');
const path = require('path');

const { db } = require('../../databases/index');
const { readCache, fmt, id: emojiId } = require('../../Lib/managerEmojis');

function customEmoji(emojis, ...keys) {
  for (const key of keys) {
    const value = emojiId(emojis, key, null);
    if (value) return value;
  }
  return null;
}
function buttonEmoji(button, value) { if (value) button.setEmoji(value); return button; }
function isImageLink(value) {
  if (!value || typeof value !== 'string') return false;
  try { return /\.(png|jpe?g|gif|webp)$/i.test(new URL(value).pathname); }
  catch { return /\.(png|jpe?g|gif|webp)(?:\?.*)?$/i.test(value); }
}
function accent(value) {
  try { return resolveColor(value || '#5865F2'); }
  catch { return 0x5865F2; }
}

module.exports = {
  name: 'setar',
  description: 'Setar um aluguel de bot para venda',
  type: ApplicationCommandType.ChatInput,
  options: [{
    name: 'alugueis',
    description: 'Veja todos os seus alugueis registrados',
    type: ApplicationCommandOptionType.String,
    required: true,
    autocomplete: true
  }],

  async autocomplete(interaction) {
    const value = interaction.options.getFocused().toLowerCase();
    const choices = db.all().filter(pd => pd.data.nomeproduto);
    const filtered = choices.filter(choice => choice.data.nomeproduto.toLowerCase().includes(value)).slice(0, 25);
    if (!choices.length) return interaction.respond([{ name: 'Crie um BOT', value: 'BOT_INEXISTENTE' }]);
    if (!filtered.length) return interaction.respond([{ name: 'Não achei nenhum BOT', value: 'BOT_INEXISTENTE_2' }]);
    return interaction.respond(filtered.map(choice => ({ name: ['NexusPro','ZenyxPro'].includes(choice.data.nomeproduto) ? 'Astra Application' : choice.data.nomeproduto, value: choice.data.nomeproduto })));
  },

  run: async (client, interaction) => {
    try {
      if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
        return interaction.reply({ content: 'Você não tem permissão para usar este comando.', flags: 64 });
      }

      const id = interaction.options.getString('alugueis');
      if (id === 'BOT_INEXISTENTE' || id === 'BOT_INEXISTENTE_2' || id !== db.get(`${id}.nomeproduto`)) {
        return interaction.reply({ content: 'Bot de aluguel não encontrado.', flags: 64 });
      }

      await interaction.deferReply({ flags: 64 });
      const lastMsgId = db.get(`${id}.lastMsgId`);
      if (lastMsgId) {
        try { const oldMsg = await interaction.channel.messages.fetch(lastMsgId); if (oldMsg) await oldMsg.delete(); }
        catch {}
      }

      const brandProduct = ['NexusPro','ZenyxPro'].includes(id);
      if (brandProduct) {
        const { buildZenyxPanel } = require('../../Lib/refreshSalesPanel');
        const sentMsg = await interaction.channel.send(buildZenyxPanel(interaction.guild, 'ZenyxPro'));
        await db.set('ZenyxPro.canalId', interaction.channel.id);
        if (sentMsg?.id) await db.set('ZenyxPro.lastMsgId', sentMsg.id);
        if (id !== 'ZenyxPro' && db.has(id)) {
          await db.set(`${id}.canalId`, interaction.channel.id);
          if (sentMsg?.id) await db.set(`${id}.lastMsgId`, sentMsg.id);
        }
        return interaction.editReply({ content: 'Painel Astra Application publicado com a configuração atual da Vitrine.' });
      }

      const banner = db.get(`${id}.banner`);
      const files = [];
      const saibaMaisText = db.get(`${id}.saibamais`) || 'Nenhuma informação adicional disponível.';
      const type = db.get(`${id}.type`);
      const title = db.get(`${id}.preco.embed.titulo`) || id;
      const description = db.get(`${id}.preco.embed.desc`);
      const color = db.get(`${id}.preco.embed.cor`);
      const content = db.get(`${id}.preco.content.content`);
      const emojis = readCache(interaction.guildId);
      const planOption = new StringSelectMenuOptionBuilder().setValue(`${id}_buy`).setLabel('Selecionar Plano').setDescription('Escolha o plano que deseja contratar');
      const planEmoji = customEmoji(emojis, 'cart', 'carrinho'); if (planEmoji) planOption.setEmoji(planEmoji);
      const select = new StringSelectMenuBuilder().setCustomId(`${id}_buy`).setPlaceholder('Escolha uma opção').addOptions(planOption);
      const container = new ContainerBuilder().setAccentColor(accent(color)).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${fmt(emojis,'store')||fmt(emojis,'bot')} ${String(title).slice(0,250)}`),new TextDisplayBuilder().setContent(String((type==='embed'?description:content)||'Consulte as opções disponíveis.').slice(0,3900)));
      if (banner && isImageLink(banner)) container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(banner)));
      container.addSeparatorComponents(new SeparatorBuilder().setDivider(true)).addActionRowComponents(new ActionRowBuilder().addComponents(select));
      const sentMsg=await interaction.channel.send({flags:MessageFlags.IsComponentsV2,components:[container],files});
      await db.set(`${id}.canalId`,interaction.channel.id); if(sentMsg?.id)await db.set(`${id}.lastMsgId`,sentMsg.id); if(!db.has('saiba_mais_mensagem'))await db.set('saiba_mais_mensagem',saibaMaisText);
      await interaction.editReply({content:'Painel de aluguel enviado em Components V2.'});
    } catch (error) {
      console.error('Erro no comando /setar:', error);
      const errorMsg = { content: 'Ocorreu um erro ao executar o comando.', flags: 64 };
      try {
        if (interaction.deferred || interaction.replied) await interaction.editReply(errorMsg);
        else await interaction.reply(errorMsg);
      } catch (err) { console.error('Falha ao enviar mensagem de erro:', err); }
    }
  }
};
