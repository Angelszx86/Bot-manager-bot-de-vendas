const { ApplicationCommandType, PermissionFlagsBits } = require("discord.js");

module.exports = {
    name: "darcargo",
    description: "[👷] Dá um cargo para bots, membros ou todos com retomada",
    type: ApplicationCommandType.ChatInput,
    default_member_permissions: PermissionFlagsBits.ManageRoles.toString(),
    options: [
        {
            name: "cargo",
            description: "Cargo que deseja dar",
            type: 8, // ROLE
            required: true,
        },
        {
            name: "alvo",
            description: "Quem deve receber o cargo?",
            type: 3, // STRING
            required: true,
            choices: [
                { name: "👤 Apenas Membros", value: "human" },
                { name: "🤖 Apenas Bots", value: "bot" },
                { name: "🌐 Todos", value: "all" },
            ],
        },
    ],

    run: async (client, interaction) => {
        const role = interaction.options.getRole("cargo");
        const target = interaction.options.getString("alvo");

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({
                content: "❌ Eu não tenho permissão para gerenciar cargos!",
                ephemeral: true,
            });
        }

        if (role.position >= interaction.guild.members.me.roles.highest.position) {
            return interaction.reply({
                content: "❌ Eu não posso atribuir esse cargo, ele está acima ou no mesmo nível que meu cargo mais alto.",
                ephemeral: true,
            });
        }

        await interaction.reply({
            content: `⏳ Iniciando em 3 segundos... preparando para dar o cargo **${role.name}** para **${target}**.`,
            ephemeral: true,
        });

        const guild = interaction.guild;
        await guild.members.fetch();

        let filtered;
        if (target === "human") {
            filtered = guild.members.cache.filter((m) => !m.user.bot);
        } else if (target === "bot") {
            filtered = guild.members.cache.filter((m) => m.user.bot);
        } else {
            filtered = guild.members.cache;
        }

        const total = filtered.size;
        const membersToGive = filtered.filter(m => !m.roles.cache.has(role.id)); // só quem não tem ainda
        const queue = Array.from(membersToGive.values()); // transforma em array

        const msg = await interaction.channel.send(
            `⏳ Esperando 3 segundos para começar...\n📌 Membros restantes para receber o cargo: **${queue.length}**`
        );

        await new Promise((res) => setTimeout(res, 3000)); // espera 3s

        let success = 0;
        let failed = 0;

        const giveNext = async () => {
            if (queue.length === 0) {
                return msg.edit(`✅ Cargo **${role.name}** atribuído a **${success}** membros com sucesso.\n❌ Falhou em **${failed}**.`);
            }

            const member = queue.shift();

            try {
                await member.roles.add(role);
                success++;
            } catch (e) {
                failed++;
            }

            if ((success + failed) % 100 === 0 || queue.length === 0) {
                await msg.edit(
                    `🔄 Progresso: ${success + failed}/${total} | ✅ Sucesso: ${success} | ❌ Falhas: ${failed} | ⏳ Restantes: ${queue.length}`
                );
            }

            // chama o próximo com pequeno delay (recursivamente)
            setTimeout(giveNext, 0); // sem travar o bot
        };

        giveNext(); // inicia loop
    },
};