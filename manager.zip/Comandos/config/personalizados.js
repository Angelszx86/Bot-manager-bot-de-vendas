const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ApplicationCommandType
} = require('discord.js');

module.exports = {
  name: "painel-personalizados",
  description: "[⭐] Setar o painel de personalização",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
      try {
        const embed = new EmbedBuilder()
            .setTitle("✨ - Configuração e Personalização de Bots")
            .setDescription(
                "Clique no botão abaixo para iniciar a criação do seu bot personalizado, escolhendo as funcionalidades e características que melhor atendem às suas necessidades.\n\n" +
                "Nossa plataforma oferece uma experiência simples e intuitiva para que você possa descrever exatamente o que deseja. Estamos aqui para transformar suas ideias em bots funcionais, eficientes e adaptados ao seu estilo."
            )
            .setColor("Blurple")
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || null)
            .setFooter({ text: "Astra Application — Desenvolvendo o futuro." });

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setLabel('Descrever Bot')
            .setEmoji("🎁")
            .setCustomId("abrir_form_personalizar")
            .setStyle(ButtonStyle.Primary)
        );

        // Envia no canal primeiro
        await interaction.channel.send({ embeds: [embed], components: [row] });

        // Só confirma se o envio der certo
        await interaction.reply({ content: "✅ Painel de personalização enviado com sucesso!", ephemeral: true });
        
      } catch (error) {
        console.error("Erro ao executar o comando painel-personalizado", error);
        
        let msgErro = "❌ Ocorreu um erro ao executar o comando. Tente novamente mais tarde.";
        if (error.code === 50001 || error.code === 50013) {
            msgErro = "❌ Eu não tenho permissão para enviar mensagens ou embeds neste canal!";
        }

        if (!interaction.replied) {
            await interaction.reply({
              content: msgErro,
              ephemeral: true
            });
        }
    }
  }
}
