const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  EmbedBuilder
} = require('discord.js');

module.exports = {
  name: 'enviar-dm',
  description: '[📨] Envie uma mensagem por DM para todos os membros do servidor',
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'titulo',
      description: 'Título que aparecerá no topo da mensagem',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'mensagem',
      description: 'Conteúdo principal da mensagem que será enviada',
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: 'imagem',
      description: 'URL de uma imagem para adicionar na mensagem (opcional)',
      type: ApplicationCommandOptionType.String,
      required: false,
    },
  ],

  run: async (client, interaction) => {
    const { guild } = interaction;
    const titulo = interaction.options.getString('titulo');
    const mensagem = interaction.options.getString('mensagem');
    const imagem = interaction.options.getString('imagem');

    await interaction.reply({ content: '📤 Iniciando envio de mensagens por DM...', ephemeral: true });

    let enviados = 0;
    let falhas = 0;

    const members = await guild.members.fetch();

    for (const [id, member] of members) {
      if (member.user.bot) continue;

      try {
        const embed = new EmbedBuilder()
          .setTitle(titulo)
          .setDescription(mensagem)
          .setColor('#2f3136')
          .setFooter({ text: `Mensagem enviada por ${interaction.user.tag}` });

        if (imagem) embed.setImage(imagem);

        await member.send({ embeds: [embed] });
        enviados++;
      } catch (err) {
        falhas++;
      }
    }

    interaction.followUp({
      content: `✅ Mensagens enviadas: **${enviados}**\n❌ Falhas (DM desativada ou erro): **${falhas}**`,
      ephemeral: true
    });
  }
};