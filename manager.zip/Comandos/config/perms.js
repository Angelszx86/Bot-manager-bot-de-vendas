const {
  EmbedBuilder,
  ActionRowBuilder,
  ApplicationCommandType,
  StringSelectMenuBuilder
} = require("discord.js");
const { perms } = require("../../databases/index");
const { isOwner } = require('../../Lib/permissions');

module.exports = {
  name: "perms",
  description: "[👷] Gerencie as permissões!",
  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction) => {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription("❌ | Apenas o Dono do Bot pode usar esta função!")
            .setColor("Red")
        ],
        ephemeral: true
      });
    }

    let a = "";
    const listaPerms = perms.get("usersPerms") || [];

    listaPerms.map((rs, index) => {
      a += `\n${index + 1}. <@${rs}>`;
    });

    const embed = new EmbedBuilder()
      .setTitle(`Permissões`)
      .setThumbnail(`${client.user.displayAvatarURL()}`)
      .setColor("#00FFFF")
      .setFooter({ text: `${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    if (listaPerms.length <= 0) {
      embed.setDescription("- **Lista de administradores vazia, nenhum administrador configurado no momento**\n\nEste painel está vazio, sem usuários autorizados.\n\nUse o menu abaixo para adicionar quem pode gerenciar o sistema.\n\n```Nenhum usuário possui acesso ao painel de gerenciamento no momento. Selecione uma opção no menu abaixo para conceder permissões.```");
    } else {
      embed.setDescription(`- **Administradores autorizados**\n\nAbaixo está a lista de quem pode gerenciar o sistema.\n\nUse o menu para adicionar ou remover permissões conforme necessário.\n${a}`);
    }

    const actionRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId(`selectMenuPerms`)
        .setPlaceholder(`Clique aqui para selecionar uma opção`)
        .addOptions(
          {
            value: `addPermBot`,
            label: `Adicionar Usuário`,
            description: `Adicione um usuário`,
            emoji: `➕`
          },
          {
            value: `remPermBot`,
            label: `Remover Usuário`,
            description: `Remova um usuário`,
            emoji: `➖`
          }
        )
    );

    return interaction.reply({ embeds: [embed], components: [actionRow], ephemeral: true });
  }
};
