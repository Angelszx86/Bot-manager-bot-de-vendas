const {
  ApplicationCommandType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { isOwner } = require('../../Lib/permissions');
const recoveryConfig = require('../../Lib/recoveryConfig');

function input(id, label, value = '', style = TextInputStyle.Short, required = false, max = 4000) {
  return new TextInputBuilder()
    .setCustomId(id)
    .setLabel(label.slice(0, 45))
    .setStyle(style)
    .setRequired(required)
    .setMaxLength(max)
    .setValue(String(value || '').slice(0, max));
}
function panel() {
  const st = recoveryConfig.status();
  return {
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle('🔐 Configurar recuperação por Gmail')
      .setDescription('Configure o Supabase e o SMTP que enviará os códigos de recuperação. Os valores secretos são salvos criptografados localmente e nunca aparecem na resposta.')
      .addFields(
        { name: 'Supabase', value: st.supabase ? '✅ URL e chave configuradas' : '❌ Ainda não configurado', inline: true },
        { name: 'Template/API', value: st.template ? '✅ Project Ref e Management Token configurados' : '❌ Ainda não configurado', inline: true },
        { name: 'SMTP Gmail', value: st.smtp ? '✅ Configurado' : '⚠️ Recomendado para Gmail externo', inline: true }
      )
      .setFooter({ text: 'Somente os donos do Manager podem usar este painel.' })],
    components: [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('recovery_config_supabase').setLabel('Configurar Supabase').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('recovery_config_smtp').setLabel('Configurar SMTP/Gmail').setStyle(ButtonStyle.Secondary)
      )],
    flags: 64
  };
}

module.exports = {
  name: 'setar-recuperacao',
  description: '[🔐] Configura o Supabase e Gmail da recuperação de bots',
  type: ApplicationCommandType.ChatInput,
  run: async (client, interaction) => {
    if (!isOwner(interaction.user.id)) return interaction.reply({ content: '❌ Este comando é exclusivo dos donos do Manager.', flags: 64 });
    return interaction.reply(panel());
  },
  button: async (client, interaction) => {
    if (!isOwner(interaction.user.id)) return interaction.reply({ content: '❌ Este painel é exclusivo dos donos do Manager.', flags: 64 });
    const saved = recoveryConfig.settings();
    if (interaction.customId === 'recovery_config_supabase') {
      return interaction.showModal(new ModalBuilder().setCustomId('recovery_config_supabase_modal').setTitle('Supabase • recuperação').addComponents(
        new ActionRowBuilder().addComponents(input('url', 'URL do Supabase', saved.url, TextInputStyle.Short, true, 300)),
        new ActionRowBuilder().addComponents(input('secretKey', 'Service Role/Secret Key', saved.secretKey, TextInputStyle.Short, true, 1000)),
        new ActionRowBuilder().addComponents(input('projectRef', 'Project Ref', saved.projectRef, TextInputStyle.Short, true, 120)),
        new ActionRowBuilder().addComponents(input('managementToken', 'Management Token', saved.managementToken, TextInputStyle.Short, true, 1000)),
        new ActionRowBuilder().addComponents(input('discordInvite', 'Convite Discord HTTPS (opcional)', saved.discordInvite, TextInputStyle.Short, false, 300))
      ));
    }
    if (interaction.customId === 'recovery_config_smtp') {
      return interaction.showModal(new ModalBuilder().setCustomId('recovery_config_smtp_modal').setTitle('SMTP • Gmail recuperação').addComponents(
        new ActionRowBuilder().addComponents(input('smtpHost', 'Servidor SMTP', saved.smtpHost || 'smtp.gmail.com', TextInputStyle.Short, true, 200)),
        new ActionRowBuilder().addComponents(input('smtpPort', 'Porta SMTP', saved.smtpPort || '587', TextInputStyle.Short, true, 6)),
        new ActionRowBuilder().addComponents(input('smtpUser', 'Usuário/e-mail Gmail', saved.smtpUser, TextInputStyle.Short, true, 320)),
        new ActionRowBuilder().addComponents(input('smtpPassword', 'Senha de app Gmail', saved.smtpPassword, TextInputStyle.Short, true, 500)),
        new ActionRowBuilder().addComponents(input('smtpSenderEmail', 'E-mail remetente', saved.smtpSenderEmail || saved.smtpUser, TextInputStyle.Short, true, 320))
      ));
    }
  },
  modalSubmit: async (client, interaction) => {
    if (!isOwner(interaction.user.id)) return interaction.reply({ content: '❌ Este painel é exclusivo dos donos do Manager.', flags: 64 });
    if (interaction.customId === 'recovery_config_supabase_modal') {
      const url = String(interaction.fields.getTextInputValue('url') || '').trim().replace(/\/$/, '');
      const secretKey = String(interaction.fields.getTextInputValue('secretKey') || '').trim();
      const projectRef = String(interaction.fields.getTextInputValue('projectRef') || '').trim();
      const managementToken = String(interaction.fields.getTextInputValue('managementToken') || '').trim();
      const discordInvite = String(interaction.fields.getTextInputValue('discordInvite') || '').trim();
      if (!/^https:\/\/[^\s]+\.supabase\.co$/i.test(url)) return interaction.reply({ content: 'URL inválida. Use o formato https://seu-projeto.supabase.co.', flags: 64 });
      if (!secretKey || !projectRef || !managementToken) return interaction.reply({ content: 'Preencha a Secret Key, Project Ref e Management Token.', flags: 64 });
      recoveryConfig.save({ url, secretKey, projectRef, managementToken, discordInvite });
      return interaction.reply({ content: '✅ Supabase salvo com proteção local. Agora configure o SMTP/Gmail neste mesmo comando.', flags: 64 });
    }
    if (interaction.customId === 'recovery_config_smtp_modal') {
      const smtpHost = String(interaction.fields.getTextInputValue('smtpHost') || '').trim();
      const smtpPort = Number(interaction.fields.getTextInputValue('smtpPort') || 587);
      const smtpUser = String(interaction.fields.getTextInputValue('smtpUser') || '').trim();
      const smtpPassword = String(interaction.fields.getTextInputValue('smtpPassword') || '').trim();
      const smtpSenderEmail = String(interaction.fields.getTextInputValue('smtpSenderEmail') || '').trim();
      if (!smtpHost || !Number.isInteger(smtpPort) || smtpPort < 1 || smtpPort > 65535 || !smtpUser || !smtpPassword || !/^\S+@\S+\.\S+$/.test(smtpSenderEmail)) return interaction.reply({ content: 'Confira servidor, porta, usuário, senha de app e e-mail remetente.', flags: 64 });
      recoveryConfig.save({ smtpHost, smtpPort, smtpUser, smtpPassword, smtpSenderEmail, smtpSenderName: 'Astra Application' });
      return interaction.reply({ content: '✅ SMTP/Gmail salvo com proteção local. O próximo código enviado aplicará o template e as configurações no Supabase.', flags: 64 });
    }
  }
};
