// commands/sorteio.js
const {
  ApplicationCommandType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ModalSubmitInteraction
} = require("discord.js");

const sorteioHandler = require("../../Functions/sorteioHandler"); // ajuste se necessário
const parseDuration = require("../../Functions/parseDuration"); // vou incluir função pequena abaixo

module.exports = {
  name: "sorteio",
  description: "[🎉] Criar sorteio personalizado",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    const userId = interaction.user.id;
    sorteioHandler.initDraft(userId);

    const embed = new EmbedBuilder()
      .setTitle("🎉 Criação de Sorteio")
      .setDescription("Use os botões para abrir e configurar o sorteio.")
      .setColor("#00b0f4");

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("modal_titulo").setLabel("📝 Título").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("modal_descricao").setLabel("📄 Descrição").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("modal_tempo").setLabel("⏳ Tempo").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("modal_cargo").setLabel("🏷️ ID Cargo vencedor").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("preview").setLabel("👁️ Preview").setStyle(ButtonStyle.Success)
    );

    const row2 = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("gerenciar_botoes").setLabel("🎛️ Gerenciar Botões").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("enviar").setLabel("✅ Enviar Sorteio").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("salvar_draft").setLabel("💾 Salvar Draft").setStyle(ButtonStyle.Primary)
    );

    const replyMsg = await interaction.reply({ embeds: [embed], components: [row, row2], ephemeral: true, fetchReply: true });

    const collector = replyMsg.createMessageComponentCollector({
      time: 1000 * 60 * 20,
      filter: (i) => i.user.id === userId
    });

    collector.on("collect", async (i) => {
      const id = i.customId;

      // --- MODAIS: abrindo modal conforme botão ---
      if (id === "modal_titulo") {
        const modal = new ModalBuilder()
          .setCustomId("modal_set_titulo")
          .setTitle("Definir Título do Sorteio");

        const input = new TextInputBuilder()
          .setCustomId("titulo_input")
          .setLabel("Título")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await i.showModal(modal);
        return;
      }

      if (id === "modal_descricao") {
        const modal = new ModalBuilder()
          .setCustomId("modal_set_descricao")
          .setTitle("Definir Descrição do Sorteio");

        const input = new TextInputBuilder()
          .setCustomId("descricao_input")
          .setLabel("Descrição")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await i.showModal(modal);
        return;
      }

      if (id === "modal_tempo") {
        const modal = new ModalBuilder()
          .setCustomId("modal_set_tempo")
          .setTitle("Definir Tempo do Sorteio");

        const input = new TextInputBuilder()
          .setCustomId("tempo_input")
          .setLabel("Ex: 10m, 2h, 1d")
          .setStyle(TextInputStyle.Short)
          .setRequired(true);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await i.showModal(modal);
        return;
      }

      if (id === "modal_cargo") {
        const modal = new ModalBuilder()
          .setCustomId("modal_set_cargo")
          .setTitle("Definir ID do cargo (opcional)");

        const input = new TextInputBuilder()
          .setCustomId("cargo_input")
          .setLabel("ID do cargo a ser dado ao vencedor (ou deixe em branco)")
          .setStyle(TextInputStyle.Short)
          .setRequired(false);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await i.showModal(modal);
        return;
      }

      // gerenciar botões: abre modal para criar label do botão de participar
      if (id === "gerenciar_botoes") {
        const modal = new ModalBuilder()
          .setCustomId("modal_gerenciar_botoes")
          .setTitle("Gerenciar Botões");

        const input = new TextInputBuilder()
          .setCustomId("btn_label")
          .setLabel("Label do botão de participação (ex: Participar)")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(80);

        modal.addComponents(new ActionRowBuilder().addComponents(input));
        await i.showModal(modal);
        return;
      }

      if (id === "preview") {
        const data = sorteioHandler.getDraft(userId);
        const preview = new EmbedBuilder()
          .setTitle(data.titulo || "Sem título")
          .setDescription(data.descricao || "Sem descrição")
          .setColor("#fcd303")
          .setFooter({ text: data.tempo ? `⏳ Duração: ${data.tempo}` : "Sem tempo definido" });

        await i.reply({ embeds: [preview], ephemeral: true });
        return;
      }

      if (id === "salvar_draft") {
        const draft = sorteioHandler.getDraft(userId);
        await sorteioHandler.saveDraft(userId, draft);
        await i.reply({ content: "💾 Draft salvo com sucesso!", ephemeral: true });
        return;
      }

      if (id === "enviar") {
        const draft = sorteioHandler.getDraft(userId);
        if (!draft.titulo || !draft.descricao || !draft.tempo) {
          return i.reply({ content: "⚠️ Preencha título, descrição e tempo antes de enviar.", ephemeral: true });
        }

        // parse duration e converter para ms
        const durMs = parseDuration(draft.tempo);
        if (!durMs || durMs <= 0) {
          return i.reply({ content: "⚠️ Tempo inválido. Use formatos como 10m, 2h, 1d.", ephemeral: true });
        }

        const guild = interaction.guild;

        // criar embed final
        const embedFinal = new EmbedBuilder()
          .setTitle(draft.titulo)
          .setDescription(draft.descricao)
          .addFields(
              { name: "⏰ Duração:", value: `\`${draft.tempo}\``, inline: true },
              { name: "💰 Vencedores:", value: "`1x`", inline: true },
              { name: "👤 Participantes:", value: "`0`", inline: true }
          )
          .setColor("#fcd303")
          .setTimestamp()
          .setFooter({ text: `${guild.name}`, iconURL: guild.iconURL({ dynamic: true }) });

        // botão de participar (id incluirá id de sorteio gerado)
        const publicButtons = [];
        const buttonLabel = draft.participationLabel || "Participar";
        const newGiveaway = await sorteioHandler.createGiveaway({
          guildId: interaction.guildId,
          channelId: interaction.channelId,
          authorId: userId,
          titulo: draft.titulo,
          descricao: draft.descricao,
          tempo: draft.tempo,
          cargoGanhador: draft.cargoGanhador || null,
        });

        const participateCustomId = `participar_${newGiveaway.id}`;
        const endCustomId = `encerrar_${newGiveaway.id}`;

        publicButtons.push(
          new ButtonBuilder().setCustomId(participateCustomId).setEmoji("👤").setLabel(buttonLabel).setStyle(ButtonStyle.Success),
          //new ButtonBuilder().setCustomId(endCustomId).setLabel("⛔ Encerrar (autor/admin)").setStyle(ButtonStyle.Danger)
        );

        const rows = [new ActionRowBuilder().addComponents(publicButtons)];

        const posted = await interaction.channel.send({ embeds: [embedFinal], components: rows });

        // salvar message id no giveaway
        sorteioHandler.linkMessage(newGiveaway.id, posted.id);

        await i.reply({ content: "🎉 Sorteio enviado publicamente!", ephemeral: true });

        // Iniciar sistema automático: cronometro via setTimeout
        setTimeout(async () => {
          const gw = sorteioHandler.getGiveaway(newGiveaway.id);
          if (!gw) return;
          if (gw.ended) return;

          // terminar sorteio
          await finishGiveaway(client, gw.id);
        }, durMs);

        return;
      }

    }); // collector.on collect

    // --- Modal submit handler (local) ---
    client.on("interactionCreate", async (int) => {
      if (!int.isModalSubmit()) return;
      if (int.user.id !== userId) return; // só dono do draft

      const cid = int.customId;

      if (cid === "modal_set_titulo") {
        const titulo = int.fields.getTextInputValue("titulo_input");
        sorteioHandler.updateDraft(userId, { titulo });
        await int.reply({ content: "✅ Título salvo.", ephemeral: true });
      } else if (cid === "modal_set_descricao") {
        const descricao = int.fields.getTextInputValue("descricao_input");
        sorteioHandler.updateDraft(userId, { descricao });
        await int.reply({ content: "✅ Descrição salva.", ephemeral: true });
      } else if (cid === "modal_set_tempo") {
        const tempo = int.fields.getTextInputValue("tempo_input");
        sorteioHandler.updateDraft(userId, { tempo });
        await int.reply({ content: "✅ Tempo salvo.", ephemeral: true });
      } else if (cid === "modal_set_cargo") {
        const cargo = int.fields.getTextInputValue("cargo_input");
        sorteioHandler.updateDraft(userId, { cargoGanhador: cargo || null });
        await int.reply({ content: "✅ Cargo salvo.", ephemeral: true });
      } else if (cid === "modal_gerenciar_botoes") {
        const btnLabel = int.fields.getTextInputValue("btn_label");
        sorteioHandler.updateDraft(userId, { participationLabel: btnLabel });
        await int.reply({ content: `✅ Botão de participação definido: **${btnLabel}**`, ephemeral: true });
      }
    });

    // função para encerrar e sortear
    async function finishGiveaway(client, giveawayId) {
      const gw = sorteioHandler.getGiveaway(giveawayId);
      if (!gw || gw.ended) return;
      gw.ended = true;
      sorteioHandler.saveGiveaway(gw);

      const channel = await client.channels.fetch(gw.channelId).catch(() => null);
      if (!channel) return;

      // recuperar a mensagem
      let msg;
      try {
        msg = await channel.messages.fetch(gw.messageId);
      } catch (e) {
        msg = null;
      }

      const participants = gw.participants || [];

      let resultText;
      if (participants.length === 0) {
        resultText = "Ninguém participou. ❌";
      } else {
        const winnerId = participants[Math.floor(Math.random() * participants.length)];
        resultText = `🏆 Vencedor: <@${winnerId}>`;

        // atribuir cargo se existir e estiver no servidor
        if (gw.cargoGanhador) {
          try {
            const guild = await client.guilds.fetch(gw.guildId);
            const member = await guild.members.fetch(winnerId);
            const role = guild.roles.cache.get(gw.cargoGanhador);
            if (member && role) await member.roles.add(role).catch(() => {});
          } catch (e) {
            // ignore
          }
        }
      }

      const resultEmbed = new EmbedBuilder()
        .setTitle(gw.titulo)
        .setDescription(`${gw.descricao}\n\n${resultText}`)
        .setColor("#00f0a6")
        .setFooter({ text: `Sorteio encerrado.` });

      // editar mensagem original para mostrar encerrado
      if (msg) {
        try {
          await msg.edit({ embeds: [resultEmbed], components: [] });
        } catch (e) {}
      } else {
        await channel.send({ embeds: [resultEmbed] }).catch(() => {});
      }

      // marque como encerrado
      sorteioHandler.markEnded(gw.id);
    }

    // listener para botões públicos (participação / encerrar)
    client.on("interactionCreate", async (int) => {
      if (!int.isButton()) return;

      const [action, id] = int.customId.split("_"); // esperar formato participar_<id> ou encerrar_<id>
      if (!id) return;

      const gw = sorteioHandler.getGiveaway(id);
      if (!gw) return;

      if (action === "participar") {
          const exists = gw.participants && gw.participants.includes(int.user.id);
          if (exists) {
              return int.reply({ content: "Você já está participando!", ephemeral: true });
          }
      
          gw.participants = gw.participants || [];
          gw.participants.push(int.user.id);
          sorteioHandler.saveGiveaway(gw);
      
          // 👉 Atualizar embed
          const message = int.message;
          const oldEmbed = message.embeds[0];
          const newEmbed = EmbedBuilder.from(oldEmbed);
      
          // altera o campo de participantes
          const updatedFields = newEmbed.data.fields.map(f => {
              if (f.name.includes("Participantes")) {
                  return {
                      name: f.name,
                      value: `\`${gw.participants.length}\``,
                      inline: f.inline
                  };
              }
              return f;
          });
      
          newEmbed.setFields(updatedFields);
      
          await message.edit({ embeds: [newEmbed] });
      
          return int.reply({ content: "🎟️ Você entrou no sorteio!", ephemeral: true });
      }

      if (action === "encerrar") {
        // somente autor ou administrador pode encerrar
        const member = await int.guild.members.fetch(int.user.id);
        const isAuthor = int.user.id === gw.authorId;
        const isAdmin = member.permissions.has("ManageGuild") || member.permissions.has("Administrator");
        if (!isAuthor && !isAdmin) {
          return int.reply({ content: "Somente o autor do sorteio ou um administrador pode encerrar manualmente.", ephemeral: true });
        }

        // executar encerramento imediato
        await int.reply({ content: "⚠️ Encerrando sorteio...", ephemeral: true });
        await finishGiveaway(client, gw.id);
      }
    });
  }
};
