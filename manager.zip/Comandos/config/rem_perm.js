const { change } = require('../../Eventos/config/perms');
module.exports = { name: 'rem_perm', description: 'Remover acesso administrativo.', type: 1,
 options: [{ name: 'usuario', description: 'Usuário que perderá acesso.', type: 6, required: true }],
 run: (client, interaction) => change(interaction, interaction.options.getUser('usuario').id, false) };
