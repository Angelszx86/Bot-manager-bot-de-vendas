const { ApplicationCommandType, PermissionFlagsBits } = require('discord.js');
const { logs } = require('../../databases');
const { isAdmin } = require('../../Lib/permissions');
module.exports={name:'unlock',description:'Restaura o envio de mensagens no canal atual',type:ApplicationCommandType.ChatInput,run:async(client,i)=>{
 if(!i.guild||(!i.memberPermissions?.has(PermissionFlagsBits.ManageChannels)&&!isAdmin(i.user.id))) return i.reply({content:'Você não tem permissão para desbloquear este canal.',ephemeral:true});
 await i.deferReply({ephemeral:true}); const channel=i.channel; const key=`astroSolution.locks.${channel.id}`; const saved=logs.get(key);
 const allow=saved?.sendMessages === true ? true : null;
 await channel.permissionOverwrites.edit(i.guild.roles.everyone,{SendMessages:allow},{reason:`Astra Application • /unlock por ${i.user.tag}`}); logs.delete(key);
 return i.editReply('Canal desbloqueado.');
}};
