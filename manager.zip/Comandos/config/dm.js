const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder
} = require("discord.js");
const { perms } = require("../../databases/index.js");

module.exports = {
  name: 'dm',
  description: '[👑] Envia uma mensagem privada (DM) para um usuário.',
  options: [
    {
      name: "user",
      description: "Usuário",
      type: ApplicationCommandOptionType.User,
      required: true,
    },
    {
      name: "mensagem",
      description: "Mensagem que será enviada",
      type: ApplicationCommandOptionType.String,
      required: true,
    }
  ],
  //usage: '!enviar @usuário mensagem',
  run: async (client, interaction) => {

    if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: "\`❌\` Você não tem permissão para usar este comando.", ephemeral: true })
    };

    
    // Verifica se foi mencionado alguém
    const user = interaction.options.getUser("user");
    const msg = interaction.options.getString("mensagem");
    
    if (!user) {
      return interaction.reply('❌ Você precisa mencionar um usuário para enviar a mensagem.');
    }

    // Remove a menção dos argumentos para formar a mensagem
    /*const mensagem = args.slice(1).join(' ');
    if (!mensagem) {
      return message.reply('❌ Você precisa escrever uma mensagem para enviar.');
    }*/

    try {
      await user.send(`${msg}`);
      await interaction.reply(`✅ Mensagem enviada para ${user.tag}.`);
    } catch (error) {
      console.error('Erro ao enviar DM:', error);
      await interaction.reply('❌ Não foi possível enviar a mensagem. O usuário pode estar com DMs fechadas.');
    }
  },
};