const {
  ApplicationCommandType, ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder, SeparatorBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle, resolveColor
}=require('discord.js');
const trialSettings=require('../../Lib/trialSettings');
const {readCache,fmt,id}=require('../../Lib/managerEmojis');
function withEmoji(builder,emojiId){if(emojiId)builder.setEmoji(emojiId);return builder;}
function configModal(){const cfg=trialSettings.settings();const banner=new TextInputBuilder().setCustomId('banner_url').setLabel('URL DO BANNER (VAZIO = REMOVER)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(1000);if(cfg.bannerUrl)banner.setValue(cfg.bannerUrl.slice(0,1000));return new ModalBuilder().setCustomId('setar_bot_gratis_config').setTitle('Painel de teste gratuito').addComponents(
 new ActionRowBuilder().addComponents(banner),
 new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('panel_title').setLabel('TÍTULO').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100).setValue(cfg.title.slice(0,100))),
 new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('panel_description').setLabel('DESCRIÇÃO').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(1200).setValue(cfg.description.slice(0,1200)))
 );}

function parseDuration(raw){const v=String(raw||'').trim().toLowerCase().replace(/\s+/g,'');const m=v.match(/^(\d+(?:[.,]\d+)?)(min|m|h|d|dia|dias|hora|horas)?$/);if(!m)throw new Error('Use duração como 90min, 12h, 24h, 2d ou número de minutos.');const n=Number(m[1].replace(',','.'));if(!Number.isFinite(n)||n<=0)throw new Error('Duração inválida.');const unit=m[2]||'min';let minutes=unit.startsWith('d')?n*1440:unit.startsWith('h')||unit.startsWith('hora')?n*60:n;minutes=Math.round(minutes);if(minutes<5||minutes>525600)throw new Error('A duração precisa ficar entre 5 minutos e 365 dias.');return minutes;}
function panelPayload(interaction,cfg=trialSettings.settings()){
 const emojis=readCache(interaction.guildId);const c=new ContainerBuilder().setAccentColor((()=>{try{return resolveColor(cfg.accent)}catch{return 0x3155ff}})());
 if(cfg.bannerUrl)c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(cfg.bannerUrl).setDescription('Banner do teste gratuito'))).addSeparatorComponents(new SeparatorBuilder().setDivider(true));
 c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${fmt(emojis,'science')} ${cfg.title}`),new TextDisplayBuilder().setContent(cfg.description));
 const sections=[];
 if(cfg.showHowItWorks)sections.push(`### ${fmt(emojis,'info')} Como funciona\n1. Clique em **${cfg.buttonLabel}**.\n2. O Manager abre um tópico privado.\n3. Informe o token do bot filho e o ID do servidor onde ele já foi convidado.\n4. O período só começa depois que a instância for validada e ficar online.`);
 if(cfg.showDuration)sections.push(`### ${fmt(emojis,'clock')} Duração\nO acesso permanece ativo por **${trialSettings.label(cfg.durationMinutes)}** e é encerrado automaticamente ao vencer.`);
 if(cfg.showSecurity)sections.push(`### ${fmt(emojis,'shield')} Segurança\nO token é usado apenas para preparar a instância solicitada. Nunca envie tokens em canais públicos.`);
 if(sections.length)c.addTextDisplayComponents(new TextDisplayBuilder().setContent(sections.join('\n\n')));
 c.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
 const buttons=[];buttons.push(withEmoji(new ButtonBuilder().setCustomId('botfree').setLabel(`${cfg.buttonLabel} • ${trialSettings.label(cfg.durationMinutes)}`.slice(0,80)).setStyle(ButtonStyle.Primary),id(emojis,'science',null)));
 if(cfg.showSupport&&cfg.supportUrl)buttons.push(withEmoji(new ButtonBuilder().setLabel('Falar com o Suporte').setStyle(ButtonStyle.Link).setURL(cfg.supportUrl),id(emojis,'support',null)||id(emojis,'headset',null)));
 c.addActionRowComponents(new ActionRowBuilder().addComponents(...buttons));return{flags:MessageFlags.IsComponentsV2,components:[c]};
}
module.exports={name:'setar-bot-gratis',description:'Configurar e publicar o painel de teste gratuito',type:ApplicationCommandType.ChatInput,
 run:async(client,interaction)=>{if(!require('../../Lib/permissions').isAdmin(interaction.user.id))return interaction.reply({content:'Você não tem permissão para usar este comando.',flags:64});return interaction.showModal(configModal());},
 modalSubmit:async(client,interaction)=>{if(interaction.customId!=='setar_bot_gratis_config')return;if(!require('../../Lib/permissions').isAdmin(interaction.user.id))return interaction.reply({content:'Você não tem permissão para configurar este painel.',flags:64});if(!interaction.guildId||!interaction.channel?.send)return interaction.reply({content:'Use este comando em um canal de texto.',flags:64});
  try{const bannerUrl=interaction.fields.getTextInputValue('banner_url').trim();if(bannerUrl&&!trialSettings.validUrl(bannerUrl))throw new Error('O banner precisa ser uma URL HTTPS válida.');const cfg={...trialSettings.settings(),bannerUrl,title:interaction.fields.getTextInputValue('panel_title').trim(),description:interaction.fields.getTextInputValue('panel_description').trim()};await interaction.deferReply({flags:64});const sent=await interaction.channel.send(panelPayload(interaction,cfg));trialSettings.save(cfg);return interaction.editReply({content:`Painel publicado: ${sent.url} • duração ${trialSettings.label(cfg.durationMinutes)}.`});}catch(error){const msg=String(error?.message||error).slice(0,700);if(interaction.deferred)return interaction.editReply({content:`Não foi possível publicar: ${msg}`});return interaction.reply({content:`Não foi possível publicar: ${msg}`,flags:64});}
 },_test:{currentConfig:trialSettings.settings,panelPayload,configModal,parseDuration}};
