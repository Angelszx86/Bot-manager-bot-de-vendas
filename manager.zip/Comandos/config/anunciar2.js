const {
  MessageFlags,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ThumbnailBuilder,
  SectionBuilder,
  ChannelSelectMenuBuilder,
  ActionRowBuilder,
  ContainerBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ButtonBuilder,
  ButtonStyle,
  FileBuilder,
  ApplicationCommandType,
  ApplicationCommandOptionType,
  AttachmentBuilder
} = require('discord.js');
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");
const path = require('path');

module.exports = {
  name: "anunciar-moderno",
  description: "[⭐] Anuncie algo em ComponentesV2",
  type: ApplicationCommandType.ChatInput,
  options: [
  {
      name: "txt_datadoup",
      description: "Update dia: tal que será enviado",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "txt_nov",
      description: "Texto das Novidades que será enviado",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "txt_melhorias",
      description: "Texto das Melhorias que será enviado",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "txt_embreve",
      description: "Texto das Melhorias que será enviado",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction) => {

    if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: "\`❌\` Você não tem permissão para usar este comando.", ephemeral: true })
    };

    //const img1 = interaction.options.getUser("Imagem1");
    const text1 = interaction.options.getString("txt_nov");
    const text2 = interaction.options.getString("txt_datadoup");
    const text3 = interaction.options.getString("txt_melhorias");
    const text4 = interaction.options.getString("txt_embreve");
    
    const container = new ContainerBuilder()
      .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL("https://cdn.discordapp.com/attachments/1442689111117791332/1443270230221656174/wmremove-transformed.jpg?ex=692875a5&is=69272425&hm=b09f0bebc657d01855b166e17733cd17ffb6cab4be9b5e031493f16c3a8eb49c&")))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`# Atualização do dia: ${text2}`),
        new TextDisplayBuilder().setContent(`## \`📄\` Novidades:\n${text1}`),
        new TextDisplayBuilder().setContent(`## \`⚙️\` Melhorias/Fix:\n${text3}`),
        new TextDisplayBuilder().setContent(`## \`⏰\` Em breve:\n${text4}`),
        /*new TextDisplayBuilder().setContent()*/
        new TextDisplayBuilder().setContent("**Atenciosamente**,\n- Equipe da Astra Application\n-# **Astra Application** - Tecnologia e Inovação")
      )

      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      //.addFileComponents(fileComponent);

    await interaction.reply({
      flags: MessageFlags.IsComponentsV2,
      components: [container],
      files: []
    });
  }
}