const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle
} = require('discord.js');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');

module.exports = {
  name: 'hospedar-imagem',
  description: '[📤] Hospeda uma imagem na Square Cloud via URL (inclusive imagens do Discord)',
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'url',
      description: 'URL da imagem (pode ser do Discord ou externa)',
      type: ApplicationCommandOptionType.String,
      required: true
    }
  ],

  run: async (client, interaction) => {
    const imageUrl = interaction.options.getString('url');

    const isValidUrl = /^https?:\/\/.+\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i.test(imageUrl);
    if (!isValidUrl) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ URL inválida!')
            .setDescription('A URL precisa apontar diretamente para uma imagem válida (`.jpg`, `.png`, `.gif`, etc).')
            .setColor('#ff0000')
        ],
        ephemeral: true
      });
    }

    await interaction.deferReply({ ephemeral: true });

    const extension = imageUrl.split('.').pop().split('?')[0];
    const imageName = `imagem-${Date.now()}.${extension}`;
    const filePath = path.join(__dirname, '..', '..', 'temp', imageName);

    try {
      const response = await fetch(imageUrl);
      if (!response.ok) throw new Error(`Erro ao baixar imagem. Status: ${response.status}`);

      const buffer = await response.buffer();
      fs.writeFileSync(filePath, buffer);

      const form = new FormData();
      form.append('file', fs.createReadStream(filePath));

      const upload = await fetch('https://api.squarecloud.app/v2/project/files/upload', {
        method: 'POST',
        headers: {
          Authorization: '883ccc8e0eadb79956c196c88cb8d55802c30700-93d0aeceaaf7de3bb6943d3e9bcdbdbb29780eb3dbe3f47da56fa3e63cfdbdb8',
          'project-id': '43f3cb8a260140898a132c9ee6d5233a'
        },
        body: form
      });

      const json = await upload.json();
      if (!json.success) throw new Error(json.message || 'Erro ao hospedar na Square Cloud.');

      const embed = new EmbedBuilder()
        .setTitle('✅ Imagem hospedada com sucesso!')
        .setColor('#00ff99')
        .setThumbnail(imageUrl)
        .addFields(
          { name: '🖼️ Nome do Arquivo', value: `\`${imageName}\`` },
          { name: '📁 Caminho no Projeto', value: `\`${json.data.path}\`` }
        )
        .setFooter({ text: 'Square Cloud - Upload de Arquivos', iconURL: 'https://squarecloud.app/favicon.ico' })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('📎 Ver imagem original')
          .setStyle(ButtonStyle.Link)
          .setURL(imageUrl)
      );

      await interaction.editReply({ embeds: [embed], components: [row] });

    } catch (err) {
      console.error('Erro ao hospedar imagem:', err);

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Erro durante o processo')
            .setDescription(`\`\`\`${err.message}\`\`\``)
            .setColor('#ff0000')
        ]
      });
    } finally {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
  }
};