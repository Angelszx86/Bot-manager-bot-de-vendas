const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType
} = require("discord.js");
const fs = require("fs");
const path = require("path");

const { isAdmin } = require("../../Lib/permissions");
const CONFIG_PATH = path.join(__dirname, "../../databases/faq_config.json");

module.exports = {
  name: "faq",
  description: "[🤖] Envie a mensagem sobre os termos e faq",
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "canal",
      description: "Selecione o canal onde o painel será enviado",
      type: ApplicationCommandOptionType.Channel,
      required: false
    }
  ],

  run: async (client, interaction) => {
    try {
      if (!isAdmin(interaction.user.id)) {
        return interaction.reply({
          content: "`❌` Você não tem permissão para usar este comando.",
          ephemeral: true,
        });
      }

      const canalAlvo = interaction.options.getChannel("canal") || interaction.channel;

      let faqData = {
          titulo: "Faq e Termos da Astra Application",
          descricao: "⚡ Na **Astra Application**, oferecemos uma variedade de bots Discord de alta qualidade, desde moderação até música e utilidade. Com suporte excepcional e atualizações regulares, estamos aqui para elevar a sua experiência no Discord. Visite nossa loja hoje mesmo e descubra como podemos melhorar o seu servidor!\n\n👑 **Astra Application no Topo!**",
          imagem: null
      };

      if (fs.existsSync(CONFIG_PATH)) {
          faqData = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
      }

      const embed = new EmbedBuilder()
        .setTitle(faqData.titulo)
        .setDescription(faqData.descricao.replace(/\\n/g, "\n"))
        .setColor("#5865F2")
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }) || null)
        .setFooter({ text: "Astra Application — Desenvolvendo o futuro." })
        .setTimestamp();

      if (faqData.imagem) {
          embed.setImage(faqData.imagem);
      }

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("info_terms")
          .setLabel("Termos de uso")
          .setEmoji("🔧")
          .setStyle(ButtonStyle.Primary),

        new ButtonBuilder()
          .setCustomId("faq")
          .setLabel("Faq (Dúvidas Frequentes)")
          .setEmoji("🔧")
          .setStyle(ButtonStyle.Primary),

        new ButtonBuilder()
          .setLabel("Dúvidas")
          .setEmoji("🔧")
          .setStyle(ButtonStyle.Link)
          .setURL("https://discord.com/channels/1488667900775501854/1519894827372646502")
      );

      // Tenta enviar PRIMEIRO
      await canalAlvo.send({
        embeds: [embed],
        components: [row],
      });

      // Se o envio acima falhar, o código cai no catch e não executa o reply de sucesso
      await interaction.reply({
        content: `✅ Mensagem enviada com sucesso no canal ${canalAlvo}!`,
        ephemeral: true,
      });

    } catch (error) {
      console.error("Erro ao executar o comando faq:", error);
      
      let msgErro = "❌ Ocorreu um erro ao tentar enviar o painel.";
      if (error.code === 50001 || error.code === 50013) {
          msgErro = "❌ Eu não tenho permissão para enviar mensagens ou embeds nesse canal!";
      }

      if (!interaction.replied) {
          await interaction.reply({
            content: msgErro,
            ephemeral: true
          });
      }
    }
  },
};
