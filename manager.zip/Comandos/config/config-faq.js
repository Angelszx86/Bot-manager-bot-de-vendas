const {
  ApplicationCommandType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");

const { isAdmin } = require("../../Lib/permissions");

module.exports = {
  name: "config-faq",
  description: "[⚙️] Configure a mensagem do FAQ",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    try {
      if (!isAdmin(interaction.user.id)) {
        return interaction.reply({
          content: "`❌` Você não tem permissão para usar este comando.",
          ephemeral: true,
        });
      }

      const embed = new EmbedBuilder()
        .setTitle("⚙️ Configuração do FAQ")
        .setDescription("Clique no botão abaixo para configurar o conteúdo da mensagem do FAQ (Título, Descrição e Imagem).")
        .setColor("#5865F2");

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("configurar_faq_modal")
          .setLabel("Configurar Mensagem")
          .setEmoji("📝")
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
        ephemeral: true
      });

    } catch (error) {
      console.error("Erro ao executar o comando config-faq:", error);
      await interaction.reply({ content: "❌ Erro ao abrir painel de configuração.", ephemeral: true });
    }
  },
};
