const {
  ApplicationCommandType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");
const { db } = require("../../databases/index");
const emojis = require("../../databases/emojis.json");

module.exports = {
  name: "infoss",
  description: "[📌] Exibe o painel com informações e suporte",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    try {
      await interaction.deferReply({ ephemeral: false });

      const embed = new EmbedBuilder()
        .setTitle("📌 Central de Informações Astra Application")
        .setDescription([
          "Aqui você encontra tudo que precisa saber para utilizar a **Astra Application** com segurança e eficiência.",
          "",
          "Use os botões abaixo para acessar documentos importantes, verificar regras da comunidade ou abrir um chamado com o suporte."
        ].join("\n"))
        .setColor("Blurple")
        .setAuthor({
          name: 'Painel de Informações',
          iconURL: 'https://public-blob.squarecloud.dev/883ccc8e0eadb79956c196c88cb8d55802c30700/simple_solutions/simple_mdwa232f-df0d.jpg'
        })
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setImage("https://cdn.discordapp.com/attachments/123456789012345678/123456789012345678/banner.png")
        .setFooter({
          text: `Solicitado por ${interaction.user.username}`,
          iconURL: interaction.user.displayAvatarURL()
        })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("info_termos")
          .setLabel("Termos de Uso")
          .setEmoji(emojis.term || "📘")
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId("info_politicas")
          .setLabel("Políticas")
          .setEmoji(emojis.policy || "📜")
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setCustomId("info_regras")
          .setLabel("Regras")
          .setEmoji(emojis.rules || "📌")
          .setStyle(ButtonStyle.Secondary),

        new ButtonBuilder()
          .setLabel("Suporte")
          .setEmoji(emojis.helpp || "🛠️")
          .setStyle(ButtonStyle.Link)
          .setURL("https://discord.com/channels/1312428786591076463/1399744766350065706")
      );

      await interaction.editReply({
        embeds: [embed],
        components: [row]
      });

    } catch (err) {
      console.error("[ERRO NO COMANDO /infoss]", err);
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({ content: "❌ Ocorreu um erro ao exibir o painel de informações." });
      } else {
        await interaction.reply({ content: "❌ Não foi possível exibir as informações.", ephemeral: true });
      }
    }
  }
};
