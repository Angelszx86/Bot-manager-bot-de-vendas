const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  EmbedBuilder,
  ButtonBuilder,
  ActionRowBuilder
} = require("discord.js");
const { perms } = require("../../databases/index.js");

/* By Gazztuy!!!! */

module.exports = {
  name: "mass_dm",
  description: "[📨] Enviar mensagem na DM de todos os membros.",
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "titulo",
      description: "Título do Embed",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "descricao",
      description: "Descrição da mensagem",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "footer_texto",
      description: "Texto do Rodapé da Embed",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "footer_url",
      description: "Imagem do rodapé da embed",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "autor",
      description: "Nome do autor",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "icone_autor",
      description: "URL do ícone do autor",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "banner",
      description: "URL da imagem/banner",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "botao_texto",
      description: "Texto do botão",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "botao_url",
      description: "URL do botão",
      type: ApplicationCommandOptionType.String,
      required: false,
    },
    {
      name: "botao_emoji",
      description: "Emoji do botão",
      type: ApplicationCommandOptionType.String,
      required: false,
    }
  ],

  run: async (client, interaction) => {
    if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: "\`❌\` Você não tem permissão para usar este comando.", ephemeral: true })
        };
    
    
    const titulo = interaction.options.getString("titulo");
    const descricao = interaction.options.getString("descricao");
    const footerNm = interaction.options.getString("footer_texto");
    const footerURL = interaction.options.getString("footer_url");
    const autor = interaction.options.getString("autor");
    const iconeAutor = interaction.options.getString("icone_autor");
    const banner = interaction.options.getString("banner");
    const botaoTexto = interaction.options.getString("botao_texto");
    const botaoURL = interaction.options.getString("botao_url");
    const botaoEmoji = interaction.options.getString("botao_emoji");

    const embed = new EmbedBuilder()
      .setTitle(titulo)
      .setDescription(descricao)
      .setColor("#00b0f4")
      .setTimestamp();

    if (autor && iconeAutor) embed.setAuthor({ name: autor, iconURL: iconeAutor });
    if (banner) embed.setImage(banner);
    if (footerNm && footerURL) embed.setFooter({ name: footerNm, iconURL: footerURL})

    const row = new ActionRowBuilder();
    if (botaoTexto && botaoURL) {
      row.addComponents(
        new ButtonBuilder()
          .setLabel(botaoTexto)
          .setStyle(5)
          .setURL(botaoURL)
          .setEmoji(botaoEmoji || "✨")
      );
    }

    const membros = await interaction.guild.members.fetch();
    let enviados = 0;

    interaction.reply({ content: `\`🔄\` Enviando mensagens para os membros...`, ephemeral: true });

    for (const membro of membros.values()) {
      if (membro.user.bot) continue;
      try {
        await membro.send({
          embeds: [embed],
          components: row.components.length > 0 ? [row] : []
        });
        enviados++;
      } catch (err) {
        continue; 
      }
    }

    interaction.followUp({
      content: `\`✅\` Mensagem enviada para \`${enviados}\` membros com sucesso.`,
      ephemeral: true
    });
  }
};