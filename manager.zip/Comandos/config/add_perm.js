const { isOwner } = require('../../Lib/permissions');
const { modal, change } = require('../../Eventos/config/perms');
module.exports = { name: 'add_perm', description: 'Conceder acesso administrativo ao manager.', type: 1,
  options: [{ name: 'usuario', description: 'Usuário que receberá acesso.', type: 6, required: false }],
  async run(client, interaction) {
    if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Apenas o dono pode conceder acesso.', flags: 64 });
    const user = interaction.options.getUser('usuario');
    return user ? change(interaction, user.id, true) : interaction.showModal(modal(true));
  }
};
