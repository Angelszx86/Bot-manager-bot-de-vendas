const { ApplicationCommandType, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: "configurar-cargos",
    description: "[👷] Cria e organiza todos os cargos do servidor para vendas de bots",
    type: ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: "❌ Você precisa ser administrador para usar este comando.", ephemeral: true });
        }

        await interaction.reply({ content: "🔧 Iniciando configuração dos cargos, aguarde...", ephemeral: true });

        const cargoInfo = [
            { name: 'xxx', color: '#000000', reason: 'Cargo de Owner' },
            { name: 'SubOwner', color: '#00BFFF', reason: 'Dono secundário' },
            { name: 'Diretor', color: '#FFA500', reason: 'Gerência' },
            { name: 'Applicativos', color: '#800080', reason: 'Bots do sistema' },
            { name: 'Developer', color: '#0000FF', reason: 'Desenvolvedores' },
            { name: 'Suporte', color: '#FFFF00', reason: 'Equipe de suporte' },
            { name: 'Friend', color: '#FFC0CB', reason: 'Amigos pessoais' },
            { name: 'Booster 2X', color: '#FF69B4', reason: 'Boosters do servidor' },
            { name: 'Consumers', color: '#FFFACD', reason: 'Clientes' },
            { name: 'Membros', color: '#FFFFFF', reason: 'Todos os membros' },
            { name: 'Verificado', color: '#00FF00', reason: 'Membro verificado' }
        ];

        const ignorarBots = ['Loritta', 'RioBot', 'Invite Tracker'];
        const guild = interaction.guild;
        let criados = 0;

        try {
            // Cria os novos cargos
            for (const cargo of cargoInfo.reverse()) {
                if (guild.roles.cache.some(role => role.name === cargo.name)) continue;
                try {
                    await guild.roles.create({
                        name: cargo.name,
                        color: cargo.color,
                        hoist: true,
                        mentionable: true,
                        reason: cargo.reason
                    });
                    criados++;
                } catch {}
            }

            await interaction.followUp({
                content: `✅ Cargos configurados com sucesso!\n📌 Cargos criados: ${criados}/${cargoInfo.length}`,
                ephemeral: true
            });

        } catch (err) {
            console.log("Erro na configuração de cargos:", err);
            await interaction.followUp({ content: "❌ Ocorreu um erro ao configurar os cargos.", ephemeral: true });
        }
    }
};