const { ApplicationCommandType, MessageFlags, PermissionFlagsBits } = require('discord.js');
const { pagePayload } = require('../../Lib/botconfigPages');
const { ensureManagerEmojis } = require('../../Lib/managerEmojis');

module.exports = {
  name: 'botconfig',
  description: '[Astra Application] Abrir o painel administrativo do Manager.',
  type: ApplicationCommandType.ChatInput,
  options: [],
  run: async (client, interaction) => {
    const isServerAdministrator = Boolean(
      interaction.inGuild?.() && interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)
    );
    if (!isServerAdministrator) {
      return interaction.reply({ content: 'Você precisa ter a permissão **Administrador** neste servidor para usar este comando.', flags: 64 });
    }
    await ensureManagerEmojis(interaction).catch(() => null);
    return interaction.reply(pagePayload(client, interaction, 0));
  }
};
