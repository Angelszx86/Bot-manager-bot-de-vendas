const { ApplicationCommandType, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");
const axios = require('axios');
const { JsonDatabase } = require("wio.db");
const fs = require('fs');

const config = require("../../config.json");

/*
const api = new JsonDatabase({ databasePath: "./DatabaseJson/apis.json" });
const auto = new JsonDatabase({ databasePath: "./DatabaseJson/autocomplete.json" });
const logs = new JsonDatabase({ databasePath: "./DatabaseJson/logs.json" });
const perms = new JsonDatabase({ databasePath: "./DatabaseJson/perms.json" });
const db = new JsonDatabase({ databasePath: "./DatabaseJson/applications.json" });*/

const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");

module.exports = {
    name: "timeapp",
    description: "[🤖] Gerencie o Tempo das aplicações",
    type: ApplicationCommandType.ChatInput,
    run: async (client, interaction) => {
        try {
            if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: `\`❌\` Você não tem permissão para usar este comando.`, ephemeral: true })
        };

            await interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`Adicionar/Remover Tempo de Aplicação`)
                        .setDescription(`Olá ***${interaction.user.username}***, seja bem-vindo(a) ao painel de gerenciamento de tempo. Escolha uma das opções abaixo!`)
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_addtimeapp`)
                                .setLabel("Adicionar Tempo")
                                .setEmoji("➕")
                                .setStyle(2), 
                            new ButtonBuilder()
                                .setCustomId(`${interaction.user.id}_removetimeapp`)
                                .setLabel("Remover Tempo")
                                .setEmoji("➖")
                                .setStyle(2),   
                        )
                ],
                ephemeral: true 
            });
        } catch (error) {
            console.error("Erro ao executar o comando timeapp:", error);
            interaction.reply({
                content: "Ocorreu um erro ao executar o comando. Por favor, tente novamente mais tarde.",
                ephemeral: true
            });
        }
    }
}