const ms = require('ms');
const { isAdmin } = require('../../Lib/permissions');
module.exports = { name: 'mute', description: 'Silencia um membro com timeout do Discord.', type: 1,
 options: [
  { name: 'usuário', type: 6, description: 'Membro que será silenciado.', required: true },
  { name: 'tempo', type: 3, description: 'Duração: 10m, 1h ou 1d. Padrão: 10m.' },
  { name: 'motivo', type: 3, description: 'Motivo do timeout.' }
 ],
 async run(client, interaction) {
  if (!isAdmin(interaction.user.id)) return interaction.reply({ content: 'Sem permissão para usar este comando.', flags: 64 });
  const duration = ms(interaction.options.getString('tempo') || '10m');
  if (!Number.isFinite(duration) || duration <= 0 || duration > 28 * 86400000) return interaction.reply({ content: 'Informe uma duração entre 1 segundo e 28 dias.', flags: 64 });
  await interaction.deferReply({ flags: 64 });
  const user = interaction.options.getUser('usuário');
  const member = await interaction.guild.members.fetch(user.id).catch(() => null);
  if (!member?.moderatable) return interaction.editReply('Não posso silenciar esse membro. Confira a hierarquia e a permissão Moderar membros.');
  await member.timeout(duration, interaction.options.getString('motivo') || 'Timeout aplicado pelo manager');
  return interaction.editReply(`Timeout aplicado a <@${user.id}>. O Discord removerá a restrição automaticamente.`);
 }
};
