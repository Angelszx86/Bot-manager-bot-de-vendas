const {
  ApplicationCommandType,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
  ChannelType
} = require('discord.js');
const { perms } = require("../../databases/index.js");

module.exports = {
  name: 'createwebhook',
  description: '[⚙️] Cria um Webhook em um canal específico',
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: 'name',
      description: 'Nome do Webhook',
      type: ApplicationCommandOptionType.String,
      required: true
    },
    {
      name: 'channel',
      description: 'Canal onde o webhook será criado',
      type: ApplicationCommandOptionType.Channel,
      required: true,
      channelTypes: [ChannelType.GuildText]
    }
  ],

  run: async (client, interaction) => {
    const name = interaction.options.getString('name');
    const channel = interaction.options.getChannel('channel');

    // Verifica se o usuário tem permissão no sistema
    const usuariosPermitidos = perms.get(`usersPerms`) || [];
    if (!usuariosPermitidos.includes(interaction.user.id)) {
      return interaction.reply({
        content: '🚫 Você não tem permissão para usar este comando.',
        ephemeral: true
      });
    }

    // Verifica se o bot pode gerenciar webhooks nesse canal
    const botPermissions = channel.permissionsFor(interaction.guild.members.me);
    if (!botPermissions || !botPermissions.has(PermissionFlagsBits.ManageWebhooks)) {
      return interaction.reply({
        content: '❌ Eu não tenho permissão para **Gerenciar Webhooks** nesse canal.',
        ephemeral: true
      });
    }

    try {
      const webhook = await channel.createWebhook({
        name,
        reason: `Webhook criado por ${interaction.user.tag}`
      });

      return interaction.reply({
        content: `✅ Webhook criado com sucesso!\n🔗 URL: \`${webhook.url}\``,
        ephemeral: false
      });
    } catch (error) {
      console.error(`[ERRO] Falha ao criar webhook:`, error);
      return interaction.reply({
        content: '❌ Ocorreu um erro inesperado ao tentar criar o webhook.',
        ephemeral: true
      });
    }
  }
};