const Discord = require("discord.js");
const {ButtonBuilder,EmbedBuilder,ActionRowBuilder,} = require('discord.js')
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");


module.exports = {
    name: "nuke",
    description: "[🗑️] Resetar um Canal e tirar marcações",
    type: Discord.ApplicationCommandType.ChatInput,
    defaultMemberPermissions: Discord.PermissionFlagsBits.Administrator,
    exclusive: true,
    options: [
        {
            name: 'canal',
            type: Discord.ApplicationCommandOptionType.Channel,
            channelTypes: [Discord.ChannelType.GuildText, Discord.ChannelType.GuildVoice],
            description: 'Canal que deseja resetar',
            required: false
        }
    ],

    run: async (client, interaction) => {

        if (!require('../../Lib/permissions').isAdmin(interaction.user.id)) {
            return interaction.reply({ content: `\`❌\` Você não tem permissão para usar este comando.`, ephemeral: true })
        };

      
        const channel = interaction.options.getChannel('canal') || interaction.channel

        await interaction.reply({content: `Resetando o canal ${channel}...`, ephemeral: true})
        const newChannel = await channel.clone()
        await channel.delete()

        newChannel.send({content: `\`Nucked by ${interaction.user.username}\``})

    }
}