/* Idempotent migration for application records. Run automatically by deployment tooling when needed. */
const { db2 } = require('../databases');
for (const row of db2.all()) {
  const id=String(row.ID||''); if (!id) continue;
  const app=row.data||{};
  if (!app.provider) db2.set(`${id}.provider`, 'shardcloud');
  if (!app.desiredState) db2.set(`${id}.desiredState`, String(app.status||'stopped').toLowerCase()==='online'?'running':'stopped');
}
console.log('Provider state migration complete.');
