import { mkdirSync, existsSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } from "discord.js";
import type { Client, Message } from "discord.js";
import type { CredentialStore } from "../core/credential-store.js";
import type { Logger } from "../core/logger.js";
import type { PaymentManager } from "./payments.js";
import type { PaymentCharge, PaymentProviderName } from "../types.js";
import { makeId, nowIso } from "../core/utils.js";
import { renderRobloxProfilePng, renderRobuxCalculationPng, renderRobuxPurchasePng } from "./robux-image.js";

export type RobuxDeliveryMode = "MANUAL" | "ASSISTED" | "COOKIE_AUTO" | "WEBHOOK";

export interface RobuxSettings {
  enabled: boolean;
  manualShortcutEnabled: boolean;
  autoDelivery: boolean;
  deliveryMode: RobuxDeliveryMode;
  deliveryWebhookUrl: string;
  deliveryAccountName: string;
  calculatorEnabled: boolean;
  calculatorFormat: "PNG" | "EMBED";
  calculatorChannelId: string;
  publicChannelId: string;
  logChannelId: string;
  title: string;
  description: string;
  bannerUrl: string;
  announcementChannelId: string;
  announcementFormat: "PNG" | "EMBED";
  announcementEnabled: boolean;
  pricePer1000Cents: number;
  minRobux: number;
  maxRobux: number;
  maxGamepasses: number;
  paymentProvider: PaymentProviderName | "AUTO";
  panelMessageId: string;
  panelChannelId: string;
  updatedAt: string;
}

export interface RobloxUser {
  id: number;
  name: string;
  displayName: string;
  description?: string;
  createdAt?: string;
  isBanned?: boolean;
}
export interface RobloxGamepass { id: number; name: string; price: number; productId?: number; sellerId?: number; }
export interface RobuxCalculation {
  requestedRobux: number;
  gamepassPrice: number;
  estimatedNetRobux: number;
  amountCents: number;
  pricePer1000Cents: number;
}

export interface RobuxOrder {
  id: string;
  guildId: string;
  discordUserId: string;
  discordUsername: string;
  robloxUserId: number;
  robloxUsername: string;
  robloxDisplayName?: string;
  gamepassId: number;
  gamepassName: string;
  requestedRobux: number;
  gamepassPrice: number;
  amountCents: number;
  provider: PaymentProviderName;
  externalId: string;
  paymentStatus: PaymentCharge["status"];
  status: "PENDING_PAYMENT" | "PAID" | "DELIVERING" | "DELIVERED" | "DELIVERY_REVIEW" | "CANCELED" | "EXPIRED";
  pixCode?: string;
  qrCodeDataUrl?: string;
  createdAt: string;
  updatedAt: string;
  deliveredAt?: string;
  error?: string;
  announcedAt?: string;
  deliveryAnnouncementAt?: string;
  deliveryReceiptSentAt?: string;
  purchaseThreadId?: string;
  purchaseMessageId?: string;
  paymentConfirmationRequestedAt?: string;
  gamepassProductId?: number;
  gamepassSellerId?: number;
  gamepassUrlOverride?: string;
  awaitingGamepassLink?: boolean;
  awaitingRobloxIdentity?: boolean;
  payerFullName?: string;
  payerDocument?: string;
  payerBankName?: string;
  sellerPaymentConfirmedAt?: string;
}

interface RobuxDocument {
  settings: Record<string, RobuxSettings>;
  orders: Record<string, RobuxOrder>;
}

const DEFAULT_SETTINGS: Omit<RobuxSettings, "updatedAt"> = {
  enabled: false,
  manualShortcutEnabled: true,
  autoDelivery: false,
  deliveryMode: "ASSISTED",
  deliveryWebhookUrl: "",
  deliveryAccountName: "",
  calculatorEnabled: true,
  calculatorFormat: "PNG",
  calculatorChannelId: "",
  publicChannelId: "",
  logChannelId: "",
  title: "LOJA DE ROBUX",
  description: "Compre Robux usando uma gamepass da sua conta. Informe seu usuário Roblox, escolha uma gamepass e conclua o pagamento.",
  bannerUrl: "",
  announcementChannelId: "",
  announcementFormat: "PNG",
  announcementEnabled: false,
  pricePer1000Cents: 2500,
  minRobux: 50,
  maxRobux: 50000,
  maxGamepasses: 25,
  paymentProvider: "AUTO",
  panelMessageId: "",
  panelChannelId: ""
};

function cleanText(value: unknown, max = 300): string { return String(value ?? "").replace(/[\r\n\t]+/g, " ").trim().slice(0, max); }
function safeError(error: unknown): string {
  const raw = error instanceof Error ? error.message : String(error);
  return raw
    .replace(/\.ROBLOSECURITY\s*=\s*[^;\s]+/gi, ".ROBLOSECURITY=[REDACTED]")
    .replace(/cookie\s*[:=]\s*[^\s,;]+/gi, "cookie=[REDACTED]")
    .slice(0, 500);
}
function clampInt(value: unknown, min: number, max: number, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.trunc(n))) : fallback;
}
function jsonRecord(value: unknown): Record<string, unknown> { return value && typeof value === "object" ? value as Record<string, unknown> : {}; }
function safeDeliveryUrl(value: string): string {
  const raw = value.trim();
  if (!raw) return "";
  let url: URL;
  try { url = new URL(raw); } catch { throw new Error("URL da integração de entrega inválida."); }
  if (url.protocol !== "https:") throw new Error("A integração de entrega precisa usar HTTPS.");
  const host = url.hostname.toLowerCase();
  if (host === "localhost" || host === "::1" || host.endsWith(".local") || /^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host)) throw new Error("Host privado/local não é permitido para a integração de entrega.");
  const m = host.match(/^172\.(\d{1,3})\./);
  if (m && Number(m[1]) >= 16 && Number(m[1]) <= 31) throw new Error("Host privado/local não é permitido para a integração de entrega.");
  url.username = ""; url.password = "";
  return url.toString();
}

export class RobuxService {
  private readonly path: string;
  private state: RobuxDocument;
  private timer?: NodeJS.Timeout;
  private readonly updateListeners = new Set<(order: RobuxOrder) => void | Promise<void>>();
  private readonly calculatorIntentWarnings = new Map<string, number>();
  private readonly calculatorNickRequests = new Map<string, number>();
  private readonly deliveryLocks = new Set<string>();

  constructor(
    private readonly client: Client,
    private readonly credentials: CredentialStore,
    private readonly payments: PaymentManager,
    private readonly logger: Logger,
    path = "database/robux.json"
  ) {
    this.path = resolve(path);
    mkdirSync(dirname(this.path), { recursive: true });
    this.state = this.load();
  }

  private load(): RobuxDocument {
    if (!existsSync(this.path)) return { settings: {}, orders: {} };
    try {
      const parsed = JSON.parse(readFileSync(this.path, "utf8")) as Partial<RobuxDocument>;
      return {
        settings: parsed.settings && typeof parsed.settings === "object" ? parsed.settings : {},
        orders: parsed.orders && typeof parsed.orders === "object" ? parsed.orders : {}
      };
    } catch (error) {
      this.logger.warn("Banco do módulo Robux inválido; um novo estado vazio será usado.", { error: safeError(error) });
      return { settings: {}, orders: {} };
    }
  }

  private save(): void {
    mkdirSync(dirname(this.path), { recursive: true });
    const tmp = `${this.path}.${process.pid}.${Date.now()}.tmp`;
    writeFileSync(tmp, `${JSON.stringify(this.state, null, 2)}\n`, "utf8");
    renameSync(tmp, this.path);
  }

  onUpdate(listener: (order: RobuxOrder) => void | Promise<void>): () => void {
    this.updateListeners.add(listener);
    return () => this.updateListeners.delete(listener);
  }

  private async emitUpdate(order: RobuxOrder): Promise<void> {
    for (const listener of this.updateListeners) {
      try { await listener({ ...order }); }
      catch (error) { this.logger.warn("Falha ao atualizar a interface de um pedido Robux.", { orderId: order.id, error: safeError(error) }); }
    }
  }

  settings(guildId: string): RobuxSettings {
    const existing = this.state.settings[guildId];
    if (!existing) {
      const created: RobuxSettings = { ...DEFAULT_SETTINGS, updatedAt: nowIso() };
      this.state.settings[guildId] = created;
      this.save();
      return created;
    }
    const normalized: RobuxSettings = {
      ...DEFAULT_SETTINGS,
      ...existing,
      pricePer1000Cents: clampInt(existing.pricePer1000Cents, 1, 10_000_000, DEFAULT_SETTINGS.pricePer1000Cents),
      minRobux: clampInt(existing.minRobux, 1, 1_000_000, DEFAULT_SETTINGS.minRobux),
      maxRobux: clampInt(existing.maxRobux, 1, 10_000_000, DEFAULT_SETTINGS.maxRobux),
      maxGamepasses: clampInt(existing.maxGamepasses, 1, 25, DEFAULT_SETTINGS.maxGamepasses),
      deliveryMode: (["MANUAL", "ASSISTED", "COOKIE_AUTO", "WEBHOOK"] as string[]).includes(String(existing.deliveryMode)) ? existing.deliveryMode : DEFAULT_SETTINGS.deliveryMode,
      deliveryWebhookUrl: typeof existing.deliveryWebhookUrl === "string" ? existing.deliveryWebhookUrl.trim() : "",
      deliveryAccountName: typeof existing.deliveryAccountName === "string" ? cleanText(existing.deliveryAccountName, 80) : "",
      manualShortcutEnabled: existing.manualShortcutEnabled === undefined ? true : Boolean(existing.manualShortcutEnabled),
      calculatorFormat: existing.calculatorFormat === "EMBED" ? "EMBED" : "PNG",
      updatedAt: existing.updatedAt || nowIso()
    };
    if (normalized.maxRobux < normalized.minRobux) normalized.maxRobux = normalized.minRobux;
    if (!normalized.title || normalized.title === "ZENYX APPLICATIONS • ROBUX") normalized.title = `${this.client.guilds.cache.get(guildId)?.name || "Servidor"} • ROBUX`;
    this.state.settings[guildId] = normalized;
    return normalized;
  }

  updateSettings(guildId: string, patch: Partial<RobuxSettings>): RobuxSettings {
    const current = this.settings(guildId);
    const next: RobuxSettings = {
      ...current,
      ...patch,
      title: patch.title === undefined ? current.title : cleanText(patch.title, 100),
      description: patch.description === undefined ? current.description : String(patch.description).trim().slice(0, 1800),
      bannerUrl: patch.bannerUrl === undefined ? current.bannerUrl : String(patch.bannerUrl || "").trim().slice(0, 1000),
      announcementChannelId: patch.announcementChannelId === undefined ? current.announcementChannelId : String(patch.announcementChannelId || "").trim(),
      announcementFormat: patch.announcementFormat === undefined ? current.announcementFormat : (patch.announcementFormat === "EMBED" ? "EMBED" : "PNG"),
      announcementEnabled: patch.announcementEnabled === undefined ? current.announcementEnabled : Boolean(patch.announcementEnabled),
      manualShortcutEnabled: patch.manualShortcutEnabled === undefined ? current.manualShortcutEnabled : Boolean(patch.manualShortcutEnabled),
      calculatorFormat: patch.calculatorFormat === undefined ? current.calculatorFormat : (patch.calculatorFormat === "EMBED" ? "EMBED" : "PNG"),
      pricePer1000Cents: patch.pricePer1000Cents === undefined ? current.pricePer1000Cents : clampInt(patch.pricePer1000Cents, 1, 10_000_000, current.pricePer1000Cents),
      minRobux: patch.minRobux === undefined ? current.minRobux : clampInt(patch.minRobux, 1, 1_000_000, current.minRobux),
      maxRobux: patch.maxRobux === undefined ? current.maxRobux : clampInt(patch.maxRobux, 1, 10_000_000, current.maxRobux),
      maxGamepasses: patch.maxGamepasses === undefined ? current.maxGamepasses : clampInt(patch.maxGamepasses, 1, 25, current.maxGamepasses),
      deliveryMode: patch.deliveryMode === undefined ? current.deliveryMode : (["MANUAL", "ASSISTED", "COOKIE_AUTO", "WEBHOOK"] as string[]).includes(String(patch.deliveryMode)) ? patch.deliveryMode : current.deliveryMode,
      deliveryWebhookUrl: patch.deliveryWebhookUrl === undefined ? current.deliveryWebhookUrl : safeDeliveryUrl(patch.deliveryWebhookUrl),
      deliveryAccountName: patch.deliveryAccountName === undefined ? current.deliveryAccountName : cleanText(patch.deliveryAccountName, 80),
      updatedAt: nowIso()
    };
    if (next.maxRobux < next.minRobux) next.maxRobux = next.minRobux;
    this.state.settings[guildId] = next;
    this.save();
    return next;
  }

  private normalizeCookie(value: string): string {
    let clean = String(value || "").trim();
    const match = clean.match(/(?:^|;\s*)\.ROBLOSECURITY=([^;]+)/i);
    if (match?.[1]) clean = match[1].trim();
    if (!clean || clean.length < 50) throw new Error("Cookie Roblox inválido ou incompleto.");
    if (/\s/.test(clean)) throw new Error("Cookie Roblox inválido: não use espaços ou quebras de linha.");
    return clean;
  }

  private async identifyDeliveryCookie(cookie: string): Promise<RobloxUser> {
    const response = await fetch("https://users.roblox.com/v1/users/authenticated", {
      headers: { Cookie: `.ROBLOSECURITY=${cookie}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000)
    });
    const body = jsonRecord(await response.json().catch(() => ({})));
    if (!response.ok) throw new Error("A sessão Roblox configurada expirou ou não é válida.");
    const id = Number(body.id);
    if (!Number.isFinite(id) || id <= 0) throw new Error("Não foi possível identificar a conta Roblox de entrega.");
    return { id: Math.trunc(id), name: cleanText(body.name, 40), displayName: cleanText(body.displayName || body.name, 40) };
  }

  setCookie(guildId: string, value: string): void {
    const cookie = this.normalizeCookie(value);
    this.credentials.set(guildId, "roblox_delivery_cookie", cookie);
  }
  async configureCookie(guildId: string, value: string): Promise<RobloxUser> {
    const cookie = this.normalizeCookie(value);
    // Valida ANTES de persistir para uma tentativa inválida não apagar uma conta já funcional.
    const user = await this.identifyDeliveryCookie(cookie);
    this.credentials.set(guildId, "roblox_delivery_cookie", cookie);
    this.updateSettings(guildId, { deliveryAccountName: user.displayName || user.name });
    return user;
  }
  removeCookie(guildId: string): void {
    this.credentials.remove(guildId, "roblox_delivery_cookie");
    this.updateSettings(guildId, { deliveryAccountName: "" });
  }
  hasCookie(guildId: string): boolean { return this.credentials.has(guildId, "roblox_delivery_cookie"); }
  async verifyCookie(guildId: string): Promise<RobloxUser> {
    const cookie = this.credentials.get(guildId, "roblox_delivery_cookie");
    if (!cookie) throw new Error("Nenhuma conta Roblox de entrega foi configurada.");
    const user = await this.identifyDeliveryCookie(cookie);
    this.updateSettings(guildId, { deliveryAccountName: user.displayName || user.name });
    return user;
  }

  deliveryConfigured(guildId: string): boolean {
    const s = this.settings(guildId);
    if (s.deliveryMode === "WEBHOOK") return Boolean(s.deliveryWebhookUrl && this.credentials.has(guildId, "robux_delivery_token"));
    if (s.deliveryMode === "ASSISTED" || s.deliveryMode === "COOKIE_AUTO") return this.hasCookie(guildId);
    return true;
  }

  configureDeliveryWebhook(guildId: string, url: string, token: string): RobuxSettings {
    const safeUrl = safeDeliveryUrl(url);
    if (!safeUrl) throw new Error("Informe a URL HTTPS da integração de entrega.");
    if (token.trim().length < 8) throw new Error("A chave da integração de entrega é muito curta.");
    this.credentials.set(guildId, "robux_delivery_token", token.trim());
    return this.updateSettings(guildId, { deliveryMode: "WEBHOOK", deliveryWebhookUrl: safeUrl, autoDelivery: true });
  }

  clearDeliveryWebhook(guildId: string): RobuxSettings {
    this.credentials.remove(guildId, "robux_delivery_token");
    return this.updateSettings(guildId, { deliveryMode: "ASSISTED", deliveryWebhookUrl: "", autoDelivery: false });
  }

  async resolveUsername(username: string): Promise<RobloxUser> {
    const clean = username.trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9_]{3,20}$/.test(clean)) throw new Error("Nome de usuário Roblox inválido.");
    const response = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ usernames: [clean], excludeBannedUsers: false }),
      signal: AbortSignal.timeout(15_000)
    });
    const body = jsonRecord(await response.json().catch(() => ({})));
    if (!response.ok) throw new Error(`Roblox respondeu HTTP ${response.status}.`);
    const data = Array.isArray(body.data) ? body.data : [];
    const first = jsonRecord(data[0]);
    const id = Number(first.id);
    if (!Number.isFinite(id)) throw new Error("Usuário Roblox não encontrado.");
    const fallback: RobloxUser = { id, name: cleanText(first.name, 40), displayName: cleanText(first.displayName, 40) };
    try {
      const profileResponse = await fetch(`https://users.roblox.com/v1/users/${Math.trunc(id)}`, { signal: AbortSignal.timeout(12_000) });
      const profile = jsonRecord(await profileResponse.json().catch(() => ({})));
      if (!profileResponse.ok) return fallback;
      return {
        id,
        name: cleanText(profile.name || fallback.name, 40),
        displayName: cleanText(profile.displayName || fallback.displayName, 40),
        description: cleanText(profile.description, 280),
        createdAt: cleanText(profile.created, 80),
        isBanned: Boolean(profile.isBanned)
      };
    } catch {
      return fallback;
    }
  }

  async listGamepasses(userId: number, limit = 25): Promise<RobloxGamepass[]> {
    const max = Math.max(1, Math.min(25, limit));
    const gamesResponse = await fetch(`https://games.roblox.com/v2/users/${userId}/games?accessFilter=Public&limit=50&sortOrder=Asc`, { signal: AbortSignal.timeout(20_000) });
    const gamesBody = jsonRecord(await gamesResponse.json().catch(() => ({})));
    if (!gamesResponse.ok) throw new Error(`Não foi possível consultar experiências Roblox (HTTP ${gamesResponse.status}).`);
    const games = Array.isArray(gamesBody.data) ? gamesBody.data : [];
    const out = new Map<number, RobloxGamepass>();
    for (const rawGame of games) {
      if (out.size >= max) break;
      const game = jsonRecord(rawGame);
      // O endpoint /v2/users/{id}/games já retorna o universe id em `id`.
      // Usamos o root place apenas como fallback para respostas antigas.
      let universeId = Number(game.id);
      if (!Number.isFinite(universeId) || universeId <= 0) {
        const rootPlaceId = Number(jsonRecord(game.rootPlace).id ?? game.rootPlaceId);
        if (!Number.isFinite(rootPlaceId) || rootPlaceId <= 0) continue;
        try {
          const universeResponse = await fetch(`https://apis.roblox.com/universes/v1/places/${rootPlaceId}/universe`, { signal: AbortSignal.timeout(10_000) });
          const universeBody = jsonRecord(await universeResponse.json().catch(() => ({})));
          universeId = Number(universeBody.universeId);
          if (!universeResponse.ok || !Number.isFinite(universeId) || universeId <= 0) continue;
        } catch { continue; }
      }
      try {
        const passesResponse = await fetch(`https://apis.roblox.com/game-passes/v1/universes/${Math.trunc(universeId)}/game-passes?passView=Full&pageSize=100`, { signal: AbortSignal.timeout(15_000) });
        const passesBody = jsonRecord(await passesResponse.json().catch(() => ({})));
        const passes = Array.isArray(passesBody.gamePasses) ? passesBody.gamePasses : Array.isArray(passesBody.data) ? passesBody.data : [];
        for (const rawPass of passes) {
          const pass = jsonRecord(rawPass);
          const id = Number(pass.id ?? pass.gamePassId);
          // No endpoint público atual `price` pode ser null quando o passe não está à venda.
          const rawPrice = pass.price ?? pass.priceInRobux;
          const price = rawPrice === null || rawPrice === undefined ? 0 : Number(rawPrice);
          const creator = jsonRecord(pass.creator);
          const productId = Number(pass.productId ?? pass.ProductId);
          const sellerId = Number(creator.creatorId ?? pass.sellerId ?? pass.TargetId);
          if (!Number.isFinite(id) || id <= 0 || !Number.isFinite(price) || price < 0) continue;
          out.set(id, {
            id,
            name: cleanText(pass.displayName || pass.name || `Gamepass ${id}`, 80),
            price: Math.trunc(price),
            productId: Number.isFinite(productId) && productId > 0 ? Math.trunc(productId) : undefined,
            sellerId: Number.isFinite(sellerId) && sellerId > 0 ? Math.trunc(sellerId) : undefined
          });
          if (out.size >= max) break;
        }
      } catch { /* uma experiência quebrada não deve abortar a busca inteira */ }
    }
    return [...out.values()].slice(0, max);
  }

  async gamepassInfo(gamepassId: number): Promise<RobloxGamepass> {
    const id = Math.trunc(Number(gamepassId));
    if (!Number.isFinite(id) || id <= 0) throw new Error("ID da Game Pass inválido.");
    const response = await fetch(`https://apis.roblox.com/game-passes/v1/game-passes/${id}/product-info`, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(15_000)
    });
    const body = jsonRecord(await response.json().catch(() => ({})));
    if (!response.ok) throw new Error(`Não foi possível consultar a Game Pass (HTTP ${response.status}).`);
    const price = Number(body.PriceInRobux ?? body.price ?? body.Price);
    const productId = Number(body.ProductId ?? body.productId);
    const sellerId = Number(jsonRecord(body.Creator).Id ?? jsonRecord(body.Creator).id ?? body.creatorTargetId ?? body.TargetId);
    if (!Number.isFinite(price) || price <= 0) throw new Error("A Game Pass não está à venda ou não possui preço válido.");
    return {
      id,
      name: cleanText(body.Name ?? body.name ?? `Gamepass ${id}`, 80),
      price: Math.trunc(price),
      productId: Number.isFinite(productId) && productId > 0 ? Math.trunc(productId) : undefined,
      sellerId: Number.isFinite(sellerId) && sellerId > 0 ? Math.trunc(sellerId) : undefined
    };
  }

  parseGamepassUrl(text: string): number | undefined {
    const raw = String(text || "").trim();
    const match = raw.match(/(?:roblox\.com\/(?:[a-z]{2}\/)?game-pass\/|roblox\.com\/(?:[a-z]{2}\/)?gamepass\/)(\d+)/i)
      ?? raw.match(/^\s*(\d{5,20})\s*$/);
    if (!match?.[1]) return undefined;
    const id = Number(match[1]);
    return Number.isFinite(id) && id > 0 ? Math.trunc(id) : undefined;
  }

  normalizeRobloxReferenceUrl(text: string): string {
    const raw = String(text || "").trim();
    if (!raw) return "";
    let url: URL;
    try { url = new URL(raw); } catch { throw new Error("O link informado não é uma URL válida."); }
    if (url.protocol !== "https:") throw new Error("Use um link HTTPS oficial do Roblox.");
    const host = url.hostname.toLowerCase();
    if (!(host === "roblox.com" || host.endsWith(".roblox.com"))) throw new Error("Use somente links oficiais do Roblox.");
    return url.toString().slice(0, 1000);
  }

  calculationEmbed(guildId: string, calc: RobuxCalculation): EmbedBuilder {
    return new EmbedBuilder()
      .setColor(0x3155ff)
      .setTitle("Calculadora de Robux")
      .setDescription(`**${calc.requestedRobux.toLocaleString("pt-BR")} Robux** por **R$ ${(calc.amountCents / 100).toFixed(2).replace(".", ",")}**`)
      .addFields(
        { name: "Preço da Game Pass", value: `${calc.gamepassPrice.toLocaleString("pt-BR")} Robux`, inline: true },
        { name: "Recebimento estimado", value: `${calc.estimatedNetRobux.toLocaleString("pt-BR")} Robux`, inline: true },
        { name: "Preço da loja", value: `R$ ${(calc.pricePer1000Cents / 100).toFixed(2).replace(".", ",")} / 1.000`, inline: false }
      )
      .setFooter({ text: "Cálculo automático de Robux" })
      .setTimestamp();
  }

  calculationFromRobux(guildId: string, requestedRobux: number): RobuxCalculation {
    const s = this.settings(guildId);
    const robux = clampInt(requestedRobux, s.minRobux, s.maxRobux, s.minRobux);
    const gamepassPrice = Math.max(1, Math.ceil(robux / 0.7));
    const estimatedNetRobux = Math.floor(gamepassPrice * 0.7);
    const amountCents = Math.max(1, Math.round((robux / 1000) * s.pricePer1000Cents));
    return { requestedRobux: robux, gamepassPrice, estimatedNetRobux, amountCents, pricePer1000Cents: s.pricePer1000Cents };
  }

  estimatedNetFromGamepassPrice(gamepassPrice: number): number {
    const price = Math.max(0, Math.trunc(Number(gamepassPrice) || 0));
    return Math.floor(price * 0.7);
  }

  recommendedGamepassPrice(guildId: string, requestedRobux: number): number {
    return this.calculationFromRobux(guildId, requestedRobux).gamepassPrice;
  }

  assertGamepassMatchesRequested(guildId: string, requestedRobux: number, gamepassPrice: number): { estimatedNet: number; recommendedPrice: number } {
    const requested = Math.max(1, Math.trunc(Number(requestedRobux) || 0));
    const actualPrice = Math.max(0, Math.trunc(Number(gamepassPrice) || 0));
    const estimatedNet = this.estimatedNetFromGamepassPrice(actualPrice);
    const recommendedPrice = this.recommendedGamepassPrice(guildId, requested);
    if (estimatedNet !== requested) {
      throw new Error(`Essa Game Pass custa ${actualPrice.toLocaleString("pt-BR")} Robux e, considerando a taxa de 30% do Roblox, entrega cerca de ${estimatedNet.toLocaleString("pt-BR")} Robux. Para receber ${requested.toLocaleString("pt-BR")} Robux, defina o preço da Game Pass como ${recommendedPrice.toLocaleString("pt-BR")} Robux e envie o link novamente.`);
    }
    return { estimatedNet, recommendedPrice };
  }

  calculationFromBrl(guildId: string, brl: number): RobuxCalculation {
    const s = this.settings(guildId);
    if (!Number.isFinite(brl) || brl <= 0) throw new Error("Informe um valor em reais maior que zero.");
    const robux = Math.floor((Math.round(brl * 100) / s.pricePer1000Cents) * 1000);
    if (robux < s.minRobux) throw new Error(`O valor corresponde a menos de ${s.minRobux} Robux, abaixo do mínimo configurado.`);
    return this.calculationFromRobux(guildId, Math.min(robux, s.maxRobux));
  }

  parseCalculation(guildId: string, text: string): RobuxCalculation | undefined {
    const raw = text.trim();
    const parseNumber = (input: string): number => {
      let value = input.replace(/\s+/g, "");
      const hasComma = value.includes(",");
      const hasDot = value.includes(".");
      if (hasComma && hasDot) {
        // PT-BR: 1.234,56. Se o último separador for ponto, aceita 1,234.56 também.
        if (value.lastIndexOf(",") > value.lastIndexOf(".")) value = value.replace(/\./g, "").replace(",", ".");
        else value = value.replace(/,/g, "");
      } else if (hasComma) {
        value = value.replace(",", ".");
      } else if (hasDot) {
        const parts = value.split(".");
        // 1.000 / 10.000 são tratados como milhares; 25.50 continua decimal.
        if (parts.length > 2 || (parts.length === 2 && /^\d{1,3}$/.test(parts[0] || "") && /^\d{3}$/.test(parts[1] || ""))) {
          value = parts.join("");
        }
      }
      return Number(value);
    };

    // Regra do canal calculadora: número sem unidade = dinheiro (R$).
    // Exemplos: 100, R$100, 100 reais, 100reais, 100 BRL.
    const money = raw.match(/^r\$\s*([\d.,]+)$/i)
      ?? raw.match(/^([\d.,]+)\s*(?:reais?|real|brl|r\$)$/i)
      ?? raw.match(/^([\d.,]+)$/);
    if (money) {
      const value = parseNumber(money[1]!);
      return Number.isFinite(value) && value > 0 ? this.calculationFromBrl(guildId, value) : undefined;
    }

    // Robux só é Robux quando a unidade é explícita, com ou sem espaço.
    // Exemplos: 100robux, 100 robux, 100rbx, 100 rbx.
    const robux = raw.match(/^([\d.,]+)\s*(?:robux?|rbx)$/i);
    if (robux) {
      const value = Math.floor(parseNumber(robux[1]!));
      return Number.isFinite(value) && value > 0 ? this.calculationFromRobux(guildId, value) : undefined;
    }
    return undefined;
  }

  async calculationImage(guildId: string, calc: RobuxCalculation): Promise<Buffer> {
    const serverName = this.client.guilds.cache.get(guildId)?.name || "Servidor";
    return renderRobuxCalculationPng(this.settings(guildId), calc, serverName);
  }

  private nickRequestKey(guildId: string, channelId: string, discordUserId: string): string {
    return `${guildId}:${channelId}:${discordUserId}`;
  }

  private pruneNickRequests(): void {
    const now = Date.now();
    for (const [key, expiresAt] of this.calculatorNickRequests) if (expiresAt <= now) this.calculatorNickRequests.delete(key);
  }

  async robloxProfileImage(guildId: string, user: RobloxUser, gamepassCount: number): Promise<Buffer> {
    const serverName = this.client.guilds.cache.get(guildId)?.name || "Servidor";
    let avatarBytes: Buffer | undefined;
    try {
      const avatarUrl = await this.robloxAvatarUrl(user.id);
      if (avatarUrl) {
        const response = await fetch(avatarUrl, { signal: AbortSignal.timeout(12_000) });
        if (response.ok) avatarBytes = Buffer.from(await response.arrayBuffer());
      }
    } catch { /* avatar é decorativo; o card continua funcionando sem ele */ }
    return renderRobloxProfilePng(user, gamepassCount, serverName, avatarBytes);
  }

  async calculatorLookupSelection(guildId: string, robloxUserId: number, gamepassId: number): Promise<RobloxGamepass | undefined> {
    const passes = await this.listGamepasses(robloxUserId, 25);
    return passes.find((pass) => pass.id === gamepassId);
  }

  async robloxAvatarUrl(userId: number): Promise<string> {
    try {
      const url = new URL("https://thumbnails.roblox.com/v1/users/avatar-headshot");
      url.searchParams.set("userIds", String(Math.trunc(userId)));
      url.searchParams.set("size", "150x150");
      url.searchParams.set("format", "Png");
      url.searchParams.set("isCircular", "false");
      const response = await fetch(url, { signal: AbortSignal.timeout(10_000) });
      if (!response.ok) return "";
      const data = jsonRecord(await response.json());
      const first = Array.isArray(data.data) ? jsonRecord(data.data[0]) : {};
      return cleanText(first.imageUrl, 500);
    } catch { return ""; }
  }

  async handleCalculatorMessage(message: Message): Promise<void> {
    if (!message.guildId || message.author.bot) return;
    const settings = this.settings(message.guildId);
    if (!settings.calculatorEnabled || !settings.calculatorChannelId || message.channelId !== settings.calculatorChannelId) return;

    const content = String(message.content || "").trim();
    if (!content) {
      this.logger.warn("Mensagem recebida no canal da calculadora sem conteúdo. Verifique MESSAGE CONTENT INTENT no Developer Portal do bot filho.", { guildId: message.guildId, channelId: message.channelId });
      const key = `${message.guildId}:${message.channelId}`;
      const last = this.calculatorIntentWarnings.get(key) || 0;
      if (Date.now() - last > 60 * 60_000 && message.channel.isSendable()) {
        this.calculatorIntentWarnings.set(key, Date.now());
        await message.channel.send({
          content: `⚠️ **Calculadora Robux:** o Discord não entregou o conteúdo da mensagem. Ative **MESSAGE CONTENT INTENT** no Developer Portal da aplicação deste bot e reinicie este bot. Depois disso, mensagens como \`100\`, \`6 reais\` e \`100 robux\` gerarão a imagem automaticamente.`,
          allowedMentions: { parse: [] }
        }).catch(() => undefined);
      }
      return;
    }

    this.pruneNickRequests();
    const lookupKey = this.nickRequestKey(message.guildId, message.channelId, message.author.id);
    const waitingNick = (this.calculatorNickRequests.get(lookupKey) || 0) > Date.now();
    const directNick = content.match(/^nick(?:name)?\s+@?([A-Za-z0-9_]{3,20})$/i);
    if (/^nick(?:name)?$/i.test(content)) {
      this.calculatorNickRequests.set(lookupKey, Date.now() + 2 * 60_000);
      if (message.channel.isSendable()) await message.channel.send({
        content: `🔎 **Consulta Roblox** • ${message.author}\nEnvie agora o **username** da sua conta Roblox (ex.: \`Builderman\`). Você também pode usar direto \`nick Builderman\`. Tempo: **2 minutos**.`,
        allowedMentions: { users: [message.author.id] }
      });
      return;
    }

    if (waitingNick || directNick) {
      const username = (directNick?.[1] || content).trim().replace(/^@/, "");
      if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
        if (message.channel.isSendable()) await message.channel.send({
          content: `❌ ${message.author}, esse username não parece válido. Digite \`nick\` novamente e envie apenas o username Roblox.`,
          allowedMentions: { users: [message.author.id] }
        });
        this.calculatorNickRequests.delete(lookupKey);
        return;
      }
      this.calculatorNickRequests.delete(lookupKey);
      try {
        const user = await this.resolveUsername(username);
        const gamepasses = await this.listGamepasses(user.id, 25);
        const profileImage = await this.robloxProfileImage(message.guildId, user, gamepasses.length);
        if (!message.channel.isSendable()) return;
        const payload: Record<string, unknown> = {
          files: [{ attachment: profileImage, name: "zenyx-roblox-perfil.png" }],
          allowedMentions: { parse: [] }
        };
        if (gamepasses.length) {
          const select = new StringSelectMenuBuilder()
            .setCustomId(`robux:calcpass:${message.author.id}:${user.id}`)
            .setPlaceholder(`Gamepasses de ${user.name} • ${gamepasses.length} encontrada(s)`)
            .addOptions(gamepasses.slice(0, 25).map((pass) => new StringSelectMenuOptionBuilder()
              .setLabel(cleanText(pass.name || `Gamepass ${pass.id}`, 100))
              .setDescription(`${Math.max(0, pass.price).toLocaleString("pt-BR")} Robux • ID ${pass.id}`.slice(0, 100))
              .setValue(String(pass.id))));
          payload.components = [new ActionRowBuilder().addComponents(select)];
        } else {
          payload.content = `ℹ️ A conta **${user.name}** foi encontrada, mas nenhuma gamepass pública apareceu para seleção.`;
        }
        await message.channel.send(payload as never);
      } catch (error) {
        this.logger.warn("Falha na consulta de perfil Roblox pelo canal calculadora.", { guildId: message.guildId, userId: message.author.id, error: safeError(error) });
        if (message.channel.isSendable()) await message.channel.send({
          content: `❌ ${message.author}, não consegui localizar essa conta/gamepasses agora. Confira o **username exato** e tente novamente.`,
          allowedMentions: { users: [message.author.id] }
        });
      }
      return;
    }

    const calculation = this.parseCalculation(message.guildId, content);
    if (!calculation) return;
    try {
      if (!message.channel.isSendable()) {
        this.logger.warn("Canal da calculadora não permite envio de mensagens.", { guildId: message.guildId, channelId: message.channelId });
        return;
      }
      // O dono escolhe entre card PNG e embed. O parser é o mesmo nos dois modos.
      if (settings.calculatorFormat === "EMBED") {
        await message.channel.send({ embeds: [this.calculationEmbed(message.guildId, calculation)], allowedMentions: { parse: [] } });
      } else {
        const image = await this.calculationImage(message.guildId, calculation);
        await message.channel.send({
          files: [{ attachment: image, name: "zenyx-calculadora-robux.png" }],
          allowedMentions: { parse: [] }
        });
      }
    } catch (error) {
      this.logger.error("Falha ao gerar/enviar a imagem PNG da calculadora Robux.", error);
    }
  }

  formatCalculation(calc: RobuxCalculation): string {
    return [
      `**${calc.requestedRobux.toLocaleString("pt-BR")} Robux**`,
      `Valor: **R$ ${(calc.amountCents / 100).toFixed(2).replace(".", ",")}**`,
      `Preço recomendado da gamepass: **${calc.gamepassPrice.toLocaleString("pt-BR")} Robux**`,
      `Recebimento estimado após taxa da plataforma: **${calc.estimatedNetRobux.toLocaleString("pt-BR")} Robux**`
    ].join("\n");
  }

  chooseProvider(guildId: string): PaymentProviderName {
    const configured = this.settings(guildId).paymentProvider;
    const enabled = this.payments.enabledMethods(guildId);
    if (configured !== "AUTO") {
      if (!enabled.includes(configured)) throw new Error(`O método ${configured.replaceAll("_", " ")} não está pronto.`);
      return configured;
    }
    const preferred: PaymentProviderName[] = ["MERCADO_PAGO", "EFI_BANK", "EVO_PAY", "MISTIC_PAY", "PURIN_CASH", "STRIPE", "IMAP_PIX", "MANUAL_PIX"];
    const selected = preferred.find((method) => enabled.includes(method));
    if (!selected) throw new Error("Nenhum método de pagamento está configurado para vendas de Robux.");
    return selected;
  }

  async createOrder(input: {
    guildId: string; discordUserId: string; discordUsername: string; robloxUser: RobloxUser; gamepass: RobloxGamepass;
    email?: string; document?: string; customerName?: string; payerBankName?: string; provider?: PaymentProviderName;
    threadId?: string; messageId?: string; requestedRobuxOverride?: number; referenceUrl?: string;
  }): Promise<RobuxOrder> {
    const s = this.settings(input.guildId);
    if (!s.enabled) throw new Error("As vendas de Robux estão desativadas.");
    const requested = input.requestedRobuxOverride === undefined
      ? Math.floor(input.gamepass.price * 0.7)
      : clampInt(input.requestedRobuxOverride, s.minRobux, s.maxRobux, s.minRobux);
    if (input.requestedRobuxOverride === undefined && input.gamepass.price <= 0) throw new Error("A gamepass selecionada não possui preço.");
    if (requested < s.minRobux || requested > s.maxRobux) throw new Error(`A quantidade informada está fora do limite atual de ${s.minRobux} a ${s.maxRobux} Robux.`);
    const calc = this.calculationFromRobux(input.guildId, requested);
    const effectiveGamepassPrice = input.gamepass.price > 0 ? Math.trunc(input.gamepass.price) : calc.gamepassPrice;
    const referenceUrl = this.normalizeRobloxReferenceUrl(input.referenceUrl || "");
    const enabledMethods = this.payments.enabledMethods(input.guildId);
    const provider = input.provider ? (enabledMethods.includes(input.provider) ? input.provider : (() => { throw new Error("O método de pagamento escolhido não está disponível."); })()) : this.chooseProvider(input.guildId);
    const orderId = makeId("RBX");
    const expiresAt = new Date(Date.now() + 30 * 60_000).toISOString();
    const charge = await this.payments.create(provider, {
      guildId: input.guildId,
      orderId,
      amountCents: calc.amountCents,
      description: `Robux ${requested} • ${input.robloxUser.name}${input.gamepass.id > 0 ? ` • gamepass ${input.gamepass.id}` : " • compra manual"}`,
      customer: {
        discordId: input.discordUserId,
        name: cleanText(input.customerName || input.discordUsername, 100),
        email: cleanText(input.email, 150),
        document: cleanText(input.document, 30)
      },
      expiresAt
    });
    const order: RobuxOrder = {
      id: orderId, guildId: input.guildId, discordUserId: input.discordUserId, discordUsername: input.discordUsername,
      robloxUserId: input.robloxUser.id, robloxUsername: input.robloxUser.name, robloxDisplayName: input.robloxUser.displayName,
      gamepassId: input.gamepass.id, gamepassName: input.gamepass.name || (input.gamepass.id > 0 ? `Game Pass ${input.gamepass.id}` : "Game Pass pendente"),
      gamepassProductId: input.gamepass.productId, gamepassSellerId: input.gamepass.sellerId,
      gamepassUrlOverride: referenceUrl || undefined,
      awaitingRobloxIdentity: input.robloxUser.id <= 0 && /aguardando/i.test(input.robloxUser.name) && input.gamepass.id <= 0,
      requestedRobux: requested, gamepassPrice: effectiveGamepassPrice, amountCents: calc.amountCents,
      provider, externalId: charge.externalId, paymentStatus: charge.status, status: charge.status === "paid" ? "PAID" : "PENDING_PAYMENT",
      pixCode: charge.pixCode, qrCodeDataUrl: charge.qrCodeDataUrl, createdAt: nowIso(), updatedAt: nowIso(),
      payerFullName: cleanText(input.customerName || input.discordUsername, 120),
      payerDocument: cleanText(input.document, 30).replace(/\D/g, ""),
      payerBankName: cleanText(input.payerBankName, 80),
      purchaseThreadId: input.threadId, purchaseMessageId: input.messageId
    };
    this.state.orders[order.id] = order;
    this.save();
    if (order.status === "PAID") await this.processPaid(order, false);
    await this.emitUpdate(order);
    return order;
  }

  getOrder(id: string): RobuxOrder | undefined { return this.state.orders[id]; }
  listOrders(guildId: string, limit = 25): RobuxOrder[] { return Object.values(this.state.orders).filter((o) => o.guildId === guildId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); }

  async markPaidManual(orderId: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (["DELIVERED", "DELIVERING"].includes(order.status)) return order;
    // Um botão antigo pode continuar clicável no cliente do Discord por alguns
    // instantes. Se o vendedor já confirmou este PIX, não execute novamente a
    // transição/DM/entrega.
    if (order.paymentStatus === "paid" && order.sellerPaymentConfirmedAt) {
      await this.emitUpdate(order);
      return order;
    }
    order.paymentStatus = "paid"; order.status = "PAID"; order.sellerPaymentConfirmedAt = nowIso(); order.updatedAt = order.sellerPaymentConfirmedAt; this.save();
    await this.processPaid(order, true);
    await this.emitUpdate(order);
    return order;
  }

  setPurchaseMessage(orderId: string, messageId: string): void {
    const order = this.getOrder(orderId);
    if (!order) return;
    order.purchaseMessageId = messageId; order.updatedAt = nowIso(); this.save();
  }

  async confirmPayment(orderId: string, userId: string): Promise<{ order: RobuxOrder; confirmed: boolean; manualReview: boolean }> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.discordUserId !== userId) throw new Error("Este pedido pertence a outro usuário.");
    if (["CANCELED", "EXPIRED"].includes(order.status)) throw new Error("Esta cobrança não está mais ativa.");
    if (order.paymentStatus === "paid" || ["PAID", "DELIVERING", "DELIVERY_REVIEW", "DELIVERED"].includes(order.status)) {
      await this.emitUpdate(order);
      return { order, confirmed: true, manualReview: false };
    }
    if (order.provider === "MANUAL_PIX" || order.provider === "IMAP_PIX") {
      // Idempotência da solicitação de conferência manual. O comprador pode
      // tocar várias vezes no botão sem disparar DMs/logs repetidos.
      if (order.paymentConfirmationRequestedAt) {
        await this.emitUpdate(order);
        return { order, confirmed: false, manualReview: true };
      }
      order.paymentConfirmationRequestedAt = nowIso();
      order.updatedAt = order.paymentConfirmationRequestedAt;
      this.save();
      const payer = order.provider === "IMAP_PIX" ? ` Pagador: ${order.payerFullName || "não informado"}; banco usado: ${order.payerBankName || "não informado"}.` : "";
      await this.notifyOrder(order, `Recebemos a confirmação de pagamento do pedido ${order.id}.${payer} A equipe fará a conferência do PIX; depois disso a página avançará para a etapa da Game Pass.`);
      await this.emitUpdate(order);
      return { order, confirmed: false, manualReview: true };
    }
    const charge = await this.payments.status(order.guildId, order.provider, order.externalId);
    order.paymentStatus = charge.status;
    order.updatedAt = nowIso();
    if (charge.status === "paid") {
      order.status = "PAID";
      this.save();
      await this.processPaid(order, false);
      await this.emitUpdate(order);
      return { order, confirmed: true, manualReview: false };
    }
    if (charge.status === "canceled") order.status = "CANCELED";
    else if (charge.status === "expired") order.status = "EXPIRED";
    this.save();
    await this.emitUpdate(order);
    return { order, confirmed: false, manualReview: false };
  }

  async cancelPending(orderId: string, userId: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.discordUserId !== userId) throw new Error("Este pedido pertence a outro usuário.");
    if (order.paymentStatus === "paid" || ["PAID", "DELIVERING", "DELIVERY_REVIEW", "DELIVERED"].includes(order.status)) throw new Error("O pagamento já foi confirmado e não é mais possível voltar para outra seleção.");
    order.status = "CANCELED";
    order.updatedAt = nowIso();
    this.save();
    await this.emitUpdate(order);
    return order;
  }

  async retryDelivery(orderId: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.paymentStatus !== "paid" && order.status !== "DELIVERY_REVIEW" && order.status !== "PAID") throw new Error("O pagamento deste pedido ainda não foi confirmado.");
    order.status = "PAID"; order.error = ""; order.updatedAt = nowIso(); this.save();
    await this.processPaid(order, false);
    await this.emitUpdate(order);
    return order;
  }

  async markDelivered(orderId: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.paymentStatus !== "paid") throw new Error("Confirme o pagamento antes de marcar a entrega.");
    if (order.status !== "DELIVERED") {
      order.status = "DELIVERED";
      order.error = "";
      order.deliveredAt = nowIso();
      order.updatedAt = order.deliveredAt;
      this.save();
    }
    await this.finalizeDelivered(order);
    await this.emitUpdate(order);
    return order;
  }

  gamepassUrl(gamepassId: number): string { return `https://www.roblox.com/game-pass/${Math.trunc(gamepassId)}`; }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.poll().catch((error) => this.logger.warn("Falha no monitor de vendas Robux.", { error: safeError(error) })), 15_000);
    this.timer.unref?.();
  }
  stop(): void { if (this.timer) clearInterval(this.timer); this.timer = undefined; }

  private async poll(): Promise<void> {
    const pending = Object.values(this.state.orders).filter((o) => o.status === "PENDING_PAYMENT").slice(0, 30);
    for (const order of pending) {
      try {
        const previousPayment = order.paymentStatus;
        const previousStatus = order.status;
        const charge = await this.payments.status(order.guildId, order.provider, order.externalId);
        order.paymentStatus = charge.status; order.updatedAt = nowIso();
        if (charge.status === "paid") { order.status = "PAID"; this.save(); await this.processPaid(order, false); }
        else if (charge.status === "canceled") order.status = "CANCELED";
        else if (charge.status === "expired") order.status = "EXPIRED";
        this.save();
        if (order.paymentStatus !== previousPayment || order.status !== previousStatus) await this.emitUpdate(order);
      } catch (error) {
        this.logger.warn("Falha ao consultar pagamento Robux; será tentado novamente.", { orderId: order.id, error: safeError(error) });
      }
    }
  }

  private async processPaid(order: RobuxOrder, sellerConfirmed = false): Promise<void> {
    const settings = this.settings(order.guildId);
    order.error = "";

    // Fluxo sem busca: o comprador pode pagar antes de informar a conta.
    // Depois do pagamento aceitamos OU o username Roblox OU o link da Game Pass.
    if (order.awaitingRobloxIdentity) {
      order.status = "DELIVERY_REVIEW";
      order.awaitingGamepassLink = !order.gamepassUrlOverride;
      order.error = order.gamepassUrlOverride ? "" : "Aguardando username Roblox ou link da Game Pass.";
      order.updatedAt = nowIso();
      this.save();
      await this.notifyOrder(order, order.gamepassUrlOverride
        ? `Pagamento aprovado. O link Roblox já foi registrado e o pedido ${order.id} está pronto para a etapa de entrega.`
        : `Pagamento aprovado. Envie no tópico o seu username Roblox ou o link completo da Game Pass para continuar.`);
      return;
    }

    // Pedidos sem Game Pass utilizável pedem o link ao comprador em vez de travar.
    if (!order.gamepassId || order.gamepassId <= 0) {
      order.status = "DELIVERY_REVIEW";
      order.awaitingGamepassLink = !order.gamepassUrlOverride;
      order.error = order.gamepassUrlOverride ? "" : "Aguardando o comprador enviar o link da Game Pass.";
      order.updatedAt = nowIso();
      this.save();
      await this.notifyOrder(order, order.gamepassUrlOverride
        ? `Pagamento aprovado. O pedido ${order.id} está pronto para entrega manual pelo link informado.`
        : `Pagamento aprovado. O pedido ${order.id} precisa do link da Game Pass do comprador.`);
      return;
    }

    if (settings.deliveryMode === "WEBHOOK") {
      await this.deliverViaWebhook(order);
      return;
    }

    // Automático: qualquer confirmação real de pagamento dispara a compra.
    if (settings.deliveryMode === "COOKIE_AUTO") {
      if (!this.hasCookie(order.guildId)) {
        order.status = "DELIVERY_REVIEW";
        order.error = "A conta Roblox de entrega automática não está configurada.";
        order.updatedAt = nowIso(); this.save();
        await this.notifyOrder(order, `Pagamento aprovado. O pedido ${order.id} está aguardando configuração da conta Roblox de entrega.`);
        return;
      }
      await this.deliverWithConfiguredAccount(order.id);
      return;
    }

    // Assistido: em PIX manual o vendedor só confere o pagamento; o bot faz
    // a compra da Game Pass. Em gateway automático, fica aguardando um clique
    // do vendedor para evitar compra sem supervisão.
    if (settings.deliveryMode === "ASSISTED" && sellerConfirmed) {
      if (this.hasCookie(order.guildId)) {
        await this.deliverWithConfiguredAccount(order.id);
        return;
      }
      order.error = "Modo assistido selecionado, mas nenhuma conta Roblox de entrega está configurada.";
    }

    // Manual: confirmar o PIX SEMPRE leva para a página da Game Pass.
    order.status = "DELIVERY_REVIEW";
    order.awaitingGamepassLink = false;
    order.updatedAt = nowIso();
    this.save();
    const mode = settings.deliveryMode === "ASSISTED" ? "assistida" : "manual";
    const gamepass = order.gamepassUrlOverride || this.gamepassUrl(order.gamepassId);
    await this.notifyOrder(order, `Pagamento aprovado. Pedido ${order.id} entrou na fila de entrega ${mode}. Game Pass: ${gamepass}`);
  }

  private async deliverViaWebhook(order: RobuxOrder): Promise<void> {
    const settings = this.settings(order.guildId);
    const token = this.credentials.get(order.guildId, "robux_delivery_token");
    if (!settings.deliveryWebhookUrl || !token) {
      order.status = "DELIVERY_REVIEW";
      order.error = "Integração de entrega automática ainda não está completamente configurada.";
      order.updatedAt = nowIso(); this.save();
      await this.notifyOrder(order, `Pagamento aprovado. Pedido ${order.id} aguardando revisão porque a integração de entrega não está configurada.`);
      return;
    }
    order.status = "DELIVERING"; order.updatedAt = nowIso(); this.save();
    try {
      const response = await fetch(settings.deliveryWebhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, "X-Zenyx-Event": "robux.delivery" },
        body: JSON.stringify({
          event: "robux.delivery", orderId: order.id, guildId: order.guildId,
          robloxUserId: order.robloxUserId, robloxUsername: order.robloxUsername,
          gamepassId: order.gamepassId, gamepassName: order.gamepassName, gamepassPrice: order.gamepassPrice,
          requestedRobux: order.requestedRobux, amountCents: order.amountCents
        }),
        signal: AbortSignal.timeout(20_000)
      });
      const body = jsonRecord(await response.json().catch(() => ({})));
      if (!response.ok) throw new Error(`Integração respondeu HTTP ${response.status}.`);
      const delivered = body.delivered === true || String(body.status || "").toUpperCase() === "DELIVERED";
      if (!delivered) throw new Error("A integração não confirmou a entrega.");
      order.status = "DELIVERED"; order.deliveredAt = nowIso(); order.updatedAt = order.deliveredAt; order.error = ""; this.save();
      await this.finalizeDelivered(order);
    } catch (error) {
      order.status = "DELIVERY_REVIEW"; order.error = safeError(error); order.updatedAt = nowIso(); this.save();
      await this.notifyOrder(order, `Pagamento aprovado. A entrega automática falhou e o pedido ${order.id} foi enviado para revisão manual.`);
    }
  }

  private async csrfToken(cookie: string): Promise<string> {
    const response = await fetch("https://auth.roblox.com/v2/logout", {
      method: "POST",
      headers: { Cookie: `.ROBLOSECURITY=${cookie}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000)
    });
    const token = response.headers.get("x-csrf-token") || "";
    if (!token) throw new Error("Não foi possível obter o token de segurança da sessão Roblox.");
    return token;
  }

  async purchaseGamepass(guildId: string, gamepassId: number, expectedPrice?: number, productIdHint?: number, sellerIdHint?: number): Promise<void> {
    const cookie = this.credentials.get(guildId, "roblox_delivery_cookie");
    if (!cookie) throw new Error("Configure uma conta Roblox de entrega antes de usar a compra automática.");
    // Confirma que a sessão ainda pertence à conta configurada antes de gastar Robux.
    await this.verifyCookie(guildId);
    const info = await this.gamepassInfo(gamepassId);
    const price = info.price;
    if (expectedPrice && price !== Math.trunc(expectedPrice)) throw new Error(`O preço da Game Pass mudou de ${Math.trunc(expectedPrice)} para ${price} Robux. A compra automática foi bloqueada por segurança.`);
    const productId = info.productId || productIdHint;
    const sellerId = info.sellerId || sellerIdHint;
    if (!productId || !sellerId) throw new Error("O Roblox não retornou Product ID/Seller ID da Game Pass; use a entrega manual.");

    let csrf = await this.csrfToken(cookie);
    const doPurchase = async () => fetch(`https://economy.roblox.com/v1/purchases/products/${Math.trunc(productId)}`, {
      method: "POST",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookie}`,
        "X-CSRF-TOKEN": csrf,
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({ expectedCurrency: 1, expectedPrice: price, expectedSellerId: Math.trunc(sellerId) }),
      signal: AbortSignal.timeout(20_000)
    });

    let response = await doPurchase();
    // O Roblox pode rotacionar o CSRF entre a obtenção e a compra. Tenta uma
    // única vez com o token novo, sem repetir compras confirmadas.
    if (response.status === 403) {
      const rotated = response.headers.get("x-csrf-token");
      if (rotated && rotated !== csrf) { csrf = rotated; response = await doPurchase(); }
    }
    const body = jsonRecord(await response.json().catch(() => ({})));
    if (!response.ok || body.purchased !== true) {
      const reason = cleanText(body.errorMsg || body.reason || body.message || `HTTP ${response.status}`, 260);
      throw new Error(`O Roblox não confirmou a compra da Game Pass: ${reason || "falha desconhecida"}.`);
    }
  }

  async deliverWithConfiguredAccount(orderId: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.paymentStatus !== "paid") throw new Error("Confirme o pagamento antes da entrega automática.");
    if (order.status === "DELIVERED") return order;
    if (this.deliveryLocks.has(orderId)) return order;
    this.deliveryLocks.add(orderId);
    try {
      if (!order.gamepassId || order.gamepassId <= 0) {
        order.status = "DELIVERY_REVIEW";
        order.awaitingGamepassLink = true;
        order.error = "O link da Game Pass precisa ser informado pelo comprador.";
        order.updatedAt = nowIso(); this.save();
        await this.emitUpdate(order);
        return order;
      }
      order.status = "DELIVERING"; order.error = ""; order.updatedAt = nowIso(); this.save(); await this.emitUpdate(order);
      try {
        await this.purchaseGamepass(order.guildId, order.gamepassId, order.gamepassPrice, order.gamepassProductId, order.gamepassSellerId);
        order.status = "DELIVERED"; order.deliveredAt = nowIso(); order.updatedAt = order.deliveredAt; order.error = ""; order.awaitingGamepassLink = false; this.save();
        await this.finalizeDelivered(order);
      } catch (error) {
        order.status = "DELIVERY_REVIEW"; order.error = safeError(error); order.updatedAt = nowIso(); this.save();
        await this.notifyOrder(order, `A compra automática da Game Pass do pedido ${order.id} não foi concluída. O pedido voltou para revisão manual.`);
      }
      await this.emitUpdate(order);
      return order;
    } finally {
      this.deliveryLocks.delete(orderId);
    }
  }

  async attachGamepassLink(orderId: string, userId: string, text: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.discordUserId !== userId) throw new Error("Este pedido pertence a outro usuário.");
    const id = this.parseGamepassUrl(text);
    if (!id) throw new Error("Envie o link completo da Game Pass do Roblox.");
    const info = await this.gamepassInfo(id);
    this.assertGamepassMatchesRequested(order.guildId, order.requestedRobux, info.price);
    order.gamepassId = info.id; order.gamepassName = info.name; order.gamepassPrice = info.price;
    order.gamepassProductId = info.productId; order.gamepassSellerId = info.sellerId;
    order.gamepassUrlOverride = this.gamepassUrl(info.id); order.awaitingGamepassLink = false; order.awaitingRobloxIdentity = false;
    if (!order.robloxUserId || /aguardando/i.test(order.robloxUsername)) {
      order.robloxUsername = "via-gamepass";
      order.robloxDisplayName = "Conta informada pela Game Pass";
    }
    order.error = ""; order.updatedAt = nowIso(); this.save();
    const mode = this.settings(order.guildId).deliveryMode;
    if (order.paymentStatus === "paid" && (mode === "COOKIE_AUTO" || (mode === "ASSISTED" && Boolean(order.sellerPaymentConfirmedAt)))) {
      await this.deliverWithConfiguredAccount(order.id);
    } else {
      await this.emitUpdate(order);
    }
    return order;
  }

  async attachManualIdentity(orderId: string, userId: string, text: string): Promise<RobuxOrder> {
    const order = this.state.orders[orderId];
    if (!order) throw new Error("Pedido Robux não encontrado.");
    if (order.discordUserId !== userId) throw new Error("Este pedido pertence a outro usuário.");
    const raw = String(text || "").trim();
    if (!raw) throw new Error("Envie seu username Roblox ou o link completo da Game Pass.");
    if (this.parseGamepassUrl(raw)) return this.attachGamepassLink(orderId, userId, raw);
    if (/^\d+$/.test(raw)) {
      const recommended = this.recommendedGamepassPrice(order.guildId, order.requestedRobux);
      throw new Error(`**${raw}** parece uma quantidade/preço, não um username Roblox. Envie seu **username Roblox** ou o **link completo da Game Pass**. Para este pedido, a Game Pass deve ficar em **${recommended.toLocaleString("pt-BR")} Robux**.`);
    }
    const username = raw.replace(/^@/, "").trim();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) throw new Error("Envie um username Roblox válido ou o link completo da Game Pass.");
    // Registro manual deliberado: não dependemos da API de busca para continuar.
    order.robloxUsername = username;
    order.robloxDisplayName = username;
    order.robloxUserId = 0;
    order.awaitingRobloxIdentity = false;
    order.awaitingGamepassLink = !order.gamepassUrlOverride && order.gamepassId <= 0;
    order.error = order.awaitingGamepassLink ? "Username registrado. Aguardando o link da Game Pass." : "";
    order.updatedAt = nowIso();
    this.save();
    await this.emitUpdate(order);
    return order;
  }

  async handlePurchaseThreadMessage(message: Message): Promise<void> {
    if (!message.guildId || message.author.bot || !message.channel.isThread?.()) return;
    const order = Object.values(this.state.orders).find((item) => item.purchaseThreadId === message.channelId && item.discordUserId === message.author.id && (item.awaitingGamepassLink || item.awaitingRobloxIdentity) && !["DELIVERED", "CANCELED", "EXPIRED"].includes(item.status));
    if (!order) return;
    try {
      const updated = await this.attachManualIdentity(order.id, message.author.id, message.content || "");
      if (message.channel.isSendable()) {
        const needsPass = Boolean(updated.awaitingGamepassLink);
        const recommended = this.recommendedGamepassPrice(updated.guildId, updated.requestedRobux);
        await message.channel.send({
          content: needsPass
            ? `✅ ${message.author}, username **${updated.robloxUsername}** registrado. Agora crie/ajuste a Game Pass para **${recommended.toLocaleString("pt-BR")} Robux** e envie o **link completo**. Considerando a taxa de 30%, ela entrega cerca de **${updated.requestedRobux.toLocaleString("pt-BR")} Robux**.`
            : `✅ ${message.author}, dados Roblox vinculados ao pedido **${order.id}**. A página de entrega foi atualizada.`,
          allowedMentions: { users: [message.author.id] }
        });
      }
    } catch (error) {
      if (message.channel.isSendable()) await message.channel.send({ content: `❌ ${message.author}, ${safeError(error)}`, allowedMentions: { users: [message.author.id] } }).catch(() => undefined);
    }
  }

  private async announcePurchase(order: RobuxOrder): Promise<void> {
    const settings = this.settings(order.guildId);
    if (!settings.announcementEnabled || !settings.announcementChannelId) return;
    const channel = await this.client.channels.fetch(settings.announcementChannelId).catch(() => undefined);
    if (!channel?.isSendable()) return;
    const buyUrl = settings.panelChannelId
      ? `https://discord.com/channels/${order.guildId}/${settings.panelChannelId}${settings.panelMessageId ? `/${settings.panelMessageId}` : ""}`
      : "";
    const row = buyUrl
      ? new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(buyUrl).setLabel("Comprar"))
      : undefined;
    const avatarUrl = order.robloxUserId > 0 ? await this.robloxAvatarUrl(order.robloxUserId).catch(() => "") : "";
    const serverName = this.client.guilds.cache.get(order.guildId)?.name || "Servidor";
    if (settings.announcementFormat === "EMBED") {
      const display = order.robloxDisplayName || order.robloxUsername;
      const embed = new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle("✅ Compra Realizada")
        .setDescription(`A entrega foi concluída com sucesso para **${display}**${order.robloxUsername && order.robloxUsername !== "via-gamepass" ? ` (@${order.robloxUsername})` : ""}.`)
        .addFields(
          { name: "Carrinho", value: `🎮 **${order.requestedRobux.toLocaleString("pt-BR")}x Robux**`, inline: true },
          { name: "Valor pago", value: `**R$ ${(order.amountCents / 100).toFixed(2).replace(".", ",")}**`, inline: true }
        )
        .setFooter({ text: `${serverName} • compra entregue` })
        .setTimestamp();
      if (avatarUrl) embed.setThumbnail(avatarUrl);
      await channel.send({ embeds: [embed], components: row ? [row] : [] });
      return;
    }
    let avatarBytes: Buffer | undefined;
    if (avatarUrl) {
      try {
        const response = await fetch(avatarUrl, { signal: AbortSignal.timeout(12_000) });
        if (response.ok) avatarBytes = Buffer.from(await response.arrayBuffer());
      } catch { /* avatar é decorativo */ }
    }
    const image = await renderRobuxPurchasePng(settings, order, serverName, avatarBytes);
    await channel.send({ files: [new AttachmentBuilder(image, { name: "zenyx-compra-robux.png" })], components: row ? [row] : [] });
  }

  private async sendDeliveryReceipt(order: RobuxOrder): Promise<boolean> {
    const user = await this.client.users.fetch(order.discordUserId).catch(() => undefined);
    if (!user) return false;
    const avatarUrl = await this.robloxAvatarUrl(order.robloxUserId).catch(() => "");
    const deliveredTs = Math.floor(Date.parse(order.deliveredAt || nowIso()) / 1000);
    const display = order.robloxDisplayName || order.robloxUsername;
    const embed = new EmbedBuilder()
      .setColor(0x22c55e)
      .setTitle("✅ Entrega concluída")
      .setDescription("Sua compra de Robux foi finalizada com sucesso.")
      .addFields(
        { name: "Roblox", value: `**${display}**\n@${order.robloxUsername}`, inline: true },
        { name: "Compra", value: `**${order.requestedRobux.toLocaleString("pt-BR")} Robux**\nR$ ${(order.amountCents / 100).toFixed(2).replace(".", ",")}`, inline: true },
        { name: "Entregue", value: `<t:${deliveredTs}:f>`, inline: false }
      )
      .setFooter({ text: `Pedido ${order.id} • pedido` });
    if (avatarUrl) embed.setThumbnail(avatarUrl);
    const gamepassUrl = order.gamepassUrlOverride || (order.gamepassId > 0 ? this.gamepassUrl(order.gamepassId) : "");
    const components = gamepassUrl
      ? [new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(gamepassUrl).setLabel("Ver gamepass"))]
      : [];
    return Boolean(await user.send({ embeds: [embed], components }).then(() => true).catch(() => false));
  }

  private async finalizeDelivered(order: RobuxOrder): Promise<void> {
    if (!order.deliveryReceiptSentAt) {
      const sent = await this.sendDeliveryReceipt(order).catch(() => false);
      if (sent) order.deliveryReceiptSentAt = nowIso();
    }
    if (!order.deliveryAnnouncementAt) {
      try {
        await this.announcePurchase(order);
        order.deliveryAnnouncementAt = nowIso();
        order.announcedAt = order.deliveryAnnouncementAt;
      } catch (error) {
        this.logger.warn("Falha ao publicar anúncio pós-entrega da compra Robux.", { orderId: order.id, error: safeError(error) });
      }
    }
    order.updatedAt = nowIso();
    this.save();
    const channelId = this.settings(order.guildId).logChannelId;
    if (channelId) {
      const channel = await this.client.channels.fetch(channelId).catch(() => undefined);
      if (channel?.isSendable()) {
        const log = new EmbedBuilder()
          .setColor(0x22c55e)
          .setTitle("✅ Robux • entrega concluída")
          .addFields(
            { name: "Pedido", value: `\`${order.id}\``, inline: true },
            { name: "Cliente", value: `<@${order.discordUserId}>`, inline: true },
            { name: "Roblox", value: order.robloxUsername === "via-gamepass" ? "Informado via Game Pass" : `@${order.robloxUsername}`, inline: true },
            { name: "Compra", value: `**${order.requestedRobux.toLocaleString("pt-BR")} Robux**`, inline: true },
            { name: "Valor", value: `**R$ ${(order.amountCents / 100).toFixed(2).replace(".", ",")}**`, inline: true }
          )
          .setTimestamp();
        await channel.send({ embeds: [log] }).catch(() => undefined);
      }
    }
  }

  private async notifyOrder(order: RobuxOrder, text: string): Promise<void> {
    const user = await this.client.users.fetch(order.discordUserId).catch(() => undefined);
    const avatarUrl = await this.robloxAvatarUrl(order.robloxUserId).catch(() => "");
    const statusColor = order.status === "DELIVERED" ? 0x22c55e
      : order.status === "DELIVERY_REVIEW" || order.paymentConfirmationRequestedAt ? 0xf59e0b
        : order.status === "CANCELED" || order.status === "EXPIRED" ? 0xef4444
          : 0x3155ff;
    const title = order.status === "DELIVERED" ? "Pedido entregue"
      : order.paymentStatus === "paid" ? "Pagamento confirmado"
        : order.paymentConfirmationRequestedAt ? "Confirmação de PIX recebida"
          : "Atualização do pedido";
    const embed = new EmbedBuilder()
      .setColor(statusColor)
      .setTitle(title)
      .setDescription(text)
      .addFields(
        { name: "Pedido", value: `\`${order.id}\``, inline: true },
        { name: "Roblox", value: `**${order.robloxDisplayName || order.robloxUsername}**\n@${order.robloxUsername}`, inline: true },
        { name: "Compra", value: `**${order.requestedRobux.toLocaleString("pt-BR")} Robux**\nR$ ${(order.amountCents / 100).toFixed(2).replace(".", ",")}`, inline: true },
        { name: "Método", value: order.provider.replaceAll("_", " "), inline: true },
        { name: "Status", value: order.status.replaceAll("_", " "), inline: true }
      )
      .setTimestamp();
    if (avatarUrl) embed.setThumbnail(avatarUrl);
    const threadUrl = order.purchaseThreadId ? `https://discord.com/channels/${order.guildId}/${order.purchaseThreadId}` : "";
    const dmRows = threadUrl
      ? [new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(threadUrl).setLabel("Abrir pedido"))]
      : [];
    await user?.send({ embeds: [embed], components: dmRows }).catch(() => undefined);
    const channelId = this.settings(order.guildId).logChannelId;
    if (!channelId) return;
    const channel = await this.client.channels.fetch(channelId).catch(() => undefined);
    if (channel?.isSendable()) {
      const logEmbed = new EmbedBuilder(embed.toJSON())
        .setTitle(`Log Robux • ${title}`)
        .setFooter({ text: `Discord ${order.discordUserId}` });
      await channel.send({ embeds: [logEmbed] }).catch(() => undefined);
    }
  }
}
