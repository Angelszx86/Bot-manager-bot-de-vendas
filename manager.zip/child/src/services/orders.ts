import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, Client, EmbedBuilder } from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { Logger } from "../core/logger.js";
import { colorNumber, formatMoney, makeId, normalizeName, nowIso, truncate } from "../core/utils.js";
import type { DeliveredProduct, Order, OrderItem, PaymentProviderName } from "../types.js";
import { PaymentManager } from "./payments.js";
import { ProductService } from "./products.js";

type OrderListener = (order: Order) => void | Promise<void>;

export class OrderService {
  private timer?: NodeJS.Timeout;
  private running = false;
  private listeners = new Set<OrderListener>();
  private fulfillmentLocks = new Set<string>();

  constructor(
    private readonly client: Client,
    private readonly db: JsonDatabase,
    private readonly products: ProductService,
    private readonly payments: PaymentManager,
    private readonly logger: Logger
  ) {}

  onUpdate(listener: OrderListener): () => void { this.listeners.add(listener); return () => this.listeners.delete(listener); }
  private async emit(order: Order): Promise<void> {
    for (const listener of this.listeners) {
      try { await listener(order); }
      catch (error) { this.logger.warn("Falha ao atualizar uma interface vinculada ao pedido.", { orderId: order.id, error: String(error) }); }
    }
  }

  pendingImap(): Order[] {
    return Object.values(this.db.state.orders).filter((order) => order.status === "PENDING" && order.provider === "IMAP_PIX" && Date.parse(order.expiresAt) > Date.now());
  }
  get(id: string, guildId?: string): Order { const order = this.db.state.orders[id]; if (!order || (guildId && order.guildId !== guildId)) throw new Error("Pedido não encontrado."); return order; }
  userOrders(userId: string, guildId?: string): Order[] { return Object.values(this.db.state.orders).filter((order) => order.userId === userId && (!guildId || order.guildId === guildId)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }

  async createFromCart(input: { guildId: string; userId: string; username: string; couponCode?: string; purchaseChannelId?: string; provider?: PaymentProviderName; payerFullName?: string; payerDocument?: string }): Promise<Order> {
    const cart = this.products.getCartSession(input.guildId, input.userId);
    if (!cart?.items.length) throw new Error("Seu carrinho está vazio.");
    if (cart.status === "PAYMENT_PENDING" && cart.orderId) return this.get(cart.orderId, input.guildId);
    const paymentSettings = this.db.payments(input.guildId);
    const provider = input.provider ?? (cart.selectedProvider || paymentSettings.defaultProvider);
    if (!this.payments.enabled(input.guildId, provider)) throw new Error("A forma de pagamento selecionada não está disponível.");
    const payerFullNameRaw = (input.payerFullName ?? "").trim().replace(/\s+/g, " ").slice(0, 120);
    const payerFullName = normalizeName(payerFullNameRaw);
    const payerDocument = (input.payerDocument ?? "").replace(/\D/g, "").slice(0, 14);
    if (provider === "IMAP_PIX" && payerFullName.split(" ").filter(Boolean).length < 2) {
      throw new Error("Informe o nome completo de quem fará o Pix para a verificação IMAP.");
    }
    if (["STRIPE", "MISTIC_PAY"].includes(provider)) {
      if (payerFullName.split(" ").filter(Boolean).length < 2) throw new Error("Informe o nome completo de quem fará o PIX.");
      if (![11, 14].includes(payerDocument.length)) throw new Error("Informe um CPF com 11 dígitos ou CNPJ com 14 dígitos.");
    }

    const now = nowIso();
    const expirationMinutes = provider === "IMAP_PIX" ? Math.min(paymentSettings.orderExpiresMinutes, paymentSettings.imapPix.maxWaitMinutes) : paymentSettings.orderExpiresMinutes;
    // Pagamentos manuais permanecem pendentes até uma decisão da equipe. O
    // gateway automático usa sua validade própria em segundos para que o estado
    // local expire no mesmo horizonte da cobrança remota.
    const expiresAt = provider === "MANUAL_PIX"
      ? "9999-12-31T23:59:59.999Z"
      : provider === "EVO_PAY"
        ? new Date(Date.now() + Math.max(180, Math.min(7200, paymentSettings.evoPay.expiresIn || 900)) * 1000).toISOString()
        : provider === "ZNY_PAY"
          ? new Date(Date.now() + Math.max(180, Math.min(7200, paymentSettings.znyPay.expiresIn || 900)) * 1000).toISOString()
          : new Date(Date.now() + Math.max(1, expirationMinutes) * 60000).toISOString();
    const orderId = makeId("ORD").toUpperCase();
    const items: OrderItem[] = []; let subtotalCents = 0;
    try {
      for (const cartItem of cart.items) {
        const product = this.products.get(cartItem.productId, input.guildId); const field = this.products.getField(product.id, cartItem.fieldId);
        if (!product.active || !field.active) throw new Error(`${product.name} • ${field.name} está indisponível.`);
        const limit = this.products.quantityLimit(product, field); if (cartItem.quantity < 1 || cartItem.quantity > limit) throw new Error(`Quantidade inválida para ${product.name} • ${field.name}. Máximo: ${limit}.`);
        if (product.perUserLimit > 0) {
          const alreadyPurchased = this.userOrders(input.userId, input.guildId).filter((order) => ["PAID", "DELIVERED", "AWAITING_DELIVERY"].includes(order.status)).flatMap((order) => order.items).filter((item) => item.productId === product.id && item.fieldId === field.id).reduce((sum, item) => sum + item.quantity, 0);
          if (alreadyPurchased + cartItem.quantity > product.perUserLimit) throw new Error(`Seu limite individual para ${product.name} • ${field.name} é ${product.perUserLimit}.`);
        }
        const reservedStockIds = product.deliveryType === "STOCK" ? this.products.reserveStock(product.id, field.id, cartItem.quantity, orderId, expiresAt) : [];
        items.push({ productId: product.id, fieldId: field.id, productName: product.name, fieldName: field.name, quantity: cartItem.quantity, unitPriceCents: field.priceCents, deliveryType: product.deliveryType, roleId: product.roleId, deliveryMessage: product.deliveryMessage, reservedStockIds });
        subtotalCents += field.priceCents * cartItem.quantity;
      }
      const applied = this.products.applyCoupon(input.couponCode ?? cart.couponCode, subtotalCents, { guildId: input.guildId, userId: input.userId, productIds: items.map((item) => item.productId) });
      const order: Order = {
        id: orderId, guildId: input.guildId, userId: input.userId, status: "PENDING", items, subtotalCents,
        discountCents: applied.discountCents, totalCents: Math.max(0, subtotalCents - applied.discountCents), couponCode: applied.coupon?.code ?? "", couponUsageRegistered: false,
        provider, providerPaymentId: "", pixCode: "", qrCodeDataUrl: "", discordDisplayName: input.username.trim() || `Discord ${input.userId}`,
        payerEmail: paymentSettings.mercadoPago.payerEmail.trim() || `${input.userId}@discord.invalid`,
        payerFullName: ["IMAP_PIX", "STRIPE", "MISTIC_PAY"].includes(provider) ? payerFullNameRaw : "",
        payerDocument,
        imapBank: provider === "IMAP_PIX" ? paymentSettings.imapPix.bank : "",
        purchaseChannelId: input.purchaseChannelId || cart.channelId,
        cartId: cart.id, paymentReference: orderId.replace(/[^A-Za-z0-9]/g, "").slice(-25), verificationStatus: "PENDING", verificationDetails: {},
        paymentKey: this.payments.paymentKey(input.guildId, provider), deliveredProducts: [], fulfilledItemKeys: [], expiresAt, createdAt: now, updatedAt: now
      };
      if (provider === "ZNY_PAY" && order.totalCents < paymentSettings.znyPay.minOrderCents) {
        throw new Error(`O Znypay aceita compras a partir de ${formatMoney(paymentSettings.znyPay.minOrderCents)}.`);
      }
      this.db.state.orders[order.id] = order; this.db.ensureUser(input.guildId, input.userId, input.username);
      cart.status = "PAYMENT_PENDING"; cart.orderId = order.id; cart.selectedProvider = provider; cart.updatedAt = nowIso(); this.db.save();

      if (order.totalCents === 0) {
        order.providerPaymentId = `free_${order.id}`; await this.markPaid(order.id, { source: "zero-total" }); return order;
      }
      const charge = await this.payments.create(provider, { guildId: input.guildId, orderId: order.id, amountCents: order.totalCents, description: `Pedido ${order.id} - ${items.map((item) => `${item.productName} (${item.fieldName})`).join(", ")}`, customer: { discordId: input.userId, name: order.payerFullName || order.discordDisplayName, email: order.payerEmail, document: order.payerDocument }, expiresAt });
      order.providerPaymentId = charge.externalId; order.pixCode = charge.pixCode ?? ""; order.qrCodeDataUrl = charge.qrCodeDataUrl ?? ""; order.paymentReference = charge.reference ?? order.paymentReference; order.expiresAt = charge.expiresAt ?? order.expiresAt; order.updatedAt = nowIso();
      cart.status = "PAYMENT_PENDING"; cart.orderId = order.id; cart.selectedProvider = provider; cart.updatedAt = nowIso();
      this.db.audit(input.userId, "ORDER_CREATE", "order", order.id, { guildId: input.guildId, totalCents: order.totalCents, provider, imapBank: order.imapBank }, input.guildId); this.db.save();
      if (charge.status === "paid") await this.markPaid(order.id, { source: "provider-create" }); else await this.emit(order);
      return order;
    } catch (error) {
      this.releaseOrderReservations({ id: orderId, items } as Order); delete this.db.state.orders[orderId];
      cart.status = "ACTIVE"; cart.orderId = ""; cart.updatedAt = nowIso(); this.db.save(); throw error;
    }
  }

  async markPaid(orderId: string, proof: Record<string, unknown> = {}): Promise<void> {
    const order = this.get(orderId);
    if (order.status === "DELIVERED") {
      // Um webhook/poll repetido nunca refaz a entrega. Ele apenas pode concluir
      // notificações/logs que falharam depois de o fulfillment já ter sido salvo.
      if (!order.deliveryNotificationSentAt) await this.sendDeliveryNotification(order, Boolean(order.manualDeliveryCompletedAt));
      await this.sendFulfillmentLog(order);
      await this.emit(order);
      return;
    }
    if (order.status === "AWAITING_DELIVERY") {
      await this.sendFulfillmentLog(order);
      await this.emit(order);
      return;
    }
    if (order.status === "PAID") {
      // Recuperação após restart: o pagamento já foi persistido, mas a entrega
      // pode ter sido interrompida antes de finalizar.
      if (order.provider === "ZNY_PAY" && !order.walletCreditedAt) {
        this.creditZnyPayWallet(order);
        this.db.save();
      }
      await this.fulfill(order);
      await this.emit(order);
      return;
    }
    if (order.status !== "PENDING") throw new Error(`Pedido ${order.id} não está pendente.`);
    order.status = "PAID";
    order.paidAt = order.paidAt || nowIso();
    order.verificationStatus = "MATCHED";
    order.verificationDetails = { ...(order.verificationDetails ?? {}), ...this.safeProof(proof) };
    order.updatedAt = nowIso();
    if (order.couponCode && !order.couponUsageRegistered) {
      const coupon = this.products.getCoupon(order.guildId, order.couponCode);
      this.products.registerCouponUsage(coupon, order.userId, order.id, order.discountCents);
      order.couponUsageRegistered = true;
    }
    this.products.archiveCartById(order.cartId, "PAID");
    this.db.paymentAudit(order.guildId, "PAYMENT_APPROVED", order.id, { provider: order.provider, proof: this.safeProof(proof) });
    if (order.provider === "ZNY_PAY") this.creditZnyPayWallet(order);
    // O estado PAID é persistido ANTES do fulfillment. Se o processo cair daqui
    // para frente, o polling retoma a entrega sem cobrar/consumir duas vezes.
    this.db.save();
    await this.fulfill(order);
    await this.emit(order);
  }

  async approveManual(orderId: string, actorId: string): Promise<void> {
    const order = this.get(orderId);
    if (order.provider !== "MANUAL_PIX") throw new Error("A aprovação manual só pode ser usada em pagamentos PIX manuais.");
    if (order.status !== "PENDING") throw new Error("Este pagamento manual não está pendente.");
    await this.markPaid(orderId, { source: "manual-approval", actorId });
    this.db.audit(actorId, "ORDER_APPROVE", "order", orderId, { guildId: order.guildId }, order.guildId);
  }

  async completeManualDelivery(orderId: string, actorId: string): Promise<void> {
    const order = this.get(orderId);
    if (order.status === "DELIVERED" && order.manualDeliveryCompletedAt) {
      if (!order.deliveryNotificationSentAt) await this.sendDeliveryNotification(order, true);
      await this.sendFulfillmentLog(order);
      await this.emit(order);
      return;
    }
    if (order.status !== "AWAITING_DELIVERY") throw new Error("Este pedido não está aguardando entrega manual.");
    const completedAt = nowIso();
    order.status = "DELIVERED";
    order.deliveredAt = completedAt;
    order.manualDeliveryCompletedAt = completedAt;
    order.fulfillmentCompletedAt = order.fulfillmentCompletedAt || completedAt;
    order.updatedAt = completedAt;
    this.db.audit(actorId, "ORDER_MANUAL_DELIVERY_COMPLETE", "order", order.id, { guildId: order.guildId }, order.guildId);
    this.db.save();
    await this.sendDeliveryNotification(order, true);
    await this.sendFulfillmentLog(order);
    await this.emit(order);
  }

  cancel(orderId: string, actorId: string): void {
    const order = this.get(orderId); if (order.status !== "PENDING") throw new Error("Somente pedidos pendentes podem ser cancelados.");
    order.status = "CANCELED"; order.updatedAt = nowIso(); this.releaseOrderReservations(order); this.products.archiveCartById(order.cartId, "CANCELED");
    this.db.audit(actorId, "ORDER_CANCEL", "order", order.id, { guildId: order.guildId }, order.guildId); this.db.paymentAudit(order.guildId, "PAYMENT_CANCELED", order.id); this.db.save(); void this.emit(order);
  }

  markEnded(orderId: string, status: "CANCELED" | "EXPIRED", actorId = "provider"): void {
    const order = this.get(orderId); if (order.status !== "PENDING") return;
    order.status = status; order.updatedAt = nowIso(); this.releaseOrderReservations(order); this.products.archiveCartById(order.cartId, status);
    this.db.audit(actorId, status === "EXPIRED" ? "ORDER_EXPIRE" : "ORDER_CANCEL", "order", order.id, { guildId: order.guildId, source: actorId }, order.guildId);
    this.db.paymentAudit(order.guildId, status === "EXPIRED" ? "PAYMENT_EXPIRED" : "PAYMENT_CANCELED", order.id, { source: actorId });
    this.db.save(); void this.emit(order);
  }

  private releaseOrderReservations(order: Pick<Order, "id" | "items">): void { for (const item of order.items) this.products.releaseReservation(item.productId, item.fieldId, order.id); }
  private safeProof(proof: Record<string, unknown>): Record<string, unknown> { const copy = { ...proof }; for (const key of Object.keys(copy)) if (/token|password|secret|authorization/i.test(key)) copy[key] = "[REMOVIDO]"; return copy; }

  private creditZnyPayWallet(order: Order): void {
    if (order.walletCreditedAt) return;
    const settings = this.db.payments(order.guildId).znyPay;
    const feeCents = Math.min(order.totalCents, Math.max(0, settings.purchaseFeeCents));
    const netCents = Math.max(0, order.totalCents - feeCents);
    const account = this.db.wallet(order.guildId, false);
    const createdAt = nowIso();
    account.balanceCents += netCents;
    account.transactions.unshift({
      id: makeId("ZWT"),
      guildId: order.guildId,
      type: "SALE_CREDIT",
      status: "COMPLETED",
      amountCents: order.totalCents,
      feeCents,
      netCents,
      orderId: order.id,
      note: `Venda Znypay ${order.id}`,
      createdAt
    });
    if (account.transactions.length > 10000) account.transactions.length = 10000;
    account.updatedAt = createdAt;
    order.walletCreditedAt = createdAt;
    order.walletCreditCents = netCents;
  }

  private itemFulfillmentKey(item: OrderItem, index: number): string {
    return `${index}:${item.productId}:${item.fieldId}`;
  }

  private async fulfill(order: Order): Promise<void> {
    if (this.fulfillmentLocks.has(order.id)) return;
    this.fulfillmentLocks.add(order.id);
    try {
      // Mesmo quando a entrega já foi processada, podemos precisar concluir uma
      // notificação que falhou por DM fechada/restart.
      if (order.fulfillmentCompletedAt) {
        if (order.status === "DELIVERED" && !order.deliveryNotificationSentAt) await this.sendDeliveryNotification(order, false);
        await this.sendFulfillmentLog(order);
        return;
      }

      const guild = await this.client.guilds.fetch(order.guildId).catch(() => undefined);
      const user = await this.client.users.fetch(order.userId).catch(() => undefined);
      const member = guild ? await guild.members.fetch(order.userId).catch(() => undefined) : undefined;
      const deliveredProducts: DeliveredProduct[] = Array.isArray(order.deliveredProducts) ? [...order.deliveredProducts] : [];
      const completedKeys = new Set(Array.isArray(order.fulfilledItemKeys) ? order.fulfilledItemKeys : []);
      let manual = false;

      for (const [index, item] of order.items.entries()) {
        const key = this.itemFulfillmentKey(item, index);
        if (completedKeys.has(key)) {
          if (item.deliveryType === "MANUAL") manual = true;
          continue;
        }

        if (item.deliveryType === "STOCK") {
          let contents = this.products.consumeReservation(item.productId, item.fieldId, order.id);
          if (!contents.length) {
            // Caso o processo tenha caído exatamente após a baixa do estoque,
            // recuperamos as unidades já marcadas como vendidas para este pedido.
            contents = this.products.consumedContentsForOrder(item.productId, item.fieldId, order.id, item.quantity);
          }
          if (contents.length < item.quantity) {
            throw new Error(`Não foi possível concluir com segurança a entrega de ${item.productName} • ${item.fieldName}.`);
          }
          const existingForItem = deliveredProducts.filter((entry) => entry.productId === item.productId && entry.fieldId === item.fieldId).length;
          for (const content of contents.slice(existingForItem, item.quantity)) {
            deliveredProducts.push({
              id: makeId("DLV"),
              productId: item.productId,
              fieldId: item.fieldId,
              productName: item.productName,
              fieldName: item.fieldName,
              content,
              deliveredAt: nowIso()
            });
          }
        } else if (item.deliveryType === "ROLE") {
          if (!member || !item.roleId) {
            manual = true;
          } else {
            const applied = await member.roles.add(item.roleId, `Compra ${order.id}`).then(() => true).catch((error) => {
              this.logger.warn("Não foi possível aplicar o cargo automático; pedido seguirá para entrega assistida.", { orderId: order.id, roleId: item.roleId, error: String(error) });
              return false;
            });
            if (!applied) manual = true;
          }
        } else {
          manual = true;
        }

        completedKeys.add(key);
        order.deliveredProducts = deliveredProducts;
        order.fulfilledItemKeys = [...completedKeys];
        order.updatedAt = nowIso();
        // Checkpoint por item: reduz a janela de duplicação em caso de restart.
        this.db.save();
      }

      const guildSettings = this.db.guild(order.guildId);
      if (member && guildSettings.customerRoleId) await member.roles.add(guildSettings.customerRoleId, `Cliente ${order.id}`).catch(() => undefined);

      const completedAt = nowIso();
      order.deliveredProducts = deliveredProducts;
      order.fulfilledItemKeys = [...completedKeys];
      order.status = manual ? "AWAITING_DELIVERY" : "DELIVERED";
      order.deliveredAt = manual ? undefined : completedAt;
      order.fulfillmentCompletedAt = completedAt;
      order.updatedAt = completedAt;

      if (!order.profileAccountingAppliedAt) {
        const profile = this.db.ensureUser(order.guildId, order.userId, user?.username ?? "");
        profile.totalSpentCents += order.totalCents;
        profile.purchases += 1;
        profile.updatedAt = completedAt;
        order.profileAccountingAppliedAt = completedAt;
      }
      this.db.save();

      // Entrega manual não gera DM de "concluído" antes da equipe realmente
      // finalizar. O checkout compartilhado é atualizado pelo listener do pedido.
      if (!manual) await this.sendDeliveryNotification(order, false);
      await this.sendFulfillmentLog(order);
    } finally {
      this.fulfillmentLocks.delete(order.id);
    }
  }

  private deliveryReceipt(order: Order, manual: boolean, user?: { displayAvatarURL?: () => string; username?: string }): EmbedBuilder {
    const brand = this.db.brand(order.guildId);
    const providerLabel = order.provider === "EVO_PAY"
      ? "PIX automático"
      : order.provider === "ZNY_PAY"
        ? "Znypay"
        : order.provider === "MANUAL_PIX"
          ? "PIX manual"
          : order.provider.replaceAll("_", " " );
    const productLines = order.items.map((item) => {
      const option = item.fieldName && item.fieldName !== "Opção principal" ? ` • ${item.fieldName}` : "";
      return `**${item.quantity}× ${item.productName}**${option}`;
    }).join("\n").slice(0, 1024) || "Pedido concluído";
    const deliveries = Array.isArray(order.deliveredProducts) ? order.deliveredProducts : [];
    const contentPreview = deliveries.length
      ? deliveries.slice(0, 6).map((entry, index) => {
          const prefix = deliveries.length > 1 ? `[${index + 1}] ` : "";
          return `${prefix}${String(entry.content || "").trim()}`;
        }).filter(Boolean).join("\n\n")
      : "";
    const safePreview = truncate(contentPreview.replace(/```/g, "'''"), 900);
    const extraCount = Math.max(0, deliveries.length - 6);
    const customMessages = [...new Set(order.items.map((item) => String(item.deliveryMessage || "").trim()).filter((message) =>
      message && !["Obrigado pela compra!", "Entrega automática após a confirmação do pagamento.", "A equipe realizará a entrega manualmente neste canal."].includes(message)
    ))];

    const embed = new EmbedBuilder()
      .setTitle(manual ? "Entrega confirmada" : "Seu produto foi entregue!")
      .setDescription(manual
        ? "Sua compra foi concluída e a equipe confirmou a entrega.\n-# Obrigado pela compra. Guarde os dados deste pedido em segurança."
        : "Obrigado pela compra! Seu produto já está disponível abaixo.\n-# Guarde estes dados em segurança e use os botões para copiar quando precisar.")
      .addFields(
        { name: "Produto", value: productLines, inline: false },
        { name: "Valor pago", value: `**${formatMoney(order.totalCents)}**`, inline: true },
        { name: "Pagamento", value: providerLabel, inline: true },
        { name: "Pedido", value: `\`${order.id}\``, inline: false }
      );
    if (safePreview) {
      embed.addFields({
        name: deliveries.length > 1 ? "Conteúdos entregues" : "Conteúdo entregue",
        value: `\`\`\`\n${safePreview}\n\`\`\`${extraCount ? `\n-# +${extraCount} item(ns) disponível(is) nos botões de cópia.` : ""}`,
        inline: false
      });
    } else if (!manual && order.items.some((item) => item.deliveryType === "ROLE")) {
      embed.addFields({ name: "Entrega", value: "Benefício aplicado automaticamente à sua conta.", inline: false });
    } else if (manual) {
      embed.addFields({ name: "Entrega", value: "Confirmada pela equipe.", inline: false });
    }
    if (customMessages.length) {
      embed.addFields({ name: "Mensagem da loja", value: truncate(customMessages.join("\n"), 1024), inline: false });
    }
    embed.setFooter({ text: truncate(`${brand.name || "Loja"} • entrega concluída`, 2048) }).setTimestamp();
    if (brand.showAccentColors) embed.setColor(colorNumber(brand.color));
    const avatar = user?.displayAvatarURL?.();
    if (avatar) embed.setThumbnail(avatar);
    if (/^https?:\/\//i.test(String(brand.logoUrl || ""))) embed.setAuthor({ name: truncate(brand.name || "Loja", 256), iconURL: String(brand.logoUrl) });
    else if (brand.name?.trim()) embed.setAuthor({ name: truncate(brand.name, 256) });
    return embed;
  }

  private buildDeliveryRows(order: Order, deliveries: DeliveredProduct[], offset = 0): ActionRowBuilder<ButtonBuilder>[] {
    const rows: ActionRowBuilder<ButtonBuilder>[] = [];
    for (let start = 0; start < deliveries.length; start += 5) {
      const slice = deliveries.slice(start, start + 5);
      rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...slice.map((delivery, localIndex) =>
        new ButtonBuilder()
          .setCustomId(`delivery:copy:${order.id}:${delivery.id}`.slice(0, 100))
          .setLabel((deliveries.length === 1 && offset === 0 ? "Copiar conteúdo" : `Copiar ${offset + start + localIndex + 1}`).slice(0, 80))
          .setStyle(ButtonStyle.Primary)
      )));
    }
    return rows;
  }

  private async sendDeliveryNotification(order: Order, manual: boolean): Promise<void> {
    if (order.deliveryNotificationSentAt) return;
    const user = await this.client.users.fetch(order.userId).catch(() => undefined);
    const purchaseChannel = order.purchaseChannelId
      ? await this.client.channels.fetch(order.purchaseChannelId).catch(() => undefined)
      : undefined;
    const purchaseTarget = purchaseChannel?.isTextBased() && "send" in purchaseChannel ? purchaseChannel : undefined;
    if (!user && !purchaseTarget) return;

    const deliveries = Array.isArray(order.deliveredProducts) ? order.deliveredProducts : [];
    const pages = deliveries.length ? Math.max(1, Math.ceil(deliveries.length / 25)) : 1;
    const sentPageIds = Array.isArray(order.deliveryNotificationPageIds) ? [...order.deliveryNotificationPageIds] : [];

    const sendToDestination = async (payload: { embeds: EmbedBuilder[]; components: ActionRowBuilder<ButtonBuilder>[] }, mention = false) => {
      if (order.deliveryNotificationDestination === "PURCHASE_CHANNEL") {
        if (!purchaseTarget) return undefined;
        return purchaseTarget.send({
          ...(mention ? { content: `<@${order.userId}>` } : {}),
          ...payload,
          allowedMentions: { users: [order.userId] }
        }).catch(() => undefined);
      }
      if (order.deliveryNotificationDestination === "DM") {
        return user?.send(payload).catch(() => undefined);
      }

      // Primeira tentativa sempre é por DM. Se o usuário bloqueou DMs, usamos o
      // carrinho privado como fallback sem perder a entrega nem duplicar o pedido.
      const dm = await user?.send(payload).catch(() => undefined);
      if (dm) {
        order.deliveryNotificationDestination = "DM";
        return dm;
      }
      if (!purchaseTarget) return undefined;
      const fallback = await purchaseTarget.send({
        content: `<@${order.userId}>`,
        ...payload,
        allowedMentions: { users: [order.userId] }
      }).catch(() => undefined);
      if (fallback) order.deliveryNotificationDestination = "PURCHASE_CHANNEL";
      return fallback;
    };

    // Persiste CADA página imediatamente. Se o processo cair depois do envio,
    // o restart continua exatamente da página seguinte.
    if (!sentPageIds[0]) {
      const firstPage = deliveries.slice(0, 25);
      const firstRows = firstPage.length ? this.buildDeliveryRows(order, firstPage) : [];
      const feedbackChannelId = this.db.guild(order.guildId).feedbackChannelId;
      if (/^\d{15,22}$/.test(feedbackChannelId) && firstRows.length < 5) {
        firstRows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${order.guildId}/${feedbackChannelId}`).setLabel("Enviar feedback")
        ));
      }
      const first = await sendToDestination({
        embeds: [this.deliveryReceipt(order, manual, user)],
        components: firstRows
      }, true);
      if (!first) {
        this.logger.warn("Não foi possível entregar a confirmação por DM nem pelo carrinho privado.", { orderId: order.id });
        return;
      }
      sentPageIds[0] = first.id;
      order.deliveryMessageId = first.id;
      order.deliveryNotificationPageIds = sentPageIds;
      order.updatedAt = nowIso();
      this.db.save();
    }

    for (let pageIndex = 1; pageIndex < pages; pageIndex++) {
      if (sentPageIds[pageIndex]) continue;
      const offset = pageIndex * 25;
      const page = deliveries.slice(offset, offset + 25);
      const sent = await sendToDestination({
        embeds: [(() => {
          const embed = new EmbedBuilder()
            .setTitle(`Produtos entregues • ${pageIndex + 1}/${pages}`)
            .setDescription("Use os botões abaixo para copiar as unidades restantes deste pedido.")
            .setFooter({ text: `Pedido ${order.id}` });
          if (this.db.brand(order.guildId).showAccentColors) embed.setColor(0x3155ff);
          return embed;
        })()],
        components: this.buildDeliveryRows(order, page, offset)
      });
      if (!sent) return;
      sentPageIds[pageIndex] = sent.id;
      order.deliveryNotificationPageIds = sentPageIds;
      order.updatedAt = nowIso();
      this.db.save();
    }

    order.deliveryNotificationSentAt = nowIso();
    order.deliveryNotificationPageIds = sentPageIds;
    order.deliveryMessageId ||= sentPageIds[0];
    order.updatedAt = nowIso();
    this.db.save();
  }

  private async sendFulfillmentLog(order: Order): Promise<void> {
    if (order.fulfillmentLogSentAt) return;
    const guildSettings = this.db.guild(order.guildId);
    if (!guildSettings.logChannelId) {
      order.fulfillmentLogSentAt = nowIso();
      this.db.save();
      return;
    }
    const logChannel = await this.client.channels.fetch(guildSettings.logChannelId).catch(() => undefined);
    if (!(logChannel?.isTextBased() && "send" in logChannel)) return;
    const providerLabel = order.provider === "EVO_PAY" ? "PIX automático" : order.provider === "ZNY_PAY" ? "Znypay" : order.provider.replaceAll("_", " ");
    const logEmbed = new EmbedBuilder()
      .setTitle(`${order.status === "AWAITING_DELIVERY" ? "Pagamento aprovado" : "Venda concluída"} • ${order.id}`)
      .setDescription(`<@${order.userId}> • ${formatMoney(order.totalCents)} • ${providerLabel}`)
      .addFields({ name: "Unidades automáticas", value: String(order.deliveredProducts?.length ?? 0), inline: true })
      .setTimestamp();
    if (this.db.brand(order.guildId).showAccentColors) logEmbed.setColor(order.status === "AWAITING_DELIVERY" ? 0xf59e0b : 0x22c55e);
    const sent = await logChannel.send({ embeds: [logEmbed] }).then(() => true).catch((error) => {
        this.logger.warn("Falha ao registrar fulfillment no canal de logs.", { orderId: order.id, error: String(error) });
        return false;
      });
    if (sent) {
      order.fulfillmentLogSentAt = nowIso();
      this.db.save();
    }
  }

  qrAttachment(order: Order): AttachmentBuilder | undefined { if (!order.qrCodeDataUrl.startsWith("data:image/")) return undefined; const match = order.qrCodeDataUrl.match(/^data:image\/[a-zA-Z0-9+.-]+;base64,(.+)$/); return match?.[1] ? new AttachmentBuilder(Buffer.from(match[1], "base64"), { name: "pix.png" }) : undefined; }

  startPolling() { this.stopPolling(); this.timer = setInterval(() => void this.poll(), 15_000); this.timer.unref?.(); setTimeout(() => void this.poll(), 7000).unref?.(); }
  stopPolling() { if (this.timer) clearInterval(this.timer); this.timer = undefined; }

  async poll() {
    if (this.running) return;
    this.running = true;
    try {
      // Primeiro recupera pagamentos que já haviam sido persistidos antes de um
      // restart, mas cujo fulfillment ficou incompleto.
      for (const order of Object.values(this.db.state.orders).filter((item) => item.status === "PAID" && !item.fulfillmentCompletedAt)) {
        try { await this.fulfill(order); await this.emit(order); }
        catch (error) { this.logger.warn(`Falha ao recuperar entrega ${order.id}.`, { error: String(error) }); this.db.errorAudit(order.guildId, "FULFILLMENT_RECOVERY_ERROR", { orderId: order.id, error: String(error) }); }
      }

      for (const order of Object.values(this.db.state.orders).filter((item) => item.status === "PENDING")) {
        if (order.provider === "MANUAL_PIX") continue;
        if (Date.parse(order.expiresAt) <= Date.now()) { this.markEnded(order.id, "EXPIRED", "system-expiration"); continue; }
        if (order.provider === "IMAP_PIX" || !order.providerPaymentId) continue;
        try {
          const charge = await this.payments.status(order.guildId, order.provider, order.providerPaymentId);
          if (charge.status === "paid") await this.markPaid(order.id, { source: "poll", externalId: charge.externalId });
          else if (["canceled", "expired"].includes(charge.status)) this.markEnded(order.id, charge.status === "expired" ? "EXPIRED" : "CANCELED", "provider-poll");
        } catch (error) {
          this.logger.warn(`Falha ao consultar ${order.id}.`, { error: String(error) });
          this.db.errorAudit(order.guildId, "PAYMENT_POLL_ERROR", { orderId: order.id, error: String(error) });
        }
      }
    } finally { this.running = false; }
  }
}
