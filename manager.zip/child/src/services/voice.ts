import { ChannelType, Client, PermissionFlagsBits } from "discord.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { Logger } from "../core/logger.js";

type VoiceLib = {
  joinVoiceChannel(options: Record<string, unknown>): any;
  getVoiceConnection(guildId: string): any;
  entersState(connection: any, status: unknown, timeout: number): Promise<any>;
  VoiceConnectionStatus: { Ready: unknown; Disconnected: unknown; Destroyed: unknown };
};

let cachedVoice: VoiceLib | null = null;
function voiceLib(): VoiceLib {
  if (cachedVoice) return cachedVoice;
  try {
    // require é intencional: permite que o bot principal continue iniciando mesmo
    // se uma instalação antiga ainda estiver terminando de receber a dependência.
    // O Manager instala @discordjs/voice 0.19.x durante a atualização oficial.
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    cachedVoice = require("@discordjs/voice") as VoiceLib;
    return cachedVoice;
  } catch {
    throw new Error("O módulo de voz ainda não está instalado nesta aplicação. Reinicie/atualize o bot pelo Manager para concluir a instalação do recurso Conectar.");
  }
}

export class VoiceService {
  private restoring = false;
  constructor(private readonly client: Client, private readonly db: JsonDatabase, private readonly logger: Logger) {}

  settings(guildId: string) {
    return this.db.guild(guildId).voiceConnection;
  }

  status(guildId: string) {
    const cfg = this.settings(guildId);
    let connected = false;
    try { connected = Boolean(voiceLib().getVoiceConnection(guildId)); } catch {}
    return { ...cfg, connected };
  }

  async connect(guildId: string, channelId: string): Promise<void> {
    const guild = this.client.guilds.cache.get(guildId) ?? await this.client.guilds.fetch(guildId);
    const channel = await guild.channels.fetch(channelId);
    if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type as ChannelType)) throw new Error("Escolha um canal de voz ou palco válido do servidor.");
    const me = guild.members.me ?? await guild.members.fetchMe();
    const permissions = channel.permissionsFor(me);
    if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions.has(PermissionFlagsBits.Connect)) {
      throw new Error("O bot precisa das permissões Ver canal e Conectar nesse canal de voz.");
    }

    const lib = voiceLib();
    const old = lib.getVoiceConnection(guildId);
    if (old) { try { old.destroy(); } catch {} }

    const connection = lib.joinVoiceChannel({
      channelId: channel.id,
      guildId,
      adapterCreator: guild.voiceAdapterCreator,
      selfDeaf: true,
      selfMute: true
    });
    try {
      await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 20_000);
      // Se o Discord desconectar a sessão por troca de endpoint/rede, tenta
      // recuperar sem exigir clique do usuário. Não cria outra conexão em paralelo.
      connection.on?.('stateChange', async (_oldState: any, newState: any) => {
        if (newState?.status !== lib.VoiceConnectionStatus.Disconnected) return;
        const cfg = this.settings(guildId);
        if (!cfg.enabled || cfg.channelId !== channel.id) return;
        try { await lib.entersState(connection, lib.VoiceConnectionStatus.Ready, 8_000); }
        catch {
          setTimeout(() => this.restore(guildId).catch((err) => this.logger.warn('Falha ao reconectar call persistente.', { guildId, error: String(err) })), 3000).unref?.();
        }
      });
    } catch (error) {
      try { connection.destroy(); } catch {}
      throw new Error(`O Discord não confirmou a conexão de voz: ${error instanceof Error ? error.message : String(error)}`);
    }

    this.db.updateGuild(guildId, (settings) => {
      settings.voiceConnection = { enabled: true, channelId: channel.id, selfDeaf: true, selfMute: true, reconnect: true, updatedAt: new Date().toISOString() };
    });
    this.logger.info("Conexão de voz persistente ativada.", { guildId, channelId: channel.id });
  }

  async disconnect(guildId: string): Promise<void> {
    try { voiceLib().getVoiceConnection(guildId)?.destroy(); } catch {}
    this.db.updateGuild(guildId, (settings) => {
      settings.voiceConnection = { ...settings.voiceConnection, enabled: false, channelId: "", updatedAt: new Date().toISOString() };
    });
    this.logger.info("Conexão de voz persistente desativada.", { guildId });
  }

  async restore(guildId: string): Promise<boolean> {
    const cfg = this.settings(guildId);
    if (!cfg.enabled || !cfg.channelId) return false;
    await this.connect(guildId, cfg.channelId);
    return true;
  }

  async restoreConfigured(): Promise<void> {
    if (this.restoring) return;
    this.restoring = true;
    try {
      for (const guild of this.client.guilds.cache.values()) {
        const cfg = this.settings(guild.id);
        if (!cfg.enabled || !cfg.channelId) continue;
        try { await this.connect(guild.id, cfg.channelId); }
        catch (error) { this.logger.warn("Não foi possível restaurar a call configurada; a preferência foi mantida para nova tentativa.", { guildId: guild.id, channelId: cfg.channelId, error: String(error) }); }
      }
    } finally { this.restoring = false; }
  }

  destroyAll(): void {
    for (const guild of this.client.guilds.cache.values()) {
      try { voiceLib().getVoiceConnection(guild.id)?.destroy(); } catch {}
    }
  }
}
