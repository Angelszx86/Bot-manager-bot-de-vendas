import {
  ActivityType,
  Client,
  Events,
  GatewayIntentBits,
  Partials,
  PermissionFlagsBits,
  REST,
  Routes
} from "discord.js";
import { closeSync, existsSync, openSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { loadConfig } from "./config.js";
import { JsonDatabase } from "./core/json-db.js";
import { CredentialStore } from "./core/credential-store.js";
import { Logger } from "./core/logger.js";
import { commands } from "./discord/commands.js";
import { InteractionRouter } from "./discord/router.js";
import { EmojiManager } from "./emojis/manager.js";
import { AutomationService } from "./services/automations.js";
import { GiveawayService } from "./services/giveaways.js";
import { ImapMonitor } from "./services/imap.js";
import { OrderService } from "./services/orders.js";
import { PaymentManager } from "./services/payments.js";
import { ProductService } from "./services/products.js";
import { TicketService } from "./services/tickets.js";
import { PermissionService } from "./services/permissions.js";
import { LockService } from "./services/locks.js";
import { ServerBackupService } from "./services/server-backups.js";
import { RestockAnnouncementService } from "./services/restock-announcements.js";
import { RobuxService } from "./services/robux.js";
import { ZCloudService } from "./services/zcloud.js";
import { InviteTrackerService } from "./services/invites.js";
import { VoiceService } from "./services/voice.js";

let config: ReturnType<typeof loadConfig>;
try {
  config = loadConfig();
} catch (error) {
  console.error(`[CONFIGURAÇÃO] ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}
const logger = new Logger(config.logLevel);
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

// R18.9.45: trava de instância por diretório. Em reinícios/starts simultâneos,
// somente um processo pode conectar o mesmo token ao Discord. Isso evita
// mensagens, invites e automações duplicadas quando um PID órfão sobrevive.
const INSTANCE_LOCK_PATH = resolve(process.cwd(), ".zenyx-instance.lock");
let instanceLockHeld = false;
function pidAlive(pid: number): boolean {
  if (!Number.isInteger(pid) || pid <= 0) return false;
  try { process.kill(pid, 0); } catch { return false; }
  if (process.platform !== "linux") return true;
  try { return realpathSync(`/proc/${pid}/cwd`) === realpathSync(process.cwd()); }
  catch { return false; }
}
function acquireInstanceLock(): boolean {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = openSync(INSTANCE_LOCK_PATH, "wx");
      writeFileSync(fd, `${process.pid}\n`, "utf8");
      closeSync(fd);
      instanceLockHeld = true;
      return true;
    } catch (error) {
      const code = (error as NodeJS.ErrnoException)?.code;
      if (code !== "EEXIST") throw error;
      let existingPid = 0;
      try { existingPid = Number(readFileSync(INSTANCE_LOCK_PATH, "utf8").trim()); } catch {}
      if (existingPid && existingPid !== process.pid && pidAlive(existingPid)) {
        logger.warn(`Outra instância desta aplicação já está ativa no PID ${existingPid}. Esta cópia será encerrada para impedir eventos duplicados.`);
        return false;
      }
      try { rmSync(INSTANCE_LOCK_PATH, { force: true }); } catch {}
    }
  }
  return false;
}
function releaseInstanceLock(): void {
  if (!instanceLockHeld || !existsSync(INSTANCE_LOCK_PATH)) return;
  try {
    const owner = Number(readFileSync(INSTANCE_LOCK_PATH, "utf8").trim());
    if (owner === process.pid) rmSync(INSTANCE_LOCK_PATH, { force: true });
  } catch {}
  instanceLockHeld = false;
}

const ZENYX_BRAND_TITLE = "𝙕𝙀𝙉𝙔𝙓 𝘼𝙋𝙋𝙇𝙄𝘾𝘼𝙏𝙄𝙊𝙉𝙎";
const ZENYX_BRAND_POWERED = "Powered by Zenyx Applications";
const ZENYX_BRAND_INVITE = "https://discord.gg/V2v8JnwdgR";
const BIO_GUARD_INTERVAL_MS = 30 * 1000;
let bioGuardRunning = false;
let bioGuardTimer: NodeJS.Timeout | undefined;

const ZENYX_ASCII = String.raw`
███████╗███████╗███╗   ██╗██╗   ██╗██╗  ██╗
╚══███╔╝██╔════╝████╗  ██║╚██╗ ██╔╝╚██╗██╔╝
  ███╔╝ █████╗  ██╔██╗ ██║ ╚████╔╝  ╚███╔╝ 
 ███╔╝  ██╔══╝  ██║╚██╗██║  ╚██╔╝   ██╔██╗ 
███████╗███████╗██║ ╚████║   ██║   ██╔╝ ██╗
╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝`;
console.log(ZENYX_ASCII);
logger.section("APLICAÇÃO • INICIALIZAÇÃO");
logger.info(`Node.js ${process.version} • PID ${process.pid}`);
logger.info(`Banco JSON: ${config.databasePath}`);
logger.info(`Emojis automáticos: ${config.autoInstallEmojis ? "ativados" : "desativados"}`);

const gatewayIntents = [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.DirectMessages,
  GatewayIntentBits.GuildInvites,
  GatewayIntentBits.GuildVoiceStates
];

type GatewayPrivilegeState = "allowed" | "disallowed" | "unknown";
type MessageContentState = GatewayPrivilegeState;

async function applicationMessageContentState(): Promise<MessageContentState> {
  try {
    const response = await fetch("https://discord.com/api/v10/applications/@me", {
      headers: { Authorization: `Bot ${config.botToken}` },
      signal: AbortSignal.timeout(10_000)
    });
    if (!response.ok) return "unknown";
    const data = await response.json() as { flags?: number };
    const flags = Number(data.flags || 0);
    const GATEWAY_MESSAGE_CONTENT = 1 << 18;
    const GATEWAY_MESSAGE_CONTENT_LIMITED = 1 << 19;
    return flags & GATEWAY_MESSAGE_CONTENT || flags & GATEWAY_MESSAGE_CONTENT_LIMITED ? "allowed" : "disallowed";
  } catch {
    return "unknown";
  }
}

async function applicationGuildMembersState(): Promise<GatewayPrivilegeState> {
  try {
    const response = await fetch("https://discord.com/api/v10/applications/@me", {
      headers: { Authorization: `Bot ${config.botToken}` },
      signal: AbortSignal.timeout(10_000)
    });
    if (!response.ok) return "unknown";
    const data = await response.json() as { flags?: number };
    const flags = Number(data.flags || 0);
    const GATEWAY_GUILD_MEMBERS = 1 << 14;
    const GATEWAY_GUILD_MEMBERS_LIMITED = 1 << 15;
    return flags & GATEWAY_GUILD_MEMBERS || flags & GATEWAY_GUILD_MEMBERS_LIMITED ? "allowed" : "disallowed";
  } catch {
    return "unknown";
  }
}

async function bootstrap(): Promise<void> {
  if (!acquireInstanceLock()) return;
  const guildMembersState = await applicationGuildMembersState();
  if (guildMembersState === "allowed" || (guildMembersState === "unknown" && config.privilegedIntents)) {
    gatewayIntents.push(GatewayIntentBits.GuildMembers);
    logger[guildMembersState === "allowed" ? "success" : "warn"](guildMembersState === "allowed"
      ? "Server Members Intent confirmado: mensagens automáticas para novos membros ativas."
      : "Não foi possível consultar Server Members Intent; ele será solicitado porque privilegedIntents está ativado.");
  } else {
    logger.warn("SERVER MEMBERS INTENT está desativado. Mensagens automáticas para quem acabou de entrar exigem ativá-lo no Developer Portal; as demais automações continuam funcionando.");
  }
  const messageContentState = await applicationMessageContentState();
  if (messageContentState !== "disallowed") {
    gatewayIntents.push(GatewayIntentBits.MessageContent);
    logger[messageContentState === "allowed" ? "success" : "warn"](
      messageContentState === "allowed"
        ? "Message Content Intent confirmado: calculadora por mensagens ativa."
        : "Não foi possível consultar as flags do Discord; Message Content será solicitado para não desativar silenciosamente a calculadora."
    );
  } else {
    logger.warn("MESSAGE CONTENT INTENT está desativado no Developer Portal. O bot continuará online, mas a calculadora por mensagens avisará no canal até o intent ser ativado e o bot reiniciado.");
  }

const client = new Client({
  intents: gatewayIntents,
  partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember]
});

const credentials = new CredentialStore("config/private-credentials.json", logger);
const db = new JsonDatabase(config.databasePath, logger, credentials);
const products = new ProductService(db);
const payments = new PaymentManager(db, logger);
const orders = new OrderService(client, db, products, payments, logger);
const emojis = new EmojiManager(client, db, config, logger);
const tickets = new TicketService(client, db, emojis, logger);
const giveaways = new GiveawayService(client, db, emojis);
const imap = new ImapMonitor(db, logger, () => orders.pendingImap(), (orderId, proof) => orders.markPaid(orderId, proof));
const permissions = new PermissionService(config, db);
const locks = new LockService(db, logger);
const automations = new AutomationService(client, db, logger, locks);
const backups = new ServerBackupService(client, db, logger);
const restocks = new RestockAnnouncementService(client, db, products, logger);
const robux = new RobuxService(client, credentials, payments, logger);
const zcloud = new ZCloudService(client, config, db, credentials, logger);
const invites = new InviteTrackerService(client, config.databasePath, logger);
const voice = new VoiceService(client, db, logger);
zcloud.start();
const router = new InteractionRouter(client, config, db, emojis, products, payments, orders, imap, tickets, giveaways, permissions, locks, backups, restocks, robux, zcloud, invites, voice, logger);
orders.onUpdate((order) => router.refreshOrderMessage(order));
robux.onUpdate(async (order) => { await router.refreshRobuxOrderMessage(order); });

function applyPresence(): void {
  if (!client.user) return;
  const brand = config.guildId ? db.brand(config.guildId) : db.state.brand;
  const activityTypes: Record<typeof brand.presenceType, ActivityType> = {
    Playing: ActivityType.Playing,
    Watching: ActivityType.Watching,
    Listening: ActivityType.Listening,
    Competing: ActivityType.Competing
  };
  client.user.setPresence({
    status: brand.status,
    activities: brand.presenceText
      ? [{ name: brand.presenceText, type: activityTypes[brand.presenceType] }]
      : []
  });
}

async function confirmConfiguredGuild(): Promise<void> {
  if (!config.guildId) throw new Error("guildId é obrigatório para validar o servidor de destino.");
  const wanted = String(config.guildId);
  let lastError: unknown;

  // O evento ready pode chegar alguns segundos antes do GuildCreate/cache em
  // instalações recém-feitas. Tentamos pelo cache, REST do discord.js e, por
  // último, /users/@me/guilds para não acusar falsamente “bot fora do servidor”.
  for (let attempt = 1; attempt <= 12; attempt++) {
    try {
      const cached = client.guilds.cache.get(wanted);
      const guild = cached ?? await client.guilds.fetch(wanted).catch(() => undefined);
      if (guild && String(guild.id) === wanted) {
        const me = await guild.members.fetchMe().catch(() => undefined);
        if (me) {
          logger.success(`Servidor de destino confirmado: ${guild.id}.`);
          return;
        }
      }

      const response = await fetch("https://discord.com/api/v10/users/@me/guilds?limit=200", {
        headers: { Authorization: `Bot ${config.botToken}` },
        signal: AbortSignal.timeout(8_000)
      });
      if (response.ok) {
        const guilds = await response.json() as Array<{ id?: string }>;
        if (guilds.some((entry) => String(entry?.id || "") === wanted)) {
          // A REST já confirma associação. Damos tempo para o gateway popular o
          // objeto Guild, necessário aos serviços e comandos guild-scoped.
          const fetched = await client.guilds.fetch(wanted).catch(() => undefined);
          if (fetched) {
            logger.success(`Servidor de destino confirmado: ${fetched.id}.`);
            return;
          }
        }
      }
    } catch (error) {
      lastError = error;
    }
    if (attempt < 12) await sleep(Math.min(1500, 350 + attempt * 100));
  }

  throw new Error(`O Discord ainda não confirmou o servidor configurado para esta aplicação.${lastError instanceof Error ? ` ${lastError.message}` : ""}`);
}

async function registerCommands(): Promise<void> {
  const applicationId = client.application?.id;
  if (!applicationId) throw new Error("Não foi possível identificar o Application ID conectado.");
  if (!config.guildId) {
    throw new Error("guildId é obrigatório. Os comandos desta aplicação nunca são registrados globalmente.");
  }
  if (config.clientId && config.clientId !== applicationId) {
    logger.warn(`clientId configurado (${config.clientId}) não corresponde ao bot conectado (${applicationId}); usando o ID conectado.`);
  }
  const rest = new REST({ version: "10" }).setToken(config.botToken);
  // Limpa apenas comandos globais DESTA aplicação filha. Nunca toca na aplicação do Manager.
  await rest.put(Routes.applicationCommands(applicationId), { body: [] });
  await rest.put(Routes.applicationGuildCommands(applicationId, config.guildId), { body: commands });
  logger.info(`Comandos isolados registrados somente no servidor ${config.guildId} para a aplicação filha ${applicationId}.`);
}

let applicationBrandRobot = "";
let applicationBrandCrown = "";
let guildBrandRobot = "";
let guildBrandCrown = "";

async function ensureApplicationBrandEmojis(): Promise<void> {
  try {
    const brand = await emojis.ensureBrandEmojis();
    applicationBrandRobot = brand.robot;
    applicationBrandCrown = brand.crown;
    if (applicationBrandRobot && applicationBrandCrown) {
      logger.success("Application Emojis transparentes da bio ZENYX confirmados.");
    } else {
      logger.warn("Um dos Application Emojis da bio não pôde ser confirmado.");
    }
  } catch (error) {
    logger.warn("Não foi possível garantir os Application Emojis da bio agora.", error);
  }
}

async function ensureGuildBrandEmojis(): Promise<void> {
  if (!config.guildId) return;
  try {
    const guild = await client.guilds.fetch(config.guildId);
    await guild.emojis.fetch().catch(() => undefined);
    const ensure = async (name: string, file: string) => {
      const existing = guild.emojis.cache.find((emoji) => emoji.name === name);
      if (existing) return existing.toString();
      const me = guild.members.me ?? await guild.members.fetchMe().catch(() => undefined);
      if (!me?.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) return "";
      const created = await guild.emojis.create({ attachment: readFileSync(file), name, reason: "Identidade visual ZENYX APPLICATIONS" });
      return created.toString();
    };
    guildBrandRobot = await ensure("zenyx_brand_robot_v23", "assets/emojis/pack/zenyx_brand_robot.png");
    guildBrandCrown = await ensure("zenyx_brand_zy_v23", "assets/emojis/pack/zenyx_brand_crown.png");
    if (guildBrandRobot || guildBrandCrown) logger.success("Emojis transparentes da bio ZENYX preparados no servidor configurado.");
  } catch (error) {
    logger.warn("Não foi possível preparar os emojis de servidor para a bio; será usado o Application Emoji quando disponível.", error);
  }
}

async function getDiscordApplicationDescription(): Promise<string> {
  const data = await client.rest.get(Routes.currentApplication()) as { description?: string | null };
  return String(data?.description ?? "").trim().slice(0, 400);
}

async function setAndVerifyDiscordApplicationDescription(description: string): Promise<string> {
  const desired = String(description ?? "").trim().slice(0, 400);
  const response = await client.rest.patch(Routes.currentApplication(), { body: { description: desired } }) as { description?: string | null };
  let confirmed = String(response?.description ?? "").trim().slice(0, 400);
  for (let attempt = 0; attempt < 3 && confirmed !== desired; attempt++) {
    if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 350 * attempt));
    confirmed = await getDiscordApplicationDescription();
  }
  if (confirmed !== desired) throw new Error(`Discord não confirmou a descrição da Application: esperado ${desired.length}, recebido ${confirmed.length}.`);
  await client.application?.fetch().catch((error) => logger.warn("Descrição salva no Discord, mas o cache local da Application não atualizou imediatamente.", error));
  return confirmed;
}

function lockedApplicationBio(): string {
  // Prioriza os dois emojis de marca instalados no próprio bot filho. Assim a
  // Bio sempre usa exatamente o robô e o selo/ZY definidos nesta build. Se a
  // instalação ainda não tiver concluído, cai com segurança para os emojis
  // canônicos do Manager sem quebrar a identidade.
  const robot = applicationBrandRobot || guildBrandRobot;
  const crown = applicationBrandCrown || guildBrandCrown;
  if (!robot || !crown) throw new Error("Emojis institucionais ZENYX ainda não foram sincronizados.");
  return `${robot} **\`${ZENYX_BRAND_TITLE}\`**\n${crown} **${ZENYX_BRAND_POWERED}** ${ZENYX_BRAND_INVITE}`.trim().slice(0, 400);
}

async function syncApplicationBio(): Promise<void> {
  const brand = config.guildId ? db.brand(config.guildId) : db.state.brand;
  try {
    // Emojis locais continuam sendo preparados para o restante da interface,
    // mas NÃO bloqueiam a Bio institucional.
    if (!applicationBrandRobot || !applicationBrandCrown) await ensureApplicationBrandEmojis();
    const desired = lockedApplicationBio();
    const remoteBio = await getDiscordApplicationDescription();
    if (desired !== remoteBio) {
      const confirmed = await setAndVerifyDiscordApplicationDescription(desired);
      brand.bio = confirmed;
      db.save();
      logger.success(`Bio institucional ZENYX sincronizada e confirmada pelo Discord (${confirmed.length}/400).`);
      return;
    }
    if (brand.bio !== desired) {
      brand.bio = desired;
      db.save();
    }
    logger.success(`Bio institucional ZENYX já está sincronizada e bloqueada (${desired.length}/400).`);
  } catch (error) {
    logger.warn("Não foi possível sincronizar/confirmar a Bio institucional agora; o restante do bot continuará normalmente.", error);
  }
}

async function enforceApplicationBio(reason = "monitor"): Promise<void> {
  if (bioGuardRunning || !client.isReady()) return;
  bioGuardRunning = true;
  try {
    if (!applicationBrandRobot || !applicationBrandCrown) await ensureApplicationBrandEmojis();
    const desired = lockedApplicationBio();
    const remote = await getDiscordApplicationDescription();
    if (remote === desired) return;
    const confirmed = await setAndVerifyDiscordApplicationDescription(desired);
    const brand = config.guildId ? db.brand(config.guildId) : db.state.brand;
    if (brand.bio !== confirmed) {
      brand.bio = confirmed;
      db.save();
    }
    logger.warn(`Bio institucional ZENYX foi alterada/removida e foi restaurada automaticamente (${reason}).`);
  } catch (error) {
    logger.warn("Monitor da Bio institucional não conseguiu verificar/restaurar agora; tentará novamente no próximo ciclo.", error);
  } finally {
    bioGuardRunning = false;
  }
}

function startApplicationBioGuard(): void {
  if (bioGuardTimer) clearInterval(bioGuardTimer);
  bioGuardTimer = setInterval(() => { void enforceApplicationBio("verificação periódica"); }, BIO_GUARD_INTERVAL_MS);
  bioGuardTimer.unref?.();
  logger.success("Proteção contínua da Bio ativada: a identidade ZENYX dos bots filhos será restaurada automaticamente.");
}

const unauthorizedGuildNotified = new Set<string>();
const unauthorizedGuildLeaveTimers = new Map<string, NodeJS.Timeout>();

async function leaveUnauthorizedGuild(guild: import("discord.js").Guild, attempt = 1): Promise<void> {
  try {
    await guild.leave();
    const timer = unauthorizedGuildLeaveTimers.get(guild.id);
    if (timer) clearTimeout(timer);
    unauthorizedGuildLeaveTimers.delete(guild.id);
    logger.success(`Servidor não autorizado removido: ${guild.name} / ${guild.id}.`);
  } catch (error) {
    logger.warn("Falha temporária ao sair do servidor não autorizado.", { guildId: guild.id, attempt, error: String(error) });
    if (attempt >= 5 || unauthorizedGuildLeaveTimers.has(guild.id)) return;
    const delay = Math.min(60_000, 5_000 * attempt);
    const timer = setTimeout(() => {
      unauthorizedGuildLeaveTimers.delete(guild.id);
      const current = client.guilds.cache.get(guild.id);
      if (current && String(current.id) !== String(config.guildId || "")) void leaveUnauthorizedGuild(current, attempt + 1);
    }, delay);
    timer.unref?.();
    unauthorizedGuildLeaveTimers.set(guild.id, timer);
  }
}

async function enforceConfiguredGuildOnly(guild: import("discord.js").Guild): Promise<boolean> {
  const allowed = String(config.guildId || "");
  if (!allowed || String(guild.id) === allowed) return false;

  // Um bot filho ZENYX pertence exclusivamente ao servidor informado no
  // provisionamento. A autorização não é ampliada só porque alguém conseguiu
  // convidar o mesmo token para outro servidor.
  if (!unauthorizedGuildNotified.has(guild.id)) {
    unauthorizedGuildNotified.add(guild.id);
    const text =
      `⚠️ **Proteção de servidor ZENYX**\n\n` +
      `Seu bot **${client.user?.username ?? "ZENYX"}** foi adicionado ao servidor **${guild.name}** (\`${guild.id}\`), mas esta aplicação está vinculada somente ao servidor \`${allowed}\`.\n\n` +
      `A aplicação saiu automaticamente do servidor não autorizado. Para trocar o servidor permitido, faça a alteração pela Central/Manager em vez de reutilizar o bot em outro servidor.`;
    for (const ownerId of config.ownerIds) {
      try {
        const owner = await client.users.fetch(ownerId);
        await owner.send({ content: text });
      } catch (error) {
        logger.warn("Não foi possível enviar a DM de segurança ao proprietário.", { ownerId, guildId: guild.id, error: String(error) });
      }
    }
  }

  logger.warn(`Servidor não autorizado detectado (${guild.name} / ${guild.id}). Saindo automaticamente; servidor permitido: ${allowed}.`);
  await leaveUnauthorizedGuild(guild);
  return true;
}

function logProfilePreservation(): void {
  logger.info("Perfil do bot filho: username, avatar e banner permanecem configuráveis; a Bio é identidade institucional ZENYX, bloqueada contra edição/remoção.");
}

router.start();
automations.start();
client.on(Events.MessageCreate, (message) => {
  if (config.guildId && message.guildId && String(message.guildId) !== String(config.guildId)) return;
  void tickets.handleMessage(message);
  void automations.handleMessage(message);
  void router.handleRobuxThreadMessage(message);
  void robux.handlePurchaseThreadMessage(message);
  void robux.handleCalculatorMessage(message);
});
client.on(Events.ChannelDelete, (channel) => {
  if ("guildId" in channel && config.guildId && String(channel.guildId || "") !== String(config.guildId)) return;
  void tickets.handleChannelDelete(channel.id).catch((error) => logger.warn("Não foi possível reconciliar o ticket após exclusão do canal.", error));
});
client.on(Events.GuildDelete, (guild) => {
  void tickets.reconcileOpenTickets(guild.id).catch((error) => logger.warn("Não foi possível liberar tickets após remoção do servidor.", error));
});
client.on(Events.GuildCreate, (guild) => {
  if (guild.id !== config.guildId) { void enforceConfiguredGuildOnly(guild); return; }
  logger.success(`Servidor de destino confirmado: ${guild.id}.`);
  void registerCommands()
    .then(() => logger.success(`Comandos de aplicação prontos. Restaurados após a aplicação voltar ao servidor ${guild.id}.`))
    .catch((error) => logger.warn("Não foi possível restaurar os comandos após a aplicação voltar ao servidor.", error));
});
client.on(Events.GuildMemberAdd, (member) => {
  if (config.guildId && String(member.guild.id) !== String(config.guildId)) return;
  void invites.handleMemberAdd(member).catch((error) => logger.warn("Invite Tracker falhou ao registrar entrada.", { guildId: member.guild.id, userId: member.id, error: String(error) }));
});
client.on(Events.GuildMemberRemove, (member) => {
  if (config.guildId && String(member.guild.id) !== String(config.guildId)) return;
  void invites.handleMemberRemove(member).catch((error) => logger.warn("Invite Tracker falhou ao registrar saída.", { guildId: member.guild.id, userId: member.id, error: String(error) }));
});
client.on(Events.InviteCreate, (invite) => {
  if (config.guildId && String(invite.guild?.id || "") !== String(config.guildId)) return;
  void invites.handleInviteCreate(invite).catch((error) => logger.warn("Invite Tracker falhou ao registrar novo convite.", { code: invite.code, error: String(error) }));
});
client.on(Events.InviteDelete, (invite) => {
  if (config.guildId && String(invite.guild?.id || "") !== String(config.guildId)) return;
  void invites.handleInviteDelete(invite).catch((error) => logger.warn("Invite Tracker falhou ao remover convite do cache.", { code: invite.code, error: String(error) }));
});

client.once(Events.ClientReady, async () => {
  logger.success(`Discord conectado como ${client.user?.tag ?? "bot"}.`);
  logger.info(`Application ID: ${client.application?.id ?? config.clientId ?? "indisponível"}.`);
  logger.info(`Servidores conectados: ${client.guilds.cache.size}.`);
  logProfilePreservation();
  applyPresence();

  // R18.9.76: remove no boot qualquer servidor que não seja o guild vinculado.
  // Isso também cobre convites feitos enquanto o processo estava offline.
  for (const guild of [...client.guilds.cache.values()]) {
    if (config.guildId && String(guild.id) !== String(config.guildId)) await enforceConfiguredGuildOnly(guild);
  }

  // R18.9.31: valide o guild e publique os comandos ANTES da sincronização
  // pesada de emojis. Além de reduzir o tempo até o bot responder, isso cria um
  // sinal de saúde confiável para o Manager confirmar que a aplicação realmente
  // está instalada no servidor informado antes de considerar o provisionamento
  // concluído.
  let destinationGuildConfirmed = false;
  try {
    logger.info("Confirmando servidor de destino configurado...");
    await confirmConfiguredGuild();
    destinationGuildConfirmed = true;
  } catch (error) {
    logger.error("Falha ao confirmar servidor de destino.", error);
  }

  if (destinationGuildConfirmed) {
    try {
      logger.info("Registrando comandos de aplicação isolados...");
      await registerCommands();
      logger.success("Comandos de aplicação prontos.");
    } catch (error) {
      logger.error("Falha ao registrar comandos de aplicação; o bot está no servidor, mas o Discord recusou o registro.", error);
    }
  } else {
    logger.warn("Registro inicial de comandos adiado: o servidor de destino ainda não foi confirmado. A reconciliação continuará em segundo plano.");
    void (async () => {
      for (let attempt = 1; attempt <= 18; attempt++) {
        await sleep(5_000);
        try {
          await confirmConfiguredGuild();
          await registerCommands();
          logger.success("Comandos de aplicação prontos.");
          logger.success(`Reconciliação do servidor concluída na tentativa ${attempt}.`);
          return;
        } catch (error) {
          if (attempt === 18) logger.warn("A reconciliação automática do servidor continuará dependendo de um novo GuildCreate/restart.", error);
        }
      }
    })();
  }

  // Depois da validação do guild, sincroniza a identidade visual. Painéis
  // publicados continuam sendo atualizados somente após os emojis estarem prontos.
  if (config.autoInstallEmojis) {
    logger.info("Instalação automática de emojis detectada. A sincronização começará agora.");
    // A marca vem primeiro. Assim, mesmo que algum asset secundário falhe ou a
    // aplicação alcance um limite temporário de emojis, os dois emojis usados na
    // bio já estão reservados e a identidade visual não desaparece.
    await ensureApplicationBrandEmojis();
    await ensureGuildBrandEmojis();
    await emojis.syncAutomatic();
    // Revalida após o pacote completo para atualizar IDs caso o Discord tenha
    // recriado algum emoji durante a reconciliação.
    await ensureApplicationBrandEmojis();
    await ensureGuildBrandEmojis();
    try {
      const count = await router.refreshPublishedMessages();
      logger.success(`Painéis publicados atualizados após os emojis: ${count}.`);
    } catch (error) {
      logger.warn("Os emojis foram processados, mas alguns painéis publicados não puderam ser atualizados.", error);
    }
  } else {
    await ensureApplicationBrandEmojis();
    await ensureGuildBrandEmojis();
    logger.warn("Instalação automática de emojis desativada. Use /emojis instalar para sincronizar manualmente.");
  }

  // Só depois dos Application Emojis existirem montamos a bio institucional.
  // Isso evita gravar novamente a bio genérica das builds R18.9.15/R18.9.16.
  await syncApplicationBio();
  startApplicationBioGuard();

  const reconciledTickets = await tickets.reconcileOpenTickets().catch((error) => { logger.warn("Falha ao reconciliar tickets órfãos no boot.", error); return 0; });
  if (reconciledTickets) logger.success(`Tickets órfãos removidos do limite no boot: ${reconciledTickets}.`);
  orders.startPolling();
  imap.start();
  giveaways.start();
  robux.start();
  await invites.start().catch((error) => logger.warn("Invite Tracker não pôde preparar o cache inicial; tentará novamente nas próximas entradas.", error));
  await voice.restoreConfigured().catch((error) => logger.warn("A call persistente não pôde ser restaurada agora; a configuração foi preservada.", error));
  logger.success("Serviços de pedidos, pagamentos, tickets, Robux, Invites, voz persistente e automações iniciados.");

  try {
    const removed = await emojis.reconcileSavedEmojis();
    const savedCount = emojis.listSaved().length;
    logger.success(`[SALVAR EMOJI] Biblioteca verificada: ${savedCount} emoji(s) disponível(is)${removed ? `; ${removed} registro(s) inválido(s) removido(s)` : ""}.`);
  } catch (error) {
    logger.warn("[SALVAR EMOJI] Não foi possível conferir a biblioteca de emojis salvos. O bot continuará normalmente.", error);
  }

  logger.section("APLICAÇÃO ONLINE");
  logger.success("Bot totalmente iniciado. Use /painel para abrir a central de controle.");
});

client.on("error", (error) => logger.error("Erro do cliente Discord.", error));
client.on("warn", (warning) => logger.warn("Aviso do cliente Discord.", warning));

let stopping = false;
async function shutdown(signal: string): Promise<void> {
  if (stopping) return;
  stopping = true;
  logger.info(`Encerrando aplicação (${signal})...`);
  orders.stopPolling();
  imap.stop();
  giveaways.stop();
  automations.stop();
  robux.stop();
  zcloud.stop();
  voice.destroyAll();
  client.destroy();
  releaseInstanceLock();
}

process.on("exit", releaseInstanceLock);
process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
process.on("unhandledRejection", (reason) => logger.error("Promise rejeitada sem tratamento.", reason));
process.on("uncaughtException", (error) => logger.error("Exceção não tratada.", error));

client.login(config.botToken).catch((error) => {
  logger.error("Não foi possível conectar ao Discord. Verifique o token em Token.json e os intents habilitados.", error);
  releaseInstanceLock();
  process.exitCode = 1;
});

}

void bootstrap().catch((error) => {
  logger.error("Falha fatal durante a inicialização da aplicação.", error);
  process.exitCode = 1;
});
