import {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChannelSelectMenuInteraction,
  ChannelType,
  ChatInputCommandInteraction,
  Client,
  ContainerBuilder,
  EmbedBuilder,
  Events,
  GuildMember,
  ModalBuilder,
  ModalSubmitInteraction,
  MessageContextMenuCommandInteraction,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
  PermissionFlagsBits,
  OverwriteType,
  RoleSelectMenuInteraction,
  Routes,
  UserSelectMenuInteraction,
  UserSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  SeparatorBuilder,
  StringSelectMenuOptionBuilder,
  TextChannel,
  TextDisplayBuilder,
  TextInputBuilder,
  TextInputStyle
} from "discord.js";
import { readFileSync } from "node:fs";
import type { AppConfig, BotMessageTemplate, ButtonStyleName, DeliveryType, ImapBank, ImapEmailProvider, PaymentProviderName, SavedApplicationEmoji, StockRequest, TicketRecord } from "../types.js";
import type { JsonDatabase } from "../core/json-db.js";
import type { Logger } from "../core/logger.js";
import { channelSafe, colorNumber, formatMoney, makeId, normalizeColor, nowIso, parseBoolean, parseDuration, parseMoney, truncate } from "../core/utils.js";
import type { EmojiManager } from "../emojis/manager.js";
import type { ProductService } from "../services/products.js";
import type { PaymentManager } from "../services/payments.js";
import type { OrderService } from "../services/orders.js";
import type { ImapMonitor } from "../services/imap.js";
import type { TicketService } from "../services/tickets.js";
import type { GiveawayService } from "../services/giveaways.js";
import type { PermissionService } from "../services/permissions.js";
import type { LockService } from "../services/locks.js";
import type { ServerBackupService } from "../services/server-backups.js";
import type { RestockAnnouncementService } from "../services/restock-announcements.js";
import type { RobuxService, RobuxDeliveryMode, RobloxGamepass, RobloxUser } from "../services/robux.js";
import type { ZCloudService } from "../services/zcloud.js";
import type { InviteTrackerService } from "../services/invites.js";
import type { VoiceService } from "../services/voice.js";
import { applyEmailPreset, bankProfile } from "../services/imap-profiles.js";
import { Views } from "./views.js";
import { checkedDiscordPayload } from "./payload-validator.js";
import QRCode from "qrcode";

const DEFAULT_APPLICATION_BIO = "Automação completa para Discord • vendas, tickets e pagamentos 24/7."; // legado R18.9.16; não é mais aplicado ao perfil
const ZENYX_BRAND_TITLE = "𝙕𝙀𝙉𝙔𝙓 𝘼𝙋𝙋𝙇𝙄𝘾𝘼𝙏𝙄𝙊𝙉𝙎";
const ZENYX_BRAND_POWERED = "Powered by Zenyx Applications";
const ZENYX_BRAND_INVITE = "https://discord.gg/V2v8JnwdgR";

function input(id: string, label: string, value = "", style = TextInputStyle.Short, required = true, max = 1000, placeholder = "") {
  const safeMax = Math.max(1, Math.min(4000, Math.trunc(max) || 1000));
  const field = new TextInputBuilder()
    .setCustomId(truncate(id || "field", 100))
    .setLabel(truncate(label || "Campo", 45))
    .setStyle(style)
    .setRequired(required)
    .setMaxLength(safeMax);
  if (value) field.setValue(value.slice(0, safeMax));
  if (placeholder) field.setPlaceholder(truncate(placeholder, 100));
  return new ActionRowBuilder<TextInputBuilder>().addComponents(field);
}
function modal(id: string, title: string, rows: ActionRowBuilder<TextInputBuilder>[]) { return new ModalBuilder().setCustomId(id).setTitle(title.slice(0, 45)).addComponents(...rows.slice(0, 5)); }
function styleName(value: string): ButtonStyleName { const normalized = value.trim().toUpperCase(); return ["PRIMARY", "SECONDARY", "SUCCESS", "DANGER"].includes(normalized) ? normalized as ButtonStyleName : "SUCCESS"; }
function delivery(value: string): DeliveryType {
  const normalized = value.trim().toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (["AUTOMATICA", "AUTOMATICO", "AUTO", "STOCK"].includes(normalized)) return "STOCK";
  if (["CARGO", "ROLE"].includes(normalized)) return "ROLE";
  return "MANUAL";
}

function normalizeImageLink(value: string): string {
  const raw = value.trim();
  if (!raw) return "";
  let parsed: URL;
  try { parsed = new URL(raw); }
  catch { throw new Error("Informe uma URL válida de imagem."); }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("A imagem precisa usar um link http:// ou https://.");
  if (!parsed.hostname) throw new Error("Informe uma URL válida de imagem.");
  return parsed.toString().slice(0, 1000);
}
function normalizeDiscordInvite(value: string): string {
  const raw = value.trim();
  if (!raw) return "";
  let parsed: URL;
  try { parsed = new URL(raw); }
  catch { throw new Error("Informe um link de convite Discord válido."); }
  const host = parsed.hostname.toLowerCase();
  const ok = parsed.protocol === "https:" && ((host === "discord.gg" && /^\/[A-Za-z0-9_-]+\/?$/.test(parsed.pathname)) || (host === "discord.com" && /^\/invite\/[A-Za-z0-9_-]+\/?$/.test(parsed.pathname)));
  if (!ok) throw new Error("Use um convite no formato https://discord.gg/codigo ou https://discord.com/invite/codigo.");
  return parsed.toString().slice(0, 500);
}

interface RobuxSession {
  guildId: string;
  userId: string;
  robloxUser?: RobloxUser;
  gamepasses: RobloxGamepass[];
  selected?: RobloxGamepass;
  selectedProvider?: PaymentProviderName;
  threadId?: string;
  messageId?: string;
  expiresAt: number;
  manualRequestedRobux?: number;
  manualReferenceUrl?: string;
  manualFlow?: boolean;
  manualAwaitingUsername?: boolean;
  checkoutCreating?: boolean;
  pendingOrderId?: string;
}

export class InteractionRouter {
  readonly views: Views;
  private readonly purchaseGuards = new Map<string, number>();
  private readonly robuxSessions = new Map<string, RobuxSession>();
  private zcloudRuntimeTimer?: NodeJS.Timeout;
  private zcloudRuntimeSignature = "";
  constructor(
    private readonly client: Client,
    private readonly config: AppConfig,
    private readonly db: JsonDatabase,
    private readonly emojis: EmojiManager,
    private readonly products: ProductService,
    private readonly payments: PaymentManager,
    private readonly orders: OrderService,
    private readonly imap: ImapMonitor,
    private readonly tickets: TicketService,
    private readonly giveaways: GiveawayService,
    private readonly permissions: PermissionService,
    private readonly locks: LockService,
    private readonly backups: ServerBackupService,
    private readonly restocks: RestockAnnouncementService,
    private readonly robux: RobuxService,
    private readonly zcloud: ZCloudService,
    private readonly invites: InviteTrackerService,
    private readonly voice: VoiceService,
    private readonly logger: Logger
  ) { this.views = new Views(db, emojis, products, tickets); }

  private async fetchDiscordApplicationDescription(): Promise<string> {
    const data = await this.client.rest.get(Routes.currentApplication()) as { description?: string | null };
    return String(data?.description ?? "").trim().slice(0, 400);
  }

  private async writeAndVerifyDiscordApplicationDescription(description: string): Promise<string> {
    const desired = String(description ?? "").trim().slice(0, 400);
    const patched = await this.client.rest.patch(Routes.currentApplication(), { body: { description: desired } }) as { description?: string | null };
    let confirmed = String(patched?.description ?? "").trim().slice(0, 400);

    // Não confie apenas no objeto em memória do discord.js. O GET de confirmação
    // consulta a Application real que alimenta a descrição exibida no perfil.
    for (let attempt = 0; attempt < 3 && confirmed !== desired; attempt++) {
      if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 350 * attempt));
      confirmed = await this.fetchDiscordApplicationDescription();
    }
    if (confirmed !== desired) {
      throw new Error(`O Discord não confirmou a descrição da Application. Esperado ${desired.length} caracteres, recebido ${confirmed.length}.`);
    }

    // Atualiza também o cache do discord.js para que as próximas telas não leiam
    // uma descrição antiga até o próximo reconnect do bot.
    await this.client.application?.fetch().catch((error) => this.logger.warn("Bio foi salva no Discord, mas o cache local da Application não atualizou imediatamente.", { error: String(error) }));
    return confirmed;
  }

  private async lockedInstitutionalBio(): Promise<string> {
    // Prioriza os emojis realmente instalados no bot filho. Isso garante que a
    // Bio exibida no perfil use o robô e o ZY desta build, mantendo fallback
    // seguro para os emojis canônicos caso a sincronização ainda esteja em andamento.
    const robot = this.emojis.textVariant("brand_robot");
    const crown = this.emojis.textVariant("brand_crown");
    if (!robot || !crown) throw new Error("Emojis institucionais ZENYX ainda não foram sincronizados.");
    return `${robot} **\`${ZENYX_BRAND_TITLE}\`**\n${crown} **${ZENYX_BRAND_POWERED}** ${ZENYX_BRAND_INVITE}`.trim().slice(0, 400);
  }

  private async restoreLockedInstitutionalBio(gid: string): Promise<string> {
    const desired = await this.lockedInstitutionalBio();
    const confirmed = await this.writeAndVerifyDiscordApplicationDescription(desired);
    const b = this.db.brand(gid);
    if (b.bio !== confirmed) {
      b.bio = confirmed;
      this.db.save();
    }
    return confirmed;
  }

  start() {
    this.client.on(Events.InteractionCreate, (interaction) => void this.route(interaction).catch((error) => this.fail(interaction as never, error)));
    // O Manager grava a disponibilidade/URL em config/runtime.json. Só
    // atualizamos publicações quando esses valores realmente mudarem.
    const pollZcloudRuntime = () => {
      const signature = `${this.zcloud.managerEnabled() ? "1" : "0"}|${this.zcloud.managedPublicBaseUrl()}`;
      if (!this.zcloudRuntimeSignature) { this.zcloudRuntimeSignature = signature; return; }
      if (signature === this.zcloudRuntimeSignature) return;
      this.zcloudRuntimeSignature = signature;
      void this.refreshPublishedMessages().catch((error) => this.logger.warn("Falha ao sincronizar painéis ZCloud após alteração no Manager.", error));
    };
    pollZcloudRuntime();
    this.zcloudRuntimeTimer = setInterval(pollZcloudRuntime, 2_000);
    this.zcloudRuntimeTimer.unref?.();
  }

  async refreshPublishedMessages(): Promise<number> {
    let updated = 0;
    for (const product of Object.values(this.db.state.products)) {
      for (const publication of [...product.publications]) {
        try {
          const channel = await this.client.channels.fetch(publication.channelId);
          if (!(channel instanceof TextChannel)) throw new Error("Canal não é de texto.");
          const message = await channel.messages.fetch(publication.messageId);
          await message.edit(this.views.publishedProductEdit(publication.guildId || channel.guild.id, product));
          updated++;
        } catch (error) {
          this.products.removePublication(product.id, publication.messageId);
          this.logger.warn("Publicação de produto inacessível foi removida do índice.", { productId: product.id, messageId: publication.messageId, error: String(error) });
        }
      }
    }
    for (const panel of Object.values(this.db.state.ticketPanels)) {
      if (!panel.channelId || !panel.messageId) continue;
      try {
        const channel = await this.client.channels.fetch(panel.channelId);
        if (channel instanceof TextChannel) {
          const message = await channel.messages.fetch(panel.messageId);
          await message.edit(this.views.publicTicketPanelEdit(channel.guild.id, panel));
          updated++;
        }
      } catch (error) { this.logger.warn("Não foi possível atualizar um painel de ticket publicado.", { panelId: panel.id, error: String(error) }); }
    }
    for (const template of Object.values(this.db.state.messageTemplates)) {
      for (const publication of [...template.publications]) {
        try {
          const channel = await this.client.channels.fetch(publication.channelId);
          if (!(channel instanceof TextChannel)) throw new Error("Canal não é de texto.");
          const message = await channel.messages.fetch(publication.messageId);
          await message.edit(this.views.botMessageEdit(template.guildId, template) as never);
          updated++;
        } catch (error) {
          template.publications = template.publications.filter((item) => item.messageId !== publication.messageId);
          this.db.save();
          this.logger.warn("Publicação de mensagem personalizada inacessível foi removida do índice.", { templateId: template.id, messageId: publication.messageId, error: String(error) });
        }
      }
    }
    for (const [guildId, guild] of Object.entries(this.db.state.guilds)) {
      const settings = guild.stockRequest;
      if (!settings.panelChannelId || !settings.panelMessageId) continue;
      try {
        const channel = await this.client.channels.fetch(settings.panelChannelId);
        if (!(channel instanceof TextChannel)) throw new Error("Canal não é de texto.");
        const message = await channel.messages.fetch(settings.panelMessageId);
        await message.edit(this.views.publicStockRequestPanel(guildId));
        updated++;
      } catch (error) {
        this.logger.warn("Não foi possível atualizar o painel Pedir Stock publicado.", { guildId, error: String(error) });
      }
    }
    // Reaplica o painel público de Robux após a sincronização dos emojis.
    // Isso garante que mensagens já publicadas recebam o semantic atual correto
    // (saco verde em Comprar Robux e o ícone Robux apenas no /painel admin).
    for (const guild of this.client.guilds.cache.values()) {
      const settings = this.robux.settings(guild.id);
      if (!settings.panelChannelId || !settings.panelMessageId) continue;
      try { await this.refreshRobuxPanel(guild.id); updated++; }
      catch (error) { this.logger.warn("Não foi possível atualizar o painel Robux publicado.", { guildId: guild.id, error: String(error) }); }
    }

    // Migra automaticamente publicações ZCloud antigas (inclusive links do
    // Supabase/Quick Tunnel) para a rota HTTPS isolada do próprio Manager.
    for (const [guildId, z] of Object.entries(this.db.state.zcloudSettings)) {
      if (!z.verificationChannelId || !z.panelMessageId) continue;
      try {
        const channel = await this.client.channels.fetch(z.verificationChannelId);
        if (!(channel instanceof TextChannel)) throw new Error("Canal ZCloud não é de texto.");
        const old = await channel.messages.fetch(z.panelMessageId);
        const desiredV2 = z.panelMode === "V2";
        const oldV2 = old.flags.has(MessageFlags.IsComponentsV2);
        let message = old;
        const payload = this.zcloudPanelPayload(guildId) as Record<string, unknown>;
        if (oldV2 !== desiredV2) {
          await old.delete().catch(() => undefined);
          message = await channel.send(payload as never);
          this.zcloud.update(guildId, { panelMessageId: message.id });
        } else {
          await old.edit({ ...payload, attachments: [] } as never);
        }
        updated++;
      } catch (error) {
        this.logger.warn("Não foi possível atualizar o painel ZCloud publicado.", { guildId, error: String(error) });
      }
    }
    return updated;
  }

  async refreshProductPublications(productId: string): Promise<{ updated: number; removed: number }> {
    const product = this.products.get(productId);
    let updated = 0;
    let removed = 0;
    for (const publication of [...product.publications]) {
      try {
        const channel = await this.client.channels.fetch(publication.channelId);
        if (!(channel instanceof TextChannel)) throw new Error("Canal não é de texto.");
        const message = await channel.messages.fetch(publication.messageId);
        await message.edit(this.views.publishedProductEdit(publication.guildId || channel.guild.id, product));
        updated++;
      } catch (error) {
        this.products.removePublication(product.id, publication.messageId);
        removed++;
        this.logger.warn("Publicação de produto inacessível foi removida do índice.", { productId: product.id, messageId: publication.messageId, error: String(error) });
      }
    }
    return { updated, removed };
  }

  private xml(value: string): string {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&apos;");
  }

  private salesReceiptTargetUrl(order: import("../types.js").Order): string {
    const cart = this.db.state.carts[order.cartId] ?? this.db.state.abandonedCarts[order.cartId];
    const settings = this.db.guild(order.guildId);
    if (cart?.sourceChannelId && cart.sourceMessageId) return `https://discord.com/channels/${order.guildId}/${cart.sourceChannelId}/${cart.sourceMessageId}`;
    if (settings.salesChannelId) return `https://discord.com/channels/${order.guildId}/${settings.salesChannelId}`;
    return `https://discord.com/channels/${order.guildId}`;
  }

  private async salesReceiptImage(
    order: import("../types.js").Order,
    avatarUrl: string,
    serverName = "Servidor",
    username = "cliente"
  ): Promise<Buffer> {
    let avatarData = "";
    try {
      const response = await fetch(avatarUrl, { signal: AbortSignal.timeout(10_000) });
      if (response.ok) avatarData = Buffer.from(await response.arrayBuffer()).toString("base64");
    } catch { /* card has a fallback avatar */ }

    const clean = (value: string, max: number) => String(value || "").replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim().slice(0, max);
    const displayName = clean(order.discordDisplayName || username || "Cliente", 30) || "Cliente";
    const handle = `@${clean(username || "cliente", 28) || "cliente"}`;
    const server = clean(serverName || "Servidor", 34) || "Servidor";
    const first = order.items[0];
    const itemName = first
      ? `${Math.max(1, first.quantity)}x ${clean(first.productName, 38)}${first.fieldName && first.fieldName !== "Opção principal" ? ` • ${clean(first.fieldName, 24)}` : ""}`
      : "Produto";
    const extra = Math.max(0, order.items.length - 1);
    const itemLabel = `${itemName}${extra ? ` +${extra} item(ns)` : ""}`;
    const total = formatMoney(order.totalCents);
    const when = new Date(order.deliveredAt || order.updatedAt || order.createdAt || Date.now()).toLocaleString("pt-BR", {
      timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit"
    });
    const initials = displayName.slice(0, 1).toUpperCase();
    const avatar = avatarData
      ? `<image href="data:image/png;base64,${avatarData}" x="70" y="48" width="84" height="84" preserveAspectRatio="xMidYMid slice" clip-path="url(#saleAvatar)"/>`
      : `<text x="112" y="101" text-anchor="middle" class="r-main" font-size="34" font-weight="800">${this.xml(initials)}</text>`;

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="960" height="520" viewBox="0 0 960 520">
  <defs>
    <linearGradient id="receiptBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#080a0e"/><stop offset="1" stop-color="#101319"/></linearGradient>
    <filter id="receiptShadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="18" stdDeviation="22" flood-color="#000" flood-opacity=".52"/></filter>
    <clipPath id="saleAvatar"><circle cx="112" cy="90" r="42"/></clipPath>
    <style>
      .r-main{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f7f8fa}
      .r-muted{font-family:Inter,Arial,Helvetica,sans-serif;fill:#8d929c}
      .r-small{font-family:Inter,Arial,Helvetica,sans-serif;fill:#a5a9b1;font-size:17px}
      .r-label{font-family:Inter,Arial,Helvetica,sans-serif;fill:#aeb2ba;font-size:20px;font-weight:650}
      .r-title{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f8fafc;font-size:34px;font-weight:800}
      .r-name{font-family:Inter,Arial,Helvetica,sans-serif;fill:#f8fafc;font-size:25px;font-weight:760}
      .r-total{font-family:Inter,Arial,Helvetica,sans-serif;fill:#38dc79;font-size:42px;font-weight:850}
    </style>
  </defs>
  <rect width="960" height="520" fill="#050608"/>
  <rect x="28" y="24" width="904" height="472" rx="38" fill="url(#receiptBg)" stroke="#232831" stroke-width="2" filter="url(#receiptShadow)"/>
  <rect x="29" y="25" width="902" height="470" rx="37" fill="none" stroke="#ffffff" stroke-opacity=".025"/>

  <circle cx="112" cy="90" r="47" fill="#151922" stroke="#2c333f" stroke-width="2"/>
  ${avatar}
  <text x="174" y="81" class="r-name">${this.xml(displayName)}</text>
  <text x="174" y="111" class="r-small">${this.xml(handle)}</text>
  <text x="882" y="82" text-anchor="end" class="r-small">${this.xml(when)}</text>

  <circle cx="78" cy="174" r="18" fill="#24c96b"/>
  <path d="M69 174l6 6 12-14" fill="none" stroke="#06140b" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
  <text x="112" y="186" class="r-title">Compra Realizada</text>

  <text x="64" y="246" class="r-label">Carrinho</text>
  <rect x="64" y="266" width="832" height="76" rx="18" fill="#0c0f14" stroke="#222831"/>
  <circle cx="100" cy="304" r="19" fill="#151a22"/>
  <text x="100" y="311" text-anchor="middle" class="r-main" font-size="18" font-weight="800">R$</text>
  <text x="136" y="300" class="r-main" font-size="21" font-weight="760">${this.xml(clean(itemLabel, 45))}</text>
  <text x="136" y="325" class="r-muted" font-size="16">Pedido concluído</text>
  <text x="864" y="311" text-anchor="end" class="r-main" font-size="22" font-weight="760">${this.xml(total)}</text>

  <line x1="64" y1="374" x2="896" y2="374" stroke="#252a31" stroke-width="2"/>
  <text x="64" y="430" class="r-label">Valor pago</text>
  <text x="896" y="439" text-anchor="end" class="r-total">${this.xml(total)}</text>

  <text x="64" y="474" class="r-small">${this.xml(server)}</text>
  <text x="896" y="474" text-anchor="end" class="r-small">Pedido ${this.xml(clean(order.id, 34))}</text>
</svg>`;
    const loaded = require("sharp") as ((input?: Buffer) => { png(): { toBuffer(): Promise<Buffer> } }) | { default?: (input?: Buffer) => { png(): { toBuffer(): Promise<Buffer> } } };
    const factory = typeof loaded === "function" ? loaded : loaded.default;
    if (!factory) throw new Error("Gerador de imagem indisponível nesta hospedagem.");
    return factory(Buffer.from(svg)).png().toBuffer();
  }

  private async publishSalesReceipt(order: import("../types.js").Order): Promise<void> {
    if (order.status !== "DELIVERED" || order.salesReceiptMessageId) return;
    const settings = this.db.guild(order.guildId);
    if (!settings.salesReceiptEnabled || !settings.salesChannelId) return;
    const channel = await this.client.channels.fetch(settings.salesChannelId).catch(() => undefined);
    if (!(channel instanceof TextChannel)) return;
    const user = await this.client.users.fetch(order.userId).catch(() => undefined);
    const avatarUrl = user?.displayAvatarURL({ extension: "png", size: 256 }) ?? "";
    const targetUrl = this.salesReceiptTargetUrl(order);
    const button = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(targetUrl).setLabel("Comprar também").setEmoji(this.emojis.component("cart", order.guildId));
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);
    const buildEmbed = () => {
      const firstProduct = this.db.state.products[order.items[0]?.productId ?? ""];
      const embed = new EmbedBuilder()
        .setColor(0x3155ff)
        .setAuthor({ name: "Nova venda concluída", iconURL: avatarUrl || undefined })
        .setTitle(order.items.length === 1 ? order.items[0]!.productName : `${order.items.length} itens adquiridos`)
        .setDescription(`Obrigado pela compra, <@${order.userId}>. Pedido concluído com sucesso.`)
        .addFields(
          { name: "Cliente", value: `**${truncate(order.discordDisplayName, 80)}**`, inline: true },
          { name: "Valor", value: `**${formatMoney(order.totalCents)}**`, inline: true },
          { name: "Pedido", value: `\`${order.id}\``, inline: true },
          { name: "Itens", value: order.items.map((item) => `${item.quantity}× **${item.productName}**${item.fieldName && item.fieldName !== "Opção principal" ? ` • ${item.fieldName}` : ""}`).join("\n").slice(0, 1024) }
        )
        .setFooter({ text: "ZENYX APPLICATIONS • venda concluída" })
        .setTimestamp();
      if (avatarUrl) embed.setThumbnail(avatarUrl);
      const visual = firstProduct?.bannerUrl || firstProduct?.imageUrl;
      if (visual && /^https?:\/\//i.test(visual)) embed.setImage(visual);
      return embed;
    };

    let sent;
    if (settings.salesReceiptMode === "IMAGE") {
      try {
        const image = await this.salesReceiptImage(order, avatarUrl, channel.guild.name, user?.username ?? order.discordDisplayName);
        const attachment = new AttachmentBuilder(image, { name: `venda-${order.id}.png` });
        sent = await channel.send({ files: [attachment], components: [row], allowedMentions: { parse: [] } });
      } catch (error) {
        // Se a hospedagem não carregar Sharp, a venda continua funcionando e o
        // recibo cai automaticamente para EMBED em vez de quebrar o checkout.
        this.logger.warn("Card de venda não pôde ser renderizado; usando embed como fallback.", { orderId: order.id, error: String(error) });
        sent = await channel.send({ embeds: [buildEmbed()], components: [row], allowedMentions: { users: [order.userId] } });
      }
    } else {
      sent = await channel.send({ embeds: [buildEmbed()], components: [row], allowedMentions: { users: [order.userId] } });
    }
    order.salesReceiptMessageId = sent.id;
    order.salesReceiptChannelId = channel.id;
    this.db.save();
  }

  async refreshOrderMessage(order: import("../types.js").Order): Promise<void> {
    // A disponibilidade pública deve acompanhar reservas, cancelamentos,
    // expirações e entregas. Quando a última unidade fica reservada/consumida,
    // o botão "Comprar agora" é desativado automaticamente; se a reserva for
    // liberada, ele volta a ficar disponível sem o dono precisar republicar.
    const affectedProducts = [...new Set(order.items.filter((item) => item.deliveryType === "STOCK").map((item) => item.productId))];
    for (const productId of affectedProducts) {
      await this.refreshProductPublications(productId).catch((error) =>
        this.logger.warn("Não foi possível sincronizar a disponibilidade do produto publicado.", { orderId: order.id, productId, error: String(error) })
      );
    }

    const cart = this.db.state.carts[order.cartId] ?? this.db.state.abandonedCarts[order.cartId];
    if (cart?.channelId && cart.messageId) {
      const channel = await this.client.channels.fetch(cart.channelId).catch(() => undefined);
      if (channel instanceof TextChannel) {
        const message = await channel.messages.fetch(cart.messageId).catch(() => undefined);
        if (message) {
          const attachment = this.orders.qrAttachment(order);
          const payload = this.views.paymentPending(order.guildId, order);
          await message.edit({ ...payload, files: attachment ? [attachment] : [], attachments: [] } as never).catch((error) => this.logger.warn("Não foi possível atualizar a mensagem do pagamento.", { orderId: order.id, error: String(error) }));
        }
      }
    }
    if (order.status === "DELIVERED") {
      await this.publishSalesReceipt(order).catch((error) => this.logger.warn("Não foi possível publicar o comprovante visual da venda.", { orderId: order.id, error: String(error) }));
    }
    if (["CANCELED", "EXPIRED"].includes(order.status)) await this.closePurchaseChannel(cart, order.status === "EXPIRED" ? "pagamento expirado" : "pagamento cancelado");
  }

  private purchaseUrl(guildId: string, channelId: string): string {
    return `https://discord.com/channels/${guildId}/${channelId}`;
  }

  private purchaseLinkRow(guildId: string, channelId: string, label = "Abrir minha compra") {
    return new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(this.purchaseUrl(guildId, channelId)).setLabel(label).setEmoji(this.emojis.component("link", guildId))
    );
  }

  private async closePurchaseChannel(cart: import("../types.js").CartSession | undefined, reason: string): Promise<void> {
    if (!cart) return;
    const channel = cart.channelId ? await this.client.channels.fetch(cart.channelId).catch(() => undefined) : undefined;
    if (channel instanceof TextChannel) {
      await channel.permissionOverwrites.edit(cart.userId, { SendMessages: false }, { type: OverwriteType.Member }).catch(() => undefined);
      await channel.send({ content: `🔒 **Compra encerrada.** ${reason}` }).catch(() => undefined);
      setTimeout(() => void channel.delete(`ZENYX • ${reason}`).catch(() => undefined), 2500).unref?.();
    }
    if (cart.sourceChannelId && cart.sourceNoticeMessageId) {
      const source = await this.client.channels.fetch(cart.sourceChannelId).catch(() => undefined);
      if (source instanceof TextChannel) {
        const notice = await source.messages.fetch(cart.sourceNoticeMessageId).catch(() => undefined);
        await notice?.delete().catch(() => undefined);
      }
    }
  }

  async refreshRobuxOrderMessage(order: import("../services/robux.js").RobuxOrder): Promise<boolean> {
    if (!order.purchaseThreadId) return false;
    const channel = await this.client.channels.fetch(order.purchaseThreadId).catch(() => undefined);
    if (!channel?.isThread?.() || !channel.messages?.fetch || !channel.send) return false;
    const payload = ["PAID", "DELIVERING", "DELIVERY_REVIEW", "DELIVERED"].includes(order.status) || order.paymentStatus === "paid"
      ? this.robuxDeliveryPayload(order.guildId, order.discordUserId, order)
      : ["CANCELED", "EXPIRED"].includes(order.status)
        ? this.robuxThreadPayload(order.guildId, order.discordUserId, order.status === "EXPIRED" ? "Pagamento expirado" : "Compra cancelada", order.status === "EXPIRED" ? "A cobrança expirou. Inicie uma nova compra." : "Esta cobrança foi cancelada.", [], false)
        : await this.robuxCheckoutPayload(order.guildId, order.discordUserId, order);
    const publish = async (target?: import("discord.js").Message) => {
      const full = { ...payload, flags: MessageFlags.IsComponentsV2, attachments: [] } as never;
      try {
        if (target) { await target.edit(full); return target; }
        return await channel.send(full);
      } catch (firstError) {
        const record = payload as Record<string, unknown>;
        const files = Array.isArray(record.files) ? record.files : [];
        if (!files.length) throw firstError;
        this.logger.warn("Cobrança Robux falhou com QR no Media Gallery; tentando página segura e QR separado.", { orderId: order.id, error: String(firstError) });
        const safeRecord = await this.robuxCheckoutPayload(order.guildId, order.discordUserId, order, false);
        const safePayload = { ...safeRecord, files: [], attachments: [], flags: MessageFlags.IsComponentsV2 } as never;
        const page = target ? await target.edit(safePayload) : await channel.send(safePayload);
        await channel.send({
          content: `### QR Code PIX\nPedido **${order.id}**`,
          files: files as never,
          allowedMentions: { parse: [] }
        }).catch((error) => this.logger.warn("Página do PIX foi publicada, mas o QR separado falhou.", { orderId: order.id, error: String(error) }));
        return page;
      }
    };
    try {
      if (order.purchaseMessageId) {
        const message = await channel.messages.fetch(order.purchaseMessageId).catch(() => undefined);
        if (message) { await publish(message); return true; }
      }
    } catch (error) { this.logger.warn("Falha ao editar cobrança Robux; usando mensagem de recuperação.", { orderId: order.id, error: String(error) }); }
    try {
      const replacement = await publish();
      this.robux.setPurchaseMessage(order.id, replacement.id);
      order.purchaseMessageId = replacement.id;
      return true;
    } catch (error) {
      this.logger.error("Não foi possível publicar a cobrança Robux no tópico.", { orderId: order.id, error: String(error) });
      return false;
    }
  }

  private async refreshCartMessage(guildId: string, userId: string): Promise<void> {
    const cart = this.products.getCartSession(guildId, userId);
    if (!cart?.channelId || !cart.messageId) return;
    const channel = await this.client.channels.fetch(cart.channelId).catch(() => undefined);
    if (!(channel instanceof TextChannel)) return;
    const message = await channel.messages.fetch(cart.messageId).catch(() => undefined);
    if (!message) return;
    const user = await this.client.users.fetch(userId).catch(() => undefined);
    await message.edit(this.views.cart(guildId, userId, user?.displayName ?? user?.username ?? "Cliente", user?.displayAvatarURL() ?? "") as never);
  }

  private assertCartOwner(guildId: string, userId: string, channelId?: string): import("../types.js").CartSession {
    const cart = this.products.getCartSession(guildId, userId);
    if (!cart) throw new Error("Você não possui um carrinho ativo.");
    if (channelId && cart.channelId && cart.channelId !== channelId) throw new Error("Use os controles no canal privado do seu carrinho.");
    return cart;
  }

  private guardPurchase(guildId: string, userId: string, productId: string, fieldId: string): boolean {
    const key = `${guildId}:${userId}:${productId}:${fieldId}`;
    const now = Date.now();
    const previous = this.purchaseGuards.get(key) ?? 0;
    if (now - previous < 2500) return false;
    this.purchaseGuards.set(key, now);
    setTimeout(() => this.purchaseGuards.delete(key), 3000).unref?.();
    return true;
  }


  private robuxSessionKey(guildId: string, userId: string): string { return `${guildId}:${userId}`; }

  private requireOwner(interaction: { user: { id: string } }): void {
    if (!this.config.ownerIds.includes(interaction.user.id)) throw new Error("Esta função é exclusiva do proprietário desta aplicação.");
  }

  private invitesAdminView(guildId: string) {
    const cfg = this.invites.settings(guildId);
    const top = this.invites.top(guildId, 10);
    const ranking = top.length
      ? top.map((stat, index) => `${index + 1}. <@${stat.userId}> • **${this.invites.score(stat)}** válidos • ${stat.joins} entradas • ${stat.leaves} saídas • ${stat.fake} fake`).join("\n")
      : "Nenhum convite contabilizado ainda.";
    const embed = new EmbedBuilder()
      .setColor(0x3155ff)
      .setTitle(`${this.emojis.text("announcement", guildId)} Invite Tracker`)
      .setDescription("Rastreie convites usados quando membros entram, desconte saídas e contas muito novas e acompanhe um ranking interno.")
      .addFields(
        { name: "Status", value: `Sistema: **${cfg.enabled ? "Ativado" : "Desativado"}**\nCanal: ${cfg.channelId ? `<#${cfg.channelId}>` : "não configurado"}`, inline: true },
        { name: "Regras", value: `Descontar saídas: **${cfg.trackLeaves ? "sim" : "não"}**\nConta fake: **menos de ${cfg.fakeAccountDays} dia(s)**\nIgnorar bots: **${cfg.ignoreBots ? "sim" : "não"}**`, inline: true },
        { name: "Mensagem de entrada", value: truncate(cfg.message || "-", 1000), inline: false },
        { name: "Ranking", value: truncate(ranking, 1024), inline: false }
      )
      .setFooter({ text: "Placeholders: {member} • {inviter} • {invites} • {code} • {server}" });
    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(guildId, "admin:invites:toggle", cfg.enabled ? "Desativar" : "Ativar", cfg.enabled ? "off" : "on", cfg.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(guildId, "admin:invites:channel", "Canal de entradas", "message", ButtonStyle.Primary),
          this.views.button(guildId, "admin:invites:message", "Mensagem", "edit", ButtonStyle.Primary),
          this.views.button(guildId, "admin:invites:settings", "Regras", "settings", ButtonStyle.Secondary),
          this.views.button(guildId, "admin:invites:ranking", "Ranking", "analytics", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(guildId, "admin:invites:refresh", "Atualizar convites", "refresh", ButtonStyle.Success),
          this.views.button(guildId, "admin:invites:reset", "Zerar estatísticas", "delete", ButtonStyle.Danger),
          this.views.button(guildId, "admin:home", "Voltar", "back")
        )
      ]
    };
  }

  private invitesRankingView(guildId: string) {
    const top = this.invites.top(guildId, 25);
    const text = top.length
      ? top.map((stat, index) => `**${index + 1}.** <@${stat.userId}> — **${this.invites.score(stat)}** válidos\n-# Entradas ${stat.joins} • Saídas ${stat.leaves} • Fakes ${stat.fake}`).join("\n")
      : "Nenhuma entrada por convite foi contabilizada ainda.";
    return {
      embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Ranking de convites").setDescription(truncate(text, 4000))],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId, "admin:invites:refresh", "Atualizar cache", "refresh", ButtonStyle.Success),
        this.views.button(guildId, "admin:invites", "Voltar", "back")
      )]
    };
  }

  private zcloudPanelPayload(guildId: string) {
    const z = this.zcloud.settings(guildId);
    const available = this.zcloud.managerEnabled() && z.enabled;
    const button = available
      ? new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(this.zcloud.panelAuthorizeUrl(guildId)).setLabel(truncate(z.buttonLabel || "Verificar minha conta", 80))
      : new ButtonBuilder().setCustomId("zcloud:disabled").setStyle(ButtonStyle.Secondary).setLabel("Verificação indisponível").setDisabled(true);
    const emojiChoice = String(z.buttonEmoji || "shield");
    if (emojiChoice !== "__none__") {
      const emoji = this.emojis.component(emojiChoice, guildId);
      if (typeof emoji !== "string" || emoji.trim()) button.setEmoji(emoji);
    }
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);

    if (z.panelMode === "V2") {
      const container = new ContainerBuilder();
      if (this.db.brand(guildId).showAccentColors) container.setAccentColor(colorNumber(z.panelColor));
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${truncate(z.panelTitle || "ZENYX VERIFICATION", 300)}`));
      if (z.panelDescription.trim()) container.addTextDisplayComponents(new TextDisplayBuilder().setContent(truncate(z.panelDescription, 3900)));
      if (z.panelImageUrl) container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(z.panelImageUrl).setDescription("Painel de verificação")));
      container.addActionRowComponents(row);
      if (z.panelFooter.trim()) {
        container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ${truncate(z.panelFooter, 1900)}`));
      }
      return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, "painel público ZCloud");
    }

    const embed = new EmbedBuilder().setTitle(z.panelTitle).setDescription(z.panelDescription);
    if (this.db.brand(guildId).showAccentColors) embed.setColor(colorNumber(z.panelColor));
    if (z.panelImageUrl) embed.setImage(z.panelImageUrl);
    if (z.panelFooter.trim()) embed.setFooter({ text: truncate(z.panelFooter, 2048) });
    return checkedDiscordPayload({ embeds: [embed], components: [row] }, "painel público ZCloud embed");
  }

  private zcloudAdminView(guildId: string) {
    const z = this.zcloud.settings(guildId);
    const members = this.zcloud.members(guildId);
    const publicUrl = this.zcloud.effectivePublicBaseUrl(guildId);
    const callback = this.zcloud.effectiveRedirectUri(guildId);
    const embed = new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("zcloud",guildId)} ZCloud Auth`).setDescription("Central OAuth2 da aplicação. O botão público abre diretamente a autorização oficial do Discord; depois, o site ZCloud conclui a sincronização e aplica as configurações deste servidor.").addFields(
      {name:"Status",value:`Disponibilidade do Manager: **${this.zcloud.managerEnabled()?"Ativada":"Desativada"}**\nZCloud do servidor: **${z.enabled?"Ativado":"Desativado"}**\nOAuth: **${z.clientId&&this.zcloud.secretConfigured(guildId)?"Configurado":"Incompleto"}**\nPainel: **${z.panelMessageId?"Publicado":"Não publicado"}** • **${z.panelMode === "V2" ? "Components V2" : "Embed normal"}**`,inline:true},
      {name:"Acesso",value:`Verificados: **${members.length}**\nBackup elegíveis: **${members.filter(m=>m.backupEligible).length}**\nCargo: ${z.verificationRoleId?`<@&${z.verificationRoleId}>`:"não configurado"}`,inline:true},
      {name:"Servidor adicional",value:z.autoJoinEnabled?`**Ativado**\nID: \`${z.autoJoinGuildId||"não configurado"}\`\nConvite: **${z.autoJoinInviteUrl?"configurado":"ausente"}**` : "**Desativado**",inline:true},
      {name:"Backup de membros",value:z.backupTransferEnabled?`**Ativado (somente autorizados via OAuth)**\nServidor: \`${z.backupGuildId||"não configurado"}\`\nLimite por envio: **${z.backupTransferLimit}**\nConvite: **${z.backupInviteUrl?"configurado":"ausente"}**` : "**Desativado**",inline:true},
      {name:"Aparência",value:`Cor lateral: **${z.panelColor}**\nImagem: **${z.panelImageUrl?"configurada":"não configurada"}**\nEmoji do botão: **${z.buttonEmoji === "__none__" ? "removido" : z.buttonEmoji ? "personalizado" : "padrão"}**`,inline:true},
      {name:"Infraestrutura HTTPS",value:`URL pública: ${publicUrl?`\`${publicUrl}\``:"**não disponível**"}\nCallback OAuth: ${callback?`\`${callback}\``:"**não disponível**"}`,inline:false},
      {name:"Fluxo público",value:"Botão → **Discord OAuth2** → callback HTTPS no Reverse Proxy do Manager → **site ZCloud** → cargo/sincronização → retorno ao Discord.",inline:false}
    );
    const guildOptions=[...this.client.guilds.cache.values()].slice(0,25).map(g=>new StringSelectMenuOptionBuilder().setLabel(truncate(g.name,100)).setValue(g.id).setDescription(g.id));
    const rows:Array<ActionRowBuilder<ButtonBuilder|StringSelectMenuBuilder>>=[
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId,"admin:zcloud:toggle",z.enabled?"Desativar ZCloud":"Ativar ZCloud","zcloud",z.enabled?ButtonStyle.Danger:ButtonStyle.Success),
        this.views.button(guildId,"admin:zcloud:oauth","Configurar OAuth","settings",ButtonStyle.Primary),
        this.views.button(guildId,"admin:zcloud:role","Cargo de verificação","shield",ButtonStyle.Primary),
        this.views.button(guildId,"admin:zcloud:publish",z.panelMessageId?"Atualizar publicação":"Publicar verificação","announcement",ButtonStyle.Success),
        this.views.button(guildId,"admin:zcloud:test","Testar ZCloud","refresh",ButtonStyle.Success)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId,"admin:zcloud:appearance","Texto, imagem e cor","customize"),
        this.views.button(guildId,"admin:zcloud:button-style","Texto do botão","edit"),
        this.views.button(guildId,"admin:zcloud:preview","Pré-visualizar","search"),
        this.views.button(guildId,"admin:zcloud:members","Membros verificados","users"),
        this.views.button(guildId,"admin:zcloud:auto-join","Servidor adicional","server",ButtonStyle.Primary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId,"admin:zcloud:backup-config","Servidor de backup","backup",ButtonStyle.Primary),
        this.views.button(guildId,"admin:zcloud:backup-transfer","Enviar autorizados","users",ButtonStyle.Success,!z.backupTransferEnabled || !z.backupGuildId),
        this.views.button(guildId,"admin:zcloud:backup-toggle",z.backupTransferEnabled?"Desativar backup":"Ativar backup","shield",z.backupTransferEnabled?ButtonStyle.Danger:ButtonStyle.Success),
        this.views.button(guildId,"admin:zcloud:emoji:0","Emoji do botão","emoji",ButtonStyle.Primary),
        this.views.button(guildId,"admin:saved-emojis","Biblioteca","saved_emoji",ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("admin:zcloud:panel-mode").setPlaceholder("Tipo do painel público").addOptions(
        new StringSelectMenuOptionBuilder().setLabel("Embed normal").setDescription("Embed tradicional com cor lateral, imagem e botão OAuth").setValue("EMBED").setEmoji(this.emojis.component("message",guildId)),
        new StringSelectMenuOptionBuilder().setLabel("Components V2").setDescription("Container moderno com accent color, mídia e botão OAuth").setValue("V2").setEmoji(this.emojis.component("customize",guildId))
      ))
    ];
    if(guildOptions.length) rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("admin:zcloud:backup-select").setPlaceholder("Servidor de backup").addOptions(guildOptions)));
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(guildId,"admin:home","Voltar","back")));
    return {embeds:[embed],components:rows};
  }


  private robuxAdminView(guildId: string) {
    const s = this.robux.settings(guildId);
    const orders = this.robux.listOrders(guildId, 100);
    const delivered = orders.filter((order) => order.status === "DELIVERED").length;
    const review = orders.filter((order) => order.status === "DELIVERY_REVIEW").length;
    const methods = this.payments.enabledMethods(guildId);
    const modeLabel = s.deliveryMode === "COOKIE_AUTO" ? "Automática • conta Roblox" : s.deliveryMode === "WEBHOOK" ? "Automática • integração HTTPS" : s.deliveryMode === "ASSISTED" ? "Assistida" : "Manual";
    const account = this.robux.hasCookie(guildId) ? `**Configurada**${s.deliveryAccountName ? ` • ${s.deliveryAccountName}` : ""}` : "**Não configurada**";
    const embed = new EmbedBuilder()
      .setColor(0x3155ff)
      .setTitle("Central Robux")
      .setDescription("Controle o fluxo completo: venda, pagamento, Game Pass, entrega, calculadora e anúncio pós-compra. A conta de entrega é opcional e fica disponível somente para o dono.")
      .addFields(
        { name: "Vendas", value: `Status: **${s.enabled ? "Ativas" : "Desativadas"}**\nPreço por 1.000: **${formatMoney(s.pricePer1000Cents)}**\nLimites: **${s.minRobux.toLocaleString("pt-BR")} a ${s.maxRobux.toLocaleString("pt-BR")} Robux**`, inline: true },
        { name: "Calculadora", value: `Status: **${s.calculatorEnabled ? "Ativa" : "Desativada"}**\nCanal: ${s.calculatorChannelId ? `<#${s.calculatorChannelId}>` : "não configurado"}\nResposta: **${s.calculatorFormat}**`, inline: true },
        { name: "Pagamento", value: `Método: **${s.paymentProvider === "AUTO" ? "Todos os configurados" : s.paymentProvider.replaceAll("_", " ")}**\nMétodos prontos: **${methods.length}**`, inline: true },
        { name: "Entrega", value: `Modo: **${modeLabel}**\nConta Roblox: ${account}\nLogs: ${s.logChannelId ? `<#${s.logChannelId}>` : "não configurado"}`, inline: false },
        { name: "Pós-compra", value: `${s.announcementEnabled ? "**Ativo**" : "Desativado"} • ${s.announcementChannelId ? `<#${s.announcementChannelId}>` : "canal não configurado"} • **${s.announcementFormat}**`, inline: true },
        { name: "Pedidos", value: `Registrados: **${orders.length}** • Entregues: **${delivered}** • Revisão: **${review}**`, inline: true }
      );

    const provider = new StringSelectMenuBuilder().setCustomId("admin:robux:provider").setPlaceholder("Forma de pagamento do módulo Robux").addOptions(
      new StringSelectMenuOptionBuilder().setLabel("Todos os configurados").setDescription("O comprador escolhe entre os métodos habilitados").setValue("AUTO").setDefault(s.paymentProvider === "AUTO").setEmoji(this.emojis.component("payment", guildId)),
      ...(["MERCADO_PAGO", "EFI_BANK", "STRIPE", "MISTIC_PAY", "PURIN_CASH", "EVO_PAY", "IMAP_PIX", "MANUAL_PIX"] as PaymentProviderName[]).map((name) =>
        new StringSelectMenuOptionBuilder().setLabel(name.replaceAll("_", " ").slice(0, 100)).setDescription(methods.includes(name) ? "Configurado e disponível" : "Ainda não configurado").setValue(name).setDefault(s.paymentProvider === name).setEmoji(this.emojis.component("payment", guildId))
      )
    );
    const deliveryMode = new StringSelectMenuBuilder().setCustomId("admin:robux:delivery-mode").setPlaceholder("Escolha como os Robux serão entregues").addOptions(
      new StringSelectMenuOptionBuilder().setLabel("Manual").setDescription("Você confirma PIX, abre a Game Pass, compra e confirma entrega").setValue("MANUAL").setDefault(s.deliveryMode === "MANUAL").setEmoji(this.emojis.component("delivery", guildId)),
      new StringSelectMenuOptionBuilder().setLabel("Assistida").setDescription("Você confirma o pagamento e o bot compra a Game Pass").setValue("ASSISTED").setDefault(s.deliveryMode === "ASSISTED").setEmoji(this.emojis.component("delivery", guildId)),
      new StringSelectMenuOptionBuilder().setLabel("Automática • conta Roblox").setDescription("Pagamento aprovado → bot compra a Game Pass automaticamente").setValue("COOKIE_AUTO").setDefault(s.deliveryMode === "COOKIE_AUTO").setEmoji(this.emojis.component("automation", guildId)),
      new StringSelectMenuOptionBuilder().setLabel("Automática • integração HTTPS").setDescription("Entrega por endpoint externo configurado pelo dono").setValue("WEBHOOK").setDefault(s.deliveryMode === "WEBHOOK").setEmoji(this.emojis.component("automation", guildId))
    );
    const calculatorMode = new StringSelectMenuBuilder().setCustomId("admin:robux:calculator-mode").setPlaceholder("Formato da calculadora Robux").addOptions(
      new StringSelectMenuOptionBuilder().setLabel("PNG").setDescription("Responder com o card visual em imagem").setValue("PNG").setDefault(s.calculatorEnabled && s.calculatorFormat === "PNG").setEmoji(this.emojis.component("image", guildId)),
      new StringSelectMenuOptionBuilder().setLabel("Embed").setDescription("Responder usando embed tradicional").setValue("EMBED").setDefault(s.calculatorEnabled && s.calculatorFormat === "EMBED").setEmoji(this.emojis.component("message", guildId)),
      new StringSelectMenuOptionBuilder().setLabel("Desativada").setDescription("Não responder cálculos pelo painel/canal configurado").setValue("OFF").setDefault(!s.calculatorEnabled).setEmoji(this.emojis.component("off", guildId))
    );

    const rows = [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId, "admin:robux:toggle", s.enabled ? "Desativar vendas" : "Ativar vendas", s.enabled ? "off" : "on", s.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(guildId, "admin:robux:prices", "Preços e limites", "settings", ButtonStyle.Primary),
        this.views.button(guildId, "admin:robux:text", "Texto e banner", "edit", ButtonStyle.Primary),
        this.views.button(guildId, "admin:robux:publish", "Publicar painel", "catalog", ButtonStyle.Success),
        this.views.button(guildId, "admin:payments", "Pagamentos", "payment", ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(guildId, "admin:robux:calculator-channel", "Canal calculadora", "message"),
        this.views.button(guildId, "admin:robux:manual-shortcut-toggle", s.manualShortcutEnabled ? "Desativar lupa" : "Ativar lupa", "robux_manual", s.manualShortcutEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(guildId, "admin:robux:orders-list", "Pedidos / fila", "invoice"),
        this.views.button(guildId, "admin:robux:delivery-cookie", this.robux.hasCookie(guildId) ? "Conta Roblox" : "Configurar conta Roblox", "settings", ButtonStyle.Primary),
        this.views.button(guildId, "admin:robux:advanced", "Mais opções", "settings", ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(deliveryMode),
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(calculatorMode),
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(provider)
    ];
    const adminBody = [
      `### Vendas\nStatus: **${s.enabled ? "Ativas" : "Desativadas"}**\nPreço por 1.000: **${formatMoney(s.pricePer1000Cents)}**\nLimites: **${s.minRobux.toLocaleString("pt-BR")} a ${s.maxRobux.toLocaleString("pt-BR")} Robux**`,
      `### Calculadora\nStatus: **${s.calculatorEnabled ? "Ativa" : "Desativada"}**\nCanal: ${s.calculatorChannelId ? `<#${s.calculatorChannelId}>` : "não configurado"}\nResposta: **${s.calculatorFormat}**`,
      `### Pagamento\nMétodo: **${s.paymentProvider === "AUTO" ? "Todos os configurados" : s.paymentProvider.replaceAll("_", " ")}**\nMétodos prontos: **${methods.length}**`,
      `### Entrega\nModo: **${modeLabel}**\nConta Roblox: ${account}\nLogs: ${s.logChannelId ? `<#${s.logChannelId}>` : "não configurado"}`,
      `### Pós-compra\n${s.announcementEnabled ? "**Ativo**" : "Desativado"} • ${s.announcementChannelId ? `<#${s.announcementChannelId}>` : "canal não configurado"} • **${s.announcementFormat}**`,
      `### Pedidos\nRegistrados: **${orders.length}** • Entregues: **${delivered}** • Revisão: **${review}**`
    ].join("\n\n");
    return this.robuxContainer(guildId, `${this.emojis.text("robux", guildId)} Central Robux`, adminBody, rows, "", true);
  }

  private robuxAdminAdvancedView(guildId: string) {
    const s = this.robux.settings(guildId);
    const embed = new EmbedBuilder()
      .setColor(0x3155ff)
      .setTitle("Robux • opções avançadas")
      .setDescription("Canais privados, anúncios pós-compra e integração de entrega. Nenhuma configuração desta página altera preços ou métodos de pagamento.")
      .addFields(
        { name: "Logs", value: s.logChannelId ? `<#${s.logChannelId}>` : "não configurado", inline: true },
        { name: "Pós-compra", value: `${s.announcementEnabled ? "Ativo" : "Desativado"} • ${s.announcementChannelId ? `<#${s.announcementChannelId}>` : "sem canal"} • ${s.announcementFormat}`, inline: true },
        { name: "Integração HTTPS", value: this.robux.deliveryConfigured(guildId) ? "Configurada" : "Não configurada", inline: true }
      );
    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(guildId, "admin:robux:log-channel", "Canal de logs", "logs"),
          this.views.button(guildId, "admin:robux:announcement-channel", "Canal pós-compra", "announcement"),
          this.views.button(guildId, "admin:robux:announcement-toggle", s.announcementEnabled ? "Desativar anúncio" : "Ativar anúncio", "announcement", s.announcementEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(guildId, "admin:robux:announcement-format-toggle", `Anúncio: ${s.announcementFormat}`, "image", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(guildId, "admin:robux:delivery-webhook", "Integração HTTPS", "automation", ButtonStyle.Secondary),
          this.views.button(guildId, "admin:robux", "Voltar", "back", ButtonStyle.Secondary)
        )
      ]
    };
  }

  private robuxOrdersView(guildId: string) {
    const orders = this.robux.listOrders(guildId, 25);
    const embed = new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("invoice", guildId)} Pedidos Robux`).setDescription(
      orders.length ? orders.slice(0, 10).map((o) => `\`${o.id}\` • **${o.robloxUsername}** • ${o.requestedRobux} Robux • **${o.status}**`).join("\n") : "Nenhum pedido Robux foi criado ainda."
    );
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (orders.length) {
      const select = new StringSelectMenuBuilder().setCustomId("admin:robux:order-select").setPlaceholder("Abrir um pedido Robux").addOptions(
        orders.map((o) => new StringSelectMenuOptionBuilder().setLabel(`${o.robloxUsername} • ${o.requestedRobux} Robux`.slice(0, 100)).setDescription(`${o.id} • ${o.status}`.slice(0, 100)).setValue(o.id).setEmoji(this.emojis.component("invoice", guildId)))
      );
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
    }
    components.push(this.views.back(guildId, "admin:robux"));
    return { embeds: [embed], components };
  }

  private robuxOrderDetail(guildId: string, orderId: string) {
    const order = this.robux.getOrder(orderId);
    if (!order || order.guildId !== guildId) throw new Error("Pedido Robux não encontrado.");
    const embed = new EmbedBuilder().setColor(order.status === "DELIVERED" ? 0x22c55e : order.status === "DELIVERY_REVIEW" ? 0xf59e0b : 0x3155ff)
      .setTitle(`Pedido Robux • ${order.id}`)
      .addFields(
        { name: "Cliente", value: `<@${order.discordUserId}>`, inline: true },
        { name: "Roblox", value: `**${order.robloxUsername}** (${order.robloxUserId})`, inline: true },
        { name: "Gamepass", value: `**${order.gamepassName}** • ID ${order.gamepassId}\nPreço: ${order.gamepassPrice} Robux`, inline: false },
        { name: "Venda", value: `${order.requestedRobux} Robux • ${formatMoney(order.amountCents)}`, inline: true },
        { name: "Pagamento", value: `${order.provider.replaceAll("_", " ")} • ${order.paymentStatus}`, inline: true },
        { name: "Estado", value: order.status, inline: true },
        ...(order.paymentConfirmationRequestedAt ? [{ name: "Confirmação do cliente", value: `Cliente informou pagamento em <t:${Math.floor(Date.parse(order.paymentConfirmationRequestedAt) / 1000)}:R>. Confira o PIX antes de marcar como pago.`, inline: false }] : []),
        ...(order.error ? [{ name: "Última falha", value: truncate(order.error, 1000), inline: false }] : [])
      );
    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(guildId, `admin:robux:mark-paid:${order.id}`, "Marcar pago", "approve", ButtonStyle.Success, order.paymentStatus === "paid" || order.status === "DELIVERED"),
      this.views.button(guildId, `admin:robux:retry:${order.id}`, "Tentar entrega", "delivery", ButtonStyle.Primary, !["PAID", "DELIVERY_REVIEW"].includes(order.status)),
      this.views.button(guildId, `admin:robux:mark-delivered:${order.id}`, "Marcar entregue", "success", ButtonStyle.Success, order.paymentStatus !== "paid" || order.status === "DELIVERED")
    );
    const gamepassUrl = order.gamepassUrlOverride || (order.gamepassId > 0 ? this.robux.gamepassUrl(order.gamepassId) : "");
    if (gamepassUrl) row.addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(gamepassUrl).setLabel("Abrir gamepass"));
    row.addComponents(this.views.button(guildId, "admin:robux:orders-list", "Voltar", "back"));
    return {
      embeds: [embed],
      components: [row]
    };
  }

  private robuxContainer(guildId: string, title: string, body: string, rows: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [], bannerUrl = "", includeFlags = true) {
    const container = new ContainerBuilder();
    if (this.db.brand(guildId).showAccentColors) container.setAccentColor(0x3155ff);
    const mediaUrl = /^(?:https?:\/\/|attachment:\/\/)/i.test(bannerUrl) ? bannerUrl : "";
    if (mediaUrl) {
      container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL(mediaUrl).setDescription("Painel de Robux")));
      container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    }
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${title}\n${body}`));
    if (rows.length) container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    for (const row of rows) container.addActionRowComponents(row as never);
    const payload: Record<string, unknown> = { components: [container] };
    if (includeFlags) payload.flags = MessageFlags.IsComponentsV2;
    return payload;
  }

  private publicRobuxPanel(guildId: string, includeDefaultBanner = true) {
    const s = this.robux.settings(guildId);
    const body = `${s.description}\n\n### Como funciona\nVocê pode buscar sua conta Roblox e escolher uma Game Pass automaticamente ou continuar manualmente informando nick, quantidade e um link Roblox opcional. Depois confira o valor e escolha a forma de pagamento.\n\n**Faixa:** ${s.minRobux.toLocaleString("pt-BR")} a ${s.maxRobux.toLocaleString("pt-BR")} Robux\n**Preço base:** ${formatMoney(s.pricePer1000Cents)} / 1.000 Robux`;
    const publicRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(guildId, "robux:buy", "Comprar Robux", "robux_buy", ButtonStyle.Success),
      this.views.button(guildId, "robux:calc", "Calcular valores", "robux_calc", ButtonStyle.Primary)
    );
    if (s.manualShortcutEnabled) {
      const shortcut = new ButtonBuilder().setCustomId("robux:manual-quick").setStyle(ButtonStyle.Secondary);
      const emoji = this.emojis.component("robux_manual", guildId);
      if (typeof emoji !== "string" || emoji.trim()) shortcut.setEmoji(emoji);
      publicRow.addComponents(shortcut);
    }
    const rows = [publicRow];
    if (!includeDefaultBanner) return this.robuxContainer(guildId, `${s.title}`, body, rows, "", true);
    const customBanner = /^https?:\/\//i.test(s.bannerUrl) ? s.bannerUrl : "";
    if (customBanner) return this.robuxContainer(guildId, `${s.title}`, body, rows, customBanner, true);
    const container = this.robuxContainer(guildId, `${s.title}`, body, rows, "attachment://panel-banner.png", true);
    return { ...container, files: [new AttachmentBuilder("assets/panel-banner.png", { name: "panel-banner.png" })] };
  }

  /**
   * Publica ou atualiza o painel Robux e só retorna sucesso depois de buscar a
   * mensagem novamente no Discord. Isso evita o falso positivo "painel publicado"
   * quando uma edição antiga falha, quando o painel anterior era legado ou quando
   * o upload do banner é recusado. O fallback sem banner mantém o Components V2
   * funcional mesmo sem Attach Files.
   */
  private async upsertRobuxPanel(guildId: string, channel: TextChannel, preferredMessageId = "") {
    const me = channel.guild.members.me;
    const permissions = me ? channel.permissionsFor(me) : null;
    if (!permissions?.has(PermissionFlagsBits.ViewChannel) || !permissions.has(PermissionFlagsBits.SendMessages)) {
      throw new Error("Não consigo publicar nesse canal. Conceda Ver canal e Enviar mensagens para o bot.");
    }

    const primary = this.publicRobuxPanel(guildId, true) as Record<string, unknown>;
    const fallback = this.publicRobuxPanel(guildId, false) as Record<string, unknown>;
    const asEdit = (payload: Record<string, unknown>) => {
      const { flags: _flags, content: _content, embeds: _embeds, stickers: _stickers, poll: _poll, ...rest } = payload;
      // Mensagens V2 não aceitam campos legados nem vazios.
      return { ...rest, attachments: [] };
    };
    const verify = async (message: import("discord.js").Message) => {
      const fetched = await channel.messages.fetch(message.id);
      const isV2 = fetched.flags.has(MessageFlags.IsComponentsV2);
      if (!isV2 || !fetched.components.length) throw new Error("O Discord não confirmou o painel Components V2 publicado.");
      return fetched;
    };

    const existing = preferredMessageId ? await channel.messages.fetch(preferredMessageId).catch(() => undefined) : undefined;
    if (existing) {
      const alreadyV2 = existing.flags.has(MessageFlags.IsComponentsV2) && !existing.embeds.length && !existing.content;
      if (alreadyV2) {
        try {
          const edited = await existing.edit(asEdit(primary) as never);
          return { message: await verify(edited), updated: true, fallback: false };
        } catch (error) {
          this.logger.warn("Falha ao atualizar painel Robux com banner; tentando Components V2 sem banner.", { guildId, channelId: channel.id, messageId: existing.id, error: String(error) });
          try {
            const edited = await existing.edit(asEdit(fallback) as never);
            return { message: await verify(edited), updated: true, fallback: true };
          } catch (fallbackError) {
            this.logger.warn("Painel Robux existente não pôde ser atualizado; uma nova publicação será criada.", { guildId, channelId: channel.id, messageId: existing.id, error: String(fallbackError) });
          }
        }
      }
    }

    let sent: import("discord.js").Message | undefined;
    let usedFallback = false;
    try {
      sent = await channel.send(primary as never);
      sent = await verify(sent);
    } catch (error) {
      if (sent) await sent.delete().catch(() => undefined);
      this.logger.warn("Falha ao publicar painel Robux com banner; tentando Components V2 sem banner.", { guildId, channelId: channel.id, error: String(error) });
      usedFallback = true;
      sent = await channel.send(fallback as never);
      sent = await verify(sent);
    }

    if (existing && existing.id !== sent.id) await existing.delete().catch(() => undefined);
    return { message: sent, updated: false, fallback: usedFallback };
  }

  private robuxCalcMenu(guildId: string) {
    const rows = [new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(guildId, "robux:calc:money", "Tenho um valor em R$", "coin", ButtonStyle.Primary),
      this.views.button(guildId, "robux:calc:robux", "Tenho uma quantidade de Robux", "robux", ButtonStyle.Success)
    )];
    return this.robuxContainer(guildId, `Calculadora de Robux`, "Escolha o tipo de cálculo. **R$ → Robux** mostra quanto você consegue comprar; **Robux → valor/gamepass** mostra quanto custa e o preço recomendado da Game Pass.", rows, "", true);
  }

  private robuxThreadPayload(guildId: string, userId: string, title: string, body: string, extraRows: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [], includeFlags = true) {
    const rows = [...extraRows, new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(guildId, `robux:close:${userId}`, "Fechar compra", "delete", ButtonStyle.Danger))];
    return this.robuxContainer(guildId, title, body, rows, "", includeFlags);
  }

  private robuxPaymentMethods(guildId: string): PaymentProviderName[] {
    const enabled = this.payments.enabledMethods(guildId);
    const configured = this.robux.settings(guildId).paymentProvider;
    return configured === "AUTO" ? enabled : enabled.includes(configured) ? [configured] : [];
  }

  private async updateV2(interaction: ButtonInteraction | StringSelectMenuInteraction, payload: Record<string, unknown>) {
    await interaction.deferUpdate();
    return interaction.message.edit({ ...payload, flags: MessageFlags.IsComponentsV2 } as never);
  }

  private robuxGamepassMenu(guildId: string, session: { userId: string; robloxUser?: RobloxUser; gamepasses: RobloxGamepass[] }) {
    if (!session.robloxUser) throw new Error("A conta Roblox desta compra não está mais disponível.");
    if (!session.gamepasses.length) throw new Error("Nenhuma gamepass está disponível nesta consulta.");
    const select = new StringSelectMenuBuilder()
      .setCustomId(`robux:gamepass:${session.userId}`)
      .setPlaceholder("Escolha uma gamepass / quantidade")
      .addOptions(session.gamepasses.slice(0, 25).map((pass) => new StringSelectMenuOptionBuilder()
        .setLabel(pass.name.slice(0, 100))
        .setDescription(`${pass.price.toLocaleString("pt-BR")} Robux • recebe ~${Math.floor(pass.price * 0.7).toLocaleString("pt-BR")} Robux`.slice(0, 100))
        .setValue(String(pass.id))));
    return this.robuxThreadPayload(
      guildId,
      session.userId,
      `Gamepasses de ${session.robloxUser.name}`,
      `Escolha a gamepass que representa a quantidade desejada. Você pode voltar para esta lista antes de concluir o pagamento.`,
      [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select)],
      false
    );
  }

  private async robuxThreadMessage(session: { threadId?: string; messageId?: string }) {
    if (!session.threadId || !session.messageId) return undefined;
    const channel = await this.client.channels.fetch(session.threadId).catch(() => undefined);
    if (!channel?.isThread?.() || !channel.messages?.fetch) return undefined;
    return channel.messages.fetch(session.messageId).catch(() => undefined);
  }

  async handleRobuxThreadMessage(message: import("discord.js").Message): Promise<void> {
    if (!message.guildId || message.author.bot || !message.channel.isThread?.()) return;
    const session = [...this.robuxSessions.values()].find((item) =>
      item.guildId === message.guildId &&
      item.userId === message.author.id &&
      item.threadId === message.channelId &&
      item.manualFlow &&
      item.manualAwaitingUsername
    );
    if (!session) return;
    if (session.expiresAt < Date.now()) {
      session.manualAwaitingUsername = false;
      if (message.channel.isSendable()) await message.channel.send({ content: `${message.author}, esta compra manual expirou. Abra uma nova compra pelo painel.`, allowedMentions: { users: [message.author.id] } }).catch(() => undefined);
      return;
    }

    const username = String(message.content || "").trim().replace(/^@/, "");
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
      if (message.channel.isSendable()) await message.channel.send({ content: `${message.author}, envie somente um **username Roblox válido** (3 a 20 caracteres, letras, números ou _).`, allowedMentions: { users: [message.author.id] } }).catch(() => undefined);
      return;
    }

    const settings = this.robux.settings(message.guildId);
    const requested = session.manualRequestedRobux;
    if (!requested || requested < settings.minRobux || requested > settings.maxRobux || !session.selected) {
      session.manualAwaitingUsername = false;
      if (message.channel.isSendable()) await message.channel.send({ content: `${message.author}, os dados desta compra não estão mais válidos. Abra uma nova compra pelo painel.`, allowedMentions: { users: [message.author.id] } }).catch(() => undefined);
      return;
    }

    session.robloxUser = { id: 0, name: username, displayName: username };
    session.manualAwaitingUsername = false;
    session.expiresAt = Date.now() + 15 * 60_000;
    const calc = this.robux.calculationFromRobux(message.guildId, requested);
    const referenceText = session.manualReferenceUrl ? `\n**Link informado:** ${session.manualReferenceUrl}` : "\n**Link:** não informado; poderá ser solicitado após o pagamento.";
    const purchaseMessage = await this.robuxThreadMessage(session);
    await purchaseMessage?.edit({ ...this.robuxThreadPayload(
      message.guildId,
      message.author.id,
      `${this.emojis.text("robux_manual", message.guildId)} Compra manual preparada`,
      `**Roblox:** ${username}\n**Quantidade:** ${requested.toLocaleString("pt-BR")} Robux\n**Game Pass recomendada:** ${calc.gamepassPrice.toLocaleString("pt-BR")} Robux\n**Valor:** ${formatMoney(calc.amountCents)}${referenceText}\n\nO username foi registrado manualmente. Escolha a forma de pagamento para continuar.`,
      [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(message.guildId, `robux:payment:${message.author.id}`, "Escolher pagamento", "payment", ButtonStyle.Success))],
      false
    ), flags: MessageFlags.IsComponentsV2 } as never).catch(() => undefined);
  }

  private async refreshRobuxPanel(guildId: string): Promise<void> {
    const s = this.robux.settings(guildId);
    if (!s.panelChannelId || !s.panelMessageId) return;
    const channel = await this.client.channels.fetch(s.panelChannelId).catch(() => undefined);
    if (!(channel instanceof TextChannel)) return;
    try {
      const result = await this.upsertRobuxPanel(guildId, channel, s.panelMessageId);
      if (result.message.id !== s.panelMessageId) this.robux.updateSettings(guildId, { panelMessageId: result.message.id });
    } catch (error) {
      this.logger.warn("Não foi possível atualizar o painel Robux publicado.", { guildId, channelId: s.panelChannelId, error: String(error) });
    }
  }

  private robuxSellerOrderId(customId: string, action: "confirm-payment" | "auto-deliver" | "confirm-delivery"): string {
    const prefix = `robux:seller-${action}:`;
    if (!customId.startsWith(prefix)) return "";
    const orderId = customId.slice(prefix.length).trim();
    // IDs do pedido são gerados internamente com o prefixo RBX_. Usar slice pelo
    // prefixo evita depender da posição de split(":"), que foi a causa do
    // "Pedido Robux inválido" nos botões da equipe.
    return /^RBX_[A-Za-z0-9_-]{4,80}$/.test(orderId) ? orderId : "";
  }

  private robuxQrAttachment(dataUrl?: string): AttachmentBuilder | undefined {
    if (!dataUrl) return undefined;
    const match = dataUrl.match(/^data:image\/(?:png|jpeg);base64,(.+)$/i);
    if (!match) return undefined;
    try { return new AttachmentBuilder(Buffer.from(match[1]!, "base64"), { name: "robux-pix.png" }); } catch { return undefined; }
  }

  private async robuxCheckoutPayload(guildId: string, userId: string, order: import("../services/robux.js").RobuxOrder, includeQrMedia = true) {
    let qrDataUrl = order.qrCodeDataUrl || "";
    if (!qrDataUrl && order.pixCode) {
      try { qrDataUrl = await QRCode.toDataURL(order.pixCode, { width: 640, margin: 2 }); } catch { qrDataUrl = ""; }
    }
    const qr = this.robuxQrAttachment(qrDataUrl);
    const avatarUrl = await this.robux.robloxAvatarUrl(order.robloxUserId);
    const pixKey = this.payments.paymentKey(guildId, order.provider);
    const pixKeyBlock = pixKey ? `**Chave PIX:** \`${truncate(pixKey.replace(/`/g, ""), 220)}\`\n` : "";
    const pixBlock = order.pixCode ? `### PIX copia e cola\n\`\`\`\n${truncate(order.pixCode, 1500)}\n\`\`\`` : "O método selecionado não retornou um código PIX copia e cola.";
    const statusText = order.paymentConfirmationRequestedAt
      ? "**Confirmação enviada.** A equipe recebeu o pedido de conferência. Assim que o vendedor confirmar o PIX, esta mesma página avança automaticamente para a Game Pass."
      : order.provider === "MANUAL_PIX"
        ? "Depois de pagar, clique em **Confirmar compra**. O vendedor confere o PIX e libera a etapa da Game Pass."
        : "Depois de pagar, clique em **Verificar pagamento**. O bot também consulta gateways automáticos em segundo plano.";
    const payer = order.provider === "IMAP_PIX"
      ? `\nPagador: **${order.payerFullName || "não informado"}**\nBanco usado no PIX: **${order.payerBankName || "não informado"}**${order.payerDocument ? `\nCPF: **•••${order.payerDocument.slice(-4)}**` : ""}`
      : "";
    const identityPending = Boolean(order.awaitingRobloxIdentity || order.robloxUserId <= 0);
    const accountText = identityPending ? "será informado após o pagamento" : `${order.robloxDisplayName || order.robloxUsername} (@${order.robloxUsername})`;
    const gamepassText = order.gamepassId > 0 ? `${order.gamepassName} • ${order.gamepassPrice.toLocaleString("pt-BR")} Robux` : `pendente • recomendada: ${order.gamepassPrice.toLocaleString("pt-BR")} Robux`;
    const checkoutText = `## ${this.emojis.text("payment", guildId)} Checkout Robux\n**Pedido:** ${order.id}\n**Conta Roblox:** ${accountText}\n**Você recebe:** ${order.requestedRobux.toLocaleString("pt-BR")} Robux\n**Game Pass:** ${gamepassText}\n**Total:** ${formatMoney(order.amountCents)}\n**Método:** ${order.provider.replaceAll("_", " ")}${payer}\n${pixKeyBlock}\n${pixBlock}\n\n${statusText}\n\n${qr ? (includeQrMedia ? "O QR Code PIX aparece abaixo nesta cobrança." : "O QR Code PIX será enviado em uma mensagem separada logo abaixo.") : ""}`;

    // Discord Components V2 exige `accessory` em todo Section (type 9).
    // No fluxo manual o usuário Roblox ainda pode estar pendente, portanto não
    // existe avatar para usar como Thumbnail. Nesse caso usamos Text Display
    // diretamente; enviar Section sem accessory faz a API rejeitar a mensagem.
    const components: Record<string, unknown>[] = [];
    if (avatarUrl && !identityPending) {
      components.push({
        type: 9,
        components: [{ type: 10, content: checkoutText }],
        accessory: { type: 11, media: { url: avatarUrl }, description: `Avatar Roblox de ${order.robloxUsername}` }
      });
    } else {
      components.push({ type: 10, content: checkoutText });
    }

    if (qr && includeQrMedia) {
      components.push(
        new MediaGalleryBuilder()
          .addItems(new MediaGalleryItemBuilder().setURL("attachment://robux-pix.png").setDescription(`QR Code PIX • ${order.id}`))
          .toJSON() as unknown as Record<string, unknown>
      );
    }
    components.push({ type: 14, divider: true, spacing: 1 });

    const paymentButtons = [
      this.views.button(guildId, `robux:confirm-payment:${userId}:${order.id}`, order.provider === "MANUAL_PIX" ? "Confirmar compra" : "Verificar pagamento", "approve", ButtonStyle.Success).toJSON(),
      this.views.button(guildId, `robux:back-from-checkout:${userId}:${order.id}`, "Voltar", "back", ButtonStyle.Secondary, order.paymentStatus === "paid").toJSON(),
      this.views.button(guildId, `robux:close:${userId}`, "Fechar compra", "delete", ButtonStyle.Danger).toJSON()
    ];
    if (order.pixCode) paymentButtons.unshift(this.views.button(guildId, `robux:pix-code:${userId}:${order.id}`, "PIX copia e cola", "payment", ButtonStyle.Secondary).toJSON());
    if (pixKey) paymentButtons.unshift(this.views.button(guildId, `robux:pix-key:${userId}:${order.id}`, "Chave PIX", "copy", ButtonStyle.Secondary).toJSON());
    components.push({ type: 1, components: paymentButtons.slice(0, 5) });

    if (order.paymentConfirmationRequestedAt && order.paymentStatus !== "paid") {
      components.push({ type: 1, components: [this.views.button(guildId, `robux:seller-confirm-payment:${order.id}`, "Confirmar PIX • vendedor", "approve", ButtonStyle.Primary).toJSON()] });
    }
    return checkedDiscordPayload({ components: [{ type: 17, accent_color: 0x3155ff, components }], files: qr && includeQrMedia ? [qr] : [], attachments: [], flags: MessageFlags.IsComponentsV2 }, `checkout robux ${order.id}`);
  }

  private robuxDeliveryPayload(guildId: string, userId: string, order: import("../services/robux.js").RobuxOrder) {
    const settings = this.robux.settings(guildId);
    const delivered = order.status === "DELIVERED";
    const processing = order.status === "DELIVERING";
    const display = order.robloxDisplayName || order.robloxUsername;
    const url = order.gamepassUrlOverride || (order.gamepassId > 0 ? this.robux.gamepassUrl(order.gamepassId) : "");
    const awaitingIdentity = Boolean(order.awaitingRobloxIdentity);
    const awaitingLink = Boolean(order.awaitingGamepassLink || !url);
    const modeLabel = settings.deliveryMode === "COOKIE_AUTO" ? "automática" : settings.deliveryMode === "WEBHOOK" ? "integração" : settings.deliveryMode === "ASSISTED" ? "assistida" : "manual";
    const recommendedGamepassPrice = this.robux.recommendedGamepassPrice(guildId, order.requestedRobux);

    let body = `**Pedido:** ${order.id}\n**Roblox:** ${display} (@${order.robloxUsername})\n**Robux:** ${order.requestedRobux.toLocaleString("pt-BR")}\n**Valor:** ${formatMoney(order.amountCents)}\n**Entrega:** ${modeLabel}`;
    if (delivered) body += `\n\n✅ **Entrega concluída.** O comprador recebeu o extrato por DM.`;
    else if (processing) body += `\n\n⏳ A conta de entrega está comprando a Game Pass. Não clique novamente enquanto o processamento estiver ativo.`;
    else if (awaitingIdentity) body += `\n\n### Dados Roblox necessários\n<@${userId}>, envie **uma destas opções** neste tópico:\n• seu **username Roblox**; ou\n• o **link completo da Game Pass**.\n\nPara este pedido de **${order.requestedRobux.toLocaleString("pt-BR")} Robux**, a Game Pass deve custar **${recommendedGamepassPrice.toLocaleString("pt-BR")} Robux**. Considerando a taxa de 30%, o recebimento fica em cerca de **${order.requestedRobux.toLocaleString("pt-BR")} Robux**.\n\nA compra já está paga. O fluxo continua assim que os dados forem registrados.`;
    else if (awaitingLink) body += `\n\n### Game Pass necessária\n<@${userId}>, crie ou ajuste sua Game Pass para **${recommendedGamepassPrice.toLocaleString("pt-BR")} Robux** e depois envie **o link completo** neste tópico.\n\nO pedido é de **${order.requestedRobux.toLocaleString("pt-BR")} Robux**; considerando a taxa de 30% do Roblox, esse é o preço recomendado para o cliente receber aproximadamente a quantidade comprada. Assim que o link for validado, a página será atualizada.`;
    else if (settings.deliveryMode === "MANUAL") body += `\n\n**Vendedor:** abra a Game Pass, compre no Roblox e depois confirme a entrega.`;
    else if (settings.deliveryMode === "ASSISTED") body += `\n\n**Vendedor:** o pagamento está confirmado. Você pode mandar o bot comprar a Game Pass ou abrir o link e concluir manualmente.`;
    else if (settings.deliveryMode === "COOKIE_AUTO") body += `\n\nA compra automática não foi concluída. Você pode tentar novamente ou concluir manualmente pelo link abaixo.`;
    else body += `\n\nA integração não concluiu a entrega. Use o link abaixo para finalizar manualmente, se necessário.`;
    if (order.error && !delivered) body += `\n\n**Observação:** ${truncate(order.error, 500)}`;

    const rows: ActionRowBuilder<ButtonBuilder>[] = [];
    if (!delivered && !processing && !awaitingLink) {
      const row = new ActionRowBuilder<ButtonBuilder>();
      if (url) row.addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(url).setLabel(order.gamepassId > 0 ? "Abrir Game Pass no Roblox" : "Abrir link Roblox informado"));
      if ((settings.deliveryMode === "ASSISTED" || settings.deliveryMode === "COOKIE_AUTO") && this.robux.hasCookie(guildId)) {
        row.addComponents(this.views.button(guildId, `robux:seller-auto-deliver:${order.id}`, settings.deliveryMode === "ASSISTED" ? "Comprar automaticamente" : "Tentar automático", "automation", ButtonStyle.Primary));
      }
      row.addComponents(this.views.button(guildId, `robux:seller-confirm-delivery:${order.id}`, "Confirmar entrega • vendedor", "success", ButtonStyle.Success));
      rows.push(row);
    } else if (delivered && url) {
      rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(url).setLabel("Ver Game Pass")));
    }
    return this.robuxThreadPayload(guildId, userId, delivered ? "Entrega concluída" : awaitingIdentity ? "Envie seus dados Roblox" : awaitingLink ? "Game Pass necessária" : processing ? "Entrega em andamento" : "Pagamento confirmado", body, rows, false);
  }

  private async robuxButton(i: ButtonInteraction, id: string, gid: string) {
    const s = this.robux.settings(gid);
    if (id === "robux:calc") {
      if (!s.calculatorEnabled) throw new Error("A calculadora de Robux está desativada.");
      return i.reply({ ...this.robuxCalcMenu(gid), flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral } as never);
    }
    if (id === "robux:calc:money") return i.showModal(modal("modal:robux-public:calculate-money", "Calcular por valor em reais", [input("value", "Valor em reais", "", TextInputStyle.Short, true, 30, "Ex.: 5,00")]));
    if (id === "robux:calc:robux") return i.showModal(modal("modal:robux-public:calculate-robux", "Calcular por quantidade de Robux", [input("value", "Quantidade de Robux", "", TextInputStyle.Short, true, 30, "Ex.: 150")]));
    if (id.startsWith("robux:close:")) {
      const expected = id.split(":")[2];
      if (expected !== i.user.id) throw new Error("Esta compra pertence a outro usuário.");

      const sessionKey = this.robuxSessionKey(gid, i.user.id);
      const session = this.robuxSessions.get(sessionKey);
      await i.deferReply({ flags: MessageFlags.Ephemeral });

      // R18.9.42: fecha o tópico de verdade e espera a API do Discord confirmar.
      // O fluxo antigo disparava setArchived() dentro de um setTimeout e engolia
      // qualquer erro, então a interface dizia “será arquivado” mesmo quando o
      // tópico continuava aberto. Agora usamos o tópico atual (ou o salvo na
      // sessão), tentamos o método normal do discord.js e fazemos fallback pelo
      // REST em caso de objeto/cache stale.
      let thread = i.channel?.isThread?.() ? i.channel : undefined;
      if (!thread && session?.threadId) {
        const candidate = await this.client.channels.fetch(session.threadId).catch(() => undefined);
        if (candidate?.isThread?.()) thread = candidate;
      }

      if (!thread) {
        await i.editReply("Compra encerrada. Não havia um tópico ativo para arquivar.");
        this.robuxSessions.delete(sessionKey);
        return;
      }

      const reason = "Compra Robux encerrada pelo usuário";
      let archived = Boolean(thread.archived);
      if (!archived) {
        try {
          const updated = await thread.setArchived(true, reason);
          archived = Boolean(updated.archived);
        } catch (error) {
          this.logger.warn("Falha ao arquivar tópico Robux pelo discord.js; tentando REST.", { guildId: gid, threadId: thread.id, error: String(error) });
        }
      }

      if (!archived) {
        try {
          const updated = await this.client.rest.patch(Routes.channel(thread.id), { body: { archived: true }, reason }) as { archived?: boolean };
          archived = updated?.archived !== false;
        } catch (error) {
          this.logger.error("Não foi possível arquivar o tópico Robux.", { guildId: gid, threadId: thread.id, error: String(error) });
          await i.editReply("Não consegui fechar este tópico. Verifique se o bot possui permissão para gerenciar o tópico e tente novamente.");
          return;
        }
      }

      if (!archived) {
        await i.editReply("Não consegui confirmar o fechamento deste tópico. Tente novamente.");
        return;
      }

      this.robuxSessions.delete(sessionKey);
      await i.editReply("Compra encerrada. O tópico foi arquivado.").catch(() => undefined);
      return;
    }
    if (id.startsWith("robux:back-gamepasses:")) {
      const expected = id.split(":")[2];
      if (expected !== i.user.id) throw new Error("Esta compra pertence a outro usuário.");
      const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
      if (!session || session.expiresAt < Date.now()) throw new Error("Sua consulta expirou. Clique em Comprar Robux novamente.");
      session.selected = undefined; session.selectedProvider = undefined; session.expiresAt = Date.now() + 10 * 60_000;
      await this.updateV2(i, this.robuxGamepassMenu(gid, session));
      return;
    }
    if (id.startsWith("robux:seller-confirm-payment:")) {
      const orderId = this.robuxSellerOrderId(id, "confirm-payment");
      if (!orderId) return i.reply({ content: "Pedido Robux inválido. Atualize a cobrança e tente novamente.", flags: MessageFlags.Ephemeral });
      try { this.requireRobuxSeller(i); }
      catch { return i.reply({ content: "Somente o dono, administradores ou a equipe com permissão de pagamentos podem confirmar o PIX.", flags: MessageFlags.Ephemeral }); }
      // ACK separado da edição do Components V2. Isso impede o Discord de exibir
      // “Esta interação falhou” enquanto o serviço confirma o pedido e monta a próxima página.
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const order = await this.robux.markPaidManual(orderId);
        await this.refreshRobuxOrderMessage(order);
        await i.editReply(`✅ PIX confirmado. O pedido **${order.id}** avançou para a etapa final de entrega.`);
      } catch (error) {
        await i.editReply(`❌ Não foi possível confirmar o PIX: ${truncate(error instanceof Error ? error.message : String(error), 1200)}`);
      }
      return;
    }
    if (id.startsWith("robux:seller-auto-deliver:")) {
      this.requireRobuxSeller(i);
      const orderId = this.robuxSellerOrderId(id, "auto-deliver");
      if (!orderId) throw new Error("Pedido Robux inválido. Atualize a cobrança e tente novamente.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const order = await this.robux.deliverWithConfiguredAccount(orderId);
      await this.refreshRobuxOrderMessage(order);
      await i.editReply(order.status === "DELIVERED" ? `✅ Game Pass do pedido **${order.id}** comprada e entrega concluída.` : `⚠️ A compra automática não foi concluída. A página foi atualizada com o modo manual de segurança.`);
      return;
    }
    if (id.startsWith("robux:seller-confirm-delivery:")) {
      this.requireRobuxSeller(i);
      const orderId = this.robuxSellerOrderId(id, "confirm-delivery");
      if (!orderId) throw new Error("Pedido Robux inválido. Atualize a cobrança e tente novamente.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const order = await this.robux.markDelivered(orderId);
      await this.refreshRobuxOrderMessage(order);
      await i.editReply(`✅ Entrega do pedido **${order.id}** confirmada. O cliente recebeu o extrato por DM.`);
      return;
    }
    if (id.startsWith("robux:pix-key:")) {
      const [, , expected, orderId] = id.split(":");
      if (expected !== i.user.id || !orderId) return i.reply({ content: "Esta compra pertence a outro usuário.", flags: MessageFlags.Ephemeral });
      const order = this.robux.getOrder(orderId);
      if (!order || order.guildId !== gid || order.discordUserId !== i.user.id) return i.reply({ content: "Pedido Robux não encontrado ou indisponível.", flags: MessageFlags.Ephemeral });
      const key = this.payments.paymentKey(gid, order.provider);
      if (!key) return i.reply({ content: "Este método não usa uma chave PIX fixa. Use o PIX copia e cola da cobrança.", flags: MessageFlags.Ephemeral });
      return i.reply({ content: `**Chave PIX**\n\`\`\`\n${truncate(key, 1800)}\n\`\`\``, flags: MessageFlags.Ephemeral, allowedMentions: { parse: [] } });
    }
    if (id.startsWith("robux:pix-code:")) {
      const [, , expected, orderId] = id.split(":");
      if (expected !== i.user.id || !orderId) return i.reply({ content: "Esta compra pertence a outro usuário.", flags: MessageFlags.Ephemeral });
      const order = this.robux.getOrder(orderId);
      if (!order || order.guildId !== gid || order.discordUserId !== i.user.id) return i.reply({ content: "Pedido Robux não encontrado ou indisponível.", flags: MessageFlags.Ephemeral });
      if (!order.pixCode) return i.reply({ content: "O código PIX ainda não está disponível.", flags: MessageFlags.Ephemeral });
      return i.reply({ content: `**PIX copia e cola**\n\`\`\`\n${truncate(order.pixCode, 1800)}\n\`\`\``, flags: MessageFlags.Ephemeral, allowedMentions: { parse: [] } });
    }
    if (id.startsWith("robux:confirm-payment:")) {
      const [, , expected, orderId] = id.split(":");
      if (expected !== i.user.id || !orderId) return i.reply({ content: "Esta compra pertence a outro usuário.", flags: MessageFlags.Ephemeral });
      // A confirmação responde de forma efêmera e a página é atualizada separadamente.
      // Assim a edição de uma mensagem Components V2 nunca bloqueia o ACK do botão.
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const result = await this.robux.confirmPayment(orderId, i.user.id);
        await this.refreshRobuxOrderMessage(result.order);
        if (result.confirmed) {
          await i.editReply("✅ Pagamento confirmado. A página avançou para a finalização.");
        } else {
          await i.editReply(result.manualReview ? "✅ Confirmação enviada. Agora o vendedor confere o PIX e libera a etapa final." : `O gateway ainda não confirmou o pagamento. Status: **${result.order.paymentStatus}**.`);
        }
      } catch (error) {
        await i.editReply(`❌ Não foi possível verificar o pagamento: ${truncate(error instanceof Error ? error.message : String(error), 1200)}`);
      }
      return;
    }
    if (id.startsWith("robux:back-from-checkout:")) {
      const [, , expected, orderId] = id.split(":");
      if (expected !== i.user.id || !orderId) throw new Error("Esta compra pertence a outro usuário.");
      const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
      if (!session || session.expiresAt < Date.now()) throw new Error("Sua consulta expirou. Clique em Comprar Robux novamente.");
      await i.deferUpdate();
      await this.robux.cancelPending(orderId, i.user.id);
      session.selected = undefined; session.selectedProvider = undefined; session.expiresAt = Date.now() + 10 * 60_000;
      await i.message.edit({ ...this.robuxGamepassMenu(gid, session), flags: MessageFlags.IsComponentsV2, attachments: [] } as never);
      return;
    }
    if (id === "robux:buy") {
      if (!s.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      return i.showModal(modal("modal:robux-public:lookup", "Comprar Robux", [input("username", "Usuário Roblox", "", TextInputStyle.Short, true, 20, "Seu username do Roblox")]));
    }
    if (id === "robux:manual-quick") {
      if (!s.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      if (!s.manualShortcutEnabled) throw new Error("A compra manual rápida está desativada pela loja.");
      return i.showModal(modal("modal:robux-public:manual-quick", "Compra Robux • manual", [
        input("amount", "Quantidade de Robux", "", TextInputStyle.Short, true, 12, "Ex.: 100"),
        input("link", "Link Game Pass ou jogo (opcional)", "", TextInputStyle.Short, false, 1000, "https://www.roblox.com/...")
      ]));
    }
    if (id === "robux:manual") {
      if (!s.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      return i.showModal(modal("modal:robux-public:manual", "Continuar sem buscar", [
        input("amount", "Quantidade de Robux", "", TextInputStyle.Short, true, 12, "Ex.: 100"),
        input("link", "Game Pass (opcional agora)", "", TextInputStyle.Short, false, 1000, "Pode enviar depois do pagamento")
      ]));
    }
    if (id.startsWith("robux:payment:")) {
      const expected = id.split(":")[2]; if (expected !== i.user.id) throw new Error("Esta compra pertence a outro usuário.");
      const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
      if (!session?.selected || session.expiresAt < Date.now()) throw new Error("Sua seleção expirou. Comece novamente.");
      const methods = this.robuxPaymentMethods(gid);
      if (!methods.length) throw new Error("Nenhuma forma de pagamento está configurada para Robux.");
      const select = new StringSelectMenuBuilder().setCustomId(`robux:payment-select:${i.user.id}`).setPlaceholder("Escolha a forma de pagamento").addOptions(methods.slice(0, 25).map((method) => new StringSelectMenuOptionBuilder().setLabel(method.replaceAll("_", " ")).setDescription("Método configurado pela loja").setValue(method).setEmoji(this.emojis.component("payment", gid))));
      const quantityText = session.manualRequestedRobux ? `\nQuantidade: **${session.manualRequestedRobux.toLocaleString("pt-BR")} Robux**` : "";
      const manualPending = Boolean(session.manualFlow && (!session.robloxUser || session.robloxUser.id <= 0));
      const backButton = session.manualFlow
        ? this.views.button(gid, "robux:manual", "Alterar quantidade", "back", ButtonStyle.Secondary)
        : this.views.button(gid, `robux:back-gamepasses:${i.user.id}`, "Voltar", "back", ButtonStyle.Secondary);
      const robloxLine = manualPending ? "**Roblox:** será informado no tópico após o pagamento" : `**Roblox:** ${session.robloxUser?.name ?? "—"}`;
      const gamepassLine = session.selected.id > 0 ? `**Game Pass:** ${session.selected.name}` : "**Game Pass:** poderá ser enviada após o pagamento";
      await this.updateV2(i, this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("payment", gid)} Forma de pagamento`, `${gamepassLine}\n${robloxLine}${quantityText}\nEscolha abaixo uma das formas de pagamento habilitadas pela loja.`, [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select), new ActionRowBuilder<ButtonBuilder>().addComponents(backButton)], false));
      return;
    }
    if (id.startsWith("robux:checkout:")) {
      const expected = id.split(":")[2]; if (expected !== i.user.id) throw new Error("Esta compra pertence a outro usuário.");
      const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
      if (!session?.selected || !session.selectedProvider || !session.robloxUser || session.expiresAt < Date.now()) throw new Error("Selecione uma gamepass e uma forma de pagamento antes de continuar.");
      // PIX manual não precisa pedir e-mail, CPF ou CNPJ do comprador.
      if (session.selectedProvider === "MANUAL_PIX") {
        await i.deferReply({ flags: MessageFlags.Ephemeral });
        if (session.checkoutCreating) { await i.editReply("A cobrança já está sendo criada. Aguarde a página do tópico atualizar."); return; }
        if (session.pendingOrderId) {
          const existing = this.robux.getOrder(session.pendingOrderId);
          if (existing && existing.status === "PENDING_PAYMENT") {
            const published = await this.refreshRobuxOrderMessage(existing);
            await i.editReply(published ? `O pedido **${existing.id}** já existe. A cobrança existente foi aberta no tópico.` : `O pedido **${existing.id}** já existe, mas não consegui publicar a cobrança no tópico. Tente novamente ou avise a equipe.`);
            return;
          }
        }
        session.checkoutCreating = true;
        try {
          const order = await this.robux.createOrder({ guildId: gid, discordUserId: i.user.id, discordUsername: i.user.username, robloxUser: session.robloxUser, gamepass: session.selected, provider: session.selectedProvider, customerName: i.user.displayName, email: "", document: "", threadId: session.threadId, messageId: session.messageId, requestedRobuxOverride: session.manualRequestedRobux, referenceUrl: session.manualReferenceUrl });
          session.pendingOrderId = order.id;
          const published = await this.refreshRobuxOrderMessage(order);
          await i.editReply(published ? `Pedido **${order.id}** criado. A cobrança está pronta no tópico da compra.` : `Pedido **${order.id}** criado, mas a cobrança não pôde ser publicada no tópico. Nenhum segundo pedido será criado; tente novamente para reabrir esta cobrança.`);
        } finally { session.checkoutCreating = false; }
        return;
      }
      if (session.selectedProvider === "IMAP_PIX") {
        return i.showModal(modal("modal:robux-public:checkout-imap", "Finalizar PIX • IMAP", [
          input("name", "Nome completo de quem fará o PIX", "", TextInputStyle.Short, true, 120, "Nome e sobrenome"),
          input("bank", "Banco usado para pagar", "", TextInputStyle.Short, true, 80, "Ex.: Nubank, Inter, Itaú"),
          input("document", "CPF (opcional)", "", TextInputStyle.Short, false, 14, "Somente números")
        ]));
      }
      return i.showModal(modal("modal:robux-public:checkout", "Finalizar pedido Robux", [
        input("name", "Nome do pagador", i.user.displayName, TextInputStyle.Short, true, 100),
        input("email", "E-mail do pagador", "", TextInputStyle.Short, true, 150, "email@exemplo.com"),
        input("document", "CPF/CNPJ (somente se o gateway exigir)", "", TextInputStyle.Short, false, 20)
      ]));
    }
  }

  private async robuxPublicSelect(i: StringSelectMenuInteraction, gid: string) {
    const id = i.customId;
    const expected = id.split(":").pop();
    if (expected !== i.user.id) throw new Error("Este menu pertence a outro usuário.");
    const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
    if (!session || session.expiresAt < Date.now()) throw new Error("Sua consulta expirou. Clique em Comprar Robux novamente.");
    if (id.startsWith("robux:payment-select:")) {
      const provider = i.values[0] as PaymentProviderName;
      if (!this.robuxPaymentMethods(gid).includes(provider)) throw new Error("Esta forma de pagamento não está mais disponível.");
      session.selectedProvider = provider; session.expiresAt = Date.now() + 10 * 60_000;
      const calc = session.manualRequestedRobux
        ? this.robux.calculationFromRobux(gid, session.manualRequestedRobux)
        : session.selected ? this.robux.calculationFromRobux(gid, Math.floor(session.selected.price * 0.7)) : undefined;
      const selectedBack = session.manualFlow
        ? this.views.button(gid, "robux:manual", "Alterar quantidade", "back", ButtonStyle.Secondary)
        : this.views.button(gid, `robux:back-gamepasses:${i.user.id}`, "Voltar", "back", ButtonStyle.Secondary);
      const identityText = session.manualFlow && session.robloxUser?.id === 0 ? "\nDados Roblox: **serão enviados após o pagamento**" : "";
      await this.updateV2(i, this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("payment", gid)} Pagamento selecionado`, `Método: **${provider.replaceAll("_", " ")}**\n${session.selected ? `Gamepass: **${session.selected.id > 0 ? session.selected.name : "pendente"}**\nRobux estimados: **${calc?.requestedRobux.toLocaleString("pt-BR")}**\nValor: **${formatMoney(calc?.amountCents ?? 0)}**` : ""}${identityText}\n\nConfira os dados e finalize o pagamento.`, [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `robux:checkout:${i.user.id}`, "Finalizar pagamento", "payment", ButtonStyle.Success), this.views.button(gid, `robux:payment:${i.user.id}`, "Trocar método", "refresh", ButtonStyle.Secondary), selectedBack)], false));
      return;
    }
    if (!id.startsWith("robux:gamepass:")) throw new Error("Menu Robux inválido.");
    const gamepass = session.gamepasses.find((item) => String(item.id) === i.values[0]);
    if (!gamepass) throw new Error("Gamepass não encontrada nesta consulta.");
    session.selected = gamepass; session.selectedProvider = undefined; session.expiresAt = Date.now() + 10 * 60_000;
    const estimated = Math.floor(gamepass.price * 0.7);
    if (estimated < this.robux.settings(gid).minRobux || estimated > this.robux.settings(gid).maxRobux) throw new Error("A gamepass escolhida está fora dos limites atuais da loja.");
    const calc = this.robux.calculationFromRobux(gid, estimated);
    await this.updateV2(i, this.robuxThreadPayload(gid, i.user.id, `Gamepass selecionada`, `Roblox: **${session.robloxUser?.name ?? "—"}**\nGamepass: **${gamepass.name}**\nPreço atual: **${gamepass.price.toLocaleString("pt-BR")} Robux**\nRecebimento estimado: **${estimated.toLocaleString("pt-BR")} Robux**\nValor da compra: **${formatMoney(calc.amountCents)}**`, [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `robux:payment:${i.user.id}`, "Escolher pagamento", "payment", ButtonStyle.Success), this.views.button(gid, `robux:back-gamepasses:${i.user.id}`, "Voltar", "back", ButtonStyle.Secondary), this.views.button(gid, "robux:buy", "Trocar usuário", "refresh", ButtonStyle.Secondary))], false));
    return;
  }

  private async fail(interaction: { id?: string; guildId?: string | null; customId?: string; commandName?: string; replied: boolean; deferred: boolean; reply: Function; followUp: Function; editReply: Function }, error: unknown) {
    const message = error instanceof Error ? error.message : "Falha inesperada.";
    this.logger.error("Falha em interação.", error);
    if (interaction.guildId) this.db.errorAudit(interaction.guildId, "INTERACTION_ERROR", { interactionId: interaction.id ?? "", customId: interaction.customId ?? "", commandName: interaction.commandName ?? "", error: message });

    // Componentes de ticket podem permanecer abertos no Discord por bastante tempo.
    // Se uma referência antiga for impossível de recuperar com segurança (ex.: vários
    // painéis foram recriados), não exibimos um erro morto. Entregamos a central
    // atual para o administrador selecionar novamente o painel correto.
    const staleTicketReference = Boolean(
      interaction.guildId &&
      interaction.customId?.startsWith("admin:ticket:") &&
      /(?:Painel de ticket|Opção de atendimento|Opção não encontrada|Campo do painel).*não encontrad/i.test(message)
    );
    if (staleTicketReference && interaction.guildId) {
      const recovery = {
        content: "A tela de ticket que você clicou estava desatualizada. A configuração atual foi recarregada abaixo; selecione o painel e continue sem recriar nada.",
        ...this.views.ticketPanelsHome(interaction.guildId)
      };
      try {
        if (interaction.deferred) await interaction.editReply(recovery);
        else if (interaction.replied) await interaction.followUp({ ...recovery, flags: MessageFlags.Ephemeral });
        else await interaction.reply({ ...recovery, flags: MessageFlags.Ephemeral });
        return;
      } catch (recoveryError) {
        this.logger.warn("Não foi possível recarregar automaticamente a central de tickets.", { interactionId: interaction.id, error: String(recoveryError) });
      }
    }

    const content = `❌ ${truncate(message, 1800)}`.trim();
    try {
      if (interaction.deferred) await interaction.editReply({ content });
      else if (interaction.replied) await interaction.followUp({ content, flags: MessageFlags.Ephemeral });
      else await interaction.reply({ content, flags: MessageFlags.Ephemeral });
    }
    catch (replyError) { this.logger.warn("A interação expirou antes de receber a mensagem de erro.", { interactionId: interaction.id, error: String(replyError) }); }
  }

  private async route(interaction: import("discord.js").Interaction) {
    // Sincronização visual nunca bloqueia compras, pagamentos, tickets ou
    // outros fluxos públicos. Somente telas administrativas aguardam os emojis.
    const visualSyncAdminOnly = interaction.isChatInputCommand()
      ? interaction.commandName === "emojis"
      : "customId" in interaction && typeof interaction.customId === "string" && interaction.customId.startsWith("modal:emoji");
    if (this.emojis.status.syncing && visualSyncAdminOnly && interaction.isRepliable()) {
      await interaction.reply({ content: "A aplicação está finalizando a sincronização dos componentes visuais. Tente novamente em alguns segundos.", flags: MessageFlags.Ephemeral }).catch(() => undefined);
      return;
    }
    if (interaction.isMessageContextMenuCommand()) return this.contextMenu(interaction);
    if (interaction.isChatInputCommand()) return this.command(interaction);
    if (interaction.isButton()) {
      const target = interaction.customId.startsWith("admin:") && interaction.guildId ? this.adminInteraction(interaction, interaction.guildId) : interaction;
      const result = await this.button(target);
      if (/^admin:(?:product:(?:toggle|field-toggle|field-delete-confirm|delete-confirm)|stock:(?:unique|clear-confirm)|ticket:(?:delete|option-delete|field-delete)|message:links-clear|emoji:(?:set|reset))/.test(interaction.customId)) this.schedulePublishedRefresh();
      return result;
    }
    if (interaction.isStringSelectMenu()) {
      const target = interaction.customId.startsWith("admin:") && interaction.guildId ? this.adminInteraction(interaction, interaction.guildId) : interaction;
      const result = await this.select(target);
      if (/^admin:(?:product:(?:emoji-select|field-emoji-select)|ticket:emoji-select|ticket:option-emoji-select|emoji:asset-select)/.test(interaction.customId)) this.schedulePublishedRefresh();
      return result;
    }
    if (interaction.isChannelSelectMenu()) return this.channelSelect(interaction.customId.startsWith("admin:") && interaction.guildId ? this.adminInteraction(interaction, interaction.guildId) : interaction);
    if (interaction.isRoleSelectMenu()) return this.roleSelect(interaction.customId.startsWith("admin:") && interaction.guildId ? this.adminInteraction(interaction, interaction.guildId) : interaction);
    if (interaction.isUserSelectMenu()) return this.userSelect(interaction.customId.startsWith("admin:") && interaction.guildId ? this.adminInteraction(interaction, interaction.guildId) : interaction);
    if (interaction.isModalSubmit()) {
      const result = await this.modal(interaction);
      if (/^modal:(?:product:|stock:|ticket:(?:create|basic|option-add|option-edit|field-add|field-edit)|message:|brand:edit|store:edit)/.test(interaction.customId)) this.schedulePublishedRefresh();
      return result;
    }
  }

  private schedulePublishedRefresh(): void {
    setTimeout(() => void this.refreshPublishedMessages().catch((error) => this.logger.warn("Falha ao atualizar publicações automaticamente.", error)), 300).unref?.();
  }

  private member(interaction: { member: unknown }): GuildMember {
    if (!(interaction.member instanceof GuildMember)) throw new Error("Membro do servidor indisponível.");
    return interaction.member;
  }
  private isAdmin(interaction: { guildId: string | null; member: unknown; user: { id: string } }): boolean {
    if (this.config.ownerIds.includes(interaction.user.id)) return true;
    if (!interaction.guildId || !(interaction.member instanceof GuildMember)) return false;
    return this.permissions.has(interaction.member, "ADMIN");
  }
  private requireAdmin(interaction: { guildId: string | null; member: unknown; user: { id: string } }) {
    if (!interaction.guildId) throw new Error("Use esta função dentro de um servidor.");
    this.permissions.require(this.member(interaction), "ADMIN");
  }
  private requireScope(interaction: { guildId: string | null; member: unknown; user: { id: string } }, scope: import("../types.js").PermissionScope) {
    if (!interaction.guildId) throw new Error("Use esta função dentro de um servidor.");
    this.permissions.require(this.member(interaction), scope);
  }

  private adminScopeFor(id: string): import("../types.js").PermissionScope {
    // Os modais de imagem por URL mantêm o mesmo escopo da área que os abriu.
    // Isso evita exigir ADMIN de vendedores/atendentes que possuem apenas o
    // escopo delegado de Produtos ou Tickets.
    if (/^modal:image-url:(?:product-image|product-banner)/.test(id)) return "PRODUCTS";
    if (/^modal:image-url:(?:ticket-banner|ticket-thumb|stock-request)/.test(id)) return "TICKETS";
    if (/^(?:admin|modal):(?:product|stock:|restock|coupon)/.test(id)) return "PRODUCTS";
    if (/^(?:admin|modal):(?:payment|order|revenue|wallet)/.test(id)) return "PAYMENTS";
    if (/^(?:admin|modal):(?:ticket|stock-request)/.test(id)) return "TICKETS";
    if (/^(?:admin|modal):backup/.test(id)) return "BACKUPS";
    if (/^(?:admin|modal):(?:giveaway|message)/.test(id)) return "ADMIN_COMMANDS";
    if (/^(?:admin|modal):saved-emoji/.test(id)) return "AUTHORIZED";
    if (id === "admin:commands") return "AUTHORIZED";
    return "ADMIN";
  }

  private requireAdminAction(interaction: { guildId: string | null; member: unknown; user: { id: string } }, id: string) {
    if (id === "admin:home" || id === "admin:navigate") {
      if (!this.permissions.hasAnyManagement(this.member(interaction))) throw new Error("Você não possui permissão para abrir o painel.");
      return;
    }
    this.requireScope(interaction, this.adminScopeFor(id));
  }

  private requireRobuxSeller(interaction: { guildId: string | null; member: unknown; user: { id: string } }) {
    if (this.config.ownerIds.includes(interaction.user.id) || this.isAdmin(interaction)) return;
    this.requireScope(interaction, "PAYMENTS");
  }

  private assertZnyProductPrice(guildId: string, cents: number): void {
    const zny = this.db.payments(guildId).znyPay;
    if (zny.enabled && this.payments.walletManagerEnabled() && cents < zny.minOrderCents) {
      throw new Error(`Com o Znypay ativo, o valor mínimo de cada opção é ${formatMoney(zny.minOrderCents)}.`);
    }
  }

  private async contextMenu(interaction: MessageContextMenuCommandInteraction) {
    if (!interaction.guildId) throw new Error("Use esta ação dentro de um servidor.");
    this.requireAdmin(interaction);
    const messageId = interaction.targetMessage.id;

    if (interaction.commandName === "Editar Produto" || interaction.commandName === "Gerenciar Estoque") {
      const product = Object.values(this.db.state.products).find((item) => item.publications.some((publication) => publication.messageId === messageId));
      if (!product) throw new Error("Esta mensagem não está vinculada a um produto publicado por esta aplicação.");
      const payload = interaction.commandName === "Gerenciar Estoque"
        ? this.views.productFieldsView(interaction.guildId, product)
        : this.views.productDetail(interaction.guildId, product);
      await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      return;
    }

    if (interaction.commandName === "Editar Painel de Ticket") {
      const panel = Object.values(this.db.state.ticketPanels).find((item) => item.messageId === messageId);
      if (!panel) throw new Error("Esta mensagem não está vinculada a um painel de ticket desta aplicação.");
      await interaction.reply({ ...this.views.ticketPanelDetail(interaction.guildId, panel), flags: MessageFlags.Ephemeral });
    }
  }

  private commandHelpView(guildId: string) {
    const rows = [
      ["/painel", "Abre a central administrativa completa do bot."],
      ["/comandos", "Mostra esta lista com a função de cada comando."],
      ["/meus-pedidos", "Mostra seus pedidos recentes e respectivos status."],
      ["/ticket", "Abre a central de atendimento/tickets configurada."],
      ["/pedir-stock", "Abre o formulário público para solicitar reposição de produto."],
      ["/status", "Mostra o estado dos principais sistemas da aplicação."],
      ["/calcular valor:<valor>", "Calcula Robux, valor em reais e preço recomendado de gamepass."],
      ["/lock", "Tranca o canal atual ou, com a opção all, os canais permitidos."],
      ["/unlock", "Destranca o canal atual ou os canais bloqueados pelo bot."],
      ["/emojis status|instalar|remover", "Gerencia o pacote de emojis da aplicação."],
      ["/salvar-emojis adicionar|listar|copiar|remover", "Gerencia emojis salvos na própria Application."]
    ];
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle(`${this.emojis.text("commands", guildId)} Comandos disponíveis`)
        .setDescription(rows.map(([name, description]) => `**${name}**\n${description}`).join("\n\n"))
        .setFooter({ text: "Alguns comandos exigem permissões administrativas." })],
      components: []
    };
  }

  private voiceAdminView(guildId: string) {
    const state = this.voice.status(guildId);
    const selected = state.channelId ? `<#${state.channelId}>` : "Nenhum canal selecionado";
    const embed = new EmbedBuilder()
      .setColor(state.connected ? 0x23a55a : 0x5865f2)
      .setTitle(`${this.emojis.text("voice", guildId)} Conectar em call`)
      .setDescription("Escolha um canal de voz para manter o bot conectado. A configuração fica salva e é restaurada automaticamente depois de um restart do bot.")
      .addFields(
        { name: "Canal configurado", value: selected, inline: false },
        { name: "Estado", value: state.connected ? `${this.emojis.text("success", guildId)} Conectado` : (state.enabled ? `${this.emojis.text("pending", guildId)} Configurado • aguardando reconexão` : `${this.emojis.text("reject", guildId)} Desativado`), inline: true },
        { name: "Áudio", value: "O bot entra mudo e ensurdecido; ele não grava nem reproduz áudio.", inline: false }
      );
    const picker = new ChannelSelectMenuBuilder()
      .setCustomId("admin:voice:channel-set")
      .setPlaceholder("Escolha o canal de voz")
      .setChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice)
      .setMinValues(1)
      .setMaxValues(1);
    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(picker),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(guildId, "admin:voice:reconnect", "Reconectar", "refresh", ButtonStyle.Primary, !state.channelId),
          this.views.button(guildId, "admin:voice:disconnect", "Sair da call", "reject", ButtonStyle.Danger, !state.enabled && !state.connected),
          this.views.button(guildId, "admin:home", "Voltar", "back", ButtonStyle.Secondary)
        )
      ]
    };
  }

  private async command(interaction: ChatInputCommandInteraction) {
    if (!interaction.guildId) throw new Error("Use este comando dentro de um servidor.");
    if (interaction.commandName === "lock" || interaction.commandName === "unlock") {
      this.requireScope(interaction, "LOCKS");
      if (!interaction.guild || !(interaction.member instanceof GuildMember)) throw new Error("Servidor indisponível.");
      const all = interaction.options.getBoolean("all") ?? false;
      const reason = interaction.options.getString("motivo")?.trim() || (interaction.commandName === "lock" ? "Bloqueio administrativo" : "Desbloqueio administrativo");
      if (all) {
        const count = interaction.commandName === "lock" ? this.locks.eligible(interaction.guild).length : Object.keys(this.db.guild(interaction.guildId).locks.snapshots).length;
        await interaction.reply({
          embeds: [new EmbedBuilder().setColor(interaction.commandName === "lock" ? 0xef4444 : 0x22c55e).setTitle(`${interaction.commandName === "lock" ? "Trancar" : "Destrancar"} todos os canais`).setDescription(`Serão processados **${count}** canais.
Motivo: ${truncate(reason, 500)}

Canais configurados como exceção serão ignorados. Esta ação será registrada.`)],
          components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
            this.views.button(interaction.guildId, `lock:all-confirm:${interaction.commandName}:${encodeURIComponent(reason).slice(0, 50)}`, "Confirmar", interaction.commandName === "lock" ? "lock" : "unlock", interaction.commandName === "lock" ? ButtonStyle.Danger : ButtonStyle.Success),
            this.views.button(interaction.guildId, "lock:all-cancel", "Cancelar", "reject", ButtonStyle.Secondary)
          )], flags: MessageFlags.Ephemeral
        });
        return;
      }
      if (!(interaction.channel instanceof TextChannel)) throw new Error("Este comando só funciona em canais de texto.");
      if (interaction.commandName === "lock") await this.locks.lock(interaction.channel, interaction.member, reason);
      else await this.locks.unlock(interaction.channel, interaction.member, reason);
      await interaction.reply({ content: `✅ Canal ${interaction.commandName === "lock" ? "trancado" : "destrancado"}.`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (interaction.commandName === "calcular") {
      const raw = interaction.options.getString("valor", true);
      const calculation = this.robux.parseCalculation(interaction.guildId, raw);
      if (!calculation) throw new Error("Use um formato como `100 robux` ou `3 reais`.");
      const settings = this.robux.settings(interaction.guildId);
      if (settings.calculatorFormat === "EMBED") {
        await interaction.reply({ embeds: [this.robux.calculationEmbed(interaction.guildId, calculation)], flags: MessageFlags.Ephemeral });
      } else {
        const image = await this.robux.calculationImage(interaction.guildId, calculation);
        await interaction.reply({ files: [new AttachmentBuilder(image, { name: "calculadora-robux.png" })], flags: MessageFlags.Ephemeral });
      }
      return;
    }
    if (interaction.commandName === "comandos") {
      await interaction.reply({ ...this.commandHelpView(interaction.guildId), flags: MessageFlags.Ephemeral });
      return;
    }
    if (interaction.commandName === "painel") {
      if (!this.permissions.hasAnyManagement(this.member(interaction))) throw new Error("Você não possui permissão para abrir o painel.");
      const payload = this.views.adminPage(interaction.guildId, this.views.adminHome(interaction.guildId, interaction.user.displayName, this.zcloud.managerEnabled()), false);
      await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 }); return;
    }
    if (interaction.commandName === "meus-pedidos") { await interaction.reply({ embeds: [this.userOrdersEmbed(interaction.guildId, interaction.user.id)], flags: MessageFlags.Ephemeral }); return; }
    if (interaction.commandName === "ticket") {
      const panel = this.tickets.listPanels(interaction.guildId)[0]; if (!panel) throw new Error("Nenhum painel de ticket foi configurado.");
      await interaction.reply({ ...this.views.publicTicketPanel(interaction.guildId, panel), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 }); return;
    }
    if (interaction.commandName === "pedir-stock") {
      const settings = this.db.guild(interaction.guildId).stockRequest;
      if (!settings.enabled) throw new Error("Os pedidos de stock estão desativados neste servidor.");
      await interaction.reply({ ...this.views.publicStockRequestPanel(interaction.guildId), flags: MessageFlags.Ephemeral });
      return;
    }
    if (interaction.commandName === "salvar-emojis") {
      await this.savedEmojiCommand(interaction);
      return;
    }
    if (interaction.commandName === "emojis") {
      this.requireAdmin(interaction);
      const action = interaction.options.getSubcommand();
      if (action === "status") {
        const status = this.emojis.status;
        await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("emoji", interaction.guildId)} Emojis da aplicação`).setDescription(`Pacote: **${this.emojis.packName()}**\nInstalados: **${status.installed}/${status.total}**\nSincronizando: **${status.syncing ? `${status.completed}/${status.total}` : "não"}**${status.lastError ? `\nÚltimo erro: ${truncate(status.lastError, 1000)}` : ""}`)], flags: MessageFlags.Ephemeral });
        return;
      }
      if (action === "instalar") {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        await this.emojis.syncAutomatic(true);
        const refreshed = await this.refreshPublishedMessages();
        await interaction.editReply(`Pacote sincronizado: **${this.emojis.status.installed}/${this.emojis.status.total}** emojis. Mensagens atualizadas: **${refreshed}**.`);
        return;
      }
      if (action === "remover") {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const removed = await this.emojis.removeAll();
        await interaction.editReply(`Foram removidos **${removed}** emojis do pacote visual da aplicação.`);
        return;
      }
    }
    if (interaction.commandName === "status") {
      this.requireAdmin(interaction); const es = this.emojis.status; const stats = this.db.stats(interaction.guildId);
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Status da aplicação").addFields(
        { name: "Discord", value: this.client.isReady() ? "Conectado" : "Desconectado", inline: true },
        { name: "Emojis", value: `${es.installed}/${es.total}${es.syncing ? " sincronizando" : ""}`, inline: true },
        { name: "Produtos", value: String(stats.activeProducts), inline: true },
        { name: "Pedidos pendentes", value: String(stats.pendingOrders), inline: true },
        { name: "IMAP", value: this.db.payments(interaction.guildId).imapPix.enabled ? "Ativo" : "Desativado", inline: true },
        { name: "Banco", value: "JSON operacional", inline: true }
      ).setTimestamp()], flags: MessageFlags.Ephemeral });
    }
  }

  private async updateAdmin(interaction: ButtonInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction, payload: ReturnType<Views["adminHome"]>) {
    // ACK imediato: evita "não respondeu a tempo" em servidores com banco grande.
    if (!interaction.deferred && !interaction.replied) await interaction.deferUpdate();
    await interaction.editReply(payload as never);
  }

  /**
   * Normaliza toda navegação administrativa para Components V2.
   *
   * O /painel novo já nasce em V2, mas versões anteriores ainda podiam deixar
   * respostas efêmeras de Produto/Ticket em embed legado. Se um botão dessas
   * mensagens antigas tentar ativar IsComponentsV2 sem antes remover os campos
   * legados, o Discord responde MESSAGE_CANNOT_USE_LEGACY_FIELDS_WITH_COMPONENTS_V2.
   *
   * R18.9.20: V2 permanece V2; mensagens legadas são migradas com segurança em
   * duas etapas e, depois disso, também permanecem V2 durante toda a navegação.
   */
  private adminInteraction<T extends ButtonInteraction | StringSelectMenuInteraction | ChannelSelectMenuInteraction | RoleSelectMenuInteraction | UserSelectMenuInteraction>(interaction: T, guildId: string): T {
    const views = this.views;
    const sourceIsV2 = interaction.message.flags.has(MessageFlags.IsComponentsV2);
    const hasDefaultBanner = interaction.message.attachments.some((attachment) => attachment.name === "panel-banner.png");
    const normalize = (payload: { content?: unknown; embeds?: unknown[]; components?: unknown[]; flags?: unknown; stickers?: unknown; poll?: unknown }) => {
      const flags = Number(payload.flags ?? 0);
      const alreadyV2 = (flags & Number(MessageFlags.IsComponentsV2)) === Number(MessageFlags.IsComponentsV2);
      if (alreadyV2) {
        // Nunca deixe um payload V2 carregar campos legados, mesmo vazios.
        // É exatamente isso que dispara MESSAGE_CANNOT_USE_LEGACY_FIELDS_WITH_COMPONENTS_V2.
        const { content: _content, embeds: _embeds, stickers: _stickers, poll: _poll, ...safe } = payload;
        return { ...safe, flags: MessageFlags.IsComponentsV2 };
      }
      // Toda navegação administrativa passa a terminar em Components V2. Isso é
      // especialmente importante em Tickets: respostas antigas de modal podiam
      // criar uma mensagem legada e, a partir dali, manter todo o fluxo em embeds.
      return views.adminPageEdit(guildId, payload, hasDefaultBanner);
    };

    return new Proxy(interaction, {
      get(target, property) {
        if (property === "update") return async (payload: { content?: unknown; embeds?: unknown[]; components?: unknown[]; flags?: unknown; stickers?: unknown; poll?: unknown }) => {
          const next = normalize(payload);
          if (sourceIsV2) return target.update(next as never);

          // Para migrar uma mensagem legada, ACK primeiro sem alterar a tela e
          // use o endpoint de edição da resposta original. Ao ATIVAR V2 em uma
          // mensagem já existente, a API do Discord exige que os campos legados
          // usados antes sejam resetados no mesmo edit (content=null, embeds=[]).
          // Isso evita tanto o erro de Invalid Form Body quanto o piscar de uma
          // mensagem intermediária no cliente.
          await target.deferUpdate();
          return target.editReply({ ...next, content: null, embeds: [], attachments: [], poll: null } as never);
        };
        if (property === "editReply") return async (payload: { content?: unknown; embeds?: unknown[]; components?: unknown[]; flags?: unknown; stickers?: unknown; poll?: unknown } | string) => {
          if (typeof payload === "string" || !sourceIsV2) return target.editReply(payload as never);
          return target.editReply(normalize(payload) as never);
        };
        const value = Reflect.get(target, property, target) as unknown;
        return typeof value === "function" ? value.bind(target) : value;
      }
    });
  }

  private async storeRespond(interaction: ButtonInteraction | StringSelectMenuInteraction, payload: Record<string, unknown>) {
    if (interaction.message.flags.has(MessageFlags.Ephemeral)) return interaction.update(payload as never);
    return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral } as never);
  }

  private async button(interaction: ButtonInteraction) {
    const id = interaction.customId;
    if (id.startsWith("delivery:copy:")) return this.deliveryCopyButton(interaction, id);
    const gid = interaction.guildId;
    if (!gid) throw new Error("Esta interação precisa ser utilizada dentro do servidor.");
    if (id.startsWith("robux:")) return this.robuxButton(interaction, id, gid);
    if (id.startsWith("admin:")) { this.requireAdminAction(interaction, id); return this.adminButton(interaction, id, gid); }
    if (id.startsWith("cart:")) return this.cartButton(interaction, id, gid);
    if (id.startsWith("payment:")) return this.paymentButton(interaction, id, gid);
    if (id.startsWith("lock:")) return this.lockButton(interaction, id, gid);
    if (id.startsWith("product:")) return this.productButton(interaction, id, gid);
    if (id.startsWith("store:")) return interaction.reply({ content: "Este painel antigo de loja foi desativado. Use um painel individual de produto publicado pela equipe.", flags: MessageFlags.Ephemeral });
    if (id.startsWith("stock-request:")) return this.stockRequestButton(interaction, id, gid);
    if (id.startsWith("ticket:")) return this.ticketButton(interaction, id, gid);
    if (id.startsWith("giveaway:")) return this.giveawayButton(interaction, id);
  }

  private async adminButton(i: ButtonInteraction, id: string, gid: string) {
    if (id.startsWith("admin:robux")) this.requireOwner(i);
    if (id === "admin:home") return this.updateAdmin(i, this.views.adminHome(gid, i.user.displayName, this.zcloud.managerEnabled()));
    if (id === "admin:voice") return i.update(this.voiceAdminView(gid) as never);
    if (id === "admin:commands") return i.update(this.commandHelpView(gid) as never);
    if (id === "admin:voice:reconnect") {
      const state = this.voice.status(gid);
      if (!state.channelId) throw new Error("Escolha primeiro o canal de voz que o bot deve permanecer conectado.");
      await i.deferUpdate();
      await this.voice.connect(gid, state.channelId);
      return i.editReply(this.voiceAdminView(gid) as never);
    }
    if (id === "admin:voice:disconnect") {
      await i.deferUpdate();
      await this.voice.disconnect(gid);
      return i.editReply(this.voiceAdminView(gid) as never);
    }
    if (id === "admin:zcloud") { if(!this.zcloud.managerEnabled()) throw new Error("ZCloud está desativado pelo ZENYX Manager."); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:invites") return i.update(this.invitesAdminView(gid) as never);
    if (id === "admin:invites:toggle") {
      const cfg = this.invites.settings(gid);
      if (!cfg.enabled && !cfg.channelId) throw new Error("Escolha o canal de entradas antes de ativar o Invite Tracker.");
      this.invites.update(gid, { enabled: !cfg.enabled });
      if (!cfg.enabled && i.guild) await this.invites.prime(i.guild).catch(() => undefined);
      return i.update(this.invitesAdminView(gid) as never);
    }
    if (id === "admin:invites:channel") return i.update(this.views.channelPicker(gid, "admin:invites:channel-set", "Canal onde o Invite Tracker anunciará novas entradas") as never);
    if (id === "admin:invites:message") {
      const cfg = this.invites.settings(gid);
      return i.showModal(modal("modal:invites:message", "Invites • mensagem de entrada", [
        input("message", "MENSAGEM DE ENTRADA", cfg.message, TextInputStyle.Paragraph, true, 1900, "{member} entrou por {inviter}")
      ]));
    }
    if (id === "admin:invites:settings") {
      const cfg = this.invites.settings(gid);
      return i.showModal(modal("modal:invites:settings", "Invites • regras", [
        input("fakeDays", "CONTA FAKE ABAIXO DE QUANTOS DIAS?", String(cfg.fakeAccountDays), TextInputStyle.Short, true, 3, "3"),
        input("trackLeaves", "DESCONTAR SAÍDAS? (sim/não)", cfg.trackLeaves ? "sim" : "não", TextInputStyle.Short, true, 5, "sim"),
        input("ignoreBots", "IGNORAR BOTS? (sim/não)", cfg.ignoreBots ? "sim" : "não", TextInputStyle.Short, true, 5, "sim")
      ]));
    }
    if (id === "admin:invites:ranking") return i.update(this.invitesRankingView(gid) as never);
    if (id === "admin:invites:refresh") {
      if (!i.guild) throw new Error("Servidor indisponível.");
      await i.deferUpdate();
      await this.invites.prime(i.guild);
      return i.editReply(this.invitesAdminView(gid) as never);
    }
    if (id === "admin:invites:reset") return i.showModal(modal("modal:invites:reset", "Zerar estatísticas de convites", [input("confirm", "DIGITE ZERAR PARA CONFIRMAR", "", TextInputStyle.Short, true, 5, "ZERAR")]));
    if (id === "admin:zcloud:toggle") { if(!this.zcloud.managerEnabled()) throw new Error("ZCloud está desativado pelo ZENYX Manager."); const z=this.zcloud.settings(gid); if(!z.enabled){const issues=await this.zcloud.test(gid);if(issues.length) throw new Error(`ZCloud ainda não está pronto: ${issues.join("; ")}`);} this.zcloud.update(gid,{enabled:!z.enabled}); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:zcloud:oauth") {
      const z=this.zcloud.settings(gid);
      const managed=this.zcloud.managedPublicBaseUrl();
      const fields = managed
        ? [
            input("clientId","Discord Client ID",z.clientId,TextInputStyle.Short,true,22),
            input("secret","Discord Client Secret","",TextInputStyle.Short,!this.zcloud.secretConfigured(gid),200,"Deixe vazio para manter o atual"),
            input("returnUrl","Destino ao voltar",z.discordReturnUrl,TextInputStyle.Short,true,500,"https://discord.com/channels/...")
          ]
        : [
            input("clientId","Discord Client ID",z.clientId,TextInputStyle.Short,true,22),
            input("secret","Discord Client Secret","",TextInputStyle.Short,!this.zcloud.secretConfigured(gid),200,"Deixe vazio para manter o atual"),
            input("publicBaseUrl","URL pública HTTPS",this.zcloud.effectivePublicBaseUrl(gid)||z.publicBaseUrl,TextInputStyle.Short,true,500,"https://auth.exemplo.com"),
            input("redirectUri","Redirect URI HTTPS",this.zcloud.effectiveRedirectUri(gid)||z.redirectUri,TextInputStyle.Short,true,500,"Cadastre exatamente esta URL no Discord"),
            input("returnUrl","Destino ao voltar",z.discordReturnUrl,TextInputStyle.Short,true,500,"https://discord.com/channels/...")
          ];
      return i.showModal(modal("modal:zcloud:oauth","ZCloud • OAuth2",fields));
    }
    if (id === "admin:zcloud:appearance") { const z=this.zcloud.settings(gid); return i.showModal(modal("modal:zcloud:appearance","ZCloud • aparência",[input("title","Título",z.panelTitle,TextInputStyle.Short,true,100),input("description","Descrição",z.panelDescription,TextInputStyle.Paragraph,true,1500),input("image","Link da imagem / banner",z.panelImageUrl,TextInputStyle.Short,false,1000,"https://..."),input("color","Cor lateral / accent (#RRGGBB)",z.panelColor,TextInputStyle.Short,true,7,"#3155ff"),input("footer","Rodapé",z.panelFooter,TextInputStyle.Short,false,300,"Opcional")])); }
    if (id === "admin:zcloud:button-style") { const z=this.zcloud.settings(gid); return i.showModal(modal("modal:zcloud:button-style","ZCloud • texto do botão",[input("label","Texto do botão",z.buttonLabel,TextInputStyle.Short,true,80,"Verificar minha conta") ])); }
    if (/^admin:zcloud:emoji:\d+$/.test(id)) return i.update(this.emojiAssetPicker(gid, "zcloud-button", Number(id.split(":")[3] ?? 0)) as never);
    if (id === "admin:zcloud:emoji-remove") { this.zcloud.update(gid,{buttonEmoji:"__none__"}); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:zcloud:emoji-add") return i.showModal(modal("modal:zcloud:emoji-add","Adicionar emoji ao bot",[input("name","Nome do emoji","",TextInputStyle.Short,true,32,"Ex.: verificar") ]));
    if (id === "admin:zcloud:auto-join") { const z=this.zcloud.settings(gid); return i.showModal(modal("modal:zcloud:auto-join","ZCloud • servidor adicional",[input("enabled","Ativar? (sim/não)",z.autoJoinEnabled?"sim":"não",TextInputStyle.Short,true,5,"sim"),input("guildId","ID do servidor",z.autoJoinGuildId,TextInputStyle.Short,z.autoJoinEnabled,22,"123456789012345678"),input("invite","Link de convite Discord",z.autoJoinInviteUrl,TextInputStyle.Short,z.autoJoinEnabled,500,"https://discord.gg/...")])); }
    if (id === "admin:zcloud:backup-config") { const z=this.zcloud.settings(gid); return i.showModal(modal("modal:zcloud:backup-config","ZCloud • servidor de backup",[input("enabled","Ativar? (sim/não)",z.backupTransferEnabled?"sim":"não",TextInputStyle.Short,true,5,"sim"),input("guildId","ID do servidor backup",z.backupGuildId,TextInputStyle.Short,false,22,"123456789012345678"),input("invite","Link de convite do backup",z.backupInviteUrl,TextInputStyle.Short,false,500,"https://discord.gg/..."),input("limit","Quantidade padrão por envio",String(z.backupTransferLimit||50),TextInputStyle.Short,true,3,"50")])); }
    if (id === "admin:zcloud:backup-toggle") { const z=this.zcloud.settings(gid); if(!z.backupTransferEnabled && !z.backupGuildId) throw new Error("Configure primeiro o servidor de backup."); this.zcloud.update(gid,{backupTransferEnabled:!z.backupTransferEnabled,allowBackupJoin:!z.backupTransferEnabled || z.allowBackupJoin}); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:zcloud:backup-transfer") { const z=this.zcloud.settings(gid); if(!z.backupTransferEnabled) throw new Error("Ative o backup de membros primeiro."); return i.showModal(modal("modal:zcloud:backup-transfer","Enviar membros autorizados",[input("amount","QUANTOS MEMBROS ENVIAR",String(z.backupTransferLimit||50),TextInputStyle.Short,true,3,"1 a 500")])); }
    if (id === "admin:zcloud:preview") { const payload=this.zcloudPanelPayload(gid) as Record<string, unknown>; const flags=Number(payload.flags ?? 0) | Number(MessageFlags.Ephemeral); return i.reply({ ...payload, flags } as never); }
    if (id === "admin:zcloud:role") return i.update({embeds:[new EmbedBuilder().setColor(0x3155ff).setTitle("Cargo após verificação").setDescription("Selecione o cargo que o ZCloud aplicará após a autorização.")],components:[new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId("admin:zcloud:role-set").setPlaceholder("Escolha o cargo").setMaxValues(1)),this.views.back(gid,"admin:zcloud")]} as never);
    if (id === "admin:zcloud:publish") return i.update(this.views.channelPicker(gid,"admin:zcloud:publish-channel","Canal onde o painel de verificação será publicado") as never);
    if (id === "admin:zcloud:test") { await i.deferReply({flags:MessageFlags.Ephemeral}); const issues=await this.zcloud.test(gid); await i.editReply(issues.length?`ZCloud ainda precisa de ajustes:\n• ${issues.join("\n• ")}`:"✓ ZCloud está pronto para OAuth2."); return; }
    if (id === "admin:zcloud:members") { const ms=this.zcloud.members(gid); const text=ms.length?ms.slice(0,25).map(m=>`<@${m.userId}> • <t:${Math.floor(Date.parse(m.verifiedAt)/1000)}:R> • backup ${m.backupEligible?"sim":"não"}`).join("\n"):"Nenhum membro verificado."; return i.update({embeds:[new EmbedBuilder().setColor(0x3155ff).setTitle("Membros verificados • ZCloud").setDescription(text)],components:[this.views.back(gid,"admin:zcloud")]} as never); }
    if (id === "admin:robux") return i.update(this.robuxAdminView(gid) as never);
    if (id === "admin:robux:advanced") return i.update(this.robuxAdminAdvancedView(gid) as never);
    if (id === "admin:robux:toggle") { const s = this.robux.settings(gid); this.robux.updateSettings(gid, { enabled: !s.enabled }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:manual-shortcut-toggle") { const s = this.robux.settings(gid); this.robux.updateSettings(gid, { manualShortcutEnabled: !s.manualShortcutEnabled }); await this.refreshRobuxPanel(gid); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:calculator-toggle") { const s = this.robux.settings(gid); this.robux.updateSettings(gid, { calculatorEnabled: !s.calculatorEnabled }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:calculator-format-toggle") { const s = this.robux.settings(gid); this.robux.updateSettings(gid, { calculatorFormat: s.calculatorFormat === "PNG" ? "EMBED" : "PNG" }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:prices") { const s = this.robux.settings(gid); return i.showModal(modal("modal:robux-admin:prices", "Robux • preços e limites", [input("price", "R$ por 1.000 Robux", (s.pricePer1000Cents / 100).toFixed(2), TextInputStyle.Short, true, 20), input("min", "Mínimo de Robux", String(s.minRobux), TextInputStyle.Short, true, 12), input("max", "Máximo de Robux", String(s.maxRobux), TextInputStyle.Short, true, 12), input("passes", "Máximo de gamepasses exibidas", String(s.maxGamepasses), TextInputStyle.Short, true, 2)])); }
    if (id === "admin:robux:text") { const s = this.robux.settings(gid); return i.showModal(modal("modal:robux-admin:text", "Robux • painel público", [input("title", "Título", s.title, TextInputStyle.Short, true, 100), input("description", "Descrição", s.description, TextInputStyle.Paragraph, true, 1800), input("banner", "URL do banner (opcional)", s.bannerUrl, TextInputStyle.Short, false, 1000, "https://...")])); }
    if (id === "admin:robux:calculator-channel") return i.update(this.views.channelPicker(gid, "admin:robux:calculator-channel-set", "Canal onde mensagens como 100 robux e 3 reais serão calculadas") as never);
    if (id === "admin:robux:log-channel") return i.update(this.views.channelPicker(gid, "admin:robux:log-channel-set", "Canal privado de logs das vendas Robux") as never);
    if (id === "admin:robux:announcement-channel") return i.update(this.views.channelPicker(gid, "admin:robux:announcement-channel-set", "Canal onde compras confirmadas de Robux serão anunciadas") as never);
    if (id === "admin:robux:announcement-toggle") {
      const s = this.robux.settings(gid);
      if (!s.announcementEnabled) {
        const announcementChannelId = s.announcementChannelId || s.logChannelId;
        if (!announcementChannelId) throw new Error("Configure o canal pós-compra ou o canal de logs antes de ativar os anúncios.");
        // Se o dono já configurou o canal de logs, ele também pode ser usado como
        // canal pós-compra. Persistimos a escolha para sobreviver a reinícios.
        this.robux.updateSettings(gid, { announcementEnabled: true, announcementChannelId });
      } else {
        this.robux.updateSettings(gid, { announcementEnabled: false });
      }
      return i.update(this.robuxAdminView(gid) as never);
    }
    if (id === "admin:robux:publish") return i.update(this.views.channelPicker(gid, "admin:robux:publish-channel", "Canal onde o painel de compra de Robux será publicado") as never);
    if (id === "admin:robux:delivery-webhook") { const s = this.robux.settings(gid); return i.showModal(modal("modal:robux-admin:delivery-webhook", "Robux • integração de entrega", [input("url", "URL HTTPS do provedor", s.deliveryWebhookUrl, TextInputStyle.Short, true, 500, "https://seu-provedor.exemplo/robux/deliver"), input("token", "Chave privada da integração", "", TextInputStyle.Short, true, 500, "Não use cookie Roblox aqui") ])); }
    if (id === "admin:robux:delivery-clear") { this.robux.clearDeliveryWebhook(gid); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:announcement-format-toggle") { const current = this.robux.settings(gid); this.robux.updateSettings(gid, { announcementFormat: current.announcementFormat === "PNG" ? "EMBED" : "PNG" }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:delivery-cookie") return i.showModal(modal("modal:robux-admin:delivery-cookie", "Robux • conta de entrega", [
      input("cookie", "Cookie .ROBLOSECURITY (vazio remove)", "", TextInputStyle.Paragraph, false, 1000, "Cole somente o cookie da conta de entrega")
    ]));
    if (id === "admin:robux:delivery-cookie-remove") { this.robux.removeCookie(gid); const current = this.robux.settings(gid); if (["ASSISTED", "COOKIE_AUTO"].includes(current.deliveryMode)) this.robux.updateSettings(gid, { deliveryMode: "MANUAL", autoDelivery: false }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:orders-list" || id === "admin:robux:queue") return i.update(this.robuxOrdersView(gid) as never);
    if (id.startsWith("admin:robux:mark-paid:")) { const order = await this.robux.markPaidManual(id.split(":")[3]!); return i.update(this.robuxOrderDetail(gid, order.id) as never); }
    if (id.startsWith("admin:robux:mark-delivered:")) { const order = await this.robux.markDelivered(id.split(":")[3]!); return i.update(this.robuxOrderDetail(gid, order.id) as never); }
    if (id.startsWith("admin:robux:retry:")) { const order = await this.robux.retryDelivery(id.split(":")[3]!); return i.update(this.robuxOrderDetail(gid, order.id) as never); }
    if (id === "admin:products") return i.update(this.views.productsHome(gid) as never);
    if (id === "admin:restock") return i.update(this.views.restockSettings(gid) as never);
    if (id === "admin:restock:channel") return i.update(this.views.channelPicker(gid, "admin:restock:channel-set", "Canal onde os avisos de reposição serão publicados") as never);
    if (id === "admin:restock:role") return i.update(this.views.rolePicker(gid, "admin:restock:role-set", "Cargo mencionado nos avisos de reposição", 1) as never);
    if (id === "admin:restock:toggle") {
      const settings = this.db.guild(gid).restockAnnouncements;
      if (!settings.enabled && !settings.channelId) throw new Error("Escolha o canal de restock antes de ativar os avisos.");
      settings.enabled = !settings.enabled; this.db.save(); return i.update(this.views.restockSettings(gid) as never);
    }
    if (id === "admin:restock:banner") {
      const settings = this.db.guild(gid).restockAnnouncements;
      settings.includeProductBanner = !settings.includeProductBanner; this.db.save(); return i.update(this.views.restockSettings(gid) as never);
    }
    if (id === "admin:restock:edit") {
      const settings = this.db.guild(gid).restockAnnouncements;
      return i.showModal(modal("modal:restock:edit", "Mensagem de restock", [
        input("title", "Título", settings.title, TextInputStyle.Short, true, 250),
        input("message", "Mensagem", settings.message, TextInputStyle.Paragraph, true, 1800)
      ]));
    }
    if (/^admin:products:\d+$/.test(id)) return i.update(this.views.productsHome(gid, Number(id.split(":")[2])) as never);
    if (id === "admin:store") return i.update(this.views.productsHome(gid) as never);
    if (id === "admin:payments") return i.update(this.views.paymentsHome(gid) as never);
    if (id === "admin:wallet") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      return i.update(this.views.walletHome(gid) as never);
    }
    if (id === "admin:wallet:refresh") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      return i.update(this.views.walletHome(gid) as never);
    }
    if (id === "admin:wallet:pix") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      const account = this.db.wallet(gid, false);
      return i.showModal(modal("modal:wallet:pix", "Zwallet • chave PIX", [
        input("key", "Chave PIX para saque", account.pixKey, TextInputStyle.Short, true, 200, "CPF/CNPJ, e-mail, telefone ou chave aleatória")
      ]));
    }
    if (id === "admin:wallet:withdraw") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      const account = this.db.wallet(gid, false);
      const zny = this.db.payments(gid).znyPay;
      if (!account.pixKey) throw new Error("Cadastre sua chave PIX na Zwallet antes de solicitar um saque.");
      if (account.balanceCents < zny.minWithdrawalCents) throw new Error(`O saque fica disponível a partir de ${formatMoney(zny.minWithdrawalCents)}.`);
      return i.showModal(modal("modal:wallet:withdraw", "Zwallet • solicitar saque", [
        input("amount", "Valor do saque", (account.balanceCents / 100).toFixed(2), TextInputStyle.Short, true, 20, `Mínimo ${(zny.minWithdrawalCents / 100).toFixed(2)}`)
      ]));
    }
    if (id === "admin:tickets") return i.update(this.views.ticketPanelsHome(gid) as never);
    if (id === "admin:messages") return i.update(this.botMessagesView(gid) as never);
    if (id === "admin:stock-requests") return i.update(this.views.stockRequestsHome(gid) as never);
    if (id === "admin:saved-emojis") return i.update(this.views.savedEmojisHome(gid) as never);
    if (/^admin:saved-emojis:\d+$/.test(id)) return i.update(this.views.savedEmojisHome(gid, Number(id.split(":")[2] ?? 0)) as never);
    if (id === "admin:emojis") return i.update(this.views.emojisHome(gid) as never);
    if (id === "admin:channels") return i.update(this.views.channelSettings(gid) as never);
    if (id === "admin:personalize") return i.update(this.personalizeView(gid) as never);
    if (id === "admin:automations") return i.update(this.automationsView(gid) as never);
    if (id === "admin:protection") return i.update(this.protectionView(gid) as never);
    if (id === "admin:revenue") return i.update(this.revenueView(gid) as never);
    if (id === "admin:orders") return i.update(this.ordersAdminView(gid) as never);
    if (id === "admin:giveaways") return i.update(this.giveawaysView(gid) as never);
    if (id === "admin:coupons") return i.update(this.couponsView(gid) as never);
    if (id === "admin:permissions") return i.update(this.permissionsView(gid) as never);
    if (id === "admin:backups") return i.update(this.backupsView(gid) as never);
    if (id === "admin:backup") {
      await i.deferReply({ flags: MessageFlags.Ephemeral }); const path = this.db.backup(); await i.editReply({ content: "Backup JSON criado.", files: [new AttachmentBuilder(path)] }); return;
    }
    if (id.startsWith("admin:coupon:CPN_")) return i.update(this.couponDetail(gid, id.split(":")[2]!) as never);
    if (id.startsWith("admin:backup:BKP_")) return i.update(this.backupDetail(gid, id.split(":")[2]!) as never);
    if (id === "admin:quick-setup") return i.update({
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Instalação rápida do servidor").setDescription("O bot criará os cargos **Equipe** e **Cliente**, categorias de tickets, um canal para painéis de produtos, canais de logs, um painel inicial de atendimento e publicará os painéis de suporte automaticamente. Itens já configurados serão reaproveitados.")],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:quick-setup-confirm", "Criar estrutura", "approve", ButtonStyle.Success),
        this.views.button(gid, "admin:home", "Cancelar", "back", ButtonStyle.Danger)
      )]
    });
    if (id === "admin:quick-setup-confirm") return this.runQuickSetup(i, gid);
    if (id.startsWith("admin:permissions:user:")) {
      const key = id.split(":")[3]!;
      const current = key === "admins" ? this.db.guild(gid).permissions.adminUserIds : this.db.guild(gid).permissions.authorizedUserIds;
      return i.update({ embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(key === "admins" ? "Usuários administradores" : "Usuários autorizados").setDescription("Selecione os usuários. O proprietário do bot e o dono do servidor sempre mantêm acesso.")], components: [new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(new UserSelectMenuBuilder().setCustomId(`admin:permissions-user-set:${key}`).setPlaceholder("Selecione usuários").setMinValues(0).setMaxValues(25).setDefaultUsers(current)), this.views.back(gid, "admin:permissions")] } as never);
    }
    if (id.startsWith("admin:permissions:role:")) {
      const key = id.split(":")[3]!;
      const map: Record<string, keyof import("../types.js").GuildPermissions> = { admins: "adminRoleIds", authorized: "authorizedRoleIds", support: "supportRoleIds", tickets: "ticketRoleIds", payments: "paymentRoleIds", products: "productRoleIds", commands: "adminCommandRoleIds" };
      const field = map[key]; if (!field) throw new Error("Grupo de permissão inválido.");
      const current = this.db.guild(gid).permissions[field] as string[];
      return i.update({ embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Cargos autorizados").setDescription(`Grupo: **${key}**. Selecione até 25 cargos.`)], components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId(`admin:permissions-role-set:${key}`).setPlaceholder("Selecione cargos").setMinValues(0).setMaxValues(25).setDefaultRoles(current)), this.views.back(gid, "admin:permissions")] } as never);
    }
    if (id === "admin:locks:ignored") return i.update({ embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Canais ignorados no /lock all").setDescription("Estes canais nunca serão bloqueados pelo comando em massa.")], components: [new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId("admin:locks-ignored-set").setPlaceholder("Selecione canais ignorados").setChannelTypes(ChannelType.GuildText).setMinValues(0).setMaxValues(25).setDefaultChannels(this.db.guild(gid).locks.ignoredChannelIds)), this.views.back(gid, "admin:permissions")] } as never);
    if (id === "admin:locks:speaking") return i.update({ embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Cargos que podem falar durante o bloqueio")], components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(new RoleSelectMenuBuilder().setCustomId("admin:locks-speaking-set").setPlaceholder("Selecione cargos").setMinValues(0).setMaxValues(25).setDefaultRoles(this.db.guild(gid).locks.speakingRoleIds)), this.views.back(gid, "admin:permissions")] } as never);
    if (id === "admin:product:create") return i.update({
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle("Criar produto")
        .setDescription("Escolha como o produto será entregue. A opção poderá ser alterada depois sem recriar o produto.")
        .addFields(
          { name: "Entrega automática", value: "O bot reserva o stock e envia a unidade após a aprovação do pagamento." },
          { name: "Entrega manual", value: "O pagamento é aprovado e a equipe conclui a entrega no canal privado." }
        )],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:product:create-type:STOCK", "Entrega automática", "delivery", ButtonStyle.Success),
        new ButtonBuilder().setCustomId("admin:product:create-type:MANUAL").setLabel("Entrega manual").setStyle(ButtonStyle.Primary),
        this.views.button(gid, "admin:products", "Cancelar", "back", ButtonStyle.Secondary)
      )]
    } as never);
    if (id.startsWith("admin:product:create-type:")) {
      const selectedDelivery = id.split(":")[3] === "STOCK" ? "STOCK" : "MANUAL";
      return i.showModal(modal(`modal:product:create:${selectedDelivery}`, selectedDelivery === "STOCK" ? "Produto automático" : "Produto manual", [
        input("name", "Nome do produto", "", TextInputStyle.Short, true, 100),
        input("description", "Descrição da mensagem", "", TextInputStyle.Paragraph, true, 4000),
        input("field_name", "Nome da primeira opção", "Opção principal", TextInputStyle.Short, true, 100),
        input("price", "Preço da primeira opção", "", TextInputStyle.Short, true, 20, "9,90")
      ]));
    }
    if (/^admin:product:PRD_[^:]+$/.test(id)) return i.update(this.views.productDetail(gid, this.products.get(id.split(":")[2]!, gid)) as never);
    if (id.startsWith("admin:product:separators:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.get(productId, gid);
      this.products.update(productId, { showSeparators: !product.showSeparators }, i.user.id);
      await this.refreshProductPublications(productId).catch(() => undefined);
      return i.update(this.views.productDetail(gid, this.products.get(productId, gid)) as never);
    }
    if (/^admin:product:emoji:[^:]+:\d+$/.test(id)) {
      const [, , , productId, pageRaw] = id.split(":");
      return i.update(this.emojiAssetPicker(gid, "product", Number(pageRaw ?? 0), { productId }) as never);
    }
    if (/^admin:product:field-emoji:[^:]+:[^:]+:\d+$/.test(id)) {
      const [, , , productId, fieldId, pageRaw] = id.split(":");
      return i.update(this.emojiAssetPicker(gid, "product-field", Number(pageRaw ?? 0), { productId, fieldId }) as never);
    }
    if (id.startsWith("admin:product:basic:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:basic:${product.id}`, "Descrição do produto", [
        input("name", "Nome", product.name, TextInputStyle.Short, true, 100),
        input("description", "Descrição pública", product.description, TextInputStyle.Paragraph, true, 4000)
      ]));
    }
    if (id.startsWith("admin:product:visual:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:visual:${product.id}`, "Banner e visual do painel", [
        input("image", "URL da miniatura (opcional)", product.imageUrl, TextInputStyle.Short, false, 1000),
        input("banner", "URL do banner principal", product.bannerUrl, TextInputStyle.Short, false, 1000),
        input("color", "Cor hexadecimal", product.color, TextInputStyle.Short, true, 7)
      ]));
    }
    if (id.startsWith("admin:product:purchase:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:purchase:${product.id}`, "Texto da compra", [
        input("label", "Texto do botão quando houver 1 campo", product.buttonLabel, TextInputStyle.Short, true, 80),
        input("style", "Estilo: PRIMARY / SECONDARY / SUCCESS / DANGER", product.buttonStyle, TextInputStyle.Short, true, 20),
        input("placeholder", "Texto do select quando houver 2+ campos", product.selectPlaceholder, TextInputStyle.Short, true, 150)
      ]));
    }
    if (id.startsWith("admin:product:demo:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:demo:${product.id}`, "Botão de demonstração", [
        input("url", "Link da demonstração (vazio desativa)", product.demonstrationUrl, TextInputStyle.Short, false, 1000, "https://..."),
        input("label", "Texto do botão", product.demonstrationLabel, TextInputStyle.Short, true, 80),
        input("emoji", "Emoji: ID, saved:nome, Unicode ou função", product.demonstrationEmoji, TextInputStyle.Short, false, 100)
      ]));
    }
    if (id.startsWith("admin:product:delivery-type:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.get(productId, gid);
      const select = new StringSelectMenuBuilder()
        .setCustomId(`admin:product:delivery-type-select:${product.id}`)
        .setPlaceholder("Escolha o tipo de entrega")
        .addOptions(
          new StringSelectMenuOptionBuilder().setLabel("Entrega automática").setDescription("Consome e envia o stock após o pagamento").setValue("STOCK").setEmoji(this.emojis.component("delivery", gid)).setDefault(product.deliveryType === "STOCK"),
          new StringSelectMenuOptionBuilder().setLabel("Entrega manual").setDescription("A equipe conclui a entrega no canal privado").setValue("MANUAL").setEmoji(this.emojis.component("delivery", gid)).setDefault(product.deliveryType === "MANUAL"),
          new StringSelectMenuOptionBuilder().setLabel("Entrega por cargo").setDescription("Adiciona o cargo configurado após o pagamento").setValue("ROLE").setEmoji(this.emojis.component("role", gid)).setDefault(product.deliveryType === "ROLE")
        );
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`Tipo de entrega • ${product.name}`).setDescription("Selecione uma opção. A alteração é salva imediatamente e as mensagens publicadas podem ser atualizadas pelo painel do produto.")],
        components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select), this.views.back(gid, `admin:product:delivery:${product.id}`)]
      } as never);
    }
    if (id.startsWith("admin:product:delivery-role:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      const select = new RoleSelectMenuBuilder()
        .setCustomId(`admin:product:delivery-role-set:${product.id}`)
        .setPlaceholder("Escolha o cargo entregue")
        .setMinValues(0)
        .setMaxValues(1);
      if (product.roleId) select.setDefaultRoles(product.roleId);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`Cargo entregue • ${product.name}`).setDescription("Selecione um cargo ou confirme sem seleção para remover o cargo atual.")],
        components: [new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select), this.views.back(gid, `admin:product:delivery:${product.id}`)]
      } as never);
    }
    if (id.startsWith("admin:product:delivery-message:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:delivery-message:${product.id}`, "Mensagem de entrega", [
        input("message", "Mensagem exibida após o pagamento", product.deliveryMessage, TextInputStyle.Paragraph, false, 1800)
      ]));
    }
    if (id.startsWith("admin:product:delivery-limits:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:delivery-limits:${product.id}`, "Limites de compra", [
        input("minimum", "Quantidade mínima", String(product.minQuantity), TextInputStyle.Short, true, 4),
        input("maximum", "Quantidade máxima", String(product.maxQuantity), TextInputStyle.Short, true, 4),
        input("per_user", "Limite total por usuário (0 sem limite)", String(product.perUserLimit), TextInputStyle.Short, true, 6),
        input("coupon_group", "Grupo de cupons (opcional)", product.couponGroup, TextInputStyle.Short, false, 80)
      ]));
    }
    if (id.startsWith("admin:product:terms-toggle:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      const updated = this.products.update(product.id, { requireTerms: !product.requireTerms }, i.user.id);
      return i.update(this.productDeliveryView(gid, updated) as never);
    }
    if (id.startsWith("admin:product:terms-text:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:product:terms-text:${product.id}`, "Termos do produto", [
        input("terms", "Texto apresentado antes da compra", product.termsText, TextInputStyle.Paragraph, false, 1800)
      ]));
    }
    if (/^admin:product:delivery:PRD_[^:]+$/.test(id)) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.update(this.productDeliveryView(gid, product) as never);
    }
    if (id.startsWith("admin:product:mode:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.update(this.views.productModeView(gid, product) as never);
    }
    if (id.startsWith("admin:product:fields:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      return i.update(this.views.productFieldsView(gid, product) as never);
    }
    if (id.startsWith("admin:product:field:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      return i.update(this.views.productFieldDetail(gid, product, this.products.getField(product.id, fieldId)) as never);
    }
    if (id.startsWith("admin:product:field-add:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.get(productId, gid);
      const multi = product.purchaseMode === "SELECT";
      return i.showModal(modal(`modal:product:field-add:${productId}`, multi ? "Adicionar produto/opção" : "Adicionar campo", [
        input("name", multi ? "Nome do produto/opção" : "Nome do campo", "", TextInputStyle.Short, true, 100),
        input("description", multi ? "Descrição curta desta opção" : "Descrição curta no select", "", TextInputStyle.Short, false, 100),
        input("price", "Preço", "", TextInputStyle.Short, true, 20, "9,90"),
        input("compare", "Preço anterior (opcional)", "", TextInputStyle.Short, false, 20),
        input("emoji", "Emoji: ID, saved:nome, Unicode ou função", "cart", TextInputStyle.Short, false, 100)
      ]));
    }
    if (id.startsWith("admin:product:field-edit:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      const field = this.products.getField(productId!, fieldId);
      const multi = product.purchaseMode === "SELECT";
      return i.showModal(modal(`modal:product:field-edit:${productId}:${fieldId}`, multi ? "Editar produto/opção" : "Editar campo", [
        input("name", multi ? "Nome do produto/opção" : "Nome do campo", field.name, TextInputStyle.Short, true, 100),
        input("description", multi ? "Descrição curta desta opção" : "Descrição curta no select", field.description, TextInputStyle.Short, false, 100),
        input("price", "Preço", (field.priceCents / 100).toFixed(2), TextInputStyle.Short, true, 20),
        input("compare", "Preço anterior (opcional)", field.compareAtCents ? (field.compareAtCents / 100).toFixed(2) : "", TextInputStyle.Short, false, 20),
        input("emoji", "Emoji: ID, saved:nome, Unicode ou função", field.emoji, TextInputStyle.Short, false, 100)
      ]));
    }
    if (id.startsWith("admin:product:field-stock:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      return i.update(this.views.stockView(gid, product, this.products.getField(product.id, fieldId)) as never);
    }
    if (id.startsWith("admin:product:field-toggle:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      const field = this.products.getField(product.id, fieldId);
      const updatedField = this.products.updateField(product.id, field.id, { active: !field.active }, i.user.id);
      return i.update(this.views.productFieldDetail(gid, this.products.get(product.id, gid), updatedField) as never);
    }
    if (id.startsWith("admin:product:field-delete:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      const field = this.products.getField(product.id, fieldId);
      const unitName = product.purchaseMode === "SELECT" ? "produto/opção" : "campo";
      return i.update({
        embeds: [new EmbedBuilder().setColor(0xef4444).setTitle(`Excluir ${unitName}`).setDescription(`Excluir **${field.name}** e o stock disponível desse ${unitName}?`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:product:field-delete-confirm:${product.id}:${field.id}`, "Excluir", "trash", ButtonStyle.Danger),
          this.views.button(gid, `admin:product:field:${product.id}:${field.id}`, "Cancelar", "back")
        )]
      });
    }
    if (id.startsWith("admin:product:field-delete-confirm:")) {
      const [, , , productId, fieldId] = id.split(":");
      this.products.deleteField(productId!, fieldId!, i.user.id);
      return i.update(this.views.productFieldsView(gid, this.products.get(productId!, gid)) as never);
    }
    if (id.startsWith("admin:product:image-upload:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.get(productId, gid);
      return i.showModal(modal(`modal:image-url:product-image:${productId}`, "Miniatura do produto", [
        input("url", "URL da miniatura (vazio remove)", product.imageUrl, TextInputStyle.Short, false, 1000, "https://...")
      ]));
    }
    if (id.startsWith("admin:product:banner-upload:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.get(productId, gid);
      return i.showModal(modal(`modal:image-url:product-banner:${productId}`, "Banner do produto", [
        input("url", "URL do banner (vazio remove)", product.bannerUrl, TextInputStyle.Short, false, 1000, "https://...")
      ]));
    }
    if (id.startsWith("admin:stock:add:")) {
      const [, , , productId, fieldId] = id.split(":");
      return i.showModal(modal(`modal:stock:add:${productId}:${fieldId}`, "Adicionar stock individual", [input("items", "Itens (linha vazia separa blocos)", "", TextInputStyle.Paragraph, true, 4000, "Uma linha por unidade; use uma linha vazia entre unidades com várias linhas")]));
    }
    if (id.startsWith("admin:stock:ghost:")) {
      const [, , , productId, fieldId] = id.split(":");
      const field = this.products.getField(productId!, fieldId);
      return i.showModal(modal(`modal:stock:ghost:${productId}:${fieldId}`, "Configurar stock fantasma", [
        input("content", "Conteúdo entregue em todas as unidades", "", TextInputStyle.Paragraph, true, 4000),
        input("quantity", "Quantidade disponível", String(Math.max(1, this.products.stockCount(productId!, "AVAILABLE", field.id) || 1)), TextInputStyle.Short, true, 10)
      ]));
    }
    if (id.startsWith("admin:stock:unique:")) {
      const [, , , productId, fieldId] = id.split(":");
      this.products.updateField(productId!, fieldId!, { stockMode: "UNIQUE" }, i.user.id);
      const product = this.products.get(productId!, gid);
      await this.refreshProductPublications(productId!).catch(() => undefined);
      return i.update(this.views.stockView(gid, product, this.products.getField(product.id, fieldId)) as never);
    }
    if (id.startsWith("admin:stock:clear:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      const field = this.products.getField(product.id, fieldId);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Confirmar limpeza").setDescription(`Remover todo o stock disponível de **${product.name} • ${field.name}**?`) ],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:stock:clear-confirm:${product.id}:${field.id}`, "Confirmar", "trash", ButtonStyle.Danger),
          this.views.button(gid, `admin:product:field-stock:${product.id}:${field.id}`, "Cancelar", "back")
        )]
      });
    }
    if (id.startsWith("admin:stock:clear-confirm:")) {
      const [, , , productId, fieldId] = id.split(":");
      const removed = this.products.clearStock(productId!, fieldId!, i.user.id);
      const product = this.products.get(productId!, gid);
      await this.refreshProductPublications(productId!).catch(() => undefined);
      await i.update(this.views.stockView(gid, product, this.products.getField(product.id, fieldId)) as never);
      await i.followUp({ content: `${removed} unidade(s) disponível(is) removida(s).`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id.startsWith("admin:product:update-message:")) {
      const productId = id.split(":")[3]!;
      await i.deferUpdate();
      const result = await this.refreshProductPublications(productId);
      await i.editReply(this.views.productDetail(gid, this.products.get(productId, gid)) as never);
      await i.followUp({ content: `✅ ${result.updated} mensagem(ns) atualizada(s)${result.removed ? `; ${result.removed} vínculo(s) inválido(s) removido(s)` : ""}.`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id.startsWith("admin:product:toggle:")) { const product = this.products.get(id.split(":")[3]!, gid); this.products.update(product.id, { active: !product.active }, i.user.id); return i.update(this.views.productDetail(gid, product) as never); }
    if (id.startsWith("admin:product:featured:")) { const product = this.products.get(id.split(":")[3]!, gid); this.products.update(product.id, { featured: !product.featured }, i.user.id); return i.update(this.views.productDetail(gid, product) as never); }
    if (id.startsWith("admin:product:duplicate:")) { const copy = this.products.duplicate(id.split(":")[3]!, i.user.id); return i.update(this.views.productDetail(gid, copy) as never); }
    if (id.startsWith("admin:product:delete:")) { const product = this.products.get(id.split(":")[3]!, gid); return i.update({ embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Excluir produto").setDescription(`Confirma a exclusão/arquivamento de **${product.name}**?`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:product:delete-confirm:${product.id}`, "Excluir", "product_delete", ButtonStyle.Danger), this.views.button(gid, `admin:product:${product.id}`, "Cancelar", "back"))] }); }
    if (id.startsWith("admin:product:delete-confirm:")) { this.products.delete(id.split(":")[3]!, i.user.id); return i.update(this.views.productsHome(gid) as never); }
    if (id.startsWith("admin:product:publish:")) return i.update(this.views.channelPicker(gid, `admin:product:publish-channel:${id.split(":")[3]}`, "Selecione o canal de publicação") as never);

    if (id === "admin:stock-request:edit") {
      const settings = this.db.guild(gid).stockRequest;
      return i.showModal(modal("modal:stock-request:edit", "Mensagem • Pedir Stock", [
        input("title", "Título", settings.title, TextInputStyle.Short, true, 256),
        input("description", "Descrição", settings.description, TextInputStyle.Paragraph, true, 4000),
        input("footer", "Rodapé", settings.footer, TextInputStyle.Short, false, 2048),
        input("button", "Texto do botão", settings.buttonLabel, TextInputStyle.Short, true, 80),
        input("confirmation", "Confirmação enviada ao cliente", settings.confirmationMessage, TextInputStyle.Paragraph, true, 1500)
      ]));
    }
    if (id === "admin:stock-request:appearance") {
      const settings = this.db.guild(gid).stockRequest;
      return i.showModal(modal("modal:stock-request:appearance", "Aparência • Pedir Stock", [
        input("color", "Cor hexadecimal", settings.color, TextInputStyle.Short, true, 7),
        input("emoji", "Emoji/função", settings.emojiSemantic, TextInputStyle.Short, true, 40),
        input("style", "Estilo: PRIMARY/SECONDARY/SUCCESS/DANGER", settings.buttonStyle, TextInputStyle.Short, true, 12),
        input("image", "URL da imagem (opcional)", settings.imageUrl, TextInputStyle.Paragraph, false, 1000),
        input("thumbnail", "URL da miniatura (opcional)", settings.thumbnailUrl, TextInputStyle.Paragraph, false, 1000)
      ]));
    }
    if (id === "admin:stock-request:image-upload") {
      const current = this.db.guild(gid).stockRequest.imageUrl;
      return i.showModal(modal("modal:image-url:stock-request", "Imagem do painel Pedir Stock", [
        input("url", "URL da imagem (vazio remove)", current, TextInputStyle.Short, false, 1000, "https://...")
      ]));
    }
    if (id === "admin:stock-request:confirmation") {
      const current = this.db.guild(gid).stockRequest.confirmationMessage;
      return i.showModal(modal("modal:stock-request:confirmation", "Confirmação • Pedir Stock", [
        input("confirmation", "Mensagem após enviar solicitação", current, TextInputStyle.Paragraph, true, 1500)
      ]));
    }
    if (id === "admin:stock-request:toggle") {
      this.db.guild(gid).stockRequest.enabled = !this.db.guild(gid).stockRequest.enabled;
      this.db.audit(i.user.id, "STOCK_REQUEST_TOGGLE", "guild", gid, { enabled: this.db.guild(gid).stockRequest.enabled });
      this.db.save();
      this.schedulePublishedRefresh();
      return i.update(this.views.stockRequestsHome(gid) as never);
    }
    if (id === "admin:stock-request:destination") return i.update(this.views.channelPicker(gid, "admin:stock-request:destination-set", "Canal que receberá os pedidos de stock") as never);
    if (id === "admin:stock-request:roles") return i.update(this.views.rolePicker(gid, "admin:stock-request:roles-set", "Cargos notificados nos pedidos", 10) as never);
    if (id === "admin:stock-request:publish") return i.update(this.views.channelPicker(gid, "admin:stock-request:publish-channel", "Canal público do painel Pedir Stock") as never);
    if (id === "admin:stock-request:preview") return i.update(this.views.publicStockRequestPanel(gid, true) as never);
    if (id === "admin:stock-request:list") return i.update(this.views.stockRequestQueue(gid) as never);

    if (id === "admin:saved-emoji:add") return i.showModal(modal("modal:saved-emoji:prepare", "Salvar Emoji na Aplicação", [
      input("name", "Nome do emoji", "meu_emoji", TextInputStyle.Short, true, 32, "produto_vip")
    ]));
    if (id === "admin:saved-emoji:settings") {
      const settings = this.db.guild(gid).emojiLibrary;
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Permissões • Salvar Emojis").setDescription(`Membros comuns: **${settings.allowMembers ? "podem salvar" : "não podem salvar"}**
Limite por membro: **${settings.maxPerUser}**`) ],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:saved-emoji:members-toggle", settings.allowMembers ? "Bloquear membros" : "Permitir membros", settings.allowMembers ? "off" : "on", settings.allowMembers ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, "admin:saved-emoji:limit", "Alterar limite", "settings", ButtonStyle.Primary),
          this.views.button(gid, "admin:saved-emojis", "Voltar", "back", ButtonStyle.Secondary)
        )]
      } as never);
    }
    if (id === "admin:saved-emoji:members-toggle") {
      const settings = this.db.guild(gid).emojiLibrary;
      settings.allowMembers = !settings.allowMembers;
      this.db.audit(i.user.id, "EMOJI_LIBRARY_MEMBER_ACCESS", "guild", gid, { allowMembers: settings.allowMembers });
      this.db.save();
      return i.update(this.views.savedEmojisHome(gid) as never);
    }
    if (id === "admin:saved-emoji:limit") {
      const settings = this.db.guild(gid).emojiLibrary;
      return i.showModal(modal("modal:saved-emoji:limit", "Limite de emojis por membro", [
        input("limit", "Quantidade máxima", String(settings.maxPerUser), TextInputStyle.Short, true, 4)
      ]));
    }
    if (id === "admin:saved-emoji:refresh") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const removed = await this.emojis.reconcileSavedEmojis();
      await i.editReply(`Biblioteca atualizada. Registros inválidos removidos: **${removed}**.`);
      return;
    }
    if (id.startsWith("admin:saved-emoji:copy:")) {
      const item = this.emojis.findSaved(id.split(":")[3]!);
      if (!item) throw new Error("Emoji salvo não encontrado.");
      const mention = this.emojis.mentionSaved(item);
      return i.reply({ content: `**Código pronto para copiar:**\n\`\`\`\n${mention}\n\`\`\`\n**ID:** \`${item.id}\` • **Nome:** \`${item.name}\``, flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("admin:saved-emoji:remove:")) {
      const item = await this.emojis.removeSaved(id.split(":")[3]!, i.user.id, true);
      await i.update(this.views.savedEmojisHome(gid) as never);
      await i.followUp({ content: `${this.emojis.fallback("approve")} Emoji **${item.name}** removido da aplicação.`, flags: MessageFlags.Ephemeral });
      return;
    }

    if (id === "admin:payment:mp") return i.update(this.views.paymentProviderSettings(gid, "MERCADO_PAGO") as never);
    if (id === "admin:payment:mp-configure") {
      const settings = this.db.payments(gid).mercadoPago;
      return i.showModal(modal("modal:payment:mp", "Mercado Pago", [
        input("token", "Access Token (vazio mantém atual)", "", TextInputStyle.Paragraph, false, 500),
        input("pix", "Chave Pix para o botão de copiar", settings.pixKey, TextInputStyle.Short, true, 200),
        input("email", "E-mail padrão do pagador", settings.payerEmail, TextInputStyle.Short, false, 200),
        input("descriptor", "Identificação na fatura", settings.statementDescriptor, TextInputStyle.Short, true, 22)
      ]));
    }
    if (id === "admin:payment:mp-toggle") {
      const settings = this.db.payments(gid).mercadoPago;
      if (!settings.enabled && (!settings.pixKey.trim() || !this.db.getSecret("mp_access_token", gid))) throw new Error("Configure o Access Token e a chave Pix antes de ativar o Mercado Pago.");
      settings.enabled = !settings.enabled;
      this.db.save();
      return i.update(this.views.paymentProviderSettings(gid, "MERCADO_PAGO") as never);
    }
    if (id === "admin:payment:efi") return i.update(this.views.paymentProviderSettings(gid, "EFI_BANK") as never);
    if (id === "admin:payment:efi-configure") {
      const settings = this.db.payments(gid).efiBank;
      return i.showModal(modal("modal:payment:efi", "Efí Bank", [
        input("client", "Client ID (vazio mantém)", "", TextInputStyle.Paragraph, false, 500),
        input("secret", "Client Secret (vazio mantém)", "", TextInputStyle.Paragraph, false, 500),
        input("pix", "Chave PIX", settings.pixKey, TextInputStyle.Short, true, 200),
        input("merchant", "Nome do recebedor", settings.merchantName, TextInputStyle.Short, true, 80),
        input("city", "Cidade do recebedor", settings.merchantCity, TextInputStyle.Short, true, 40)
      ]));
    }
    if (id === "admin:payment:efi-toggle") {
      const settings = this.db.payments(gid).efiBank;
      if (!settings.enabled && (!settings.pixKey.trim() || !this.db.getSecret("efi_client_id", gid) || !this.db.getSecret("efi_client_secret", gid) || !this.db.getSecret("efi_certificate_base64", gid))) throw new Error("Configure a chave Pix, as credenciais e o certificado antes de ativar a Efí.");
      settings.enabled = !settings.enabled;
      this.db.save();
      return i.update(this.views.paymentProviderSettings(gid, "EFI_BANK") as never);
    }
    if (id === "admin:payment:efi-environment") {
      const settings = this.db.payments(gid).efiBank;
      settings.sandbox = !settings.sandbox;
      this.db.save();
      return i.update(this.views.paymentProviderSettings(gid, "EFI_BANK") as never);
    }
    if (id === "admin:payment:efi-cert") return this.collectCertificate(i);
    if (id === "admin:payment:evopay") return i.update(this.views.evoPaySettingsHome(gid) as never);
    if (id === "admin:payment:evopay-token") {
      return i.showModal(modal("modal:payment:evopay-token", "EvoPay • credencial", [
        input("token", "Token Bearer (vazio mantém o atual)", "", TextInputStyle.Paragraph, false, 1000)
      ]));
    }
    if (id === "admin:payment:evopay-expiry") {
      return i.showModal(modal("modal:payment:evopay-expiry", "EvoPay • validade do PIX", [
        input("expires", "Validade em segundos", String(this.db.payments(gid).evoPay.expiresIn), TextInputStyle.Short, true, 5, "Entre 180 e 7200 segundos")
      ]));
    }
    if (id === "admin:payment:evopay-toggle") {
      const settings = this.db.payments(gid).evoPay;
      if (!settings.enabled && !this.db.getSecret("evopay_token", gid)) throw new Error("Configure o token da forma de pagamento automática antes de ativar.");
      settings.enabled = !settings.enabled;
      this.db.save();
      return i.update(this.views.evoPaySettingsHome(gid) as never);
    }
    if (id === "admin:payment:evopay-test") {
      if (!this.db.getSecret("evopay_token", gid)) throw new Error("Configure o token antes de testar a conexão.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const result = await this.payments.test(gid, "EVO_PAY");
        await i.editReply(`${this.emojis.fallback("approve")} Conexão do PIX automático validada: ${result}`);
      } catch (error) {
        this.logger.warn("Falha no teste do gateway PIX automático.", { guildId: gid, error: String(error) });
        await i.editReply("Não foi possível validar a conexão. Confira a credencial e tente novamente.");
      }
      return;
    }
    if (id === "admin:payment:znypay") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Znypay está indisponível no momento pelo ZENYX Manager.");
      return i.update(this.views.znyPaySettingsHome(gid) as never);
    }
    if (id === "admin:payment:znypay-toggle") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Znypay está indisponível no momento pelo ZENYX Manager.");
      const settings = this.db.payments(gid).znyPay;
      if (!settings.enabled && !String(process.env.ZNYPAY_EVOPAY_TOKEN ?? "").trim()) {
        throw new Error("O gateway central do Znypay ainda não foi configurado no /botconfig do ZENYX Manager.");
      }
      settings.enabled = !settings.enabled;
      this.db.save();
      return i.update(this.views.znyPaySettingsHome(gid) as never);
    }
    if (id === "admin:payment:stripe") return i.update(this.views.paymentProviderSettings(gid, "STRIPE") as never);
    if (id === "admin:payment:stripe-configure") {
      const settings = this.db.payments(gid).stripe;
      return i.showModal(modal("modal:payment:stripe", "Stripe PIX", [
        input("key", "Secret Key (vazio mantém a atual)", "", TextInputStyle.Paragraph, false, 500),
        input("descriptor", "Identificação da cobrança", settings.statementDescriptor, TextInputStyle.Short, true, 22),
        input("webhook", "URL pública do webhook (opcional)", settings.webhookUrl, TextInputStyle.Short, false, 500)
      ]));
    }
    if (id === "admin:payment:mistic") return i.update(this.views.paymentProviderSettings(gid, "MISTIC_PAY") as never);
    if (id === "admin:payment:mistic-configure") {
      const settings = this.db.payments(gid).misticPay;
      return i.showModal(modal("modal:payment:mistic", "MisticPay", [
        input("client", "Client ID (vazio mantém o atual)", "", TextInputStyle.Paragraph, false, 500),
        input("secret", "Client Secret (vazio mantém o atual)", "", TextInputStyle.Paragraph, false, 500),
        input("webhook", "URL pública do webhook (opcional)", settings.webhookUrl, TextInputStyle.Short, false, 500)
      ]));
    }
    if (id === "admin:payment:purin") return i.update(this.views.paymentProviderSettings(gid, "PURIN_CASH") as never);
    if (id === "admin:payment:purin-configure") {
      const settings = this.db.payments(gid).purinCash;
      return i.showModal(modal("modal:payment:purin", "Purin Cash", [
        input("key", "API Key ps_live_ ou ps_test_ (vazio mantém)", "", TextInputStyle.Paragraph, false, 500),
        input("callback", "Callback HTTPS público (opcional)", settings.callbackUrl, TextInputStyle.Short, false, 500)
      ]));
    }
    if (id === "admin:payment:stripe-toggle") {
      const settings = this.db.payments(gid).stripe;
      if (!settings.enabled && !this.db.getSecret("stripe_secret_key", gid)) throw new Error("Configure a Secret Key da Stripe antes de ativar.");
      settings.enabled = !settings.enabled; this.db.save(); return i.update(this.views.paymentProviderSettings(gid, "STRIPE") as never);
    }
    if (id === "admin:payment:mistic-toggle") {
      const settings = this.db.payments(gid).misticPay;
      if (!settings.enabled && (!this.db.getSecret("mistic_client_id", gid) || !this.db.getSecret("mistic_client_secret", gid))) throw new Error("Configure Client ID e Client Secret da MisticPay antes de ativar.");
      settings.enabled = !settings.enabled; this.db.save(); return i.update(this.views.paymentProviderSettings(gid, "MISTIC_PAY") as never);
    }
    if (id === "admin:payment:purin-toggle") {
      const settings = this.db.payments(gid).purinCash;
      if (!settings.enabled && !this.db.getSecret("purin_api_key", gid)) throw new Error("Configure a API Key da Purin Cash antes de ativar.");
      settings.enabled = !settings.enabled; this.db.save(); return i.update(this.views.paymentProviderSettings(gid, "PURIN_CASH") as never);
    }
    if (id === "admin:payment:test-api") {
      const methods = this.payments.enabledMethods(gid).filter((provider) => !["IMAP_PIX", "MANUAL_PIX"].includes(provider));
      if (!methods.length) throw new Error("Ative pelo menos um gateway de API para testar.");
      const labels: Record<string, string> = { MERCADO_PAGO: "Mercado Pago", EFI_BANK: "Efí Bank", STRIPE: "Stripe PIX", MISTIC_PAY: "MisticPay", PURIN_CASH: "Purin Cash", EVO_PAY: "EvoPay PIX", ZNY_PAY: "Znypay" };
      const select = new StringSelectMenuBuilder().setCustomId("admin:payment:test-api-select").setPlaceholder("Escolha o gateway que será testado").addOptions(methods.map((provider) => new StringSelectMenuOptionBuilder().setLabel(labels[provider] ?? provider).setValue(provider)));
      return i.update({ embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Teste seguro de gateway").setDescription("O teste valida as credenciais e a comunicação sem criar uma cobrança.")], components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select), this.views.back(gid, "admin:payments")] } as never);
    }
    if (id === "admin:payment:imap") return i.update(this.views.imapSettingsHome(gid) as never);
    if (id === "admin:payment:imap-account") {
      const settings = this.db.payments(gid).imapPix;
      return i.showModal(modal("modal:payment:imap-account", "IMAP e chave PIX por e-mail", [
        input("user", "E-mail da caixa e da chave PIX", settings.username || settings.pixKey, TextInputStyle.Short, true, 200),
        input("password", "Senha de aplicativo (vazio mantém)", "", TextInputStyle.Paragraph, false, 500, "Use uma senha de aplicativo, não a senha principal")
      ]));
    }
    if (id === "admin:payment:imap-pix") {
      const settings = this.db.payments(gid).imapPix;
      return i.showModal(modal("modal:payment:imap-pix", "Dados do PIX", [
        input("key", "Chave PIX", settings.pixKey, TextInputStyle.Short, true, 200),
        input("merchant", "Nome do recebedor", settings.merchantName, TextInputStyle.Short, true, 80),
        input("city", "Cidade do recebedor", settings.merchantCity, TextInputStyle.Short, true, 40)
      ]));
    }
    if (id === "admin:payment:imap-timing") {
      const settings = this.db.payments(gid).imapPix;
      return i.showModal(modal("modal:payment:imap-timing", "Tempo de verificação", [
        input("poll", "Verificar a cada quantos segundos", String(settings.pollIntervalSeconds), TextInputStyle.Short, true, 5),
        input("lookback", "Buscar e-mails dos últimos minutos", String(settings.lookbackMinutes), TextInputStyle.Short, true, 6),
        input("maxwait", "Tempo máximo para pagamento (minutos)", String(settings.maxWaitMinutes), TextInputStyle.Short, true, 6),
        input("mailbox", "Pasta do e-mail", settings.mailbox, TextInputStyle.Short, true, 100)
      ]));
    }
    if (id === "admin:payment:imap-custom-server") {
      const settings = this.db.payments(gid).imapPix;
      return i.showModal(modal("modal:payment:imap-custom-server", "Servidor IMAP personalizado", [
        input("host", "Servidor IMAP", settings.host, TextInputStyle.Short, true, 200),
        input("port", "Porta", String(settings.port), TextInputStyle.Short, true, 5)
      ]));
    }
    if (id === "admin:payment:imap-toggle") {
      const settings = this.db.payments(gid).imapPix;
      if (!settings.enabled && (!settings.username || !settings.pixKey || !this.db.getSecret("imap_password", gid))) throw new Error("Configure a conta de e-mail, a senha de aplicativo e a chave PIX antes de ativar.");
      settings.enabled = !settings.enabled;
      this.db.save();
      this.imap.start();
      return i.update(this.views.imapSettingsHome(gid) as never);
    }
    if (id === "admin:payment:imap-seen-toggle") {
      const settings = this.db.payments(gid).imapPix;
      settings.markSeen = !settings.markSeen;
      this.db.save();
      return i.update(this.views.imapSettingsHome(gid) as never);
    }
    if (id === "admin:payment:imap-test") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const result = await this.imap.testConnection(gid);
      await i.editReply(`✅ ${result}`);
      return;
    }
    if (id === "admin:payment:manual") {
      const settings = this.db.payments(gid);
      return i.showModal(modal("modal:payment:manual", "PIX manual", [
        input("key", "Chave PIX", settings.manualPixKey, TextInputStyle.Short, true, 200, "E-mail, CPF/CNPJ, telefone ou chave aleatória")
      ]));
    }
    if (id === "admin:payment:general") return i.showModal(modal("modal:payment:general", "Prazos e consultas", [
      input("expiration", "Expiração do pedido em minutos", String(this.db.payments(gid).orderExpiresMinutes), TextInputStyle.Short, true, 5),
      input("poll", "Consulta API em segundos", String(this.db.payments(gid).pollIntervalSeconds), TextInputStyle.Short, true, 5)
    ]));
    if (id === "admin:payment:efi-certpass") return i.showModal(modal("modal:payment:efi-certpass", "Senha do certificado Efí", [input("password", "Senha do P12/PFX (vazio remove)", "", TextInputStyle.Paragraph, false, 500)]));
    if (id === "admin:payment:provider") {
      const select = new StringSelectMenuBuilder().setCustomId("admin:payment:provider-select").setPlaceholder("Provedor padrão").addOptions([
        ["Mercado Pago", "MERCADO_PAGO", "mercadopago"], ["Efí Bank", "EFI_BANK", "efibank"], ["Stripe PIX", "STRIPE", "payment"], ["MisticPay", "MISTIC_PAY", "pix"], ["Purin Cash", "PURIN_CASH", "payment"], ["EvoPay PIX", "EVO_PAY", "pix"], ["Znypay", "ZNY_PAY", "wallet"], ["IMAP PIX", "IMAP_PIX", "imap"], ["PIX manual", "MANUAL_PIX", "manual"]
      ].map(([label, value, em]) => new StringSelectMenuOptionBuilder().setLabel(label!).setValue(value!).setEmoji(this.emojis.component(em!, gid)).setDefault(this.db.payments(gid).defaultProvider === value)));
      return i.update({ embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Provedor padrão").setDescription("Escolha o método usado no checkout.")], components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select), this.views.back(gid, "admin:payments")] });
    }
    if (id === "admin:payment:test") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const result = await this.imap.testConnection(gid);
      await i.editReply(`✅ ${result}`);
      return;
    }

    if (/^admin:emoji:mapping:\d+$/.test(id)) return i.update(this.emojiFunctionPicker(gid, Number(id.split(":")[3] ?? 0)) as never);
    if (/^admin:emoji:catalog:\d+$/.test(id)) return i.update(this.emojiAssetPicker(gid, "catalog", Number(id.split(":")[3] ?? 0)) as never);
    if (/^admin:emoji:assets:[^:]+:\d+$/.test(id)) {
      const [, , , functional, pageRaw] = id.split(":");
      return i.update(this.emojiAssetPicker(gid, "mapping", Number(pageRaw ?? 0), { functional }) as never);
    }
    if (id.startsWith("admin:emoji:function:")) return i.update(this.emojiFunctionDetail(gid, id.split(":")[3]!) as never);
    if (id.startsWith("admin:emoji:reset:")) {
      const semantic = id.split(":")[3]!;
      this.db.updateGuild(gid, (guild) => { delete guild.emojiOverrides[semantic]; });
      return i.update(this.emojiFunctionDetail(gid, semantic) as never);
    }
    if (id === "admin:emoji:sync") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      await this.emojis.syncAutomatic(true);
      const refreshed = await this.refreshPublishedMessages();
      await i.editReply(`Sincronização concluída: **${this.emojis.status.installed}/${this.emojis.status.total}** emojis registrados e **${refreshed}** mensagens publicadas atualizadas.`);
      return;
    }
    if (id === "admin:emoji:remove") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const count = await this.emojis.removeAll();
      await i.editReply(`${count} emojis do pacote da aplicação removidos. O bot continuará funcionando com emojis Unicode até uma nova sincronização.`);
      return;
    }

    if (id === "admin:ticket:create") return i.showModal(modal("modal:ticket:create", "Criar painel de ticket", [
      input("name", "Nome interno", "Atendimento", TextInputStyle.Short, true, 80),
      input("title", "Título público", this.db.brand(gid).ticketTitle, TextInputStyle.Short, true, 256),
      input("description", "Descrição pública", this.db.brand(gid).ticketDescription, TextInputStyle.Paragraph, true, 4000),
      input("color", "Cor hexadecimal", this.db.brand(gid).color, TextInputStyle.Short, true, 7)
    ]));
    if (id.startsWith("admin:ticket:fields:")) return i.update(this.views.ticketPanelFieldsView(gid, this.tickets.resolvePanel(id.split(":")[3]!, gid)) as never);
    if (id.startsWith("admin:ticket:field-add:")) {
      const panelId = id.split(":")[3]!;
      return i.showModal(modal(`modal:ticket:field-add:${panelId}`, "Adicionar campo ao painel", [
        input("name", "Título do campo", "Informação", TextInputStyle.Short, true, 256),
        input("value", "Conteúdo do campo", "Descreva aqui uma informação importante para o cliente.", TextInputStyle.Paragraph, true, 1024)
      ]));
    }
    if (id.startsWith("admin:ticket:field-edit:")) {
      const [, , , panelId, fieldId] = id.split(":");
      const panel = this.tickets.getPanelForField(panelId!, fieldId!, gid);
      const field = panel.fields.find((item) => item.id === fieldId);
      if (!field) throw new Error("Campo do painel não encontrado.");
      return i.showModal(modal(`modal:ticket:field-edit:${panelId}:${fieldId}`, "Editar campo do painel", [
        input("name", "Título do campo", field.name, TextInputStyle.Short, true, 256),
        input("value", "Conteúdo do campo", field.value, TextInputStyle.Paragraph, true, 1024)
      ]));
    }
    if (id.startsWith("admin:ticket:field-inline:")) {
      const [, , , panelId, fieldId] = id.split(":");
      const panel = this.tickets.getPanelForField(panelId!, fieldId!, gid);
      const field = panel.fields.find((item) => item.id === fieldId);
      if (!field) throw new Error("Campo do painel não encontrado.");
      this.tickets.updatePanelField(panel.id, fieldId!, { inline: !field.inline }, i.user.id, gid);
      return i.update(this.views.ticketPanelFieldDetail(gid, panel, field) as never);
    }
    if (id.startsWith("admin:ticket:field-delete:")) {
      const [, , , panelId, fieldId] = id.split(":");
      const panel = this.tickets.getPanelForField(panelId!, fieldId!, gid);
      this.tickets.deletePanelField(panel.id, fieldId!, i.user.id, gid);
      return i.update(this.views.ticketPanelFieldsView(gid, panel) as never);
    }
    if (/^admin:ticket:[^:]+$/.test(id)) return i.update(this.views.ticketPanelDetail(gid, this.tickets.resolvePanel(id.split(":")[2]!, gid)) as never);
    if (/^admin:ticket:emoji:[^:]+:\d+$/.test(id)) {
      const [, , , panelId, pageRaw] = id.split(":");
      return i.update(this.emojiAssetPicker(gid, "ticket-panel", Number(pageRaw ?? 0), { panelId }) as never);
    }
    if (/^admin:ticket:option-emoji:[^:]+:[^:]+:\d+$/.test(id)) {
      const [, , , panelId, optionId, pageRaw] = id.split(":");
      return i.update(this.emojiAssetPicker(gid, "ticket-option", Number(pageRaw ?? 0), { panelId, optionId }) as never);
    }
    if (id.startsWith("admin:ticket:mode-toggle:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.resolvePanel(panelId, gid);
      const updated = this.tickets.updatePanel(panel.id, { mode: panel.mode === "SELECT" ? "BUTTONS" : "SELECT" }, i.user.id);
      return i.update(this.views.ticketPanelDetail(gid, updated) as never);
    }
    if (id.startsWith("admin:ticket:option-edit:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const option = panel.options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      return i.showModal(modal(`modal:ticket:option-edit:${panelId}:${optionId}`, "Textos da opção", [
        input("name", "Nome da opção", option.name, TextInputStyle.Short, true, 100),
        input("description", "Descrição no menu", option.description, TextInputStyle.Short, true, 100),
        input("prefix", "Prefixo do canal", option.channelPrefix, TextInputStyle.Short, true, 40),
        input("opening_title", "Título da mensagem inicial", option.openingTitle, TextInputStyle.Short, true, 256),
        input("opening_description", "Mensagem inicial", option.openingDescription, TextInputStyle.Paragraph, true, 4000)
      ]));
    }
    if (id.startsWith("admin:ticket:option-close-message:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const option = panel.options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      return i.showModal(modal(`modal:ticket:option-close-message:${panelId}:${optionId}`, "Mensagem de encerramento", [
        input("close", "Mensagem ao fechar", option.closeMessage, TextInputStyle.Paragraph, true, 1800)
      ]));
    }
    if (id.startsWith("admin:ticket:option-limit:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const option = panel.options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      return i.showModal(modal(`modal:ticket:option-limit:${panelId}:${optionId}`, "Limite por usuário", [
        input("limit", "Tickets simultâneos (1 a 10)", String(option.maxOpenTicketsPerUser), TextInputStyle.Short, true, 2)
      ]));
    }
    if (id.startsWith("admin:ticket:option-emoji-manual:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const option = panel.options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      return i.showModal(modal(`modal:ticket:option-emoji-manual:${panelId}:${optionId}`, "Emoji da opção", [
        input("emoji", "Emoji, menção ou ID", option.emojiSemantic, TextInputStyle.Short, true, 120, "🛠️ ou <:nome:123456789012345678>")
      ]));
    }
    if (id.startsWith("admin:ticket:option-emoji-clear:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, { emojiSemantic: "" }, i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:ticket:option-category-clear:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, { categoryId: "" }, i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:ticket:option-category:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const select = new ChannelSelectMenuBuilder()
        .setCustomId(`admin:ticket:option-category-set:${panelId}:${optionId}`)
        .setPlaceholder("Escolha a categoria do ticket")
        .setChannelTypes(ChannelType.GuildCategory)
        .setMinValues(1)
        .setMaxValues(1);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Categoria da opção").setDescription("Selecione onde os tickets desta opção serão criados. Sem categoria própria, a opção utiliza a categoria geral de tickets.")],
        components: [
          new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(select),
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            this.views.button(gid, `admin:ticket:option-category-clear:${panelId}:${optionId}`, "Usar categoria geral", "minus", ButtonStyle.Secondary),
            this.views.button(gid, `admin:ticket:options:${panelId}`, "Voltar", "back")
          )
        ]
      });
    }
    if (id.startsWith("admin:ticket:option-roles-clear:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, { supportRoleIds: [] }, i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:ticket:option-roles:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const select = new RoleSelectMenuBuilder()
        .setCustomId(`admin:ticket:option-roles-set:${panelId}:${optionId}`)
        .setPlaceholder("Escolha os cargos responsáveis")
        .setMinValues(0)
        .setMaxValues(20);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Equipe responsável").setDescription("Selecione os cargos que terão acesso aos tickets desta opção. Sem cargos próprios, a opção utiliza a equipe geral configurada no servidor.")],
        components: [
          new ActionRowBuilder<RoleSelectMenuBuilder>().addComponents(select),
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            this.views.button(gid, `admin:ticket:option-roles-clear:${panelId}:${optionId}`, "Usar equipe geral", "minus", ButtonStyle.Secondary),
            this.views.button(gid, `admin:ticket:options:${panelId}`, "Voltar", "back")
          )
        ]
      });
    }
    if (id.startsWith("admin:ticket:option-toggle:")) {
      const [, , , panelId, optionId, field] = id.split(":");
      const option = this.tickets.getPanelForOption(panelId!, optionId!, gid).options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      if (field === "active") this.tickets.updateOption(panelId!, optionId!, { active: !option.active }, i.user.id, gid);
      else if (field === "subject") this.tickets.updateOption(panelId!, optionId!, { askSubject: !option.askSubject }, i.user.id, gid);
      else if (field === "mention") this.tickets.updateOption(panelId!, optionId!, { mentionSupport: !option.mentionSupport }, i.user.id, gid);
      else throw new Error("Configuração de opção inválida.");
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:ticket:option-move:")) {
      const [, , , panelId, optionId, direction] = id.split(":");
      this.tickets.moveOption(panelId!, optionId!, direction === "up" ? "UP" : "DOWN", i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:ticket:basic:")) {
      const panel = this.tickets.resolvePanel(id.split(":")[3]!, gid);
      return i.showModal(modal(`modal:ticket:basic:${panel.id}`, "Mensagem do painel", [
        input("title", "Título", panel.title, TextInputStyle.Short, true, 256),
        input("description", "Descrição", panel.description, TextInputStyle.Paragraph, true, 4000),
        input("color", "Cor hexadecimal", panel.color, TextInputStyle.Short, true, 7),
        input("footer", "Rodapé", panel.footer, TextInputStyle.Short, false, 200),
        input("label", panel.mode === "SELECT" ? "Texto do menu" : "Texto padrão dos botões", panel.buttonLabel, TextInputStyle.Short, true, 100)
      ]));
    }
    if (id.startsWith("admin:ticket:option:add:")) {
      const panelId = this.tickets.resolvePanel(id.split(":")[4]!, gid).id;
      return i.showModal(modal(`modal:ticket:option-add:${panelId}`, "Adicionar opção", [
        input("name", "Nome da opção", "Suporte", TextInputStyle.Short, true, 100),
        input("description", "Descrição no menu", "Falar com nossa equipe", TextInputStyle.Short, true, 100),
        input("prefix", "Prefixo do canal", "ticket", TextInputStyle.Short, true, 40),
        input("opening_title", "Título da mensagem inicial", "Atendimento aberto", TextInputStyle.Short, true, 256),
        input("opening_description", "Mensagem inicial", "Explique com detalhes como podemos ajudar.", TextInputStyle.Paragraph, true, 4000)
      ]));
    }
    if (id.startsWith("admin:ticket:options:")) return i.update(this.ticketOptionsView(gid, this.tickets.resolvePanel(id.split(":")[3]!, gid)) as never);
    if (id.startsWith("admin:ticket:publish:")) return i.update(this.views.channelPicker(gid, `admin:ticket:publish-channel:${id.split(":")[3]}`, "Selecione o canal do painel") as never);
    if (id.startsWith("admin:ticket:image-upload:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.resolvePanel(panelId, gid);
      return i.showModal(modal(`modal:image-url:ticket-banner:${panel.id}`, "Banner do painel de ticket", [
        input("url", "URL do banner (vazio remove)", panel.imageUrl, TextInputStyle.Short, false, 1000, "https://...")
      ]));
    }
    if (id.startsWith("admin:ticket:thumb-upload:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.resolvePanel(panelId, gid);
      return i.showModal(modal(`modal:image-url:ticket-thumb:${panel.id}`, "Miniatura do painel de ticket", [
        input("url", "URL da miniatura (vazio remove)", panel.thumbnailUrl, TextInputStyle.Short, false, 1000, "https://...")
      ]));
    }
    if (id.startsWith("admin:ticket:delete-request:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.resolvePanel(panelId, gid);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Excluir painel de tickets?").setDescription(`O painel **${panel.name}** e suas opções serão removidos da configuração. Mensagens já publicadas não serão apagadas automaticamente.`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:delete:${panel.id}`, "Confirmar exclusão", "trash", ButtonStyle.Danger),
          this.views.button(gid, `admin:ticket:${panel.id}`, "Cancelar", "back", ButtonStyle.Secondary)
        )]
      });
    }
    if (id.startsWith("admin:ticket:option-delete-request:")) {
      let [, , , panelId, optionId] = id.split(":");
      const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid);
      panelId = panel.id;
      const option = panel.options.find((item) => item.id === optionId);
      if (!option) throw new Error("Opção não encontrada.");
      return i.update({
        embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Excluir opção de atendimento?").setDescription(`A opção **${option.name}** será removida do painel. Tickets já abertos continuarão registrados no histórico.`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:option-delete:${panelId}:${optionId}`, "Confirmar exclusão", "trash", ButtonStyle.Danger),
          this.views.button(gid, `admin:ticket:options:${panelId}`, "Cancelar", "back", ButtonStyle.Secondary)
        )]
      });
    }
    if (id.startsWith("admin:ticket:delete:")) { const panel = this.tickets.resolvePanel(id.split(":")[3]!, gid); this.tickets.deletePanel(panel.id, i.user.id); return i.update(this.views.ticketPanelsHome(gid) as never); }
    if (id.startsWith("admin:ticket:option-delete:")) { const [, , , panelId, optionId] = id.split(":"); const panel = this.tickets.getPanelForOption(panelId!, optionId!, gid); this.tickets.deleteOption(panel.id, optionId!, i.user.id, gid); return i.update(this.ticketOptionsView(gid, panel) as never); }

    if (id === "admin:brand:edit") { const b = this.db.brand(gid); return i.showModal(modal("modal:brand:edit", "Identidade visual", [input("name", "Nome do bot/marca", b.name, TextInputStyle.Short, true, 80), input("color", "Cor principal", b.color, TextInputStyle.Short, true, 7), input("footer", "Rodapé", b.footer, TextInputStyle.Short, true, 200), input("logo", "URL do logo", b.logoUrl, TextInputStyle.Short, false, 500), input("banner", "URL do banner", b.bannerUrl, TextInputStyle.Short, false, 500)])); }
    if (id === "admin:brand:accent-toggle") {
      const b = this.db.brand(gid);
      b.showAccentColors = !b.showAccentColors;
      this.db.save();
      return i.update(this.personalizeView(gid) as never);
    }
    if (id === "admin:store:edit") { const b = this.db.brand(gid); return i.showModal(modal("modal:store:edit", "Mensagem da loja", [input("title", "Título", b.storeTitle, TextInputStyle.Short, true, 256), input("description", "Descrição", b.storeDescription, TextInputStyle.Paragraph, true, 4000)])); }
    if (id === "admin:presence:edit") { const b = this.db.brand(gid); return i.showModal(modal("modal:presence:edit", "Presença do bot", [input("text", "Texto da atividade", b.presenceText, TextInputStyle.Short, true, 128), input("type", "Playing/Watching/Listening/Competing", b.presenceType, TextInputStyle.Short, true, 20), input("status", "online/idle/dnd/invisible", b.status, TextInputStyle.Short, true, 10)])); }
    if (id === "admin:bot:bio") {
      // Compatibilidade com mensagens antigas da R18.9.16 ("Bio protegida / Sobre mim").
      // Em bot filho a Bio deixou de ser personalizável: clicar aqui apenas restaura
      // a identidade oficial, nunca abre um editor.
      const confirmed = await this.restoreLockedInstitutionalBio(gid);
      return i.reply({ content: `🔒 **Bio ZENYX bloqueada para bots filhos.**\nNinguém pode trocar/remover esta Bio pelo /painel. A identidade oficial foi restaurada e confirmada pelo Discord (**${confirmed.length}/400**).\n\n${confirmed}`, flags: MessageFlags.Ephemeral });
    }
    if (id === "admin:bot:bio-sync") {
      const confirmed = await this.restoreLockedInstitutionalBio(gid);
      return i.reply({ content: `✅ **Bio institucional ZENYX restaurada e confirmada pelo Discord.**\nA Application retornou exatamente **${confirmed.length} caracteres**.`, flags: MessageFlags.Ephemeral });
    }
    if (id === "admin:bot:bio-check") {
      const expected = await this.lockedInstitutionalBio();
      let remote = await this.fetchDiscordApplicationDescription();
      let repaired = false;
      if (remote !== expected) {
        remote = await this.restoreLockedInstitutionalBio(gid);
        repaired = true;
      }
      return i.reply({ content: `✅ **Verificação da Bio protegida**\nEsperada: **${expected.length} caracteres**\nDiscord: **${remote.length} caracteres**\nStatus: **institucional, sincronizada e bloqueada**${repaired ? "\nA Bio estava diferente/vazia e foi restaurada automaticamente." : ""}\n\nDescrição confirmada pelo Discord:\n${remote}`, flags: MessageFlags.Ephemeral });
    }
    if (id === "admin:bot:identity") return i.showModal(modal("modal:bot:identity", "Nome do bot", [input("username", "Novo nome do bot", this.client.user?.username ?? "Minha Aplicação", TextInputStyle.Short, true, 32)]));
    if (id === "admin:bot:avatar") return this.collectAvatar(i);
    if (id === "admin:brand:logo-upload") return i.showModal(modal("modal:image-url:brand-logo", "Logo da identidade visual", [input("url", "URL do logo (vazio remove)", this.db.brand(gid).logoUrl, TextInputStyle.Short, false, 1000, "https://...")]));
    if (id === "admin:brand:banner-upload") return i.showModal(modal("modal:image-url:brand-banner", "Banner da identidade visual", [input("url", "URL do banner (vazio remove)", this.db.brand(gid).bannerUrl, TextInputStyle.Short, false, 1000, "https://...")]));

    if (id === "admin:message:create") return i.showModal(this.botMessageBasicModal());
    if (id.startsWith("admin:message:basic:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      return i.showModal(this.botMessageBasicModal(template));
    }
    if (id.startsWith("admin:message:visual:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      return i.showModal(modal(`modal:message:visual:${template.id}`, "Visual da mensagem", [
        input("banner", "URL do banner", template.bannerUrl, TextInputStyle.Short, false, 1000),
        input("thumbnail", "URL da miniatura", template.thumbnailUrl, TextInputStyle.Short, false, 1000),
        input("footer", "Rodapé", template.footer, TextInputStyle.Short, false, 1900)
      ]));
    }
    if (id.startsWith("admin:message:link-add:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      if (template.links.length >= 5) throw new Error("A mensagem já possui o limite de 5 botões de link.");
      return i.showModal(modal(`modal:message:link-add:${template.id}`, "Adicionar botão de link", [
        input("label", "Texto do botão", "Abrir link", TextInputStyle.Short, true, 80),
        input("url", "URL do botão", "https://", TextInputStyle.Short, true, 1000),
        input("emoji", "Emoji, ID ou nome salvo", "link", TextInputStyle.Short, false, 120)
      ]));
    }
    if (id.startsWith("admin:message:links-clear:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      template.links = [];
      template.updatedAt = nowIso();
      this.db.audit(i.user.id, "BOT_MESSAGE_LINKS_CLEAR", "message_template", template.id, { guildId: gid }, gid);
      this.db.save();
      return i.update(this.botMessageDetail(gid, template.id) as never);
    }
    if (id.startsWith("admin:message:publish:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      return i.update({
        embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`Publicar • ${template.name}`).setDescription("Selecione o canal. Se este modelo já estiver publicado no canal escolhido, a mensagem existente será atualizada.")],
        components: [
          new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId(`admin:message:publish-channel:${template.id}`).setPlaceholder("Selecione o canal").setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1)),
          new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:message:${template.id}`, "Cancelar", "back"))
        ]
      } as never);
    }
    if (id.startsWith("admin:message:preview:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      return i.reply({ ...this.views.botMessage(gid, template), flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral } as never);
    }
    if (id.startsWith("admin:message:delete:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      delete this.db.state.messageTemplates[template.id];
      this.db.audit(i.user.id, "BOT_MESSAGE_DELETE", "message_template", template.id, { guildId: gid }, gid);
      this.db.save();
      return i.update(this.botMessagesView(gid) as never);
    }
    if (/^admin:message:[A-Za-z0-9_-]+$/.test(id)) return i.update(this.botMessageDetail(gid, id.split(":")[2]!) as never);

    if (id === "admin:automations:repeat") return i.update(this.repeatingMessagesView(gid) as never);
    if (id === "admin:automations:mention") return i.update(this.mentionMessagesView(gid) as never);
    if (id === "admin:automations:reaction") return i.update(this.autoReactionsView(gid) as never);
    if (id.startsWith("admin:automations:repeat-page:")) return i.update(this.repeatingMessagesView(gid, Number(id.split(":")[3]) || 0) as never);
    if (id.startsWith("admin:automations:mention-page:")) return i.update(this.mentionMessagesView(gid, Number(id.split(":")[3]) || 0) as never);
    if (id.startsWith("admin:automations:reaction-page:")) return i.update(this.autoReactionsView(gid, Number(id.split(":")[3]) || 0) as never);
    if (id === "admin:automations:repeat-add") return i.showModal(this.repeatingMessageModal());
    if (id === "admin:automations:mention-add") return i.showModal(this.mentionMessageModal());
    if (id === "admin:automations:reaction-add") return i.showModal(this.autoReactionModal());

    if (id.startsWith("admin:automations:repeat-edit:")) {
      const rule = this.db.automations(gid).repeatingMessages.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Mensagem recorrente não encontrada.");
      return i.showModal(this.repeatingMessageModal(rule.id, rule));
    }
    if (id.startsWith("admin:automations:mention-edit:")) {
      const rule = this.db.automations(gid).mentionMessages.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Mensagem com menção não encontrada.");
      return i.showModal(this.mentionMessageModal(rule.id, rule));
    }
    if (id.startsWith("admin:automations:reaction-edit:")) {
      const rule = this.db.automations(gid).autoReactions.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Reação automática não encontrada.");
      return i.showModal(this.autoReactionModal(rule.id, rule));
    }

    if (id.startsWith("admin:automations:repeat-toggle:")) {
      const rule = this.db.automations(gid).repeatingMessages.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Mensagem recorrente não encontrada.");
      if (!rule.channelId && !rule.enabled) throw new Error("Escolha o canal antes de ativar esta mensagem.");
      rule.enabled = !rule.enabled; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.repeatingMessageDetail(gid, rule.id) as never);
    }
    if (id.startsWith("admin:automations:mention-toggle:")) {
      const rule = this.db.automations(gid).mentionMessages.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Mensagem com menção não encontrada.");
      if (!rule.channelId && !rule.enabled) throw new Error("Escolha o canal antes de ativar esta mensagem.");
      rule.enabled = !rule.enabled; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.mentionMessageDetail(gid, rule.id) as never);
    }
    if (id.startsWith("admin:automations:reaction-toggle:")) {
      const rule = this.db.automations(gid).autoReactions.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Reação automática não encontrada.");
      if ((!rule.channelId || !rule.emojiId) && !rule.enabled) throw new Error("Escolha o canal e configure o emoji antes de ativar.");
      rule.enabled = !rule.enabled; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.autoReactionDetail(gid, rule.id) as never);
    }

    if (id.startsWith("admin:automations:repeat-channel:")) return i.update(this.automationRuleChannelPicker(gid, "repeat", id.split(":")[3]!) as never);
    if (id.startsWith("admin:automations:mention-channel:")) return i.update(this.automationRuleChannelPicker(gid, "mention", id.split(":")[3]!) as never);
    if (id.startsWith("admin:automations:reaction-channel:")) return i.update(this.automationRuleChannelPicker(gid, "reaction", id.split(":")[3]!) as never);
    if (id.startsWith("admin:automations:reaction-emoji:")) {
      const parts = id.split(":");
      const ruleId = parts[3]!;
      const page = Math.max(0, Number(parts[4]) || 0);
      await i.guild?.emojis.fetch().catch(() => undefined);
      return i.update(this.guildReactionEmojiPicker(gid, ruleId, page) as never);
    }
    if (id.startsWith("admin:automations:reaction-emoji-search:")) {
      const ruleId = id.split(":")[3]!;
      return i.showModal(modal(`modal:automations:reaction-emoji-search:${ruleId}`, "Pesquisar emoji", [
        input("query", "Nome do emoji", "", TextInputStyle.Short, true, 80, "Ex.: check, carrinho, raio")
      ]));
    }
    if (id.startsWith("admin:automations:reaction-emoji-clear:")) {
      const ruleId = id.split(":")[3]!;
      const rule = this.db.automations(gid).autoReactions.find((item) => item.id === ruleId);
      if (!rule) throw new Error("Reação automática não encontrada.");
      rule.emojiId = ""; rule.emojiName = ""; rule.emojiGuildId = ""; rule.enabled = false; rule.updatedAt = nowIso();
      this.db.save();
      return i.update(this.autoReactionDetail(gid, rule.id) as never);
    }

    if (id.startsWith("admin:automations:mention-mode:")) {
      const rule = this.db.automations(gid).mentionMessages.find((item) => item.id === id.split(":")[3]);
      if (!rule) throw new Error("Mensagem com menção não encontrada.");
      rule.audience = rule.audience === "NEW_MEMBERS" ? "EXISTING_MEMBERS" : rule.audience === "EXISTING_MEMBERS" ? "BOTH" : "NEW_MEMBERS";
      rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.mentionMessageDetail(gid, rule.id) as never);
    }

    if (id.startsWith("admin:automations:repeat-delete:")) {
      const settings = this.db.automations(gid); const ruleId = id.split(":")[3]!;
      const index = settings.repeatingMessages.findIndex((item) => item.id === ruleId); if (index < 0) throw new Error("Mensagem recorrente não encontrada.");
      const [rule] = settings.repeatingMessages.splice(index, 1); this.db.save();
      if (rule?.channelId && rule.lastMessageId) { const channel = await this.client.channels.fetch(rule.channelId).catch(() => undefined); if (channel instanceof TextChannel) await channel.messages.fetch(rule.lastMessageId).then((m) => m.delete()).catch(() => undefined); }
      return i.update(this.repeatingMessagesView(gid) as never);
    }
    if (id.startsWith("admin:automations:mention-delete:")) {
      const settings = this.db.automations(gid); const ruleId = id.split(":")[3]!;
      const index = settings.mentionMessages.findIndex((item) => item.id === ruleId); if (index < 0) throw new Error("Mensagem com menção não encontrada.");
      settings.mentionMessages.splice(index, 1); this.db.save(); return i.update(this.mentionMessagesView(gid) as never);
    }
    if (id.startsWith("admin:automations:reaction-delete:")) {
      const settings = this.db.automations(gid); const ruleId = id.split(":")[3]!;
      const index = settings.autoReactions.findIndex((item) => item.id === ruleId); if (index < 0) throw new Error("Reação automática não encontrada.");
      settings.autoReactions.splice(index, 1); this.db.save(); return i.update(this.autoReactionsView(gid) as never);
    }

    if (/^admin:automations:repeat:[A-Za-z0-9_-]+$/.test(id)) return i.update(this.repeatingMessageDetail(gid, id.split(":")[3]!) as never);
    if (/^admin:automations:mention:[A-Za-z0-9_-]+$/.test(id)) return i.update(this.mentionMessageDetail(gid, id.split(":")[3]!) as never);
    if (/^admin:automations:reaction:[A-Za-z0-9_-]+$/.test(id)) return i.update(this.autoReactionDetail(gid, id.split(":")[3]!) as never);

    if (id === "admin:automations:schedules") return i.update(this.channelSchedulesView(gid) as never);
    if (id === "admin:automations:schedule-add") return i.showModal(this.channelScheduleModal());
    if (id.startsWith("admin:automations:schedule-edit:")) {
      const schedule = this.db.automations(gid).channelSchedules.find((item) => item.id === id.split(":")[3]);
      if (!schedule) throw new Error("Horário automático não encontrado.");
      return i.showModal(this.channelScheduleModal(schedule.id, schedule));
    }
    if (id.startsWith("admin:automations:schedule-channels:")) {
      const scheduleId = id.split(":")[3]!;
      return i.update(this.channelScheduleChannelsView(gid, scheduleId) as never);
    }
    if (id.startsWith("admin:automations:schedule-toggle:")) {
      const scheduleId = id.split(":")[3]!;
      const schedule = this.db.automations(gid).channelSchedules.find((item) => item.id === scheduleId);
      if (!schedule) throw new Error("Horário automático não encontrado.");
      schedule.enabled = !schedule.enabled;
      schedule.updatedAt = nowIso();
      this.db.audit(i.user.id, "CHANNEL_SCHEDULE_TOGGLE", "channel_schedule", schedule.id, { guildId: gid, enabled: schedule.enabled }, gid);
      this.db.save();
      return i.update(this.channelScheduleDetail(gid, schedule.id) as never);
    }
    if (id.startsWith("admin:automations:schedule-delete:")) {
      const scheduleId = id.split(":")[3]!;
      const settings = this.db.automations(gid);
      const index = settings.channelSchedules.findIndex((item) => item.id === scheduleId);
      if (index < 0) throw new Error("Horário automático não encontrado.");
      settings.channelSchedules.splice(index, 1);
      this.db.audit(i.user.id, "CHANNEL_SCHEDULE_DELETE", "channel_schedule", scheduleId, { guildId: gid }, gid);
      this.db.save();
      return i.update(this.channelSchedulesView(gid) as never);
    }

    if (id.startsWith("admin:automations:toggle:")) {
      const key = id.split(":")[3]!;
      const settings = this.db.automations(gid);
      const map = { welcome: "welcomeEnabled", goodbye: "goodbyeEnabled", autorole: "autoRoleEnabled", responses: "autoResponsesEnabled" } as const;
      const field = map[key as keyof typeof map];
      if (!field) throw new Error("Automação inválida.");
      settings[field] = !settings[field];
      this.db.audit(i.user.id, "AUTOMATION_TOGGLE", "guild", gid, { field, enabled: settings[field] });
      this.db.save();
      return i.update(this.automationsView(gid) as never);
    }
    if (id === "admin:automations:welcome-message") {
      const settings = this.db.automations(gid);
      return i.showModal(modal("modal:automations:welcome-message", "Mensagem de boas-vindas", [input("message", "Mensagem", settings.welcomeMessage, TextInputStyle.Paragraph, true, 1800)]));
    }
    if (id === "admin:automations:welcome-mode") {
      const settings = this.db.automations(gid);
      settings.welcomeMode = settings.welcomeMode === "TEMPORARY" ? "EMBED" : "TEMPORARY";
      this.db.save();
      return i.update(this.automationsView(gid) as never);
    }
    if (id === "admin:automations:welcome-duration") {
      const settings = this.db.automations(gid);
      return i.showModal(modal("modal:automations:welcome-duration", "Boas-vindas temporária", [input("seconds", "Segundos até apagar (3 a 120)", String(settings.welcomeDeleteAfterSeconds || 8), TextInputStyle.Short, true, 3)]));
    }
    if (id === "admin:automations:goodbye-message") {
      const settings = this.db.automations(gid);
      return i.showModal(modal("modal:automations:goodbye-message", "Mensagem de saída", [input("message", "Mensagem", settings.goodbyeMessage, TextInputStyle.Paragraph, true, 1800)]));
    }
    if (id === "admin:automations:response-add") return i.showModal(modal("modal:automations:response-add", "Adicionar resposta automática", [
      input("trigger", "Texto que ativa a resposta", "", TextInputStyle.Short, true, 200),
      input("response", "Resposta do bot", "", TextInputStyle.Paragraph, true, 1800)
    ]));
    if (id.startsWith("admin:automations:response-edit:")) {
      const index = Number(id.split(":")[3]);
      const response = this.db.automations(gid).autoResponses[index];
      if (!response) throw new Error("Resposta automática não encontrada.");
      return i.showModal(modal(`modal:automations:response-edit:${index}`, "Editar resposta automática", [
        input("trigger", "Texto que ativa a resposta", response.trigger, TextInputStyle.Short, true, 200),
        input("response", "Resposta do bot", response.response, TextInputStyle.Paragraph, true, 1800)
      ]));
    }
    if (id.startsWith("admin:automations:response-exact:")) {
      const index = Number(id.split(":")[3]);
      const response = this.db.automations(gid).autoResponses[index];
      if (!response) throw new Error("Resposta automática não encontrada.");
      response.exact = !response.exact;
      this.db.audit(i.user.id, "AUTO_RESPONSE_MATCH_MODE", "guild", gid, { index, exact: response.exact });
      this.db.save();
      return i.update(this.automationResponseDetail(gid, index) as never);
    }
    if (id.startsWith("admin:automations:response-delete:")) {
      const index = Number(id.split(":")[3]);
      const settings = this.db.automations(gid);
      if (!settings.autoResponses[index]) throw new Error("Resposta automática não encontrada.");
      settings.autoResponses.splice(index, 1);
      this.db.audit(i.user.id, "AUTO_RESPONSE_DELETE", "guild", gid, { index });
      this.db.save();
      return i.update(this.automationsView(gid) as never);
    }
    if (id.startsWith("admin:protection:toggle:")) {
      const key = id.split(":")[3]!;
      const settings = this.db.protection(gid);
      const map = { links: "antiLink", spam: "antiSpam", invites: "blockInvites", deleted: "logDeletedMessages", edited: "logEditedMessages" } as const;
      const field = map[key as keyof typeof map];
      if (!field) throw new Error("Configuração de proteção inválida.");
      settings[field] = !settings[field];
      this.db.audit(i.user.id, "PROTECTION_TOGGLE", "guild", gid, { field, enabled: settings[field] });
      this.db.save();
      return i.update(this.protectionView(gid) as never);
    }
    if (id === "admin:protection:domains") {
      const settings = this.db.protection(gid);
      return i.showModal(modal("modal:protection:domains", "Domínios permitidos", [
        input("domains", "Um domínio por linha", settings.allowedDomains.join("\n"), TextInputStyle.Paragraph, false, 1800, "exemplo.com")
      ]));
    }
    if (id === "admin:protection:spam-limits") {
      const settings = this.db.protection(gid);
      return i.showModal(modal("modal:protection:spam-limits", "Limites do anti-spam", [
        input("messages", "Mensagens permitidas", String(settings.spamMessages), TextInputStyle.Short, true, 3),
        input("window", "Janela em segundos", String(settings.spamWindowSeconds), TextInputStyle.Short, true, 4),
        input("timeout", "Timeout em segundos", String(settings.spamTimeoutSeconds), TextInputStyle.Short, true, 6)
      ]));
    }

    if (id === "admin:coupon:create") return i.showModal(modal("modal:coupon:create", "Criar cupom", [
      input("code", "Código", "PROMO10", TextInputStyle.Short, true, 30),
      input("discount", "Tipo | desconto: PERCENT|10 ou FIXED|5,00", "PERCENT | 10", TextInputStyle.Short, true, 50),
      input("limits", "Mínimo R$ | usos totais | por usuário", "0 | 100 | 1", TextInputStyle.Short, true, 80),
      input("dates", "Início ISO | expiração ISO (opcionais)", " | ", TextInputStyle.Short, false, 120),
      input("scope", "IDs produtos | grupos (separados por vírgula)", " | ", TextInputStyle.Paragraph, false, 1000)
    ]));
    if (id.startsWith("admin:coupon:toggle:")) { const coupon = this.products.getCoupon(gid, id.split(":")[3]!); this.products.updateCoupon(gid, coupon.id, { active: !coupon.active }, i.user.id); return i.update(this.couponDetail(gid, coupon.id) as never); }
    if (id.startsWith("admin:coupon:edit-basic:")) { const coupon = this.products.getCoupon(gid, id.split(":")[3]!); return i.showModal(modal(`modal:coupon:edit-basic:${coupon.id}`, "Código e desconto", [input("code", "Código", coupon.code, TextInputStyle.Short, true, 30), input("discount", "Tipo | desconto", `${coupon.type} | ${coupon.type === "PERCENT" ? coupon.value : (coupon.value / 100).toFixed(2)}`, TextInputStyle.Short, true, 50), input("minimum", "Pedido mínimo em R$", (coupon.minOrderCents / 100).toFixed(2), TextInputStyle.Short, true, 20)])); }
    if (id.startsWith("admin:coupon:edit-rules:")) { const coupon = this.products.getCoupon(gid, id.split(":")[3]!); return i.showModal(modal(`modal:coupon:edit-rules:${coupon.id}`, "Limites e período", [input("max", "Máximo de usos (vazio = ilimitado)", coupon.maxUses === null ? "" : String(coupon.maxUses), TextInputStyle.Short, false, 10), input("per_user", "Limite por usuário (0 = ilimitado)", String(coupon.perUserLimit), TextInputStyle.Short, true, 10), input("start", "Início ISO (opcional)", coupon.startsAt ?? "", TextInputStyle.Short, false, 40), input("expires", "Expiração ISO (opcional)", coupon.expiresAt ?? "", TextInputStyle.Short, false, 40)])); }
    if (id.startsWith("admin:coupon:edit-scope:")) { const coupon = this.products.getCoupon(gid, id.split(":")[3]!); return i.showModal(modal(`modal:coupon:edit-scope:${coupon.id}`, "Escopo do cupom", [input("products", "IDs de produtos separados por vírgula", coupon.productIds.join(","), TextInputStyle.Paragraph, false, 1500), input("groups", "Grupos de produto separados por vírgula", coupon.productGroups.join(","), TextInputStyle.Paragraph, false, 500)])); }
    if (id.startsWith("admin:coupon:delete:")) { const coupon = this.products.getCoupon(gid, id.split(":")[3]!); return i.update({ embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Excluir cupom").setDescription(`Excluir permanentemente **${coupon.code}**? Os registros de usos aprovados serão mantidos no histórico.`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:coupon:delete-confirm:${coupon.id}`, "Confirmar exclusão", "trash", ButtonStyle.Danger), this.views.button(gid, `admin:coupon:${coupon.id}`, "Cancelar", "back"))] }); }
    if (id.startsWith("admin:coupon:delete-confirm:")) { this.products.deleteCoupon(gid, id.split(":")[3]!, i.user.id); return i.update(this.couponsView(gid) as never); }
    if (id === "admin:backup:create") return i.showModal(modal("modal:backup:create", "Criar backup do servidor", [input("name", "Nome do backup", `Backup ${new Date().toLocaleString("pt-BR")}`, TextInputStyle.Short, true, 100)]));
    if (id.startsWith("admin:backup:rename:")) { const backup = this.backups.get(gid, id.split(":")[3]!); return i.showModal(modal(`modal:backup:rename:${backup.id}`, "Renomear backup", [input("name", "Novo nome", backup.name, TextInputStyle.Short, true, 100)])); }
    if (id.startsWith("admin:backup:delete:") && !id.startsWith("admin:backup:delete-confirm:")) { const backup = this.backups.get(gid, id.split(":")[3]!); return i.update({ embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Excluir backup").setDescription(`Excluir **${backup.name}** e seu arquivo? Esta ação não pode ser desfeita.`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:backup:delete-confirm:${backup.id}`, "Excluir", "trash", ButtonStyle.Danger), this.views.button(gid, `admin:backup:${backup.id}`, "Cancelar", "back"))] }); }
    if (id.startsWith("admin:backup:delete-confirm:")) { const backupId = id.split(":")[3]!; this.backups.delete(gid, backupId, i.user.id); return i.update(this.backupsView(gid) as never); }
    if (id.startsWith("admin:backup:restore-plan:")) { const backupId = id.split(":")[3]!; const plan = this.backups.plan(gid, backupId, { settings: true, roles: true, channels: true, expressions: true, webhooks: true, messages: true }); return i.update({ embeds: [new EmbedBuilder().setColor(0xf59e0b).setTitle("Confirmar restauração").setDescription(`Backup: **${plan.backup.name}**

${plan.summary.map((line) => `• ${line}`).join("\n")}

Antes de restaurar, o bot criará automaticamente um backup de segurança do estado atual. Mensagens serão republicadas como cópias do bot, nunca como usuários originais.`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:backup:restore-confirm:${backupId}:full`, "Completa", "restore", ButtonStyle.Danger), this.views.button(gid, `admin:backup:restore-confirm:${backupId}:structure`, "Somente estrutura", "settings", ButtonStyle.Primary), this.views.button(gid, `admin:backup:restore-confirm:${backupId}:messages`, "Somente mensagens", "message", ButtonStyle.Secondary), this.views.button(gid, `admin:backup:${backupId}`, "Cancelar", "back"))] }); }
    if (id.startsWith("admin:backup:restore-confirm:")) { const [, , , backupId, mode] = id.split(":"); if (!i.guild) throw new Error("Servidor indisponível."); await i.deferUpdate(); const options = mode === "full" ? { settings: true, roles: true, channels: true, expressions: true, webhooks: true, messages: true } : mode === "messages" ? { settings: false, roles: false, channels: false, expressions: false, webhooks: false, messages: true } : { settings: true, roles: true, channels: true, expressions: true, webhooks: true, messages: false }; const result = await this.backups.restore(i.guild, backupId!, i.user.id, options); await i.editReply({ embeds: [new EmbedBuilder().setColor(0x22c55e).setTitle("Restauração concluída").setDescription(Object.entries(result.changed).map(([key, value]) => `• ${key}: **${value}**`).join("\n") + `

Avisos: **${result.warnings.length}**`)], components: [] }); return; }
    if (id === "admin:giveaway:create") return i.showModal(modal("modal:giveaway:create", "Criar sorteio", [input("channel", "ID do canal", "", TextInputStyle.Short, true, 24), input("prize", "Prêmio", "", TextInputStyle.Short, true, 200), input("duration", "Duração: 30m, 2h, 1d", "1h", TextInputStyle.Short, true, 20), input("winners", "Quantidade de vencedores", "1", TextInputStyle.Short, true, 2)]));

    if (id.startsWith("admin:order:approve:")) { const oid = id.split(":")[3]!; await i.deferReply({ flags: MessageFlags.Ephemeral }); await this.orders.approveManual(oid, i.user.id); await i.editReply(`Pedido ${oid} aprovado e processado.`); return; }
    if (id.startsWith("admin:order:complete:")) { const oid = id.split(":")[3]!; await i.deferReply({ flags: MessageFlags.Ephemeral }); await this.orders.completeManualDelivery(oid, i.user.id); await i.editReply(`Entrega manual do pedido ${oid} concluída.`); return; }
    if (id.startsWith("admin:order:cancel:")) { const oid = id.split(":")[3]!; this.orders.cancel(oid, i.user.id); return i.update(this.ordersAdminView(gid) as never); }
    if (id.startsWith("admin:order:")) return i.update(this.orderAdminDetail(gid, id.split(":")[2]!) as never);

    if (id === "admin:sales-receipt:toggle") {
      const settings = this.db.guild(gid); settings.salesReceiptEnabled = !settings.salesReceiptEnabled; this.db.save();
      return i.update(this.views.channelSettings(gid) as never);
    }
    if (id === "admin:sales-receipt:mode") {
      const settings = this.db.guild(gid); settings.salesReceiptMode = settings.salesReceiptMode === "IMAGE" ? "EMBED" : "IMAGE"; this.db.save();
      return i.update(this.views.channelSettings(gid) as never);
    }
    if (id === "admin:channel:sales") return i.update(this.views.channelPicker(gid, "admin:channel-set:sales", "Canal de vendas") as never);
    if (id === "admin:channel:logs") return i.update(this.views.channelPicker(gid, "admin:channel-set:logs", "Canal de logs") as never);
    if (id === "admin:channel:welcome") return i.update(this.views.channelPicker(gid, "admin:channel-set:welcome", "Canal de boas-vindas") as never);
    if (id === "admin:channel:feedback") return i.update(this.views.channelPicker(gid, "admin:channel-set:feedback", "Canal de feedbacks") as never);
    if (id === "admin:channel:goodbye") return i.update(this.views.channelPicker(gid, "admin:channel-set:goodbye", "Canal de saídas") as never);
    if (id === "admin:channel:ticket-logs") return i.update(this.views.channelPicker(gid, "admin:channel-set:ticket-logs", "Canal de logs de tickets") as never);
    if (id === "admin:category:open") return i.update(this.views.channelPicker(gid, "admin:category-set:open", "Categoria de tickets abertos", true) as never);
    if (id === "admin:category:closed") return i.update(this.views.channelPicker(gid, "admin:category-set:closed", "Categoria de tickets fechados", true) as never);
    if (id === "admin:category:archive") return i.update(this.views.channelPicker(gid, "admin:category-set:archive", "Categoria de tickets arquivados", true) as never);
    if (id === "admin:category:purchases") return i.update(this.views.channelPicker(gid, "admin:category-set:purchases", "Categoria das compras privadas", true) as never);
    if (id === "admin:role:staff") return i.update(this.views.rolePicker(gid, "admin:role-set:staff", "Cargos da equipe", 10) as never);
    if (id === "admin:role:admin") return i.update(this.views.rolePicker(gid, "admin:role-set:admin", "Cargos administradores do painel", 10) as never);
    if (id === "admin:role:customer") return i.update(this.views.rolePicker(gid, "admin:role-set:customer", "Cargo de cliente") as never);
    if (id === "admin:role:auto") return i.update(this.views.rolePicker(gid, "admin:role-set:auto", "Cargo automático") as never);
  }

  private async select(i: StringSelectMenuInteraction) {
    const gid = i.guildId; if (!gid) throw new Error("Fora de servidor."); const id = i.customId;
    if (id.startsWith("robux:calcpass:")) {
      const [, , ownerId, robloxUserIdRaw] = id.split(":");
      if (i.user.id !== ownerId) throw new Error("Este menu pertence à pessoa que consultou a conta Roblox.");
      const robloxUserId = Number(robloxUserIdRaw);
      const gamepassId = Number(i.values[0]);
      if (!Number.isFinite(robloxUserId) || !Number.isFinite(gamepassId)) throw new Error("Gamepass inválida.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const pass = await this.robux.calculatorLookupSelection(gid, robloxUserId, gamepassId);
      if (!pass) return i.editReply({ content: "Essa gamepass não está mais disponível. Faça uma nova consulta digitando `nick`." });
      return i.editReply({
        embeds: [new EmbedBuilder()
          .setColor(0x4169ff)
          .setTitle(`${pass.name}`)
          .setDescription(`**Preço:** ${Math.max(0, pass.price).toLocaleString("pt-BR")} Robux\n**ID:** \`${pass.id}\`\n\nUse o botão abaixo para abrir a página oficial da gamepass no Roblox.`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(this.robux.gamepassUrl(pass.id)).setLabel("Abrir gamepass no Roblox")
        )]
      });
    }
    if (id.startsWith("robux:gamepass:") || id.startsWith("robux:payment-select:")) return this.robuxPublicSelect(i, gid);
    if (id.startsWith("store:")) return i.reply({ content: "Este painel antigo de loja foi desativado. Use um painel individual de produto publicado pela equipe.", flags: MessageFlags.Ephemeral });
    if (id.startsWith("admin:")) this.requireAdminAction(i, id);
    if (id === "admin:robux:delivery-mode") {
      this.requireOwner(i);
      const value = i.values[0] as RobuxDeliveryMode;
      if (!(["MANUAL", "ASSISTED", "COOKIE_AUTO", "WEBHOOK"] as string[]).includes(value)) throw new Error("Modo de entrega inválido.");
      if ((value === "ASSISTED" || value === "COOKIE_AUTO") && !this.robux.hasCookie(gid)) throw new Error("Configure primeiro a conta Roblox de entrega. Depois escolha Assistida ou Automática.");
      if (value === "WEBHOOK" && !this.robux.deliveryConfigured(gid)) throw new Error("Configure primeiro a integração HTTPS de entrega.");
      this.robux.updateSettings(gid, { deliveryMode: value, autoDelivery: value === "COOKIE_AUTO" || value === "WEBHOOK" });
      return i.update(this.robuxAdminView(gid) as never);
    }
    if (id === "admin:robux:calculator-mode") {
      this.requireOwner(i);
      const value = i.values[0] ?? "";
      if (!(["PNG", "EMBED", "OFF"] as string[]).includes(value)) throw new Error("Formato da calculadora inválido.");
      this.robux.updateSettings(gid, value === "OFF"
        ? { calculatorEnabled: false }
        : { calculatorEnabled: true, calculatorFormat: value as "PNG" | "EMBED" });
      return i.update(this.robuxAdminView(gid) as never);
    }
    if (id === "admin:robux:provider") { this.requireOwner(i); const value = i.values[0] as PaymentProviderName | "AUTO"; if (value !== "AUTO" && !(["MERCADO_PAGO", "EFI_BANK", "STRIPE", "MISTIC_PAY", "PURIN_CASH", "EVO_PAY", "IMAP_PIX", "MANUAL_PIX"] as string[]).includes(value)) throw new Error("Método de pagamento inválido."); this.robux.updateSettings(gid, { paymentProvider: value }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:announcement-format") { this.requireOwner(i); const value = i.values[0] === "EMBED" ? "EMBED" : "PNG"; this.robux.updateSettings(gid, { announcementFormat: value }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:order-select") { this.requireOwner(i); return i.update(this.robuxOrderDetail(gid, i.values[0]!) as never); }
    if (id === "admin:zcloud:backup-select") { const target=i.values[0]!; if(!this.client.guilds.cache.has(target)) throw new Error("O bot precisa estar no servidor de backup antes de ele poder ser selecionado."); this.zcloud.update(gid,{backupGuildId:target}); return i.update(this.zcloudAdminView(gid) as never); }
    if (/^admin:zcloud:emoji-select:\d+$/.test(id)) { const selected=i.values[0]??""; if(!selected) throw new Error("Selecione um emoji."); this.zcloud.update(gid,{buttonEmoji:selected}); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:zcloud:panel-mode") { const mode=i.values[0] === "V2" ? "V2" : "EMBED"; this.zcloud.update(gid,{panelMode:mode}); return i.update(this.zcloudAdminView(gid) as never); }
    if (id === "admin:navigate") {
      const target = i.values[0]!;
      if (target === "zcloud" && !this.zcloud.managerEnabled()) throw new Error("ZCloud está desativado pelo ZENYX Manager.");
      const targetScopes: Record<string, import("../types.js").PermissionScope> = {
        products: "PRODUCTS", store: "PRODUCTS", coupons: "PRODUCTS", robux: "ADMIN", zcloud: "ADMIN", invites: "ADMIN",
        orders: "PAYMENTS", payments: "PAYMENTS", wallet: "PAYMENTS", revenue: "PAYMENTS",
        tickets: "TICKETS", stock_requests: "TICKETS", messages: "ADMIN_COMMANDS",
        backups: "BACKUPS", giveaways: "ADMIN_COMMANDS", saved_emojis: "AUTHORIZED", voice: "ADMIN", commands: "AUTHORIZED"
      };
      this.requireScope(i, targetScopes[target] ?? "ADMIN");
      const views: Record<string, () => Record<string, unknown>> = {
        products: () => this.views.productsHome(gid) as unknown as Record<string, unknown>,
        robux: () => { this.requireOwner(i); return this.robuxAdminView(gid) as unknown as Record<string, unknown>; },
        zcloud: () => this.zcloudAdminView(gid) as unknown as Record<string, unknown>,
        invites: () => this.invitesAdminView(gid) as unknown as Record<string, unknown>,
        orders: () => this.ordersAdminView(gid) as unknown as Record<string, unknown>,
        payments: () => this.views.paymentsHome(gid) as unknown as Record<string, unknown>,
        wallet: () => {
          if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
          return this.views.walletHome(gid) as unknown as Record<string, unknown>;
        },
        tickets: () => this.views.ticketPanelsHome(gid) as unknown as Record<string, unknown>,
        messages: () => this.botMessagesView(gid) as unknown as Record<string, unknown>,
        stock_requests: () => this.views.stockRequestsHome(gid) as unknown as Record<string, unknown>,
        saved_emojis: () => this.views.savedEmojisHome(gid) as unknown as Record<string, unknown>,
        revenue: () => this.revenueView(gid) as unknown as Record<string, unknown>,
        personalize: () => this.personalizeView(gid) as unknown as Record<string, unknown>,
        emojis: () => this.views.emojisHome(gid) as unknown as Record<string, unknown>,
        automations: () => this.automationsView(gid) as unknown as Record<string, unknown>,
        protection: () => this.protectionView(gid) as unknown as Record<string, unknown>,
        giveaways: () => this.giveawaysView(gid) as unknown as Record<string, unknown>,
        channels: () => this.views.channelSettings(gid) as unknown as Record<string, unknown>,
        coupons: () => this.couponsView(gid) as unknown as Record<string, unknown>,
        permissions: () => this.permissionsView(gid) as unknown as Record<string, unknown>,
        backups: () => this.backupsView(gid) as unknown as Record<string, unknown>,
        voice: () => this.voiceAdminView(gid) as unknown as Record<string, unknown>,
        commands: () => this.commandHelpView(gid) as unknown as Record<string, unknown>,
        store: () => this.views.productsHome(gid) as unknown as Record<string, unknown>
      };
      const render = views[target];
      if (!render) throw new Error("Área do painel inválida.");
      if (!i.deferred && !i.replied) await i.deferUpdate();
      return i.editReply(render() as never);
    }
    if (id.startsWith("ticket:purchase-select:")) {
      const ticketId = id.split(":")[2]!;
      await this.tickets.resolvePurchaseGate(ticketId, i.user.id, i.values[0]!);
      return i.reply({ content: "✅ Compra vinculada. O atendimento está liberado.", flags: MessageFlags.Ephemeral });
    }
    if (id === "cart:item-manage") {
      this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
      const [productId, fieldId] = i.values[0]!.split("|");
      const product = this.products.get(productId!, gid);
      return i.update(this.views.cartItemManage(gid, i.user.id, product, this.products.getField(product.id, fieldId)) as never);
    }
    if (id.startsWith("product:field-select:")) {
      const product = this.products.get(id.split(":")[2]!, gid);
      const field = this.products.getField(product.id, i.values[0]!);
      return this.beginDirectPurchase(i, product, field.id);
    }
    if (id.startsWith("admin:product:mode-select:")) {
      const productId = id.split(":")[3]!;
      const value = i.values[0];
      if (value !== "BUTTON" && value !== "SELECT") throw new Error("Modo de vitrine inválido.");
      const product = this.products.update(productId, { purchaseMode: value }, i.user.id);
      this.schedulePublishedRefresh();
      return i.update(this.views.productModeView(gid, product) as never);
    }
    if (id.startsWith("admin:product:delivery-type-select:")) {
      const productId = id.split(":")[3]!;
      const value = i.values[0] as DeliveryType;
      if (!["STOCK", "MANUAL", "ROLE"].includes(value)) throw new Error("Tipo de entrega inválido.");
      const product = this.products.update(productId, { deliveryType: value }, i.user.id);
      return i.update(this.productDeliveryView(gid, product) as never);
    }
    if (id.startsWith("admin:product:select:")) return i.update(this.views.productDetail(gid, this.products.get(i.values[0]!, gid)) as never);
    if (id.startsWith("admin:product:field-select:")) {
      const product = this.products.get(id.split(":")[3]!, gid);
      const field = this.products.getField(product.id, i.values[0]!);
      return i.update(this.views.productFieldDetail(gid, product, field) as never);
    }
    if (id.startsWith("admin:product:field-emoji-select:")) {
      const productId = id.split(":")[3]!;
      const fieldId = id.split(":")[4]!;
      const field = this.products.updateField(productId, fieldId, { emoji: i.values[0]! }, i.user.id);
      return i.update(this.views.productFieldDetail(gid, this.products.get(productId, gid), field) as never);
    }
    if (id.startsWith("admin:product:emoji-select:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, { emojiSemantic: i.values[0]! }, i.user.id);
      return i.update(this.views.productDetail(gid, product) as never);
    }
    if (id.startsWith("admin:ticket:emoji-select:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.updatePanel(panelId, { emojiSemantic: i.values[0]! }, i.user.id);
      return i.update(this.views.ticketPanelDetail(gid, panel) as never);
    }
    if (id.startsWith("admin:ticket:option-emoji-select:")) {
      const panelId = id.split(":")[3]!;
      const optionId = id.split(":")[4]!;
      this.tickets.updateOption(panelId, optionId, { emojiSemantic: i.values[0]! }, i.user.id);
      return i.update(this.ticketOptionDetail(gid, panelId, optionId) as never);
    }
    if (id.startsWith("admin:emoji:function-select:")) return i.update(this.emojiFunctionDetail(gid, i.values[0]!) as never);
    if (id.startsWith("admin:emoji:asset-select:")) {
      const functional = id.split(":")[3]!;
      this.db.updateGuild(gid, (guild) => { guild.emojiOverrides[functional] = `${i.values[0]}:solid`; });
      return i.update(this.emojiFunctionDetail(gid, functional) as never);
    }
    if (id.startsWith("admin:emoji:catalog-select:")) return i.update(this.emojiCatalogDetail(gid, i.values[0]!, Number(id.split(":")[3] ?? 0)) as never);
    if (id.startsWith("admin:automations:repeat-select:")) return i.update(this.repeatingMessageDetail(gid, i.values[0]!) as never);
    if (id.startsWith("admin:automations:mention-select:")) return i.update(this.mentionMessageDetail(gid, i.values[0]!) as never);
    if (id.startsWith("admin:automations:reaction-select:")) return i.update(this.autoReactionDetail(gid, i.values[0]!) as never);
    if (id === "admin:automations:response-select") {
      const index = Number(i.values[0]);
      return i.update(this.automationResponseDetail(gid, index) as never);
    }
    if (id === "admin:automations:schedule-select") return i.update(this.channelScheduleDetail(gid, i.values[0]!) as never);
    if (id === "admin:message:select") return i.update(this.botMessageDetail(gid, i.values[0]!) as never);
    if (id.startsWith("admin:automations:reaction-emoji-set:")) {
      const parts = id.split(":");
      const ruleId = parts[3]!;
      const emojiId = i.values[0] ?? "";
      const rule = this.db.automations(gid).autoReactions.find((item) => item.id === ruleId);
      if (!rule) throw new Error("Reação automática não encontrada.");
      await i.guild?.emojis.fetch().catch(() => undefined);
      const emoji = i.guild?.emojis.cache.get(emojiId);
      if (!emoji) throw new Error("Esse emoji não está mais disponível neste servidor. Atualize a lista e escolha outro.");
      rule.emojiId = emoji.id;
      rule.emojiName = emoji.name ?? "emoji";
      rule.emojiGuildId = gid;
      rule.updatedAt = nowIso();
      this.db.save();
      return i.update(this.autoReactionDetail(gid, rule.id) as never);
    }
    if (id === "admin:payment:provider-select") { const provider = i.values[0] as PaymentProviderName; if (!this.payments.enabled(gid, provider)) throw new Error("Configure e ative esse provedor antes de torná-lo padrão."); this.db.payments(gid).defaultProvider = provider; this.db.save(); return i.update(this.views.paymentsHome(gid) as never); }
    if (id === "admin:payment:test-api-select") {
      const provider = i.values[0] as PaymentProviderName;
      if (!this.payments.enabled(gid, provider)) throw new Error("Este gateway não está ativo ou está incompleto.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const result = await this.payments.test(gid, provider);
      await i.editReply(`✅ **${provider.replaceAll("_", " ")}**: ${result}`);
      return;
    }
    if (id === "admin:payment:imap-bank-select") {
      const bank = i.values[0] as ImapBank;
      if (!["INTER", "PICPAY", "NUBANK"].includes(bank)) throw new Error("Banco inválido.");
      const settings = this.db.payments(gid).imapPix;
      settings.bank = bank;
      this.db.save();
      return i.update(this.views.imapSettingsHome(gid) as never);
    }
    if (id === "admin:payment:imap-email-provider-select") {
      const provider = i.values[0] as ImapEmailProvider;
      if (!["GMAIL", "OUTLOOK", "YAHOO", "CUSTOM"].includes(provider)) throw new Error("Provedor de e-mail inválido.");
      const settings = this.db.payments(gid).imapPix;
      settings.emailProvider = provider;
      const preset = applyEmailPreset(provider);
      if (preset) Object.assign(settings, preset);
      this.db.save();
      return i.update(this.views.imapSettingsHome(gid) as never);
    }
    if (id === "admin:payment:imap-pix-key-type-select") {
      const keyType = i.values[0] as "random" | "cpf" | "cnpj" | "email" | "phone";
      if (!["random", "cpf", "cnpj", "email", "phone"].includes(keyType)) throw new Error("Tipo de chave PIX inválido.");
      this.db.payments(gid).imapPix.pixKeyType = keyType;
      this.db.save();
      return i.update(this.views.imapSettingsHome(gid) as never);
    }
    if (id === "admin:payment:test-select") { await i.deferReply({ flags: MessageFlags.Ephemeral }); const result = await this.imap.testConnection(gid); await i.editReply(`✅ ${result}`); return; }
    if (id === "admin:ticket:select") return i.update(this.views.ticketPanelDetail(gid, this.tickets.resolvePanel(i.values[0]!, gid)) as never);
    if (id === "admin:stock-request:select") {
      const request = this.db.state.stockRequests[i.values[0]!];
      if (!request || request.guildId !== gid) throw new Error("Solicitação não encontrada.");
      return i.update(this.views.stockRequestDetail(gid, request, true) as never);
    }
    if (id.startsWith("admin:saved-emoji:select:")) {
      const item = this.emojis.findSaved(i.values[0]!);
      if (!item || item.guildId !== gid) throw new Error("Emoji salvo não encontrado.");
      return i.update(this.views.savedEmojiDetail(gid, item) as never);
    }
    if (id.startsWith("admin:ticket:field-select:")) {
      const panel = this.tickets.getPanelForField(id.split(":")[3]!, i.values[0]!, gid);
      const field = panel.fields.find((item) => item.id === i.values[0]);
      if (!field) throw new Error("Campo do painel não encontrado.");
      return i.update(this.views.ticketPanelFieldDetail(gid, panel, field) as never);
    }
    if (id.startsWith("admin:ticket:option-select:")) { const panelId = id.split(":")[3]!; const panel = this.tickets.resolvePanel(panelId, gid, i.values[0]); const option = panel.options.find((o) => o.id === i.values[0]); if (!option) throw new Error("Opção de atendimento não encontrada. Atualize o /painel e tente novamente."); return i.update(this.ticketOptionDetail(gid, panel.id, option.id) as never); }
    if (id === "admin:coupon:select") return i.update(this.couponDetail(gid, i.values[0]!) as never);
    if (id === "admin:backup:select") return i.update(this.backupDetail(gid, i.values[0]!) as never);
    if (id === "admin:order:select") return i.update(this.orderAdminDetail(gid, i.values[0]!) as never);
    if (id.startsWith("store:select:")) return this.storeRespond(i, this.views.publicProduct(gid, this.products.get(i.values[0]!, gid)) as never);
    if (id === "store:cart-quantity") {
      const [productId, fieldId] = i.values[0]!.split("|");
      const product = this.products.get(productId!, gid);
      const current = this.products.cart(i.user.id).find((item) => item.productId === product.id && item.fieldId === fieldId)?.quantity ?? product.minQuantity;
      return i.showModal(modal(`modal:cart-quantity:${product.id}:${fieldId}`, "Alterar quantidade", [input("quantity", `Quantidade (${product.minQuantity} a ${product.maxQuantity})`, String(current), TextInputStyle.Short, true, 3)]));
    }
    if (id === "store:cart-remove") {
      const [productId, fieldId] = i.values[0]!.split("|");
      this.products.removeFromCart(i.user.id, productId!, fieldId);
      return this.storeRespond(i, this.views.cart(gid, i.user.id) as never);
    }
    if (id.startsWith("ticket:open-select:")) { const panelId = id.split(":")[2]!; return this.showTicketSubject(i, panelId, i.values[0]!); }
  }

  private async channelSelect(i: ChannelSelectMenuInteraction) {
    const gid = i.guildId; if (!gid) throw new Error("Fora de servidor."); const id = i.customId; this.requireAdminAction(i, id); const channelId = i.values[0]!;
    if (id.startsWith("admin:robux:")) this.requireOwner(i);
    if (id === "admin:voice:channel-set") {
      await i.deferUpdate();
      await this.voice.connect(gid, channelId);
      return i.editReply(this.voiceAdminView(gid) as never);
    }
    if (id === "admin:invites:channel-set") {
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      this.invites.update(gid, { channelId });
      return i.update(this.invitesAdminView(gid) as never);
    }
    if (id === "admin:zcloud:publish-channel") {
      const channel=await this.client.channels.fetch(channelId);
      if(!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      const z=this.zcloud.settings(gid);
      const payload=this.zcloudPanelPayload(gid) as Record<string, unknown>;
      const desiredV2=z.panelMode === "V2";
      let msg;
      if(z.panelMessageId && z.verificationChannelId===channelId){
        const old=await channel.messages.fetch(z.panelMessageId).catch(()=>undefined);
        if(old){
          const oldV2=old.flags.has(MessageFlags.IsComponentsV2);
          if(oldV2 !== desiredV2){ await old.delete().catch(()=>undefined); msg=await channel.send(payload as never); }
          else msg=await old.edit({ ...payload, attachments: [] } as never);
        } else msg=await channel.send(payload as never);
      } else msg=await channel.send(payload as never);
      this.zcloud.update(gid,{verificationChannelId:channelId,panelMessageId:msg.id});
      await i.update(this.zcloudAdminView(gid) as never);
      await i.followUp({content:`Painel ZCloud publicado em <#${channelId}>. O link passa pelo gateway do Manager e redireciona imediatamente para o OAuth oficial do Discord.`,flags:MessageFlags.Ephemeral});
      return;
    }
    if (id === "admin:robux:calculator-channel-set") { const channel = await this.client.channels.fetch(channelId); if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido."); this.robux.updateSettings(gid, { calculatorChannelId: channelId, calculatorEnabled: true }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:log-channel-set") { const channel = await this.client.channels.fetch(channelId); if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido."); this.robux.updateSettings(gid, { logChannelId: channelId }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:announcement-channel-set") { const channel = await this.client.channels.fetch(channelId); if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido."); this.robux.updateSettings(gid, { announcementChannelId: channelId }); return i.update(this.robuxAdminView(gid) as never); }
    if (id === "admin:robux:publish-channel") {
      // ACK antes de qualquer fetch/upload para nunca estourar o timeout de 3s do Discord.
      await i.deferUpdate();
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      const s = this.robux.settings(gid);
      const preferredId = s.panelChannelId === channelId ? s.panelMessageId : "";
      const result = await this.upsertRobuxPanel(gid, channel, preferredId);
      this.robux.updateSettings(gid, { enabled: true, publicChannelId: channelId, panelChannelId: channelId, panelMessageId: result.message.id });
      await i.editReply(this.robuxAdminView(gid) as never);
      const verb = result.updated ? "atualizado" : "publicado";
      const fallbackNote = result.fallback ? " O banner padrão não pôde ser anexado, então o painel foi publicado em Components V2 sem banner." : "";
      await i.followUp({ content: `Painel Robux **${verb} e confirmado** em <#${channelId}>. [Abrir painel](${result.message.url}).${fallbackNote}`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id === "admin:restock:channel-set") {
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      this.db.guild(gid).restockAnnouncements.channelId = channelId;
      this.db.audit(i.user.id, "RESTOCK_CHANNEL_SET", "guild", gid, { channelId }, gid);
      this.db.save();
      return i.update(this.views.restockSettings(gid) as never);
    }
    if (id.startsWith("admin:ticket:option-category-set:")) {
      const [, , , panelId, optionId] = id.split(":");
      const channel = await this.client.channels.fetch(channelId);
      if (channel?.type !== ChannelType.GuildCategory) throw new Error("Selecione uma categoria válida.");
      this.tickets.updateOption(panelId!, optionId!, { categoryId: channelId }, i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (id.startsWith("admin:automations:repeat-channel-set:")) {
      const rule = this.db.automations(gid).repeatingMessages.find((item) => item.id === id.split(":")[3]);
      const channel = await this.client.channels.fetch(channelId);
      if (!rule) throw new Error("Mensagem recorrente não encontrada.");
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      rule.channelId = channelId; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.repeatingMessageDetail(gid, rule.id) as never);
    }
    if (id.startsWith("admin:automations:mention-channel-set:")) {
      const rule = this.db.automations(gid).mentionMessages.find((item) => item.id === id.split(":")[3]);
      const channel = await this.client.channels.fetch(channelId);
      if (!rule) throw new Error("Mensagem com menção não encontrada.");
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      rule.channelId = channelId; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.mentionMessageDetail(gid, rule.id) as never);
    }
    if (id.startsWith("admin:automations:reaction-channel-set:")) {
      const rule = this.db.automations(gid).autoReactions.find((item) => item.id === id.split(":")[3]);
      const channel = await this.client.channels.fetch(channelId);
      if (!rule) throw new Error("Reação automática não encontrada.");
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      rule.channelId = channelId; rule.updatedAt = nowIso(); this.db.save();
      return i.update(this.autoReactionDetail(gid, rule.id) as never);
    }
    if (id.startsWith("admin:automations:schedule-channels-set:")) {
      const scheduleId = id.split(":")[3]!;
      const schedule = this.db.automations(gid).channelSchedules.find((item) => item.id === scheduleId);
      if (!schedule) throw new Error("Horário automático não encontrado.");
      schedule.channelIds = [...new Set(i.values)].slice(0, 25);
      schedule.updatedAt = nowIso();
      this.db.audit(i.user.id, "CHANNEL_SCHEDULE_CHANNELS", "channel_schedule", schedule.id, { guildId: gid, channelIds: schedule.channelIds }, gid);
      this.db.save();
      return i.update(this.channelScheduleDetail(gid, schedule.id) as never);
    }
    if (id.startsWith("admin:message:publish-channel:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Selecione um canal de texto válido.");
      const publication = template.publications.find((item) => item.channelId === channel.id);
      let message = publication ? await channel.messages.fetch(publication.messageId).catch(() => undefined) : undefined;
      if (message) await message.edit(this.views.botMessageEdit(gid, template) as never);
      else {
        message = await channel.send(this.views.botMessage(gid, template));
        template.publications = template.publications.filter((item) => item.channelId !== channel.id);
        template.publications.push({ channelId: channel.id, messageId: message.id, publishedAt: nowIso() });
      }
      template.updatedAt = nowIso();
      this.db.audit(i.user.id, "BOT_MESSAGE_PUBLISH", "message_template", template.id, { guildId: gid, channelId: channel.id, messageId: message.id }, gid);
      this.db.save();
      await i.update(this.botMessageDetail(gid, template.id) as never);
      await i.followUp({ content: `✅ Mensagem publicada ou atualizada em <#${channel.id}>.`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id.startsWith("admin:product:publish-channel:")) { const product = this.products.get(id.split(":")[3]!, gid); const channel = await this.client.channels.fetch(channelId); if (!(channel instanceof TextChannel)) throw new Error("Canal inválido."); const message = await channel.send(this.views.publishedProduct(gid, product)); this.products.addPublication(product.id, gid, channelId, message.id); await i.update(this.views.productDetail(gid, product) as never); await i.followUp({ content: `Painel individual de **${product.name}** publicado em <#${channelId}> e vinculado às atualizações automáticas.`, flags: MessageFlags.Ephemeral }); return; }
    if (id.startsWith("admin:ticket:publish-channel:")) {
      const panel = this.tickets.resolvePanel(id.split(":")[3]!, gid, undefined, i.values[0]);
      const activeOptions = panel.options.filter((option) => option.active);
      if (!activeOptions.length) throw new Error("Adicione e ative ao menos uma opção antes de publicar o painel.");
      for (const option of activeOptions) {
        const validated = await this.emojis.validateUserInput(option.emojiSemantic, gid, true);
        if (validated !== option.emojiSemantic) this.tickets.updateOption(panel.id, option.id, { emojiSemantic: validated }, i.user.id);
      }
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Canal inválido.");
      let message;
      if (panel.channelId === channelId && panel.messageId) {
        const current = await channel.messages.fetch(panel.messageId).catch(() => undefined);
        message = current ? await current.edit(this.views.publicTicketPanelEdit(gid, panel)) : await channel.send(this.views.publicTicketPanel(gid, panel));
      } else {
        if (panel.channelId && panel.messageId) {
          const oldChannel = await this.client.channels.fetch(panel.channelId).catch(() => undefined);
          if (oldChannel instanceof TextChannel) {
            const oldMessage = await oldChannel.messages.fetch(panel.messageId).catch(() => undefined);
            await oldMessage?.delete().catch(() => undefined);
          }
        }
        message = await channel.send(this.views.publicTicketPanel(gid, panel));
      }
      const updated = this.tickets.updatePanel(panel.id, { channelId, messageId: message.id }, i.user.id);
      await i.update(this.views.ticketPanelDetail(gid, updated) as never);
      await i.followUp({ content: `Painel publicado ou atualizado em <#${channelId}>.`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id === "admin:stock-request:destination-set") {
      this.db.guild(gid).stockRequest.requestChannelId = channelId;
      this.db.audit(i.user.id, "STOCK_REQUEST_CHANNEL_SET", "guild", gid, { channelId });
      this.db.save();
      return i.update(this.views.stockRequestsHome(gid) as never);
    }
    if (id === "admin:stock-request:publish-channel") {
      const channel = await this.client.channels.fetch(channelId);
      if (!(channel instanceof TextChannel)) throw new Error("Canal inválido.");
      const settings = this.db.guild(gid).stockRequest;
      let message;
      if (settings.panelMessageId && settings.panelChannelId === channelId) {
        const existing = await channel.messages.fetch(settings.panelMessageId).catch(() => undefined);
        message = existing ? await existing.edit(this.views.publicStockRequestPanel(gid)) : await channel.send(this.views.publicStockRequestPanel(gid));
      } else {
        message = await channel.send(this.views.publicStockRequestPanel(gid));
      }
      settings.panelChannelId = channelId;
      settings.panelMessageId = message.id;
      this.db.audit(i.user.id, "STOCK_REQUEST_PANEL_PUBLISH", "message", message.id, { channelId, guildId: gid });
      this.db.save();
      await i.update(this.views.stockRequestsHome(gid) as never);
      await i.followUp({ content: `Painel **Pedir Stock** publicado em <#${channelId}> e vinculado às atualizações automáticas.`, flags: MessageFlags.Ephemeral });
      return;
    }
    if (id === "admin:locks-ignored-set") { this.db.updateGuild(gid, (guild) => { guild.locks.ignoredChannelIds = [...i.values]; }); return i.update(this.permissionsView(gid) as never); }
    const map: Record<string, keyof ReturnType<JsonDatabase["guild"]>> = { "admin:channel-set:sales": "salesChannelId", "admin:channel-set:logs": "logChannelId", "admin:channel-set:ticket-logs": "ticketLogChannelId", "admin:channel-set:welcome": "welcomeChannelId", "admin:channel-set:feedback": "feedbackChannelId", "admin:channel-set:goodbye": "goodbyeChannelId", "admin:category-set:open": "ticketCategoryId", "admin:category-set:closed": "closedTicketCategoryId", "admin:category-set:archive": "archiveTicketCategoryId", "admin:category-set:purchases": "purchaseCategoryId" };
    const key = map[id]; if (key) { this.db.updateGuild(gid, (g) => { (g as unknown as Record<string, unknown>)[key] = channelId; }); return i.update(this.views.channelSettings(gid) as never); }
  }

  private async roleSelect(i: RoleSelectMenuInteraction) {
    const gid = i.guildId; if (!gid) throw new Error("Fora de servidor."); this.requireAdmin(i);
    if (i.customId === "admin:zcloud:role-set") { const roleId=i.values[0]??""; const role=i.guild?.roles.cache.get(roleId); const me=i.guild?.members.me; if(!role) throw new Error("Cargo não encontrado."); if(me&&role.position>=me.roles.highest.position) throw new Error("Esse cargo está acima ou no mesmo nível do maior cargo do bot."); this.zcloud.update(gid,{verificationRoleId:roleId}); return i.update(this.zcloudAdminView(gid) as never); }
    if (i.customId === "admin:restock:role-set") {
      this.db.guild(gid).restockAnnouncements.mentionRoleId = i.values[0] ?? "";
      this.db.save();
      return i.update(this.views.restockSettings(gid) as never);
    }
    if (i.customId.startsWith("admin:product:delivery-role-set:")) {
      const productId = i.customId.split(":")[3]!;
      const product = this.products.update(productId, { roleId: i.values[0] ?? "" }, i.user.id);
      return i.update(this.productDeliveryView(gid, product) as never);
    }
    if (i.customId.startsWith("admin:ticket:option-roles-set:")) {
      const [, , , panelId, optionId] = i.customId.split(":");
      this.tickets.updateOption(panelId!, optionId!, { supportRoleIds: [...i.values] }, i.user.id, gid);
      return i.update(this.ticketOptionDetail(gid, panelId!, optionId!) as never);
    }
    if (i.customId === "admin:role-set:staff") { this.db.updateGuild(gid, (g) => { g.staffRoleIds = [...i.values]; }); return i.update(this.views.channelSettings(gid) as never); }
    if (i.customId === "admin:role-set:admin") { this.db.updateGuild(gid, (g) => { g.adminRoleIds = [...i.values]; }); return i.update(this.views.channelSettings(gid) as never); }
    if (i.customId === "admin:role-set:customer") { this.db.updateGuild(gid, (g) => { g.customerRoleId = i.values[0]!; }); return i.update(this.views.channelSettings(gid) as never); }
    if (i.customId === "admin:role-set:auto") { this.db.updateGuild(gid, (g) => { g.autoRoleId = i.values[0]!; }); return i.update(this.views.channelSettings(gid) as never); }
    if (i.customId.startsWith("admin:permissions-role-set:")) {
      const key = i.customId.split(":")[2]!;
      const map: Record<string, keyof import("../types.js").GuildPermissions> = { admins: "adminRoleIds", authorized: "authorizedRoleIds", support: "supportRoleIds", tickets: "ticketRoleIds", payments: "paymentRoleIds", products: "productRoleIds", commands: "adminCommandRoleIds" };
      const field = map[key]; if (!field) throw new Error("Grupo de permissão inválido.");
      this.permissions.updateRoles(gid, field as never, [...i.values]);
      if (field === "adminRoleIds") this.db.updateGuild(gid, (guild) => { guild.adminRoleIds = [...i.values]; });
      if (field === "supportRoleIds") this.db.updateGuild(gid, (guild) => { guild.staffRoleIds = [...new Set([...guild.staffRoleIds, ...i.values])]; });
      return i.update(this.permissionsView(gid) as never);
    }
    if (i.customId === "admin:locks-speaking-set") { this.db.updateGuild(gid, (guild) => { guild.locks.speakingRoleIds = [...i.values]; }); return i.update(this.permissionsView(gid) as never); }
    if (i.customId === "admin:stock-request:roles-set") {
      this.db.guild(gid).stockRequest.notifyRoleIds = [...i.values];
      this.db.audit(i.user.id, "STOCK_REQUEST_ROLES_SET", "guild", gid, { roleIds: [...i.values] });
      this.db.save();
      return i.update(this.views.stockRequestsHome(gid) as never);
    }
  }

  private async userSelect(i: UserSelectMenuInteraction) {
    const gid = i.guildId; if (!gid) throw new Error("Fora de servidor.");
    if (i.customId.startsWith("ticket:transfer-select:")) {
      const ticketId = i.customId.split(":")[2]!;
      const ticket = this.tickets.getTicket(ticketId);
      const actor = i.member as GuildMember;
      if (!this.isTicketStaff(actor, ticket)) throw new Error("Somente a equipe pode transferir atendimentos.");
      const targetId = i.values[0];
      if (!targetId) throw new Error("Selecione um atendente.");
      const target = await i.guild!.members.fetch(targetId);
      if (!this.isTicketStaff(target, ticket)) throw new Error("O usuário selecionado não possui cargo/permissão de atendimento neste ticket.");
      await this.tickets.transfer(ticketId, target, i.user.id);
      return i.update({ content: `✅ Atendimento transferido para <@${target.id}>.`, components: [], allowedMentions: { users: [target.id] } } as never);
    }
    this.requireAdmin(i);
    if (i.customId === "admin:permissions-user-set:admins") this.permissions.updateUsers(gid, "adminUserIds", [...i.values]);
    else if (i.customId === "admin:permissions-user-set:authorized") this.permissions.updateUsers(gid, "authorizedUserIds", [...i.values]);
    else throw new Error("Seletor de usuários inválido.");
    return i.update(this.permissionsView(gid) as never);
  }

  private async modal(i: ModalSubmitInteraction) {
    if (!i.guildId) throw new Error("Use este modal em um servidor.");
    if (i.customId === "modal:zcloud:oauth") {
      this.requireAdmin(i);
      const gid=i.guildId;
      const clientId=i.fields.getTextInputValue("clientId").trim();
      if(!/^\d{15,22}$/.test(clientId)) throw new Error("Client ID inválido.");
      const returnUrl=i.fields.getTextInputValue("returnUrl").trim();
      let returnParsed:URL;
      try{returnParsed=new URL(returnUrl)}catch{throw new Error("Destino inválido.");}
      if(!["https:","discord:"].includes(returnParsed.protocol)) throw new Error("Destino usa protocolo não permitido.");
      const secret=i.fields.getTextInputValue("secret").trim();
      if(secret) this.zcloud.setSecret(gid,secret);
    
      const managed=this.zcloud.managedPublicBaseUrl();
      let publicBaseUrl=managed;
      let redirectUri=managed ? `${managed}/zcloud/${gid}/callback` : "";
      if(!managed){
        publicBaseUrl=i.fields.getTextInputValue("publicBaseUrl").trim().replace(/\/$/,"");
        redirectUri=i.fields.getTextInputValue("redirectUri").trim();
        for(const [label,value] of [["URL pública",publicBaseUrl],["Redirect URI",redirectUri]]){
          let u:URL;
          try{u=new URL(String(value ?? ""))}catch{throw new Error(`${label} inválida.`)}
          if(u.protocol!=="https:") throw new Error(`${label} precisa usar HTTPS.`);
        }
      }
      this.zcloud.update(gid,{clientId,publicBaseUrl,redirectUri,discordReturnUrl:returnUrl,primaryGuildId:gid});
      const callback=this.zcloud.effectiveRedirectUri(gid);
      await i.reply({content:`Configuração OAuth2 salva.\n\nNo **Discord Developer Portal → OAuth2 → Redirects**, cadastre exatamente:\n\`${callback}\`\n\nO botão público abre primeiro a autorização oficial do Discord; este endereço HTTPS é usado somente no callback e nas páginas ZCloud.`,flags:MessageFlags.Ephemeral});
      return;
    }
    if (i.customId === "modal:zcloud:auto-join") {
      this.requireAdmin(i);
      const gid=i.guildId;
      const current=this.zcloud.settings(gid);
      const enabled=parseBoolean(i.fields.getTextInputValue("enabled"),current.autoJoinEnabled);
      const targetGuildId=i.fields.getTextInputValue("guildId").trim();
      const inviteRaw=i.fields.getTextInputValue("invite").trim();
      let inviteUrl="";
      if(enabled){
        if(!/^\d{15,22}$/.test(targetGuildId)) throw new Error("Informe um ID de servidor Discord válido.");
        if(!this.client.guilds.cache.has(targetGuildId)) throw new Error("O bot precisa estar dentro do servidor adicional antes de ativar esta opção.");
        inviteUrl=normalizeDiscordInvite(inviteRaw);
        if(!inviteUrl) throw new Error("Informe o link de convite do servidor adicional.");
      } else if(inviteRaw) inviteUrl=normalizeDiscordInvite(inviteRaw);
      this.zcloud.update(gid,{autoJoinEnabled:enabled,autoJoinGuildId:targetGuildId,autoJoinInviteUrl:inviteUrl});
      await i.reply({content:enabled?`Servidor adicional ativado. Após autorizar o escopo **guilds.join**, o usuário será sincronizado também com \`${targetGuildId}\`.`:"Servidor adicional desativado. A verificação não adicionará usuários a outro servidor.",flags:MessageFlags.Ephemeral});
      return;
    }
    if (i.customId === "modal:zcloud:backup-config") {
      this.requireAdmin(i); const gid=i.guildId; const current=this.zcloud.settings(gid);
      const enabled=parseBoolean(i.fields.getTextInputValue("enabled"),current.backupTransferEnabled);
      const target=i.fields.getTextInputValue("guildId").trim(); const inviteRaw=i.fields.getTextInputValue("invite").trim(); const limit=Math.max(1,Math.min(500,Math.trunc(Number(i.fields.getTextInputValue("limit"))||50)));
      if(enabled){if(!/^\d{15,22}$/.test(target)) throw new Error("Informe um ID de servidor backup válido.");if(!this.client.guilds.cache.has(target)) throw new Error("Adicione o bot ao servidor de backup antes de ativar.");if(target===gid)throw new Error("O backup precisa ser outro servidor.");}
      let invite="";if(inviteRaw){invite=normalizeDiscordInvite(inviteRaw);if(!invite)throw new Error("Convite do servidor backup inválido.");}
      this.zcloud.update(gid,{backupTransferEnabled:enabled,backupGuildId:target,backupInviteUrl:invite,backupTransferLimit:limit,allowBackupJoin:enabled||current.allowBackupJoin});
      await i.reply({content:enabled?`Backup configurado para \`${target}\`. Somente membros que autorizaram **guilds.join** podem ser enviados; limite padrão: **${limit}**.`:"Backup de membros desativado. Nenhum usuário será enviado ao servidor de backup.",flags:MessageFlags.Ephemeral});return;
    }
    if (i.customId === "modal:zcloud:backup-transfer") {
      this.requireAdmin(i); const amount=Math.trunc(Number(i.fields.getTextInputValue("amount"))); if(!Number.isFinite(amount)||amount<1||amount>500)throw new Error("Escolha uma quantidade entre 1 e 500.");
      await i.deferReply({flags:MessageFlags.Ephemeral}); const result=await this.zcloud.transferVerifiedMembersToBackup(i.guildId,amount);
      await i.editReply(`Backup concluído para \`${result.targetGuildId}\`. Solicitados: **${result.requested}** • elegíveis OAuth: **${result.eligible}** • adicionados: **${result.joined}** • já estavam lá: **${result.already}** • sem token/autorização válida: **${result.skipped}** • falhas: **${result.failed}**.`);return;
    }
    if (i.customId === "modal:invites:message") {
      this.requireAdmin(i);
      const message = i.fields.getTextInputValue("message").trim();
      if (!message) throw new Error("A mensagem de entrada não pode ficar vazia.");
      this.invites.update(i.guildId, { message: message.slice(0, 1900) });
      return i.reply({ content: "Mensagem do Invite Tracker atualizada. Placeholders: {member}, {inviter}, {invites}, {code}, {server}.", flags: MessageFlags.Ephemeral });
    }
    if (i.customId === "modal:invites:settings") {
      this.requireAdmin(i);
      const fakeDays = Math.max(0, Math.min(365, Math.trunc(Number(i.fields.getTextInputValue("fakeDays")) || 0)));
      const trackLeaves = parseBoolean(i.fields.getTextInputValue("trackLeaves"), true);
      const ignoreBots = parseBoolean(i.fields.getTextInputValue("ignoreBots"), true);
      this.invites.update(i.guildId, { fakeAccountDays: fakeDays, trackLeaves, ignoreBots });
      return i.reply({ content: `Regras atualizadas. Contas com menos de **${fakeDays} dia(s)** são marcadas como fake; saídas **${trackLeaves ? "serão" : "não serão"}** descontadas; bots **${ignoreBots ? "serão ignorados" : "serão contabilizados"}**.`, flags: MessageFlags.Ephemeral });
    }
    if (i.customId === "modal:invites:reset") {
      this.requireAdmin(i);
      if (i.fields.getTextInputValue("confirm").trim().toUpperCase() !== "ZERAR") return i.reply({ content: "Operação cancelada. As estatísticas não foram alteradas.", flags: MessageFlags.Ephemeral });
      this.invites.reset(i.guildId);
      return i.reply({ content: "Estatísticas do Invite Tracker zeradas. A configuração e o canal foram preservados.", flags: MessageFlags.Ephemeral });
    }
    if (i.customId === "modal:zcloud:appearance") {
      this.requireAdmin(i);
      const gid=i.guildId;
      const color=normalizeColor(i.fields.getTextInputValue("color"),"");
      if(!color) throw new Error("Cor inválida. Use exatamente #RRGGBB, por exemplo #3155ff.");
      const image=normalizeImageLink(i.fields.getTextInputValue("image"));
      this.zcloud.update(gid,{panelTitle:i.fields.getTextInputValue("title").trim().slice(0,100),panelDescription:i.fields.getTextInputValue("description").trim().slice(0,1500),panelImageUrl:image,panelColor:color,panelFooter:i.fields.getTextInputValue("footer").trim().slice(0,300)});
      await i.reply({content:"Aparência do painel ZCloud atualizada. Use **Pré-visualizar** ou **Atualizar publicação** para conferir.",flags:MessageFlags.Ephemeral}); return;
    }
    if (i.customId === "modal:zcloud:button-style") {
      this.requireAdmin(i);
      const gid=i.guildId;
      const label=i.fields.getTextInputValue("label").trim().slice(0,80);
      if(!label) throw new Error("O texto do botão não pode ficar vazio.");
      this.zcloud.update(gid,{buttonLabel:label});
      await i.reply({content:"Texto do botão ZCloud atualizado. O emoji agora é escolhido pela biblioteca visual do ZCloud.",flags:MessageFlags.Ephemeral}); return;
    }
    if (i.customId === "modal:zcloud:emoji-add") {
      this.requireAdmin(i);
      const name=i.fields.getTextInputValue("name").trim();
      await this.collectSavedEmoji(i,name,true);
      return;
    }

    const gid = i.guildId; if (!gid) throw new Error("Fora de servidor."); const id = i.customId;
    if (id.startsWith("modal:") && !id.startsWith("modal:ticket:open") && !id.startsWith("modal:cart-") && !id.startsWith("modal:cart:") && !id.startsWith("modal:robux-public:") && id !== "modal:stock-request:create") this.requireScope(i, this.adminScopeFor(id));
    if (id.startsWith("modal:robux-admin:")) this.requireOwner(i);
    if (id === "modal:robux-admin:prices") {
      const price = parseMoney(i.fields.getTextInputValue("price"));
      const min = Number(i.fields.getTextInputValue("min")); const max = Number(i.fields.getTextInputValue("max")); const passes = Number(i.fields.getTextInputValue("passes"));
      this.robux.updateSettings(gid, { pricePer1000Cents: price, minRobux: min, maxRobux: max, maxGamepasses: passes });
      await this.refreshRobuxPanel(gid);
      return i.reply({ ...this.robuxAdminView(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:robux-admin:text") { const banner = i.fields.getTextInputValue("banner").trim(); if (banner && !/^https?:\/\//i.test(banner)) throw new Error("O banner precisa ser uma URL http/https válida."); this.robux.updateSettings(gid, { title: i.fields.getTextInputValue("title"), description: i.fields.getTextInputValue("description"), bannerUrl: banner }); await this.refreshRobuxPanel(gid); return i.reply({ ...this.robuxAdminView(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never); }
    if (id === "modal:robux-admin:delivery-webhook") { this.robux.configureDeliveryWebhook(gid, i.fields.getTextInputValue("url"), i.fields.getTextInputValue("token")); return i.reply({ ...this.robuxAdminView(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never); }
    if (id === "modal:robux-admin:delivery-cookie") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const raw = i.fields.getTextInputValue("cookie").trim();
      if (!raw) {
        this.robux.removeCookie(gid);
        const current = this.robux.settings(gid);
        if (["ASSISTED", "COOKIE_AUTO"].includes(current.deliveryMode)) this.robux.updateSettings(gid, { deliveryMode: "MANUAL", autoDelivery: false });
        await i.editReply({ content: "✅ Conta Roblox de entrega removida. O módulo voltou para entrega manual quando necessário." });
        return;
      }
      const account = await this.robux.configureCookie(gid, raw);
      await i.editReply({ content: `✅ Conta de entrega configurada: **${account.displayName || account.name}** (@${account.name}). O cookie não será exibido em logs ou painéis.` });
      return;
    }
    if (id.startsWith("modal:image-url:")) {
      const url = normalizeImageLink(i.fields.getTextInputValue("url"));
      const [, , target, entityId] = id.split(":");
      if (target === "product-image" || target === "product-banner") {
        if (!entityId) throw new Error("Produto não identificado.");
        const product = this.products.update(entityId, target === "product-image" ? { imageUrl: url } : { bannerUrl: url }, i.user.id);
        this.schedulePublishedRefresh();
        return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
      }
      if (target === "stock-request") {
        this.db.guild(gid).stockRequest.imageUrl = url;
        this.db.save();
        this.schedulePublishedRefresh();
        return i.reply({ ...this.views.stockRequestsHome(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
      }
      if (target === "ticket-banner" || target === "ticket-thumb") {
        if (!entityId) throw new Error("Painel de ticket não identificado.");
        const panel = this.tickets.updatePanel(entityId, target === "ticket-banner" ? { imageUrl: url } : { thumbnailUrl: url }, i.user.id);
        this.schedulePublishedRefresh();
        return i.reply({ ...this.views.adminPage(gid, this.views.ticketPanelDetail(gid, panel), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
      }
      if (target === "brand-logo" || target === "brand-banner") {
        if (target === "brand-logo") this.db.brand(gid).logoUrl = url;
        else this.db.brand(gid).bannerUrl = url;
        this.db.save();
        this.schedulePublishedRefresh();
        return i.reply({ ...this.personalizeView(gid), flags: MessageFlags.Ephemeral });
      }
      throw new Error("Destino de imagem inválido.");
    }
    if (id === "modal:robux-public:calculate" || id === "modal:robux-public:calculate-money" || id === "modal:robux-public:calculate-robux") {
      const raw = i.fields.getTextInputValue("value").trim();
      const normalized = id.endsWith("calculate-money") ? `${raw} reais` : id.endsWith("calculate-robux") ? `${raw} robux` : raw;
      const calculation = this.robux.parseCalculation(gid, normalized);
      if (!calculation) throw new Error("Informe um valor válido, como 100 Robux ou R$ 5,00.");
      const settings = this.robux.settings(gid);
      if (settings.calculatorFormat === "EMBED") return i.reply({ embeds: [this.robux.calculationEmbed(gid, calculation)], flags: MessageFlags.Ephemeral });
      const image = await this.robux.calculationImage(gid, calculation);
      return i.reply({ files: [new AttachmentBuilder(image, { name: "zenyx-calculadora-robux.png" })], flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:robux-public:manual-quick") {
      const settings = this.robux.settings(gid);
      if (!settings.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      if (!settings.manualShortcutEnabled) throw new Error("A compra manual rápida está desativada pela loja.");
      const amountRaw = i.fields.getTextInputValue("amount").replace(/\D/g, "");
      const requestedRobux = Number(amountRaw);
      if (!Number.isFinite(requestedRobux) || requestedRobux < settings.minRobux || requestedRobux > settings.maxRobux) throw new Error(`Informe uma quantidade entre ${settings.minRobux.toLocaleString("pt-BR")} e ${settings.maxRobux.toLocaleString("pt-BR")} Robux.`);
      const referenceUrl = this.robux.normalizeRobloxReferenceUrl(i.fields.getTextInputValue("link"));
      const calc = this.robux.calculationFromRobux(gid, requestedRobux);
      let selected: RobloxGamepass = { id: 0, name: "Game Pass pendente", price: calc.gamepassPrice };
      if (referenceUrl) {
        const gamepassId = this.robux.parseGamepassUrl(referenceUrl);
        if (gamepassId) {
          const info = await this.robux.gamepassInfo(gamepassId);
          this.robux.assertGamepassMatchesRequested(gid, requestedRobux, info.price);
          selected = info;
        } else {
          selected = { id: 0, name: "Link Roblox informado", price: calc.gamepassPrice };
        }
      }

      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const currentChannel = i.channel;
      const parent = currentChannel?.isThread?.() ? currentChannel.parent : currentChannel;
      if (!(parent instanceof TextChannel) || !parent.threads?.create) throw new Error("O painel de Robux precisa estar em um canal de texto que permita tópicos.");
      const key = this.robuxSessionKey(gid, i.user.id);
      const prior = this.robuxSessions.get(key);
      if (prior?.threadId) {
        const oldThread = await this.client.channels.fetch(prior.threadId).catch(() => undefined);
        if (oldThread?.isThread?.() && !oldThread.archived) await oldThread.setArchived(true, "Nova compra Robux iniciada").catch(() => undefined);
      }
      const me = i.guild?.members.me;
      const perms = me ? parent.permissionsFor(me) : null;
      let thread;
      if (perms?.has(PermissionFlagsBits.CreatePrivateThreads)) {
        thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PrivateThread, autoArchiveDuration: 60, invitable: true, reason: `Compra Robux manual rápida de ${i.user.tag}` }).catch(() => undefined);
        if (thread) await thread.members.add(i.user.id).catch(() => undefined);
      }
      if (!thread && perms?.has(PermissionFlagsBits.CreatePublicThreads)) {
        thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PublicThread, autoArchiveDuration: 60, reason: `Compra Robux manual rápida de ${i.user.tag}` }).catch(() => undefined);
      }
      if (!thread) throw new Error("Não consegui abrir o tópico da compra. Dê ao bot permissão para criar tópicos e enviar mensagens em tópicos.");

      const referenceText = referenceUrl ? `\n**Game Pass informada:** ${referenceUrl}` : "\n**Dados Roblox:** serão enviados depois do pagamento.";
      const placeholderUser: RobloxUser = { id: 0, name: "Aguardando dados", displayName: "Aguardando dados" };
      const prepared = await thread.send(this.robuxThreadPayload(
        gid,
        i.user.id,
        `${this.emojis.text("robux_manual", gid)} Compra sem busca`,
        `**Quantidade:** ${requestedRobux.toLocaleString("pt-BR")} Robux\n**Game Pass recomendada:** ${calc.gamepassPrice.toLocaleString("pt-BR")} Robux\n**Valor:** ${formatMoney(calc.amountCents)}${referenceText}\n\nVocê pode pagar primeiro. **Depois da confirmação do pagamento**, envie neste tópico o seu **username Roblox** ou o **link completo da Game Pass**.`,
        [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `robux:payment:${i.user.id}`, "Escolher pagamento", "payment", ButtonStyle.Success))],
        true
      ) as never);
      const session: RobuxSession = {
        guildId: gid, userId: i.user.id, robloxUser: placeholderUser,
        gamepasses: selected.id > 0 ? [selected] : [], selected,
        threadId: thread.id, messageId: prepared.id,
        manualRequestedRobux: requestedRobux, manualReferenceUrl: referenceUrl,
        manualFlow: true, manualAwaitingUsername: false,
        expiresAt: Date.now() + 20 * 60_000
      };
      this.robuxSessions.set(key, session);
      const link = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${gid}/${thread.id}`).setLabel("Abrir compra").setEmoji(this.emojis.component("link", gid));
      await i.editReply({ content: `Compra sem busca aberta em ${thread}. Escolha o pagamento; os dados Roblox podem ser enviados depois.`, components: [new ActionRowBuilder<ButtonBuilder>().addComponents(link)] });
      return;
    }

    if (id === "modal:robux-public:manual") {
      const settings = this.robux.settings(gid);
      if (!settings.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      const amountRaw = i.fields.getTextInputValue("amount").replace(/\D/g, "");
      const requestedRobux = Number(amountRaw);
      if (!Number.isFinite(requestedRobux) || requestedRobux < settings.minRobux || requestedRobux > settings.maxRobux) throw new Error(`Informe uma quantidade entre ${settings.minRobux.toLocaleString("pt-BR")} e ${settings.maxRobux.toLocaleString("pt-BR")} Robux.`);
      const referenceUrl = this.robux.normalizeRobloxReferenceUrl(i.fields.getTextInputValue("link"));
      const calc = this.robux.calculationFromRobux(gid, requestedRobux);
      let selected: RobloxGamepass = { id: 0, name: "Game Pass pendente", price: calc.gamepassPrice };
      if (referenceUrl) {
        const gamepassId = this.robux.parseGamepassUrl(referenceUrl);
        if (gamepassId) {
          const info = await this.robux.gamepassInfo(gamepassId);
          this.robux.assertGamepassMatchesRequested(gid, requestedRobux, info.price);
          selected = info;
        } else selected = { id: 0, name: "Link Roblox informado", price: calc.gamepassPrice };
      }

      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const key = this.robuxSessionKey(gid, i.user.id);
      const prior = this.robuxSessions.get(key);
      let thread = i.channel?.isThread?.() ? i.channel : undefined;
      if (!thread && prior?.threadId) {
        const existing = await this.client.channels.fetch(prior.threadId).catch(() => undefined);
        if (existing?.isThread?.() && !existing.archived) thread = existing;
      }
      if (!thread) {
        const currentChannel = i.channel;
        const parent = currentChannel?.isThread?.() ? currentChannel.parent : currentChannel;
        if (!(parent instanceof TextChannel) || !parent.threads?.create) throw new Error("O painel de Robux precisa estar em um canal de texto que permita tópicos.");
        const me = i.guild?.members.me;
        const perms = me ? parent.permissionsFor(me) : null;
        if (perms?.has(PermissionFlagsBits.CreatePrivateThreads)) {
          thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PrivateThread, autoArchiveDuration: 60, invitable: true, reason: `Compra Robux sem busca de ${i.user.tag}` }).catch(() => undefined);
          if (thread) await thread.members.add(i.user.id).catch(() => undefined);
        }
        if (!thread && perms?.has(PermissionFlagsBits.CreatePublicThreads)) thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PublicThread, autoArchiveDuration: 60, reason: `Compra Robux sem busca de ${i.user.tag}` }).catch(() => undefined);
      }
      if (!thread) throw new Error("Não consegui abrir/reutilizar o tópico da compra.");

      const placeholderUser: RobloxUser = { id: 0, name: "Aguardando dados", displayName: "Aguardando dados" };
      const referenceText = referenceUrl ? `\n**Game Pass informada:** ${referenceUrl}` : "\n**Dados Roblox:** serão enviados após o pagamento.";
      const payload = this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("robux_manual", gid)} Continuar sem buscar`, `**Quantidade:** ${requestedRobux.toLocaleString("pt-BR")} Robux\n**Game Pass recomendada:** ${calc.gamepassPrice.toLocaleString("pt-BR")} Robux\n**Valor:** ${formatMoney(calc.amountCents)}${referenceText}\n\nNão é necessário informar o nick agora. Escolha a forma de pagamento e, após a confirmação, envie o **username Roblox** ou o **link completo da Game Pass** neste tópico.`, [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `robux:payment:${i.user.id}`, "Escolher pagamento", "payment", ButtonStyle.Success))], false);
      let purchaseMessage = prior ? await this.robuxThreadMessage(prior) : undefined;
      if (purchaseMessage && purchaseMessage.channelId === thread.id) await purchaseMessage.edit({ ...payload, flags: MessageFlags.IsComponentsV2, attachments: [] } as never);
      else purchaseMessage = await thread.send({ ...payload, flags: MessageFlags.IsComponentsV2 } as never);

      const session: RobuxSession = {
        guildId: gid, userId: i.user.id, robloxUser: placeholderUser,
        gamepasses: selected.id > 0 ? [selected] : [], selected,
        threadId: thread.id, messageId: purchaseMessage.id,
        manualRequestedRobux: requestedRobux, manualReferenceUrl: referenceUrl, manualFlow: true, manualAwaitingUsername: false,
        expiresAt: Date.now() + 20 * 60_000
      };
      this.robuxSessions.set(key, session);
      const link = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${gid}/${thread.id}`).setLabel("Abrir compra").setEmoji(this.emojis.component("link", gid));
      await i.editReply({ content: `Fluxo sem busca preparado em ${thread}.`, components: [new ActionRowBuilder<ButtonBuilder>().addComponents(link)] });
      return;
    }
    if (id === "modal:robux-public:lookup") {
      const settings = this.robux.settings(gid);
      if (!settings.enabled) throw new Error("As vendas de Robux estão temporariamente desativadas.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const currentChannel = i.channel;
      const parent = currentChannel?.isThread?.() ? currentChannel.parent : currentChannel;
      if (!(parent instanceof TextChannel) || !parent.threads?.create) throw new Error("O painel de Robux precisa estar em um canal de texto que permita tópicos.");
      const username = i.fields.getTextInputValue("username").trim();
      const key = this.robuxSessionKey(gid, i.user.id);
      const prior = this.robuxSessions.get(key);
      if (prior?.threadId) {
        const oldThread = await this.client.channels.fetch(prior.threadId).catch(() => undefined);
        if (oldThread?.isThread?.() && !oldThread.archived) await oldThread.setArchived(true, "Nova compra Robux iniciada").catch(() => undefined);
      }
      const me = i.guild?.members.me;
      const perms = me ? parent.permissionsFor(me) : null;
      let thread;
      if (perms?.has(PermissionFlagsBits.CreatePrivateThreads)) {
        thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PrivateThread, autoArchiveDuration: 60, invitable: true, reason: `Compra Robux de ${i.user.tag}` }).catch(() => undefined);
        if (thread) await thread.members.add(i.user.id).catch(() => undefined);
      }
      if (!thread && perms?.has(PermissionFlagsBits.CreatePublicThreads)) {
        thread = await parent.threads.create({ name: `robux-${i.user.username}`.slice(0, 90), type: ChannelType.PublicThread, autoArchiveDuration: 60, reason: `Compra Robux de ${i.user.tag}` }).catch(() => undefined);
      }
      if (!thread) throw new Error("Não consegui abrir o tópico da compra. Dê ao bot permissão para criar tópicos e enviar mensagens em tópicos.");
      const searching = await thread.send(this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("search", gid)} Procurando no Roblox`, `Usuário informado: **${username}**\n\nEstou localizando a conta e carregando as gamepasses públicas com preço. Você pode fechar a compra a qualquer momento.`, [], true) as never);
      const session: RobuxSession = { guildId: gid, userId: i.user.id, gamepasses: [], threadId: thread.id, messageId: searching.id, expiresAt: Date.now() + 10 * 60_000 };
      this.robuxSessions.set(key, session);
      const link = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(`https://discord.com/channels/${gid}/${thread.id}`).setLabel("Abrir compra").setEmoji(this.emojis.component("link", gid));
      await i.editReply({ content: `Seu tópico de compra foi aberto: ${thread}`, components: [new ActionRowBuilder<ButtonBuilder>().addComponents(link)] });
      try {
        const user = await this.robux.resolveUsername(username);
        const gamepasses = await this.robux.listGamepasses(user.id, settings.maxGamepasses);
        session.robloxUser = user; session.gamepasses = gamepasses; session.expiresAt = Date.now() + 10 * 60_000;
        const message = await this.robuxThreadMessage(session);
        if (!message) return;
        if (!gamepasses.length) {
          await message.edit(this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("warning", gid)} Nenhuma gamepass encontrada`, `A conta **${user.name}** foi encontrada, mas não há Game Pass pública com preço disponível. Você pode tentar outro usuário ou continuar manualmente sem depender da busca.`, [new ActionRowBuilder<ButtonBuilder>().addComponents(
            this.views.button(gid, "robux:buy", "Tentar outro usuário", "refresh", ButtonStyle.Primary),
            this.views.button(gid, "robux:manual", "Continuar manualmente", "edit", ButtonStyle.Success)
          )], false) as never);
          return;
        }
        await message.edit({ ...this.robuxGamepassMenu(gid, session), flags: MessageFlags.IsComponentsV2 } as never);
      } catch (error) {
        const message = await this.robuxThreadMessage(session);
        await message?.edit(this.robuxThreadPayload(gid, i.user.id, `${this.emojis.text("wrong", gid)} Não foi possível concluir a busca`, `${truncate(error instanceof Error ? error.message : String(error), 1200)}\n\nVocê pode tentar novamente ou continuar manualmente sem depender da busca automática.`, [new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "robux:buy", "Tentar novamente", "refresh", ButtonStyle.Primary),
          this.views.button(gid, "robux:manual", "Continuar sem buscar", "edit", ButtonStyle.Success)
        )], false) as never).catch(() => undefined);
      }
      return;
    }
    if (id === "modal:robux-public:checkout" || id === "modal:robux-public:checkout-imap") {
      const session = this.robuxSessions.get(this.robuxSessionKey(gid, i.user.id));
      if (!session || session.expiresAt < Date.now() || !session.selected || !session.robloxUser || !session.selectedProvider) throw new Error("Sua seleção expirou. Comece novamente em Comprar Robux.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const imap = id.endsWith("checkout-imap");
      const fullName = i.fields.getTextInputValue("name").trim().replace(/\s+/g, " ");
      let email = ""; let document = ""; let bank = "";
      if (imap) {
        bank = i.fields.getTextInputValue("bank").trim().replace(/\s+/g, " ");
        document = i.fields.getTextInputValue("document").replace(/\D/g, "");
        if (fullName.split(" ").filter(Boolean).length < 2) throw new Error("No IMAP, informe o nome completo de quem fará o PIX.");
        if (bank.length < 2) throw new Error("Informe o nome do banco usado para realizar o PIX.");
        if (document && document.length !== 11) throw new Error("O CPF é opcional; se informar, use 11 dígitos.");
      } else {
        email = i.fields.getTextInputValue("email").trim();
        document = i.fields.getTextInputValue("document").replace(/\D/g, "");
      }
      if (session.checkoutCreating) { await i.editReply({content:"A cobrança já está sendo criada. Aguarde a página do tópico atualizar."}); return; }
      if (session.pendingOrderId) { const existing=this.robux.getOrder(session.pendingOrderId); if(existing&&existing.status==="PENDING_PAYMENT"){const published=await this.refreshRobuxOrderMessage(existing); await i.editReply({content:published?`O pedido **${existing.id}** já existe. A cobrança existente foi reaberta no tópico.`:`O pedido **${existing.id}** já existe, mas a página não pôde ser publicada. Tente novamente.`}); return;} }
      session.checkoutCreating=true;
      try {
        const order = await this.robux.createOrder({ guildId: gid, discordUserId: i.user.id, discordUsername: i.user.username, robloxUser: session.robloxUser, gamepass: session.selected, provider: session.selectedProvider, customerName: fullName, email, document, payerBankName: bank, threadId: session.threadId, messageId: session.messageId, requestedRobuxOverride: session.manualRequestedRobux, referenceUrl: session.manualReferenceUrl });
        session.pendingOrderId=order.id;
        const published=await this.refreshRobuxOrderMessage(order);
        await i.editReply({ content: published?`Pedido **${order.id}** criado. Continue pelo tópico da compra.`:`Pedido **${order.id}** criado, mas a cobrança não pôde ser publicada. Nenhum pedido duplicado será criado; tente novamente para reabrir este pedido.` });
      } finally { session.checkoutCreating=false; }
      return;
    }
    if (id.startsWith("modal:product:create:")) {
      const priceCents = parseMoney(i.fields.getTextInputValue("price"));
      this.assertZnyProductPrice(gid, priceCents);
      const deliveryType: DeliveryType = id.split(":")[3] === "STOCK" ? "STOCK" : "MANUAL";
      const automatic = deliveryType === "STOCK";
      const product = this.products.create({
        guildId: gid,
        name: i.fields.getTextInputValue("name"),
        priceCents,
        description: i.fields.getTextInputValue("description"),
        emojiSemantic: automatic ? "delivery" : "products",
        deliveryType,
        buttonEmoji: "cart",
        deliveryMessage: automatic ? "Entrega automática após a confirmação do pagamento." : "A equipe realizará a entrega manualmente neste canal.",
        fields: [{
          name: i.fields.getTextInputValue("field_name").trim() || "Opção principal",
          description: automatic ? "Entrega automática" : "Entrega manual",
          priceCents,
          compareAtCents: 0,
          emoji: "cart",
          active: true,
          stockMode: "UNIQUE"
        }]
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:basic:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, {
        name: i.fields.getTextInputValue("name"),
        description: i.fields.getTextInputValue("description")
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:visual:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, {
        imageUrl: i.fields.getTextInputValue("image").trim(),
        bannerUrl: i.fields.getTextInputValue("banner").trim(),
        color: normalizeColor(i.fields.getTextInputValue("color"))
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:purchase:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, {
        buttonLabel: i.fields.getTextInputValue("label").trim() || "Comprar agora",
        buttonEmoji: "cart",
        buttonStyle: styleName(i.fields.getTextInputValue("style")),
        selectPlaceholder: i.fields.getTextInputValue("placeholder").trim() || "Selecione uma opção para continuar..."
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:demo:")) {
      const productId = id.split(":")[3]!;
      const url = i.fields.getTextInputValue("url").trim();
      if (url && !/^https?:\/\//i.test(url)) throw new Error("O link da demonstração precisa começar com http:// ou https://.");
      const product = this.products.update(productId, {
        demonstrationEnabled: Boolean(url),
        demonstrationUrl: url,
        demonstrationLabel: i.fields.getTextInputValue("label").trim() || "Demonstração",
        demonstrationEmoji: i.fields.getTextInputValue("emoji").trim() || "information"
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productDetail(gid, product), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:delivery-message:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, { deliveryMessage: i.fields.getTextInputValue("message") }, i.user.id);
      return i.reply({ ...this.productDeliveryView(gid, product), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:product:delivery-limits:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, {
        minQuantity: Number(i.fields.getTextInputValue("minimum")),
        maxQuantity: Number(i.fields.getTextInputValue("maximum")),
        perUserLimit: Number(i.fields.getTextInputValue("per_user")),
        couponGroup: i.fields.getTextInputValue("coupon_group").trim()
      }, i.user.id);
      return i.reply({ ...this.productDeliveryView(gid, product), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:product:terms-text:")) {
      const productId = id.split(":")[3]!;
      const product = this.products.update(productId, { termsText: i.fields.getTextInputValue("terms") }, i.user.id);
      return i.reply({ ...this.productDeliveryView(gid, product), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:product:field-add:")) {
      const productId = id.split(":")[3]!;
      const priceCents = parseMoney(i.fields.getTextInputValue("price"));
      this.assertZnyProductPrice(gid, priceCents);
      const field = this.products.addField(productId, {
        name: i.fields.getTextInputValue("name"),
        description: i.fields.getTextInputValue("description"),
        priceCents,
        compareAtCents: i.fields.getTextInputValue("compare").trim() ? parseMoney(i.fields.getTextInputValue("compare")) : 0,
        emoji: i.fields.getTextInputValue("emoji").trim() || "cart",
        active: true,
        stockMode: "UNIQUE"
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productFieldDetail(gid, this.products.get(productId, gid), field), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:product:field-edit:")) {
      const [, , , productId, fieldId] = id.split(":");
      const priceCents = parseMoney(i.fields.getTextInputValue("price"));
      this.assertZnyProductPrice(gid, priceCents);
      const field = this.products.updateField(productId!, fieldId!, {
        name: i.fields.getTextInputValue("name"),
        description: i.fields.getTextInputValue("description"),
        priceCents,
        compareAtCents: i.fields.getTextInputValue("compare").trim() ? parseMoney(i.fields.getTextInputValue("compare")) : 0,
        emoji: i.fields.getTextInputValue("emoji").trim() || "cart"
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.productFieldDetail(gid, this.products.get(productId!, gid), field), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:stock:add:")) {
      const [, , , productId, fieldId] = id.split(":");
      const rawItems = i.fields.getTextInputValue("items");
      const added = this.products.addStock(productId!, rawItems, i.user.id, fieldId!);
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      await this.restocks.announce({ guildId: gid, productId: productId!, fieldId: fieldId!, actorId: i.user.id, addedQuantity: added });
      await this.refreshProductPublications(productId!).catch(() => undefined);
      return i.editReply({ content: `✅ ${added} unidade(s) nova(s) adicionada(s). Conteúdos duplicados foram ignorados.` });
    }
    if (id.startsWith("modal:stock:ghost:")) {
      const [, , , productId, fieldId] = id.split(":");
      const quantity = Number(i.fields.getTextInputValue("quantity").trim());
      if (!Number.isFinite(quantity) || quantity < 1) throw new Error("Informe uma quantidade virtual válida.");
      const previous = this.products.stockCount(productId!, "AVAILABLE", fieldId!);
      const field = this.products.setGhostStock(productId!, fieldId!, i.fields.getTextInputValue("content"), quantity, i.user.id);
      const added = Math.max(0, this.products.stockCount(productId!, "AVAILABLE", fieldId!) - previous);
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      await this.restocks.announce({ guildId: gid, productId: productId!, fieldId: fieldId!, actorId: i.user.id, addedQuantity: added });
      await this.refreshProductPublications(productId!).catch(() => undefined);
      return i.editReply(this.views.stockView(gid, this.products.get(productId!, gid), field) as never);
    }

    if (id === "modal:restock:edit") {
      const settings = this.db.guild(gid).restockAnnouncements;
      settings.title = i.fields.getTextInputValue("title").trim() || "Estoque atualizado";
      settings.message = i.fields.getTextInputValue("message").trim() || "Novas unidades disponíveis.";
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.restockSettings(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }

    if (id === "modal:stock-request:confirmation") {
      const settings = this.db.guild(gid).stockRequest;
      settings.confirmationMessage = i.fields.getTextInputValue("confirmation").trim();
      this.db.audit(i.user.id, "STOCK_REQUEST_CONFIRMATION_UPDATE", "guild", gid);
      this.db.save();
      return i.reply({ ...this.views.stockRequestsHome(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:stock-request:edit") {
      const settings = this.db.guild(gid).stockRequest;
      Object.assign(settings, {
        title: i.fields.getTextInputValue("title").trim(),
        description: i.fields.getTextInputValue("description").trim(),
        footer: i.fields.getTextInputValue("footer").trim(),
        buttonLabel: i.fields.getTextInputValue("button").trim(),
        confirmationMessage: i.fields.getTextInputValue("confirmation").trim()
      });
      this.db.audit(i.user.id, "STOCK_REQUEST_MESSAGE_UPDATE", "guild", gid);
      this.db.save();
      this.schedulePublishedRefresh();
      return i.reply({ ...this.views.stockRequestsHome(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:stock-request:appearance") {
      const settings = this.db.guild(gid).stockRequest;
      Object.assign(settings, {
        color: normalizeColor(i.fields.getTextInputValue("color")),
        emojiSemantic: i.fields.getTextInputValue("emoji").trim() || "stock_request",
        buttonStyle: styleName(i.fields.getTextInputValue("style")),
        imageUrl: i.fields.getTextInputValue("image").trim(),
        thumbnailUrl: i.fields.getTextInputValue("thumbnail").trim()
      });
      this.db.audit(i.user.id, "STOCK_REQUEST_APPEARANCE_UPDATE", "guild", gid);
      this.db.save();
      this.schedulePublishedRefresh();
      return i.reply({ ...this.views.stockRequestsHome(gid), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:stock-request:create") {
      const settings = this.db.guild(gid).stockRequest;
      if (!settings.enabled) throw new Error("Os pedidos de stock estão desativados.");
      if (!settings.requestChannelId) throw new Error("O administrador ainda não configurou o canal que receberá os pedidos de stock.");
      const channel = await this.client.channels.fetch(settings.requestChannelId);
      if (!(channel instanceof TextChannel)) throw new Error("O canal de pedidos de stock não está disponível.");
      const quantity = Math.max(1, Math.min(9999, Number(i.fields.getTextInputValue("quantity")) || 1));
      const now = nowIso();
      const request: StockRequest = {
        id: makeId("STK"),
        guildId: gid,
        userId: i.user.id,
        username: i.user.username,
        productName: i.fields.getTextInputValue("product").trim(),
        quantity,
        details: i.fields.getTextInputValue("details").trim(),
        status: "PENDING",
        claimedBy: "",
        channelId: channel.id,
        messageId: "",
        createdAt: now,
        updatedAt: now
      };
      this.db.state.stockRequests[request.id] = request;
      this.db.audit(i.user.id, "STOCK_REQUEST_CREATE", "stock_request", request.id, { productName: request.productName, quantity });
      this.db.save();
      const mentions = settings.notifyRoleIds.map((roleId) => `<@&${roleId}>`).join(" ");
      const message = await channel.send({ content: mentions || undefined, ...this.views.stockRequestDetail(gid, request) });
      request.messageId = message.id;
      request.updatedAt = nowIso();
      this.db.save();
      await i.reply({ content: `${this.emojis.text("stock_request_send", gid)} ${settings.confirmationMessage}\n\n**Protocolo:** \`${request.id}\``, flags: MessageFlags.Ephemeral });
      return;
    }

    if (id === "modal:saved-emoji:prepare") {
      const name = i.fields.getTextInputValue("name").trim();
      await this.collectSavedEmoji(i, name, true);
      return;
    }
    if (id === "modal:saved-emoji:limit") {
      const settings = this.db.guild(gid).emojiLibrary;
      settings.maxPerUser = Math.max(1, Math.min(500, Number(i.fields.getTextInputValue("limit")) || 25));
      this.db.audit(i.user.id, "EMOJI_LIBRARY_LIMIT", "guild", gid, { maxPerUser: settings.maxPerUser });
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.savedEmojisHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }

    if (id === "modal:wallet:pix") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      const key = i.fields.getTextInputValue("key").trim();
      if (key.length < 3) throw new Error("Informe uma chave PIX válida.");
      const account = this.db.wallet(gid, false);
      account.pixKey = key.slice(0, 200);
      account.updatedAt = nowIso();
      this.db.audit(i.user.id, "ZWALLET_PIX_UPDATE", "wallet", gid, { guildId: gid }, gid);
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.walletHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:wallet:withdraw") {
      if (!this.payments.walletManagerEnabled()) throw new Error("Zwallet está indisponível no momento pelo ZENYX Manager.");
      const account = this.db.wallet(gid, false);
      const settings = this.db.payments(gid).znyPay;
      const amountCents = parseMoney(i.fields.getTextInputValue("amount"));
      if (!account.pixKey) throw new Error("Cadastre uma chave PIX antes de solicitar o saque.");
      if (amountCents < settings.minWithdrawalCents) throw new Error(`O saque mínimo é ${formatMoney(settings.minWithdrawalCents)}.`);
      if (amountCents > account.balanceCents) throw new Error("Saldo insuficiente para esse saque.");
      if (amountCents <= settings.withdrawalFeeCents) throw new Error("O valor precisa ser maior que a taxa de saque.");
      const createdAt = nowIso();
      const netCents = amountCents - settings.withdrawalFeeCents;
      account.balanceCents -= amountCents;
      account.transactions.unshift({
        id: makeId("ZWT"),
        guildId: gid,
        type: "WITHDRAWAL",
        status: "PENDING",
        amountCents,
        feeCents: settings.withdrawalFeeCents,
        netCents,
        orderId: "",
        note: `Saque solicitado para PIX ${account.pixKey}`,
        createdAt
      });
      account.updatedAt = createdAt;
      this.db.audit(i.user.id, "ZWALLET_WITHDRAW_REQUEST", "wallet", gid, { guildId: gid, amountCents, feeCents: settings.withdrawalFeeCents, netCents }, gid);
      this.db.save();
      return i.reply({
        embeds: [new EmbedBuilder().setTitle("Saque registrado").setDescription(`Solicitação criada para sua chave PIX cadastrada.\n\nValor reservado: **${formatMoney(amountCents)}**\nTaxa: **${formatMoney(settings.withdrawalFeeCents)}**\nValor líquido: **${formatMoney(netCents)}**\n\n-# O saque fica pendente até o processamento financeiro do ZENYX Manager.`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:wallet", "Voltar para Zwallet", "wallet", ButtonStyle.Primary))],
        flags: MessageFlags.Ephemeral
      });
    }

    if (id === "modal:payment:mp") {
      const token = i.fields.getTextInputValue("token").trim();
      if (token) this.db.setSecret("mp_access_token", token, gid);
      Object.assign(this.db.payments(gid).mercadoPago, {
        pixKey: i.fields.getTextInputValue("pix").trim(),
        payerEmail: i.fields.getTextInputValue("email").trim(),
        statementDescriptor: i.fields.getTextInputValue("descriptor").trim()
      });
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "MERCADO_PAGO"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:efi") {
      const clientId = i.fields.getTextInputValue("client").trim();
      const secret = i.fields.getTextInputValue("secret").trim();
      if (clientId) this.db.setSecret("efi_client_id", clientId, gid);
      if (secret) this.db.setSecret("efi_client_secret", secret, gid);
      Object.assign(this.db.payments(gid).efiBank, {
        pixKey: i.fields.getTextInputValue("pix").trim(),
        merchantName: i.fields.getTextInputValue("merchant").trim() || "Minha Aplicação",
        merchantCity: i.fields.getTextInputValue("city").trim() || "SAO PAULO"
      });
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "EFI_BANK"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:evopay-token") {
      const token = i.fields.getTextInputValue("token").trim();
      if (token) {
        if (token.length < 12) throw new Error("A credencial informada parece incompleta.");
        this.db.setSecret("evopay_token", token, gid);
      }
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.evoPaySettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:evopay-expiry") {
      const raw = Number(i.fields.getTextInputValue("expires"));
      if (!Number.isFinite(raw) || raw < 180 || raw > 7200) throw new Error("A validade precisa ficar entre 180 e 7200 segundos.");
      this.db.payments(gid).evoPay.expiresIn = Math.trunc(raw);
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.evoPaySettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:stripe") {
      const key = i.fields.getTextInputValue("key").trim();
      if (key) this.db.setSecret("stripe_secret_key", key, gid);
      const settings = this.db.payments(gid).stripe;
      settings.statementDescriptor = i.fields.getTextInputValue("descriptor").trim() || "LOJA DISCORD";
      settings.webhookUrl = i.fields.getTextInputValue("webhook").trim();
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "STRIPE"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:mistic") {
      const clientId = i.fields.getTextInputValue("client").trim();
      const clientSecret = i.fields.getTextInputValue("secret").trim();
      if (clientId) this.db.setSecret("mistic_client_id", clientId, gid);
      if (clientSecret) this.db.setSecret("mistic_client_secret", clientSecret, gid);
      this.db.payments(gid).misticPay.webhookUrl = i.fields.getTextInputValue("webhook").trim();
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "MISTIC_PAY"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:purin") {
      const apiKey = i.fields.getTextInputValue("key").trim();
      if (apiKey) this.db.setSecret("purin_api_key", apiKey, gid);
      this.db.payments(gid).purinCash.callbackUrl = i.fields.getTextInputValue("callback").trim();
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "PURIN_CASH"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:imap-account") {
      const settings = this.db.payments(gid).imapPix;
      const email = i.fields.getTextInputValue("user").trim().toLowerCase();
      if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Informe um e-mail válido para o IMAP e para a chave PIX.");
      settings.username = email;
      settings.pixKey = email;
      settings.pixKeyType = "email";
      const password = i.fields.getTextInputValue("password").trim();
      if (password) this.db.setSecret("imap_password", password, gid);
      this.db.save();
      this.imap.start();
      return i.reply({ ...this.views.adminPage(gid, this.views.imapSettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:imap-pix") {
      const settings = this.db.payments(gid).imapPix;
      Object.assign(settings, {
        pixKey: i.fields.getTextInputValue("key").trim(),
        merchantName: i.fields.getTextInputValue("merchant").trim() || "Minha Aplicação",
        merchantCity: i.fields.getTextInputValue("city").trim() || "SAO PAULO"
      });
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.imapSettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:imap-timing") {
      const settings = this.db.payments(gid).imapPix;
      settings.pollIntervalSeconds = Math.max(20, Math.min(3600, Number(i.fields.getTextInputValue("poll")) || 30));
      settings.lookbackMinutes = Math.max(5, Math.min(10080, Number(i.fields.getTextInputValue("lookback")) || 90));
      settings.maxWaitMinutes = Math.max(5, Math.min(1440, Number(i.fields.getTextInputValue("maxwait")) || 15));
      settings.mailbox = i.fields.getTextInputValue("mailbox").trim() || "INBOX";
      this.db.save();
      this.imap.start();
      return i.reply({ ...this.views.adminPage(gid, this.views.imapSettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:imap-custom-server") {
      const settings = this.db.payments(gid).imapPix;
      settings.emailProvider = "CUSTOM";
      settings.host = i.fields.getTextInputValue("host").trim();
      settings.port = Math.max(1, Math.min(65535, Number(i.fields.getTextInputValue("port")) || 993));
      settings.secure = true;
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.imapSettingsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:manual") {
      const settings = this.db.payments(gid);
      const key = i.fields.getTextInputValue("key").trim();
      if (!key) throw new Error("Informe uma chave PIX válida.");
      settings.manualPixKey = key;
      settings.manualPixCode = "";
      this.db.save();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:general") {
      this.db.payments(gid).orderExpiresMinutes = Math.max(5, Math.min(1440, Number(i.fields.getTextInputValue("expiration")) || 15));
      this.db.payments(gid).pollIntervalSeconds = Math.max(10, Math.min(3600, Number(i.fields.getTextInputValue("poll")) || 15));
      this.db.save(); this.orders.startPolling();
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentsHome(gid), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:payment:efi-certpass") {
      this.db.setSecret("efi_certificate_password", i.fields.getTextInputValue("password").trim(), gid);
      return i.reply({ ...this.views.adminPage(gid, this.views.paymentProviderSettings(gid, "EFI_BANK"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }

    if (id.startsWith("modal:ticket:field-add:")) {
      const panelId = this.tickets.resolvePanel(id.split(":")[3]!, gid).id;
      this.tickets.addPanelField(panelId, {
        name: i.fields.getTextInputValue("name"),
        value: i.fields.getTextInputValue("value"),
        inline: false
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.ticketPanelFieldsView(gid, this.tickets.resolvePanel(panelId, gid)), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:field-edit:")) {
      let [, , , panelId, fieldId] = id.split(":");
      const panel = this.tickets.getPanelForField(panelId!, fieldId!, gid);
      panelId = panel.id;
      const current = panel.fields.find((item) => item.id === fieldId);
      if (!current) throw new Error("Campo do painel não encontrado.");
      this.tickets.updatePanelField(panelId!, fieldId!, {
        name: i.fields.getTextInputValue("name"),
        value: i.fields.getTextInputValue("value"),
        inline: current.inline
      }, i.user.id, gid);
      return i.reply({ ...this.views.adminPage(gid, this.views.ticketPanelFieldsView(gid, panel), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id === "modal:ticket:create") {
      const panel = this.tickets.createPanel({
        guildId: gid,
        name: i.fields.getTextInputValue("name"),
        title: i.fields.getTextInputValue("title"),
        description: i.fields.getTextInputValue("description"),
        color: normalizeColor(i.fields.getTextInputValue("color")),
        mode: "SELECT"
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.ticketPanelDetail(gid, panel), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:basic:")) {
      const panelId = id.split(":")[3]!;
      const panel = this.tickets.updatePanel(panelId, {
        title: i.fields.getTextInputValue("title"),
        description: i.fields.getTextInputValue("description"),
        color: normalizeColor(i.fields.getTextInputValue("color")),
        footer: i.fields.getTextInputValue("footer").trim(),
        buttonLabel: i.fields.getTextInputValue("label").trim() || "Selecione o atendimento"
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.views.ticketPanelDetail(gid, panel), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:option-add:")) {
      const panelId = this.tickets.resolvePanel(id.split(":")[3]!, gid).id;
      const option = this.tickets.addOption(panelId, {
        name: i.fields.getTextInputValue("name"),
        description: i.fields.getTextInputValue("description"),
        emojiSemantic: "support",
        channelPrefix: i.fields.getTextInputValue("prefix"),
        openingTitle: i.fields.getTextInputValue("opening_title"),
        openingDescription: i.fields.getTextInputValue("opening_description"),
        active: true,
        askSubject: true,
        mentionSupport: true,
        maxOpenTicketsPerUser: 1
      }, i.user.id);
      return i.reply({ ...this.views.adminPage(gid, this.ticketOptionDetail(gid, panelId, option.id), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:option-edit:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, {
        name: i.fields.getTextInputValue("name"),
        description: i.fields.getTextInputValue("description"),
        channelPrefix: i.fields.getTextInputValue("prefix"),
        openingTitle: i.fields.getTextInputValue("opening_title"),
        openingDescription: i.fields.getTextInputValue("opening_description")
      }, i.user.id, gid);
      return i.reply({ ...this.views.adminPage(gid, this.ticketOptionDetail(gid, panelId!, optionId!), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:option-close-message:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, { closeMessage: i.fields.getTextInputValue("close") }, i.user.id, gid);
      return i.reply({ ...this.views.adminPage(gid, this.ticketOptionDetail(gid, panelId!, optionId!), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:option-limit:")) {
      const [, , , panelId, optionId] = id.split(":");
      this.tickets.updateOption(panelId!, optionId!, { maxOpenTicketsPerUser: Number(i.fields.getTextInputValue("limit")) }, i.user.id, gid);
      return i.reply({ ...this.views.adminPage(gid, this.ticketOptionDetail(gid, panelId!, optionId!), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (id.startsWith("modal:ticket:option-emoji-manual:")) {
      const [, , , panelId, optionId] = id.split(":");
      const emoji = await this.emojis.validateUserInput(i.fields.getTextInputValue("emoji"), gid, false);
      this.tickets.updateOption(panelId!, optionId!, { emojiSemantic: emoji }, i.user.id, gid);
      return i.reply({ ...this.views.adminPage(gid, this.ticketOptionDetail(gid, panelId!, optionId!), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }

    if (id === "modal:brand:edit") { Object.assign(this.db.brand(gid), { name: i.fields.getTextInputValue("name").trim(), color: normalizeColor(i.fields.getTextInputValue("color")), footer: i.fields.getTextInputValue("footer").trim(), logoUrl: i.fields.getTextInputValue("logo").trim(), bannerUrl: i.fields.getTextInputValue("banner").trim() }); this.db.save(); return i.reply({ ...this.personalizeView(gid), flags: MessageFlags.Ephemeral }); }
    if (id === "modal:store:edit") { this.db.brand(gid).storeTitle = i.fields.getTextInputValue("title"); this.db.brand(gid).storeDescription = i.fields.getTextInputValue("description"); this.db.save(); return i.reply({ ...this.personalizeView(gid), flags: MessageFlags.Ephemeral }); }
    if (id === "modal:presence:edit") { const b = this.db.brand(gid); b.presenceText = i.fields.getTextInputValue("text"); const type = i.fields.getTextInputValue("type").trim(); b.presenceType = (["Playing", "Watching", "Listening", "Competing"].includes(type) ? type : "Watching") as never; const status = i.fields.getTextInputValue("status").trim(); b.status = (["online", "idle", "dnd", "invisible"].includes(status) ? status : "online") as never; this.db.save(); this.applyPresence(gid); return i.reply({ ...this.personalizeView(gid), flags: MessageFlags.Ephemeral }); }
    if (id === "modal:bot:bio") {
      // Interações antigas ainda podem chegar de uma mensagem que ficou aberta no
      // Discord. Nunca aceite o texto do modal: restaure a marca fixa.
      const confirmed = await this.restoreLockedInstitutionalBio(gid);
      return i.reply({ content: `🔒 **A Bio é protegida e não pode ficar vazia nem ser personalizada em bots filhos.**\nA Bio institucional ZENYX foi restaurada automaticamente e confirmada pelo Discord.\n\n${confirmed}`, ...this.personalizeView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:bot:identity") { await this.client.user?.setUsername(i.fields.getTextInputValue("username").trim()); return i.reply({ content: "Nome do bot atualizado. O Discord limita mudanças frequentes.", flags: MessageFlags.Ephemeral }); }
    if (id === "modal:automations:repeat-add" || id.startsWith("modal:automations:repeat-edit:")) {
      const settings = this.db.automations(gid);
      const name = i.fields.getTextInputValue("name").trim() || "Mensagem automática";
      const content = i.fields.getTextInputValue("content").trim();
      const intervalMinutes = Math.trunc(Number(i.fields.getTextInputValue("interval").replace(",", ".")));
      if (!content) throw new Error("A mensagem não pode ficar vazia.");
      if (!Number.isFinite(intervalMinutes) || intervalMinutes < 1 || intervalMinutes > 10080) throw new Error("O intervalo deve ficar entre 1 minuto e 10080 minutos (7 dias).");
      if (id === "modal:automations:repeat-add") {
        const rule = { id: makeId("RPT"), name: name.slice(0, 80), enabled: false, channelId: "", content: content.slice(0, 1900), intervalMinutes, lastMessageId: "", lastSentAt: "", createdAt: nowIso(), updatedAt: nowIso() };
        settings.repeatingMessages.push(rule); this.db.save();
        return i.reply({ ...this.automationRuleChannelPicker(gid, "repeat", rule.id), flags: MessageFlags.Ephemeral });
      }
      const ruleId = id.split(":")[3]!; const rule = settings.repeatingMessages.find((item) => item.id === ruleId);
      if (!rule) throw new Error("Mensagem recorrente não encontrada.");
      Object.assign(rule, { name: name.slice(0, 80), content: content.slice(0, 1900), intervalMinutes, updatedAt: nowIso() }); this.db.save();
      return i.reply({ ...this.repeatingMessageDetail(gid, rule.id), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:automations:mention-add" || id.startsWith("modal:automations:mention-edit:")) {
      const settings = this.db.automations(gid);
      const name = i.fields.getTextInputValue("name").trim() || "Mensagem da loja";
      const content = i.fields.getTextInputValue("content").trim();
      const intervalMinutes = Math.trunc(Number(i.fields.getTextInputValue("interval").replace(",", ".")));
      if (!content) throw new Error("A mensagem não pode ficar vazia.");
      if (!Number.isFinite(intervalMinutes) || intervalMinutes < 1 || intervalMinutes > 10080) throw new Error("O intervalo deve ficar entre 1 minuto e 10080 minutos (7 dias).");
      if (id === "modal:automations:mention-add") {
        const rule = { id: makeId("MEN"), name: name.slice(0, 80), enabled: false, channelId: "", content: content.slice(0, 1900), audience: "NEW_MEMBERS" as const, intervalMinutes, cursor: 0, lastSentAt: "", createdAt: nowIso(), updatedAt: nowIso() };
        settings.mentionMessages.push(rule); this.db.save();
        return i.reply({ ...this.automationRuleChannelPicker(gid, "mention", rule.id), flags: MessageFlags.Ephemeral });
      }
      const ruleId = id.split(":")[3]!; const rule = settings.mentionMessages.find((item) => item.id === ruleId);
      if (!rule) throw new Error("Mensagem com menção não encontrada.");
      Object.assign(rule, { name: name.slice(0, 80), content: content.slice(0, 1900), intervalMinutes, updatedAt: nowIso() }); this.db.save();
      return i.reply({ ...this.mentionMessageDetail(gid, rule.id), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:automations:reaction-add" || id.startsWith("modal:automations:reaction-edit:")) {
      const settings = this.db.automations(gid);
      const name = i.fields.getTextInputValue("name").trim() || "Reação do canal";
      if (id === "modal:automations:reaction-add") {
        const rule = { id: makeId("REA"), name: name.slice(0, 80), enabled: false, channelId: "", emojiId: "", emojiName: "", emojiGuildId: gid, createdAt: nowIso(), updatedAt: nowIso() };
        settings.autoReactions.push(rule); this.db.save();
        await i.guild?.emojis.fetch().catch(() => undefined);
        return i.reply({ ...this.guildReactionEmojiPicker(gid, rule.id, 0), flags: MessageFlags.Ephemeral });
      }
      const ruleId = id.split(":")[3]!; const rule = settings.autoReactions.find((item) => item.id === ruleId);
      if (!rule) throw new Error("Reação automática não encontrada.");
      Object.assign(rule, { name: name.slice(0, 80), updatedAt: nowIso() }); this.db.save();
      return i.reply({ ...this.autoReactionDetail(gid, rule.id), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:automations:reaction-emoji-search:")) {
      const ruleId = id.split(":")[3]!;
      const query = i.fields.getTextInputValue("query").trim();
      await i.guild?.emojis.fetch().catch(() => undefined);
      return i.reply({ ...this.guildReactionEmojiPicker(gid, ruleId, 0, query), flags: MessageFlags.Ephemeral });
    }

    if (id === "modal:automations:welcome-duration") {
      const seconds = Math.max(3, Math.min(120, Math.trunc(Number(i.fields.getTextInputValue("seconds")) || 8)));
      this.db.automations(gid).welcomeDeleteAfterSeconds = seconds;
      this.db.save();
      return i.reply({ content: `Boas-vindas temporária será apagada após **${seconds}s**.`, flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:automations:welcome-message" || id === "modal:automations:goodbye-message") {
      const settings = this.db.automations(gid);
      if (id.endsWith("welcome-message")) settings.welcomeMessage = i.fields.getTextInputValue("message").trim();
      else settings.goodbyeMessage = i.fields.getTextInputValue("message").trim();
      this.db.audit(i.user.id, "AUTOMATION_MESSAGE_UPDATE", "guild", gid, { type: id.endsWith("welcome-message") ? "welcome" : "goodbye" });
      this.db.save();
      return i.reply({ ...this.automationsView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:automations:response-add" || id.startsWith("modal:automations:response-edit:")) {
      const settings = this.db.automations(gid);
      const trigger = i.fields.getTextInputValue("trigger").trim();
      const responseText = i.fields.getTextInputValue("response").trim();
      if (!trigger || !responseText) throw new Error("Informe o gatilho e a resposta.");
      const duplicateIndex = settings.autoResponses.findIndex((entry) => entry.trigger.toLowerCase() === trigger.toLowerCase());
      if (id === "modal:automations:response-add") {
        if (duplicateIndex >= 0) throw new Error("Já existe uma resposta automática com esse gatilho.");
        settings.autoResponses.push({ trigger, response: responseText, exact: false });
        settings.autoResponsesEnabled = true;
        this.db.audit(i.user.id, "AUTO_RESPONSE_CREATE", "guild", gid, { trigger });
      } else {
        const index = Number(id.split(":")[3]);
        const current = settings.autoResponses[index];
        if (!current) throw new Error("Resposta automática não encontrada.");
        if (duplicateIndex >= 0 && duplicateIndex !== index) throw new Error("Já existe outra resposta automática com esse gatilho.");
        current.trigger = trigger;
        current.response = responseText;
        this.db.audit(i.user.id, "AUTO_RESPONSE_UPDATE", "guild", gid, { index, trigger });
      }
      this.db.save();
      return i.reply({ ...this.automationsView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:automations:schedule-add" || id.startsWith("modal:automations:schedule-edit:")) {
      const settings = this.db.automations(gid);
      const name = i.fields.getTextInputValue("name").trim() || "Horário de canais";
      const lockTime = i.fields.getTextInputValue("lock_time").trim();
      const unlockTime = i.fields.getTextInputValue("unlock_time").trim();
      const timePattern = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
      if (!timePattern.test(lockTime) || !timePattern.test(unlockTime)) throw new Error("Use horários no formato HH:mm, por exemplo 22:00 e 08:00.");
      if (lockTime === unlockTime) throw new Error("Os horários de fechar e abrir precisam ser diferentes.");
      const patch = {
        name: name.slice(0, 80),
        lockTime,
        unlockTime,
        lockMessage: i.fields.getTextInputValue("lock_message").trim().slice(0, 1800),
        unlockMessage: i.fields.getTextInputValue("unlock_message").trim().slice(0, 1800),
        updatedAt: nowIso()
      };
      if (id === "modal:automations:schedule-add") {
        if (settings.channelSchedules.length >= 25) throw new Error("O limite de 25 horários automáticos foi atingido.");
        const schedule = {
          id: makeId("SCH"),
          enabled: true,
          channelIds: [],
          timezone: "America/Sao_Paulo",
          lastLockDate: "",
          lastUnlockDate: "",
          createdAt: nowIso(),
          ...patch
        };
        settings.channelSchedules.push(schedule);
        this.db.audit(i.user.id, "CHANNEL_SCHEDULE_CREATE", "channel_schedule", schedule.id, { guildId: gid, lockTime, unlockTime }, gid);
        this.db.save();
        return i.reply({ ...this.channelScheduleChannelsView(gid, schedule.id), flags: MessageFlags.Ephemeral });
      }
      const scheduleId = id.split(":")[3]!;
      const schedule = settings.channelSchedules.find((item) => item.id === scheduleId);
      if (!schedule) throw new Error("Horário automático não encontrado.");
      Object.assign(schedule, patch);
      this.db.audit(i.user.id, "CHANNEL_SCHEDULE_UPDATE", "channel_schedule", schedule.id, { guildId: gid, lockTime, unlockTime }, gid);
      this.db.save();
      return i.reply({ ...this.channelScheduleDetail(gid, schedule.id), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:message:create" || id.startsWith("modal:message:basic:")) {
      const data = {
        name: i.fields.getTextInputValue("name").trim().slice(0, 80) || "Mensagem",
        content: i.fields.getTextInputValue("content").trim().slice(0, 2000),
        title: i.fields.getTextInputValue("title").trim().slice(0, 300),
        description: i.fields.getTextInputValue("description").trim().slice(0, 4000),
        color: normalizeColor(i.fields.getTextInputValue("color"))
      };
      if (!data.content && !data.title && !data.description) throw new Error("Informe conteúdo, título ou descrição para a mensagem.");
      if (id === "modal:message:create") {
        const template: BotMessageTemplate = {
          id: makeId("MSG"), guildId: gid, ...data, bannerUrl: "", thumbnailUrl: "", footer: this.db.brand(gid).footer,
          links: [], publications: [], createdAt: nowIso(), updatedAt: nowIso()
        };
        this.db.state.messageTemplates[template.id] = template;
        this.db.audit(i.user.id, "BOT_MESSAGE_CREATE", "message_template", template.id, { guildId: gid, name: template.name }, gid);
        this.db.save();
        return i.reply({ ...this.botMessageDetail(gid, template.id), flags: MessageFlags.Ephemeral });
      }
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      Object.assign(template, data, { updatedAt: nowIso() });
      this.db.audit(i.user.id, "BOT_MESSAGE_UPDATE", "message_template", template.id, { guildId: gid }, gid);
      this.db.save();
      return i.reply({ ...this.botMessageDetail(gid, template.id), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:message:visual:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      const bannerUrl = i.fields.getTextInputValue("banner").trim();
      const thumbnailUrl = i.fields.getTextInputValue("thumbnail").trim();
      if (bannerUrl && !/^https?:\/\//i.test(bannerUrl)) throw new Error("A URL do banner precisa começar com http:// ou https://.");
      if (thumbnailUrl && !/^https?:\/\//i.test(thumbnailUrl)) throw new Error("A URL da miniatura precisa começar com http:// ou https://.");
      Object.assign(template, { bannerUrl, thumbnailUrl, footer: i.fields.getTextInputValue("footer").trim().slice(0, 1900), updatedAt: nowIso() });
      this.db.audit(i.user.id, "BOT_MESSAGE_VISUAL", "message_template", template.id, { guildId: gid }, gid);
      this.db.save();
      return i.reply({ ...this.botMessageDetail(gid, template.id), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:message:link-add:")) {
      const template = this.botMessageTemplate(gid, id.split(":")[3]!);
      if (template.links.length >= 5) throw new Error("A mensagem já possui o limite de 5 botões de link.");
      const url = i.fields.getTextInputValue("url").trim();
      if (!/^https?:\/\//i.test(url)) throw new Error("A URL do botão precisa começar com http:// ou https://.");
      const emojiInput = i.fields.getTextInputValue("emoji").trim();
      const emoji = emojiInput ? await this.emojis.validateUserInput(emojiInput, gid, true) : "";
      template.links.push({ id: makeId("LNK"), label: i.fields.getTextInputValue("label").trim().slice(0, 80) || "Abrir link", url, emoji });
      template.updatedAt = nowIso();
      this.db.audit(i.user.id, "BOT_MESSAGE_LINK_ADD", "message_template", template.id, { guildId: gid, url }, gid);
      this.db.save();
      return i.reply({ ...this.botMessageDetail(gid, template.id), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:protection:domains") {
      const settings = this.db.protection(gid);
      settings.allowedDomains = [...new Set(i.fields.getTextInputValue("domains").split(/[\n,]/).map((value) => value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "")).filter(Boolean))].slice(0, 100);
      this.db.audit(i.user.id, "PROTECTION_DOMAINS_UPDATE", "guild", gid, { count: settings.allowedDomains.length });
      this.db.save();
      return i.reply({ ...this.protectionView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:protection:spam-limits") {
      const settings = this.db.protection(gid);
      settings.spamMessages = Math.max(3, Math.min(50, Math.trunc(Number(i.fields.getTextInputValue("messages"))) || 6));
      settings.spamWindowSeconds = Math.max(3, Math.min(300, Math.trunc(Number(i.fields.getTextInputValue("window"))) || 8));
      settings.spamTimeoutSeconds = Math.max(10, Math.min(86_400, Math.trunc(Number(i.fields.getTextInputValue("timeout"))) || 60));
      this.db.audit(i.user.id, "PROTECTION_SPAM_LIMITS", "guild", gid, { messages: settings.spamMessages, windowSeconds: settings.spamWindowSeconds, timeoutSeconds: settings.spamTimeoutSeconds });
      this.db.save();
      return i.reply({ ...this.protectionView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:coupon:create") {
      const [typeRaw, valueRaw] = i.fields.getTextInputValue("discount").split("|").map((value) => value.trim());
      const [minimumRaw, maxRaw, perUserRaw] = i.fields.getTextInputValue("limits").split("|").map((value) => value.trim());
      const [startsRaw, expiresRaw] = i.fields.getTextInputValue("dates").split("|").map((value) => value.trim());
      const [productsRaw, groupsRaw] = i.fields.getTextInputValue("scope").split("|").map((value) => value.trim());
      const type = typeRaw?.toUpperCase() === "FIXED" ? "FIXED" : "PERCENT";
      const value = type === "PERCENT" ? Number(valueRaw) : parseMoney(valueRaw || "0");
      if (!Number.isFinite(value) || value <= 0 || (type === "PERCENT" && value > 100)) throw new Error("Informe um desconto válido. Percentual deve ficar entre 0 e 100.");
      const startsAt = startsRaw ? new Date(startsRaw).toISOString() : null;
      const expiresAt = expiresRaw ? new Date(expiresRaw).toISOString() : null;
      if (startsAt && expiresAt && Date.parse(expiresAt) <= Date.parse(startsAt)) throw new Error("A expiração precisa ser posterior ao início.");
      const productIds = (productsRaw || "").split(",").map((value) => value.trim()).filter(Boolean);
      for (const productId of productIds) this.products.get(productId, gid);
      this.products.createCoupon({
        guildId: gid, code: i.fields.getTextInputValue("code"), type, value,
        minOrderCents: minimumRaw ? parseMoney(minimumRaw) : 0,
        maxUses: maxRaw ? Math.max(1, Math.trunc(Number(maxRaw))) : null,
        perUserLimit: Math.max(0, Math.trunc(Number(perUserRaw || 0))), active: true,
        startsAt, expiresAt, productIds,
        productGroups: (groupsRaw || "").split(",").map((item) => item.trim()).filter(Boolean).slice(0, 100)
      }, i.user.id);
      return i.reply({ ...this.couponsView(gid), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:coupon:edit-basic:")) {
      const couponId = id.split(":")[3]!;
      const [typeRaw, valueRaw] = i.fields.getTextInputValue("discount").split("|").map((value) => value.trim());
      const type = typeRaw?.toUpperCase() === "FIXED" ? "FIXED" : "PERCENT";
      const value = type === "PERCENT" ? Number(valueRaw) : parseMoney(valueRaw || "0");
      if (!Number.isFinite(value) || value <= 0 || (type === "PERCENT" && value > 100)) throw new Error("Desconto inválido.");
      this.products.updateCoupon(gid, couponId, { code: i.fields.getTextInputValue("code"), type, value, minOrderCents: parseMoney(i.fields.getTextInputValue("minimum") || "0") }, i.user.id);
      return i.reply({ ...this.couponDetail(gid, couponId), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:coupon:edit-rules:")) {
      const couponId = id.split(":")[3]!;
      const start = i.fields.getTextInputValue("start").trim(); const expires = i.fields.getTextInputValue("expires").trim();
      const startsAt = start ? new Date(start).toISOString() : null; const expiresAt = expires ? new Date(expires).toISOString() : null;
      if (startsAt && expiresAt && Date.parse(expiresAt) <= Date.parse(startsAt)) throw new Error("A expiração precisa ser posterior ao início.");
      const maxRaw = i.fields.getTextInputValue("max").trim();
      this.products.updateCoupon(gid, couponId, { maxUses: maxRaw ? Math.max(1, Math.trunc(Number(maxRaw))) : null, perUserLimit: Math.max(0, Math.trunc(Number(i.fields.getTextInputValue("per_user") || 0))), startsAt, expiresAt }, i.user.id);
      return i.reply({ ...this.couponDetail(gid, couponId), flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("modal:coupon:edit-scope:")) {
      const couponId = id.split(":")[3]!;
      const productIds = i.fields.getTextInputValue("products").split(",").map((value) => value.trim()).filter(Boolean);
      for (const productId of productIds) this.products.get(productId, gid);
      this.products.updateCoupon(gid, couponId, { productIds, productGroups: i.fields.getTextInputValue("groups").split(",").map((value) => value.trim()).filter(Boolean).slice(0, 100) }, i.user.id);
      return i.reply({ ...this.couponDetail(gid, couponId), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:backup:create") {
      if (!i.guild) throw new Error("Servidor indisponível.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const backup = await this.backups.create(i.guild, i.user.id, i.fields.getTextInputValue("name"));
      await i.editReply(this.backupDetail(gid, backup.id) as never);
      return;
    }
    if (id.startsWith("modal:backup:rename:")) {
      const backupId = id.split(":")[3]!;
      const backup = this.backups.rename(gid, backupId, i.fields.getTextInputValue("name"), i.user.id);
      return i.reply({ ...this.backupDetail(gid, backup.id), flags: MessageFlags.Ephemeral });
    }
    if (id === "modal:giveaway:create") { await i.deferReply({ flags: MessageFlags.Ephemeral }); const giveaway = await this.giveaways.create({ guildId: gid, channelId: i.fields.getTextInputValue("channel").trim(), prize: i.fields.getTextInputValue("prize"), winnersCount: Number(i.fields.getTextInputValue("winners")), endsAt: new Date(Date.now() + parseDuration(i.fields.getTextInputValue("duration"))).toISOString(), actorId: i.user.id }); await i.editReply(`Sorteio ${giveaway.id} publicado.`); return; }

    if (id === "modal:cart:coupon") {
      const cart = this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
      if (cart.status === "PAYMENT_PENDING") throw new Error("Cancele o pagamento pendente antes de alterar o cupom.");
      const code = i.fields.getTextInputValue("code").trim().toUpperCase();
      const subtotal = cart.items.reduce((sum, item) => {
        const product = this.products.get(item.productId, gid); const field = this.products.getField(product.id, item.fieldId);
        return sum + field.priceCents * item.quantity;
      }, 0);
      const validation = this.products.applyCoupon(code, subtotal, { guildId: gid, userId: i.user.id, productIds: cart.items.map((item) => item.productId) });
      cart.couponCode = validation.coupon?.code ?? ""; cart.updatedAt = nowIso(); this.db.save();
      await i.deferReply({ flags: MessageFlags.Ephemeral }); await this.refreshCartMessage(gid, i.user.id);
      await i.editReply(`✅ Cupom **${cart.couponCode}** aplicado. Desconto: **${formatMoney(validation.discountCents)}**.`); return;
    }
    if (id.startsWith("modal:cart-quantity:")) {
      const [, , productId, fieldId] = id.split(":");
      const quantity = Number(i.fields.getTextInputValue("quantity").trim());
      if (!Number.isFinite(quantity)) throw new Error("Informe uma quantidade válida.");
      this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
      this.products.setCartQuantity(i.user.id, productId!, fieldId!, quantity, gid);
      await i.deferReply({ flags: MessageFlags.Ephemeral }); await this.refreshCartMessage(gid, i.user.id);
      await i.editReply("✅ Quantidade atualizada no carrinho."); return;
    }
    if (id.startsWith("modal:cart:imap-name:")) {
      const expectedCartId = id.split(":")[3]!;
      const cart = this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
      if (cart.id !== expectedCartId) throw new Error("Este carrinho não corresponde mais à compra atual.");
      const payerFullName = i.fields.getTextInputValue("name").trim().replace(/\s+/g, " ");
      if (payerFullName.split(" ").filter(Boolean).length < 2) throw new Error("Informe o nome completo de quem fará o Pix.");
      cart.selectedProvider = "IMAP_PIX";
      cart.status = "CHECKOUT";
      cart.updatedAt = nowIso();
      this.db.save();
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const order = await this.orders.createFromCart({
        guildId: gid,
        userId: i.user.id,
        username: i.user.displayName,
        purchaseChannelId: cart.channelId,
        provider: "IMAP_PIX",
        payerFullName
      });
      await this.refreshOrderMessage(order);
      await i.editReply(`✅ Pagamento criado para **${bankProfile(order.imapBank || this.db.payments(gid).imapPix.bank).label}**. O bot verificará o valor e o nome **${truncate(order.payerFullName, 100)}**.`);
      return;
    }
    if (id.startsWith("modal:cart:gateway-payer:")) {
      const [, , , expectedCartId, providerRaw] = id.split(":");
      const provider = providerRaw as PaymentProviderName;
      if (!["STRIPE", "MISTIC_PAY"].includes(provider)) throw new Error("Gateway inválido para este formulário.");
      const cart = this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
      if (cart.id !== expectedCartId) throw new Error("Este carrinho não corresponde mais à compra atual.");
      const payerFullName = i.fields.getTextInputValue("name").trim().replace(/\s+/g, " ");
      const payerDocument = i.fields.getTextInputValue("document").replace(/\D/g, "");
      cart.selectedProvider = provider;
      cart.status = "CHECKOUT";
      cart.updatedAt = nowIso();
      this.db.save();
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const order = await this.orders.createFromCart({ guildId: gid, userId: i.user.id, username: i.user.displayName, purchaseChannelId: cart.channelId, provider, payerFullName, payerDocument });
      await this.refreshOrderMessage(order);
      await i.editReply("✅ Cobrança PIX criada. Use um dos dois botões de cópia; ambos retornam somente o código copia e cola.");
      return;
    }
    if (id === "modal:checkout") throw new Error("Este fluxo antigo foi removido. Use o painel individual do produto.");
    if (id.startsWith("modal:ticket:open:")) { const [, , , panelId, optionId] = id.split(":"); await i.deferReply({ flags: MessageFlags.Ephemeral }); const channel = await this.tickets.open(i.guild!, i.member as GuildMember, panelId!, optionId!, i.fields.getTextInputValue("subject")); await i.editReply(`Ticket criado: ${channel}`); return; }
    if (id.startsWith("modal:ticket:add:")) { const ticketId = id.split(":")[3]!; await this.tickets.addMember(ticketId, i.fields.getTextInputValue("user").replace(/\D/g, ""), i.user.id); return i.reply({ content: "Usuário adicionado.", flags: MessageFlags.Ephemeral }); }
    if (id.startsWith("modal:ticket:remove:")) { const ticketId = id.split(":")[3]!; await this.tickets.removeMember(ticketId, i.fields.getTextInputValue("user").replace(/\D/g, ""), i.user.id); return i.reply({ content: "Usuário removido.", flags: MessageFlags.Ephemeral }); }
    if (id.startsWith("modal:ticket:rename:")) { const ticketId = id.split(":")[3]!; await this.tickets.rename(ticketId, i.fields.getTextInputValue("name"), i.user.id); return i.reply({ content: "Canal renomeado.", flags: MessageFlags.Ephemeral }); }
  }

  private async cartButton(i: ButtonInteraction, id: string, gid: string) {
    const cart = this.assertCartOwner(gid, i.user.id, i.channelId ?? undefined);
    if (cart.status === "PAYMENT_PENDING" && !id.startsWith("cart:cancel")) throw new Error("Existe um pagamento pendente. Verifique ou cancele esse pagamento antes de alterar o carrinho.");
    if (id === "cart:review") return i.update(this.views.cart(gid, i.user.id, i.user.displayName, i.user.displayAvatarURL()) as never);
    if (id === "cart:payment-methods") {
      const methods = this.payments.enabledMethods(gid);
      if (!methods.length) throw new Error("Nenhuma forma de pagamento está ativa. Avise a equipe do servidor.");
      return i.update(this.views.paymentMethods(gid, methods) as never);
    }
    if (id === "cart:coupon-apply") return i.showModal(modal("modal:cart:coupon", "Aplicar cupom", [input("code", "Código do cupom", cart.couponCode, TextInputStyle.Short, true, 30)]));
    if (id === "cart:coupon-remove") {
      cart.couponCode = ""; cart.updatedAt = nowIso(); this.db.save();
      return i.update(this.views.cart(gid, i.user.id, i.user.displayName, i.user.displayAvatarURL()) as never);
    }
    if (id === "cart:return") {
      const url = cart.sourceChannelId && cart.sourceMessageId ? `https://discord.com/channels/${gid}/${cart.sourceChannelId}/${cart.sourceMessageId}` : "";
      return i.reply({ content: url ? `Volte ao painel do produto: ${url}` : "O painel original não está mais acessível. Você pode continuar usando este carrinho.", flags: MessageFlags.Ephemeral });
    }
    if (id === "cart:cancel") {
      if (cart.orderId) {
        const order = this.orders.get(cart.orderId, gid);
        if (order.status === "PENDING") this.orders.cancel(order.id, i.user.id);
      }
      this.products.abandonCart(gid, i.user.id, "CANCELED");
      await i.update({ embeds: [new EmbedBuilder().setColor(0xef4444).setTitle("Compra cancelada").setDescription("O carrinho foi cancelado, as reservas foram liberadas e este canal será fechado.")], components: [] });
      await this.closePurchaseChannel(cart, "cancelada pelo cliente");
      return;
    }
    if (id.startsWith("cart:qty-")) {
      const parts = id.split(":"); const action = parts[1]!.slice(4); const productId = parts[2]!; const fieldId = parts[3]!;
      const product = this.products.get(productId, gid); const field = this.products.getField(productId, fieldId);
      const item = cart.items.find((entry) => entry.productId === productId && entry.fieldId === fieldId);
      if (!item) throw new Error("Item não encontrado no carrinho.");
      if (action === "edit") return i.showModal(modal(`modal:cart-quantity:${productId}:${fieldId}`, "Alterar quantidade", [input("quantity", "Nova quantidade", String(item.quantity), TextInputStyle.Short, true, 5)]));
      const next = action === "inc" ? item.quantity + 1 : item.quantity - 1;
      this.products.setCartQuantity(i.user.id, productId, fieldId, next, gid);
      return i.update(this.views.cartItemManage(gid, i.user.id, product, field) as never);
    }
    if (id.startsWith("cart:remove:")) {
      const [, , productId, fieldId] = id.split(":");
      this.products.removeFromCart(i.user.id, productId!, fieldId!, gid);
      return i.update(this.views.cart(gid, i.user.id, i.user.displayName, i.user.displayAvatarURL()) as never);
    }
    if (id.startsWith("cart:pay:")) {
      const provider = id.split(":")[2] as PaymentProviderName;
      if (!this.payments.enabled(gid, provider)) throw new Error("Esta forma de pagamento não está disponível.");
      if (provider === "IMAP_PIX") {
        const bank = bankProfile(this.db.payments(gid).imapPix.bank);
        return i.showModal(modal(`modal:cart:imap-name:${cart.id}`, `Verificação PIX • ${bank.label}`.slice(0, 45), [
          input("name", "Nome completo de quem fará o Pix", "", TextInputStyle.Short, true, 120, "Digite exatamente como aparece na conta bancária")
        ]));
      }
      if (["STRIPE", "MISTIC_PAY"].includes(provider)) {
        return i.showModal(modal(`modal:cart:gateway-payer:${cart.id}:${provider}`, `Dados do pagador • ${provider === "STRIPE" ? "Stripe" : "MisticPay"}`.slice(0, 45), [
          input("name", "Nome completo de quem fará o PIX", "", TextInputStyle.Short, true, 120),
          input("document", "CPF ou CNPJ (somente números)", "", TextInputStyle.Short, true, 14)
        ]));
      }
      cart.selectedProvider = provider; cart.status = "CHECKOUT"; cart.updatedAt = nowIso(); this.db.save();
      await i.deferUpdate();
      const order = await this.orders.createFromCart({ guildId: gid, userId: i.user.id, username: i.user.displayName, purchaseChannelId: cart.channelId, provider });
      const attachment = this.orders.qrAttachment(order);
      await i.message.edit({ ...this.views.paymentPending(gid, order), files: attachment ? [attachment] : [], attachments: [] } as never);
      return;
    }
  }

  private async paymentButton(i: ButtonInteraction, id: string, gid: string) {
    const orderId = id.split(":")[2]!;
    const order = this.orders.get(orderId, gid);
    const cart = this.db.state.carts[order.cartId] ?? this.db.state.abandonedCarts[order.cartId];

    // O checkout público do carrinho mostra apenas “Ações da equipe”. As ações
    // realmente sensíveis são entregues em uma resposta efêmera depois da
    // validação PAYMENTS, portanto o cliente não vê botões de aprovação/entrega.
    if (id.startsWith("payment:staff:")) {
      this.requireScope(i, "PAYMENTS");
      const controls: ButtonBuilder[] = [];
      if (order.provider === "MANUAL_PIX" && order.status === "PENDING") {
        controls.push(this.views.button(gid, `payment:manual-approve:${order.id}`, "Confirmar pagamento", "approve", ButtonStyle.Success));
      }
      if (order.status === "AWAITING_DELIVERY") {
        controls.push(this.views.button(gid, `payment:manual-deliver:${order.id}`, "Confirmar entrega", "delivery", ButtonStyle.Success));
      }
      controls.push(this.views.button(gid, `payment:close:${order.id}`, "Fechar compra", "trash", ButtonStyle.Secondary));
      return i.reply({
        embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(`Ações da equipe • ${order.id}`).setDescription(`Status atual: **${order.status}**\nEstas ações exigem a permissão **PAYMENTS**.`)],
        components: [new ActionRowBuilder<ButtonBuilder>().addComponents(...controls.slice(0, 5))],
        flags: MessageFlags.Ephemeral
      });
    }

    if (id.startsWith("payment:manual-approve:")) {
      this.requireScope(i, "PAYMENTS");
      if (order.provider !== "MANUAL_PIX") throw new Error("Este pedido não usa PIX manual.");
      if (order.status !== "PENDING") throw new Error("Este pagamento não está pendente.");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      await this.orders.approveManual(order.id, i.user.id);
      const updated = this.orders.get(order.id, gid);
      await this.refreshOrderMessage(updated);
      await i.editReply({ embeds: [new EmbedBuilder()
        .setColor(updated.status === "AWAITING_DELIVERY" ? 0xf59e0b : 0x22c55e)
        .setTitle(updated.status === "AWAITING_DELIVERY" ? "Pagamento concluído" : "Pagamento e entrega concluídos")
        .setDescription(updated.status === "AWAITING_DELIVERY"
          ? "O PIX foi confirmado. O pedido agora está **aguardando entrega da equipe**; use **Ações da equipe** no checkout para finalizar."
          : "O pagamento foi confirmado e o pedido foi processado com sucesso.")
        .addFields({ name: "ID do pedido", value: `\`${updated.id}\``, inline: true }, { name: "Valor", value: `**${formatMoney(updated.totalCents)}**`, inline: true })] });
      return;
    }
    if (id.startsWith("payment:manual-deliver:")) {
      this.requireScope(i, "PAYMENTS");
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      await this.orders.completeManualDelivery(order.id, i.user.id);
      const updated = this.orders.get(order.id, gid);
      await this.refreshOrderMessage(updated);
      await i.editReply({ embeds: [new EmbedBuilder()
        .setColor(0x22c55e)
        .setTitle("Entrega concluída")
        .setDescription("A entrega manual foi confirmada pela equipe. O cliente recebeu o comprovante e o pedido não poderá ser concluído novamente.")
        .addFields({ name: "ID do pedido", value: `\`${updated.id}\``, inline: true }, { name: "Valor", value: `**${formatMoney(updated.totalCents)}**`, inline: true })] });
      return;
    }
    if (id.startsWith("payment:close:")) {
      const isOwner = order.userId === i.user.id;
      if (!isOwner) this.requireScope(i, "PAYMENTS");
      await i.reply({ content: "🔒 Fechando esta compra...", flags: MessageFlags.Ephemeral });
      await this.closePurchaseChannel(cart, "finalizada");
      return;
    }

    if (order.userId !== i.user.id) throw new Error("Este pagamento pertence a outro usuário.");
    if (id.startsWith("payment:key:") || id.startsWith("payment:code:")) {
      if (!order.pixCode) throw new Error("O código PIX ainda não está disponível.");
      return i.reply({ content: order.pixCode, flags: MessageFlags.Ephemeral, allowedMentions: { parse: [] } });
    }
    if (id.startsWith("payment:paid-notify:")) {
      if (order.provider !== "MANUAL_PIX" || order.status !== "PENDING") throw new Error("Esta cobrança não está aguardando confirmação manual.");
      const settings = this.db.guild(gid);
      const staffMentions = [...new Set([...settings.staffRoleIds, ...settings.permissions.paymentRoleIds, ...settings.permissions.adminRoleIds, ...settings.adminRoleIds])]
        .slice(0, 8).map((roleId) => `<@&${roleId}>`).join(" ");
      if (i.channel?.isTextBased() && "send" in i.channel) {
        await i.channel.send({ content: `${staffMentions ? `${staffMentions} ` : ""}<@${i.user.id}> informou que realizou o PIX do pedido **${order.id}**. Use **Ações da equipe** no checkout para confirmar o pagamento.`, allowedMentions: { users: [i.user.id], roles: [...new Set([...settings.staffRoleIds, ...settings.permissions.paymentRoleIds, ...settings.permissions.adminRoleIds, ...settings.adminRoleIds])].slice(0, 8) } }).catch(() => undefined);
      }
      return i.reply({ content: "✅ Equipe avisada. Aguarde a confirmação do pagamento.", flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("payment:cancel:")) {
      if (order.status !== "PENDING") throw new Error("Este pagamento não está pendente.");
      this.orders.cancel(order.id, i.user.id);
      await this.refreshOrderMessage(this.orders.get(order.id, gid));
      await i.reply({ content: "Pagamento cancelado. A compra será fechada.", flags: MessageFlags.Ephemeral });
      await this.closePurchaseChannel(cart, "pagamento cancelado pelo cliente");
      return;
    }
    if (id.startsWith("payment:check:")) {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      if (order.status !== "PENDING") { await i.editReply(`Status atual: **${order.status}**.`); return; }
      if (order.provider !== "IMAP_PIX") { await i.editReply("A verificação manual pelo botão existe somente para pagamentos IMAP."); return; }
      const result = await this.imap.checkNow(gid);
      await i.editReply(`Verificação IMAP concluída: ${result.approved} aprovado(s), ${result.review} para revisão, ${result.errors.length} erro(s). Status do pedido: **${this.orders.get(order.id).status}**.`);
      return;
    }
  }

  private async deliveryCopyButton(i: ButtonInteraction, id: string) {
    const [, , orderId, deliveryId] = id.split(":");
    if (!orderId || !deliveryId) throw new Error("Entrega inválida.");
    const order = this.orders.get(orderId);
    if (order.userId !== i.user.id) throw new Error("Este produto pertence a outro cliente.");
    if (!["DELIVERED", "AWAITING_DELIVERY"].includes(order.status)) throw new Error("O pagamento ainda não foi aprovado ou a entrega não foi concluída.");
    const delivery = order.deliveredProducts.find((item) => item.id === deliveryId);
    if (!delivery) throw new Error("A unidade entregue não foi encontrada.");
    if (!delivery.content) throw new Error("O conteúdo desta entrega está vazio.");
    const payload = { content: delivery.content, allowedMentions: { parse: [] as never[] } };
    if (i.guildId) return i.reply({ ...payload, flags: MessageFlags.Ephemeral });
    return i.reply(payload);
  }

  private async lockButton(i: ButtonInteraction, id: string, gid: string) {
    this.requireScope(i, "LOCKS");
    if (id === "lock:all-cancel") return i.update({ content: "Ação cancelada.", embeds: [], components: [] });
    if (!id.startsWith("lock:all-confirm:")) return;
    const [, , , mode, encoded] = id.split(":");
    const reason = decodeURIComponent(encoded || "Bloqueio administrativo");
    if (!i.guild || !(i.member instanceof GuildMember)) throw new Error("Servidor indisponível.");
    await i.deferUpdate();
    const result = mode === "lock" ? await this.locks.lockAll(i.guild, i.member, reason) : await this.locks.unlockAll(i.guild, i.member, reason);
    await i.editReply({ content: `✅ Operação concluída. Alterados: **${result.changed.length}** • Ignorados: **${result.skipped.length}** • Erros: **${result.errors.length}**`, embeds: [], components: [] });
  }

  private async productButton(i: ButtonInteraction, id: string, gid: string) {
    if (id.startsWith("product:buy:")) {
      const [, , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      return this.beginDirectPurchase(i, product, fieldId);
    }
    if (id.startsWith("product:terms:buy:")) {
      const [, , , productId, fieldId] = id.split(":");
      const product = this.products.get(productId!, gid);
      const field = this.products.getField(product.id, fieldId);
      return this.beginDirectPurchase(i, product, field.id, true);
    }
    if (id.startsWith("product:cancel:")) {
      const product = this.products.get(id.split(":")[2]!, gid);
      return this.storeRespond(i, this.views.publicProduct(gid, product) as never);
    }
  }

  private async beginDirectPurchase(
    i: ButtonInteraction | StringSelectMenuInteraction,
    product: ReturnType<ProductService["get"]>,
    fieldId?: string,
    termsAccepted = false
  ) {
    if (!i.guild || !i.guildId) throw new Error("Compra disponível somente dentro do servidor.");
    const field = this.products.getField(product.id, fieldId);
    if (product.guildId !== i.guildId) throw new Error("Este produto pertence a outro servidor.");
    if (!product.active || !field.active) throw new Error("Esta opção está indisponível no momento.");
    if ((product.deliveryType === "STOCK" || product.deliveryType === "MANUAL") && this.products.stockCount(product.id, "AVAILABLE", field.id) < product.minQuantity) throw new Error("Esta opção está sem stock no momento.");

    const isSelect = i.isStringSelectMenu();
    if (isSelect) {
      // O update substitui a mensagem pelo painel sem valores padrão, resetando visualmente o select.
      // Publicações em Components V2 precisam manter o mesmo formato para preservar a faixa de emojis ampliada.
      const resetPayload = i.message.flags.has(MessageFlags.IsComponentsV2)
        ? this.views.publishedProduct(i.guildId, product)
        : this.views.publicProduct(i.guildId, product);
      await i.update(resetPayload as never);
    }
    if (product.requireTerms && !termsAccepted) {
      const terms = { ...this.views.termsConfirmation(i.guildId, product, field), flags: MessageFlags.Ephemeral };
      if (isSelect || i.replied || i.deferred) await i.followUp(terms as never);
      else await i.reply(terms as never);
      return;
    }

    if (!this.guardPurchase(i.guildId, i.user.id, product.id, field.id)) {
      const content = "Este item já está sendo processado. Use o carrinho aberto para alterar a quantidade.";
      if (isSelect || i.replied || i.deferred) await i.followUp({ content, flags: MessageFlags.Ephemeral }); else await i.reply({ content, flags: MessageFlags.Ephemeral });
      return;
    }
    if (!isSelect && !i.replied && !i.deferred) await i.reply({ content: `${this.emojis.text("loading", i.guildId!)} Preparando sua compra privada...`, flags: MessageFlags.Ephemeral });

    const sourceMessageId = isSelect ? i.message.id : i.message.id;
    const cart = this.products.ensureCart(i.guildId, i.user.id, i.channelId, sourceMessageId);
    const alreadyInCart = cart.items.some((item) => item.productId === product.id && item.fieldId === field.id);
    if (!alreadyInCart) this.products.addToCart(i.user.id, product.id, field.id, 1, i.guildId);

    let channel = cart.channelId ? (i.guild.channels.cache.get(cart.channelId) ?? await i.guild.channels.fetch(cart.channelId).catch(() => undefined)) : undefined;
    if (!(channel instanceof TextChannel)) {
      const settings = this.db.guild(i.guildId);
      const category = settings.purchaseCategoryId ? (i.guild.channels.cache.get(settings.purchaseCategoryId) ?? await i.guild.channels.fetch(settings.purchaseCategoryId).catch(() => undefined)) : undefined;
      const parent = category?.type === ChannelType.GuildCategory ? category.id : undefined;
      const member = i.member instanceof GuildMember ? i.member : await i.guild.members.fetch(i.user.id);
      const botId = i.guild.members.me?.id ?? this.client.user?.id;
      // IDs de cargos podem permanecer salvos mesmo depois do cargo ser apagado.
      // Forçamos a atualização do cache e descartamos IDs inexistentes antes de
      // criar o canal. Além disso, cada overwrite informa explicitamente se é
      // Role ou Member, evitando o erro do discord.js "not a cached User or Role".
      await i.guild.roles.fetch().catch(() => undefined);
      const permittedRoles = [...new Set([
        ...settings.staffRoleIds,
        ...settings.permissions.supportRoleIds,
        ...settings.permissions.paymentRoleIds,
        ...settings.permissions.adminRoleIds,
        ...settings.adminRoleIds
      ])].filter((roleId) => i.guild!.roles.cache.has(roleId));
      channel = await i.guild.channels.create({
        name: truncate(`carrinho-${channelSafe(member.displayName || i.user.username)}-${cart.id.slice(-4).toLowerCase()}`, 90),
        type: ChannelType.GuildText,
        parent,
        topic: `Carrinho ${cart.id} • Cliente ${i.user.id}`,
        permissionOverwrites: [
          { id: i.guild.roles.everyone.id, type: OverwriteType.Role, deny: [PermissionFlagsBits.ViewChannel] },
          { id: i.user.id, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks] },
          { id: i.guild.ownerId, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages] },
          ...permittedRoles.map((roleId) => ({ id: roleId, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages] })),
          ...(botId ? [{ id: botId, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.EmbedLinks] }] : [])
        ],
        reason: `Carrinho iniciado por ${i.user.tag}`
      });
      cart.channelId = channel.id;
      this.db.save();
    }

    const userName = i.member instanceof GuildMember ? i.member.displayName : i.user.displayName;
    const payload = this.views.cart(i.guildId, i.user.id, userName, i.user.displayAvatarURL());
    let message = cart.messageId ? await channel.messages.fetch(cart.messageId).catch(() => undefined) : undefined;
    if (message) await message.edit(payload as never);
    else {
      message = await channel.send({ content: `<@${i.user.id}>`, ...payload, allowedMentions: { users: [i.user.id] } });
      cart.messageId = message.id;
      this.db.save();
    }
    const linkRow = this.purchaseLinkRow(i.guildId, channel.id);
    const content = alreadyInCart
      ? `O item já está no carrinho. Use o botão abaixo para abrir sua compra.`
      : `✅ **${product.name} • ${field.name}** foi adicionado. Use o botão abaixo para continuar.`;
    if (isSelect) await i.followUp({ content, components: [linkRow], flags: MessageFlags.Ephemeral });
    else await i.editReply({ content, components: [linkRow] });

    // O atalho da compra é propositalmente efêmero: somente o comprador vê o
    // botão. Não publicamos uma segunda mensagem no canal de vendas, evitando
    // duplicação, exposição do carrinho privado e ruído para os demais membros.
  }

  private async storeButton(i: ButtonInteraction, id: string, gid: string) {
    if (id === "store:catalog") return this.storeRespond(i, this.views.storeCatalog(gid) as never);
    if (/^store:page:\d+$/.test(id)) return this.storeRespond(i, this.views.storeCatalog(gid, Number(id.split(":")[2])) as never);
    if (id.startsWith("store:product:")) return this.storeRespond(i, this.views.publicProduct(gid, this.products.get(id.split(":")[2]!, gid)) as never);
    if (id === "store:cart") return this.storeRespond(i, this.views.cart(gid, i.user.id) as never);
    if (id === "store:orders") return this.storeRespond(i, { embeds: [this.userOrdersEmbed(gid, i.user.id)], components: [this.views.back(gid, "store:catalog")] });
    if (id === "store:cart:clear") { this.products.clearCart(i.user.id); return this.storeRespond(i, this.views.cart(gid, i.user.id) as never); }
    if (id.startsWith("store:terms:add:")) { this.products.addToCart(i.user.id, id.split(":")[3]!); return this.storeRespond(i, this.views.cart(gid, i.user.id) as never); }
    if (id.startsWith("store:terms:buy:")) throw new Error("Este painel antigo foi desativado. Publique o painel individual do produto.");
    if (id.startsWith("store:add:")) {
      const product = this.products.get(id.split(":")[2]!, gid);
      if (product.requireTerms) return this.storeRespond(i, this.views.termsConfirmation(gid, product, this.products.getField(product.id)) as never);
      this.products.addToCart(i.user.id, product.id);
      return this.storeRespond(i, this.views.cart(gid, i.user.id) as never);
    }
    if (id.startsWith("store:buy:")) {
      const product = this.products.get(id.split(":")[2]!, gid);
      if (product.requireTerms) return this.storeRespond(i, this.views.termsConfirmation(gid, product, this.products.getField(product.id)) as never);
      throw new Error("Este painel antigo foi desativado. Publique o painel individual do produto.");
    }
    if (id === "store:checkout") throw new Error("Este painel antigo foi desativado. Publique o painel individual do produto.");
  }

  private async stockRequestButton(i: ButtonInteraction, id: string, gid: string) {
    if (id === "stock-request:open") {
      const settings = this.db.guild(gid).stockRequest;
      if (!settings.enabled) throw new Error("Os pedidos de stock estão desativados neste servidor.");
      return i.showModal(modal("modal:stock-request:create", "Pedir Stock", [
        input("product", "Qual produto você procura?", "", TextInputStyle.Short, true, 150, "Ex.: Discord Nitro 1 mês"),
        input("quantity", "Quantidade desejada", "1", TextInputStyle.Short, true, 4),
        input("details", "Detalhes adicionais", "", TextInputStyle.Paragraph, false, 1500, "Plano, duração, região, prazo ou outra informação")
      ]));
    }
    const [, action, requestId] = id.split(":");
    if (!requestId) throw new Error("Solicitação inválida.");
    const request = this.db.state.stockRequests[requestId];
    if (!request || request.guildId !== gid) throw new Error("Solicitação de stock não encontrada.");
    const member = i.member as GuildMember;
    const guildSettings = this.db.guild(gid);
    const staff = this.isAdmin(i) || guildSettings.staffRoleIds.some((roleId) => member.roles.cache.has(roleId));
    if (!staff) throw new Error("Somente a equipe pode gerenciar solicitações de stock.");

    if (action === "claim") {
      request.status = "CLAIMED";
      request.claimedBy = i.user.id;
    } else if (action === "available") {
      request.status = "AVAILABLE";
      request.claimedBy ||= i.user.id;
    } else if (action === "reject") {
      request.status = "REJECTED";
      request.claimedBy ||= i.user.id;
    } else {
      throw new Error("Ação de stock inválida.");
    }
    request.updatedAt = nowIso();
    this.db.audit(i.user.id, `STOCK_REQUEST_${action.toUpperCase()}`, "stock_request", request.id, { status: request.status });
    this.db.save();
    await i.update(this.views.stockRequestDetail(gid, request, i.message.flags.has(MessageFlags.Ephemeral)) as never);

    if (action === "available" || action === "reject") {
      const user = await this.client.users.fetch(request.userId).catch(() => undefined);
      if (user) {
        const text = action === "available"
          ? `${this.emojis.text("stock_request_available", gid)} O item **${request.productName}** solicitado no protocolo \`${request.id}\` foi marcado como disponível. Fale com a equipe ou acesse o painel publicado do produto para concluir a compra.`
          : `${this.emojis.text("stock_request_reject", gid)} A solicitação \`${request.id}\` para **${request.productName}** não pôde ser atendida neste momento.`;
        await user.send(text).catch(() => undefined);
      }
    }
  }

  private async savedEmojiCommand(interaction: ChatInputCommandInteraction) {
    const gid = interaction.guildId!;
    const action = interaction.options.getSubcommand();
    const isAdmin = this.isAdmin(interaction);
    const settings = this.db.guild(gid).emojiLibrary;

    if (action === "adicionar") {
      if (!isAdmin && !settings.allowMembers) throw new Error("Somente administradores podem salvar emojis neste servidor.");
      const mine = this.emojis.listSaved(interaction.user.id, gid);
      if (!isAdmin && mine.length >= settings.maxPerUser) throw new Error(`Você atingiu o limite de ${settings.maxPerUser} emojis salvos.`);
      const name = interaction.options.getString("nome", true);
      const attachment = interaction.options.getAttachment("arquivo");
      const emojiText = interaction.options.getString("emoji") ?? "";
      if (!attachment && !emojiText) throw new Error("Envie um arquivo ou informe um emoji personalizado.");
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const source = attachment
        ? await this.emojiSourceFromAttachment(attachment)
        : await this.emojiSourceFromText(emojiText);
      const saved = await this.emojis.saveUserEmoji({ name, bytes: source.bytes, mimeType: source.mimeType, ownerId: interaction.user.id, guildId: gid, originalName: source.originalName });
      await interaction.editReply({ embeds: [this.savedEmojiResultEmbed(gid, saved)] });
      return;
    }

    if (action === "listar") {
      const scope = interaction.options.getString("escopo") ?? "meus";
      const ownerId = scope === "todos" ? undefined : interaction.user.id;
      const items = this.emojis.listSaved(ownerId, gid);
      const lines = items.slice(0, 40).map((item, index) => `${index + 1}. ${this.emojis.mentionSaved(item)} **${item.name}** — \`${item.id}\``);
      await interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(0x3155ff)
          .setTitle(`${this.emojis.text("saved_emoji_list", gid)} ${scope === "todos" ? "Emojis salvos no servidor" : "Meus emojis salvos"}`)
          .setDescription(lines.join("\n") || "Nenhum emoji encontrado.")
          .setFooter({ text: items.length > 40 ? `Mostrando 40 de ${items.length}. Use /painel para navegar pela lista completa.` : `${items.length} emoji(s)` })],
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    const identifier = interaction.options.getString("emoji", true);
    const item = this.emojis.findSaved(identifier);
    if (!item || item.guildId !== gid) throw new Error("Emoji salvo não encontrado neste servidor.");
    if (action === "copiar") {
      await interaction.reply({ embeds: [this.savedEmojiResultEmbed(gid, item)], flags: MessageFlags.Ephemeral });
      return;
    }
    if (action === "remover") {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const removed = await this.emojis.removeSaved(item.id, interaction.user.id, isAdmin);
      await interaction.editReply(`${this.emojis.fallback("approve")} Emoji **${removed.name}** removido da aplicação.`);
    }
  }

  private savedEmojiResultEmbed(gid: string, item: SavedApplicationEmoji) {
    const mention = this.emojis.mentionSaved(item);
    return new EmbedBuilder()
      .setColor(0x3155ff)
      .setTitle(`${mention} Emoji salvo na aplicação`)
      .setDescription(`Use este código em textos, descrições e produtos enviados pelo bot:\n\n\`\`\`\n${mention}\n\`\`\``)
      .addFields(
        { name: "Nome", value: `\`${item.name}\``, inline: true },
        { name: "ID", value: `\`${item.id}\``, inline: true },
        { name: "Tipo", value: item.animated ? "GIF animado" : "Imagem estática", inline: true }
      )
      .setFooter({ text: "Application Emoji" })
      .setTimestamp();
  }

  private async emojiSourceFromAttachment(attachment: { url: string; size: number; name: string | null; contentType: string | null }) {
    if (attachment.size > 256 * 1024) throw new Error("O arquivo excede 256 KiB. Comprima a imagem ou o GIF antes de enviar.");
    const extension = (attachment.name ?? "").split(".").pop()?.toLowerCase();
    const extensionMimes: Record<string, string> = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", avif: "image/avif" };
    const mimeType = attachment.contentType?.split(";")[0] ?? (extension ? extensionMimes[extension] : undefined);
    if (!mimeType || !Object.values(extensionMimes).includes(mimeType)) throw new Error("Formato inválido. Use PNG, JPG, GIF, WEBP ou AVIF.");
    const response = await fetch(attachment.url, { signal: AbortSignal.timeout(30_000) });
    if (!response.ok) throw new Error(`Não foi possível baixar o anexo (${response.status}).`);
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > 256 * 1024) throw new Error("O arquivo excede 256 KiB após o download.");
    return { bytes, mimeType, originalName: attachment.name ?? "emoji" };
  }

  private async emojiSourceFromText(value: string) {
    const match = value.trim().match(/^<(a?):([a-zA-Z0-9_]+):(\d{15,25})>$/);
    if (!match) throw new Error("Emoji inválido. Envie no formato <:nome:id> ou <a:nome:id>.");
    const animated = match[1] === "a";
    const name = match[2]!;
    const id = match[3]!;
    const mimeType = animated ? "image/gif" : "image/png";
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? "gif" : "png"}?size=128&quality=lossless`;
    const response = await fetch(url, { signal: AbortSignal.timeout(30_000) });
    if (!response.ok) throw new Error("Não foi possível acessar esse emoji. Verifique se ele ainda existe.");
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > 256 * 1024) throw new Error("Esse emoji excede 256 KiB e não pode ser salvo na aplicação.");
    return { bytes, mimeType, originalName: name };
  }

  private async collectSavedEmoji(i: ModalSubmitInteraction, name: string, adminBypass = false) {
    const gid = i.guildId;
    if (!gid || !(i.channel instanceof TextChannel)) throw new Error("Use esta função em um canal de texto do servidor.");
    const settings = this.db.guild(gid).emojiLibrary;
    if (!adminBypass && !settings.allowMembers && !this.isAdmin(i)) throw new Error("O envio de emojis está restrito aos administradores.");
    const mine = this.emojis.listSaved(i.user.id, gid);
    if (!adminBypass && !this.isAdmin(i) && mine.length >= settings.maxPerUser) throw new Error(`Você atingiu o limite de ${settings.maxPerUser} emojis.`);

    await i.reply({
      content: `${this.emojis.text("saved_emoji", gid)} Envie agora uma imagem/GIF de até **256 KiB** ou cole um emoji personalizado neste canal.\nFormatos aceitos: PNG, JPG, GIF, WEBP e AVIF. Tempo: **2 minutos**.`,
      flags: MessageFlags.Ephemeral
    });
    const collected = await i.channel.awaitMessages({
      filter: (message) => message.author.id === i.user.id && (message.attachments.size > 0 || /^<a?:[a-zA-Z0-9_]+:\d{15,25}>$/.test(message.content.trim())),
      max: 1,
      time: 120_000
    });
    const message = collected.first();
    if (!message) throw new Error("Tempo esgotado. Nenhum arquivo ou emoji foi recebido.");
    try {
      const attachment = message.attachments.first();
      const source = attachment
        ? await this.emojiSourceFromAttachment(attachment)
        : await this.emojiSourceFromText(message.content.trim());
      const saved = await this.emojis.saveUserEmoji({ name, bytes: source.bytes, mimeType: source.mimeType, ownerId: i.user.id, guildId: gid, originalName: source.originalName });
      await i.followUp({ embeds: [this.savedEmojiResultEmbed(gid, saved)], flags: MessageFlags.Ephemeral });
    } finally {
      await message.delete().catch(() => undefined);
    }
  }

  private ticketStaffRoleIds(ticket: TicketRecord): string[] {
    const settings = this.db.guild(ticket.guildId);
    const panel = this.db.state.ticketPanels[ticket.panelId];
    const option = panel?.options.find((item) => item.id === ticket.optionId);
    return [...new Set([
      ...settings.staffRoleIds,
      ...settings.permissions.supportRoleIds,
      ...settings.permissions.ticketRoleIds,
      ...(option?.supportRoleIds ?? [])
    ])];
  }

  private isTicketStaff(member: GuildMember, ticket: TicketRecord): boolean {
    return member.permissions.has(PermissionFlagsBits.ManageChannels) || this.ticketStaffRoleIds(ticket).some((roleId) => member.roles.cache.has(roleId));
  }

  private ticketInfoPayload(gid: string, ticket: TicketRecord) {
    const panel = this.db.state.ticketPanels[ticket.panelId];
    const option = panel?.options.find((item) => item.id === ticket.optionId);
    const status = ticket.status === "OPEN" ? "Aberto" : ticket.status === "CLOSED" ? "Fechado" : "Arquivado";
    const container = new ContainerBuilder();
    if (this.db.brand(gid).showAccentColors) container.setAccentColor(colorNumber(panel?.color || this.db.brand(gid).color));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `## Informações do Ticket\n` +
      `**Cliente:** <@${ticket.ownerId}>\n` +
      `**Assunto:** ${truncate(ticket.subject || option?.name || "Não informado", 900)}\n` +
      `**Tipo:** ${truncate(option?.name || "Atendimento", 200)}\n` +
      `**Status:** ${status}\n` +
      `**Atendente:** ${ticket.claimedBy ? `<@${ticket.claimedBy}>` : "Ainda não assumido"}\n` +
      `**Criado:** <t:${Math.floor(Date.parse(ticket.createdAt) / 1000)}:R>${ticket.selectedOrderId ? `\n**Pedido vinculado:** \`${ticket.selectedOrderId}\`` : ""}`
    ));
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `informações do ticket ${ticket.id}`);
  }

  private ticketUserPanelPayload(gid: string, ticket: TicketRecord) {
    const panel = this.db.state.ticketPanels[ticket.panelId];
    const container = new ContainerBuilder();
    if (this.db.brand(gid).showAccentColors) container.setAccentColor(colorNumber(panel?.color || this.db.brand(gid).color));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `## Painel do Usuário\nSomente o cliente que abriu este ticket pode usar estas ações.\n\n` +
      `**Status:** ${ticket.status === "OPEN" ? "Aberto" : ticket.status === "CLOSED" ? "Fechado" : "Arquivado"}\n` +
      `**Atendente:** ${ticket.claimedBy ? `<@${ticket.claimedBy}>` : "Aguardando equipe"}${ticket.purchaseGateStatus === "PENDING" ? "\n**Atenção:** escolha primeiro o contexto da compra para liberar as mensagens." : ""}`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    const primary = new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `ticket:notify-staff:${ticket.id}`, "Notificar atendente", "announcement", ButtonStyle.Primary, ticket.status !== "OPEN"),
      this.views.button(gid, `ticket:rename:${ticket.id}`, "Renomear", "edit", ButtonStyle.Secondary, ticket.status !== "OPEN"),
      this.views.button(gid, `ticket:transcript:${ticket.id}`, "Transcript", "message", ButtonStyle.Secondary)
    );
    const secondary = new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `ticket:info:${ticket.id}`, "Informações", "question", ButtonStyle.Secondary),
      this.views.button(gid, `ticket:close:${ticket.id}`, "Fechar Ticket", "wrong", ButtonStyle.Danger, ticket.status !== "OPEN")
    );
    container.addActionRowComponents(primary, secondary);
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `painel do usuário ${ticket.id}`);
  }

  private ticketStaffPanelPayload(gid: string, ticket: TicketRecord) {
    const panel = this.db.state.ticketPanels[ticket.panelId];
    const container = new ContainerBuilder();
    if (this.db.brand(gid).showAccentColors) container.setAccentColor(colorNumber(panel?.color || this.db.brand(gid).color));
    container.addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `## Painel do Atendente\nAções privadas da equipe de suporte.\n\n` +
      `**Cliente:** <@${ticket.ownerId}>\n` +
      `**Status:** ${ticket.status === "OPEN" ? "Aberto" : ticket.status === "CLOSED" ? "Fechado" : "Arquivado"}\n` +
      `**Responsável:** ${ticket.claimedBy ? `<@${ticket.claimedBy}>` : "Nenhum atendente assumiu ainda"}`
    ));
    container.addSeparatorComponents(new SeparatorBuilder().setDivider(true));
    if (ticket.status === "OPEN") {
      container.addActionRowComponents(
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `ticket:claim:${ticket.id}`, "Assumir", "shield", ButtonStyle.Primary),
          this.views.button(gid, `ticket:notify:${ticket.id}`, "Notificar cliente", "announcement", ButtonStyle.Primary),
          this.views.button(gid, `ticket:close:${ticket.id}`, "Fechar", "wrong", ButtonStyle.Danger)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `ticket:add:${ticket.id}`, "Adicionar usuário", "plus"),
          this.views.button(gid, `ticket:remove:${ticket.id}`, "Remover usuário", "minus"),
          this.views.button(gid, `ticket:rename:${ticket.id}`, "Renomear", "edit")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `ticket:transfer:${ticket.id}`, "Transferir", "group"),
          this.views.button(gid, `ticket:transcript:${ticket.id}`, "Transcript", "message"),
          this.views.button(gid, `ticket:archive:${ticket.id}`, "Arquivar", "back")
        )
      );
    } else {
      container.addActionRowComponents(new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `ticket:reopen:${ticket.id}`, "Reabrir", "back", ButtonStyle.Success),
        this.views.button(gid, `ticket:transcript:${ticket.id}`, "Transcript", "message"),
        this.views.button(gid, `ticket:delete:${ticket.id}`, "Excluir canal", "wrong", ButtonStyle.Danger)
      ));
    }
    return checkedDiscordPayload({ flags: MessageFlags.IsComponentsV2 as const, components: [container] }, `painel do atendente ${ticket.id}`);
  }

  private async ticketButton(i: ButtonInteraction, id: string, gid: string) {
    if (id.startsWith("ticket:purchase-none:")) {
      const ticketId = id.split(":")[2]!;
      await this.tickets.resolvePurchaseGate(ticketId, i.user.id);
      return i.reply({ content: "✅ Atendimento liberado para outro assunto.", flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith("ticket:open:")) { const [, , panelId, optionId] = id.split(":"); return this.showTicketSubject(i, panelId!, optionId!); }
    const [, action, ticketId] = id.split(":");
    if (!ticketId) return;
    const ticket = this.tickets.getTicket(ticketId);
    const member = i.member as GuildMember;
    const staff = this.isTicketStaff(member, ticket);
    const owner = ticket.ownerId === i.user.id;

    // Os dois painéis principais sempre respondem de forma privada e específica.
    // Assim até alguém sem acesso ao ticket recebe a explicação correta em vez de
    // um erro genérico ao tentar abrir o painel da equipe/cliente.
    if (action === "staff-panel") {
      if (!staff) return i.reply({ content: "❌ Você não possui o cargo ou a permissão de atendimento necessária para abrir o Painel do Atendente.", flags: MessageFlags.Ephemeral });
      return i.reply({ ...this.ticketStaffPanelPayload(gid, ticket), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (action === "user-panel") {
      if (!owner) return i.reply({ content: "❌ Este painel é privado e só pode ser aberto pelo cliente que criou o ticket.", flags: MessageFlags.Ephemeral });
      return i.reply({ ...this.ticketUserPanelPayload(gid, ticket), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (!staff && !owner) return i.reply({ content: "❌ Você não tem acesso às ações deste ticket.", flags: MessageFlags.Ephemeral });
    if (action === "info") {
      return i.reply({ ...this.ticketInfoPayload(gid, ticket), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
    }
    if (action === "claim") {
      if (!staff) throw new Error("Somente a equipe pode assumir tickets.");
      await this.tickets.claim(ticketId, member);
      return i.reply({ content: `✅ Ticket assumido por ${i.user}.`, flags: MessageFlags.Ephemeral });
    }
    if (action === "notify") {
      if (!staff) throw new Error("Somente a equipe pode notificar o cliente.");
      const result = await this.tickets.notifyOwner(ticketId, i.user.id);
      return i.reply({ content: `✅ Cliente notificado. DM: **${result.dmSent ? "enviada" : "indisponível"}**.`, flags: MessageFlags.Ephemeral });
    }
    if (action === "notify-staff") {
      if (!owner) throw new Error("Somente o cliente pode notificar a equipe por este botão.");
      const result = await this.tickets.notifyStaff(ticketId, i.user.id);
      return i.reply({ content: `✅ Equipe notificada. Solicitação nº **${result.count}**.`, flags: MessageFlags.Ephemeral });
    }
    if (action === "close") {
      if (!staff && !owner) throw new Error("Você não pode fechar este ticket.");
      await this.tickets.close(ticketId, i.user.id);
      return i.reply({ content: "✅ Ticket fechado.", flags: MessageFlags.Ephemeral });
    }
    if (action === "archive") {
      if (!staff) throw new Error("Somente a equipe pode arquivar.");
      await this.tickets.archive(ticketId, i.user.id);
      return i.reply({ content: "✅ Ticket arquivado.", flags: MessageFlags.Ephemeral });
    }
    if (action === "reopen") {
      if (!staff) throw new Error("Somente a equipe pode reabrir.");
      await this.tickets.reopen(ticketId, i.user.id);
      return i.reply({ content: "✅ Ticket reaberto.", flags: MessageFlags.Ephemeral });
    }
    if (action === "transcript") {
      await i.deferReply({ flags: MessageFlags.Ephemeral });
      const path = await this.tickets.transcript(ticketId);
      await i.editReply({ content: "Transcript gerado.", files: [new AttachmentBuilder(path)] });
      return;
    }
    if (action === "delete") {
      if (!staff) throw new Error("Somente a equipe pode excluir.");
      await i.reply({ content: "Canal será excluído em 3 segundos.", flags: MessageFlags.Ephemeral });
      setTimeout(() => void this.tickets.deleteChannel(ticketId, i.user.id).catch(() => undefined), 3000);
      return;
    }
    if (action === "add") {
      if (!staff) throw new Error("Somente a equipe pode adicionar membros.");
      return i.showModal(modal(`modal:ticket:add:${ticketId}`, "Adicionar ao ticket", [input("user", "ID ou menção do usuário", "", TextInputStyle.Short, true, 30)]));
    }
    if (action === "remove") {
      if (!staff) throw new Error("Somente a equipe pode remover membros.");
      return i.showModal(modal(`modal:ticket:remove:${ticketId}`, "Remover do ticket", [input("user", "ID ou menção do usuário", "", TextInputStyle.Short, true, 30)]));
    }
    if (action === "rename") {
      if (!staff && !owner) throw new Error("Você não pode renomear este ticket.");
      return i.showModal(modal(`modal:ticket:rename:${ticketId}`, "Renomear ticket", [input("name", "Novo nome", "ticket", TextInputStyle.Short, true, 80)]));
    }
    if (action === "transfer") {
      if (!staff) throw new Error("Somente a equipe pode transferir atendimentos.");
      return i.reply({
        content: "Selecione o novo atendente. O usuário escolhido precisa ter cargo/permissão de suporte neste ticket.",
        components: [new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
          new UserSelectMenuBuilder().setCustomId(`ticket:transfer-select:${ticketId}`).setPlaceholder("Escolha o novo atendente").setMinValues(1).setMaxValues(1)
        )],
        flags: MessageFlags.Ephemeral
      });
    }
  }
  private async showTicketSubject(i: ButtonInteraction | StringSelectMenuInteraction, panelId: string, optionId: string) {
    const panel = this.tickets.getPanelForOption(panelId, optionId, i.guildId ?? undefined);
    panelId = panel.id;
    const option = panel.options.find((item) => item.id === optionId);
    if (!option) throw new Error("Opção de ticket inválida.");
    if (option.askSubject) {
      await i.showModal(modal(`modal:ticket:open:${panelId}:${optionId}`, "Abrir atendimento", [input("subject", "Resumo do assunto", "", TextInputStyle.Paragraph, true, 1000)]));
      await this.resetTicketSelect(i, panelId);
      return;
    }
    await i.deferReply({ flags: MessageFlags.Ephemeral });
    await this.resetTicketSelect(i, panelId);
    const channel = await this.tickets.open(i.guild!, i.member as GuildMember, panelId, optionId, option.name);
    await i.editReply(`Ticket criado: ${channel}`);
  }

  private async resetTicketSelect(i: ButtonInteraction | StringSelectMenuInteraction, panelId: string): Promise<void> {
    if (!i.isStringSelectMenu() || !i.guildId) return;
    const panel = this.tickets.resolvePanel(panelId, i.guildId);
    await i.message.edit(this.views.publicTicketPanelEdit(i.guildId, panel) as never).catch((error) => {
      this.logger.warn("Não foi possível reiniciar visualmente o select do painel de ticket.", {
        panelId,
        messageId: i.message.id,
        error: String(error)
      });
    });
  }
  private async giveawayButton(i: ButtonInteraction, id: string) {
    await i.deferReply({ flags: MessageFlags.Ephemeral });
    const giveawayId = id.split(":")[2]!;
    const result = this.giveaways.join(giveawayId, i.user.id);
    if (result.already) return i.editReply(`Você **já está participando** deste sorteio. Participantes: ${result.count}.`);
    const count = await this.giveaways.refresh(giveawayId).catch(() => result.count);
    return i.editReply(`Participação confirmada! Participantes: ${count}.`);
  }

  private emojiFunctionPicker(gid: string, page = 0) {
    const all = this.emojis.functionalOptions();
    const maxPage = Math.max(0, Math.ceil(all.length / 25) - 1);
    const safePage = Math.max(0, Math.min(maxPage, Math.trunc(page) || 0));
    const slice = all.slice(safePage * 25, safePage * 25 + 25);
    const select = new StringSelectMenuBuilder()
      .setCustomId(`admin:emoji:function-select:${safePage}`)
      .setPlaceholder("Escolha a função do bot para personalizar")
      .addOptions(slice.map((item) => {
        const override = this.db.guild(gid).emojiOverrides[item.semantic];
        const selected = override?.split(":")[0] ?? item.currentAsset;
        const asset = this.emojis.option(selected);
        return new StringSelectMenuOptionBuilder()
          .setLabel(item.label.slice(0, 100))
          .setDescription(`Atual: ${asset?.label ?? selected}`.slice(0, 100))
          .setValue(item.semantic)
          .setEmoji(this.emojis.component(item.semantic, gid));
      }));
    return checkedDiscordPayload({
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`${this.emojis.text("customize", gid)} Personalizar emojis por função`)
        .setDescription(`Escolha qual função deseja alterar. Depois, selecione qualquer um dos **${this.emojis.manifestCount()} emojis enviados**. Página **${safePage + 1}/${maxPage + 1}**.`)],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:emoji:mapping:${Math.max(0, safePage - 1)}`, "Anterior", "back", ButtonStyle.Secondary, safePage === 0),
          this.views.button(gid, `admin:emoji:mapping:${Math.min(maxPage, safePage + 1)}`, "Próxima", "arrow", ButtonStyle.Secondary, safePage === maxPage),
          this.views.button(gid, "admin:emojis", "Voltar", "home")
        )
      ]
    }, `seletor de funções de emoji página ${safePage}`);
  }

  private emojiAssetPicker(
    gid: string,
    mode: "product" | "product-field" | "ticket-panel" | "ticket-option" | "mapping" | "catalog" | "zcloud-button",
    page = 0,
    target: { productId?: string; fieldId?: string; panelId?: string; optionId?: string; functional?: string } = {}
  ) {
    const all = [
      ...this.emojis.semanticOptions(),
      ...this.emojis.listSaved(undefined, gid).map((item) => ({ semantic: `saved:${item.name}`, label: `Salvo • ${item.name}`, fallback: this.emojis.mentionSaved(item) }))
    ];
    const maxPage = Math.max(0, Math.ceil(all.length / 25) - 1);
    const safePage = Math.max(0, Math.min(maxPage, Math.trunc(page) || 0));
    const slice = all.slice(safePage * 25, safePage * 25 + 25);

    let selected = "";
    let customId = `admin:emoji:catalog-select:${safePage}`;
    let prefix = "admin:emoji:catalog";
    let back = "admin:emojis";
    let title = "Catálogo de emojis enviados";
    let description = "Veja todos os arquivos que compõem o pacote do bot.";

    if (mode === "product" && target.productId) {
      const product = this.products.get(target.productId, gid);
      selected = product.emojiSemantic;
      customId = `admin:product:emoji-select:${target.productId}:${safePage}`;
      prefix = `admin:product:emoji:${target.productId}`;
      back = `admin:product:${target.productId}`;
      title = `Emoji do produto • ${product.name}`;
      description = "O emoji será usado no título e na identificação geral do produto.";
    } else if (mode === "product-field" && target.productId && target.fieldId) {
      const product = this.products.get(target.productId, gid);
      const field = this.products.getField(product.id, target.fieldId);
      selected = field.emoji;
      customId = `admin:product:field-emoji-select:${product.id}:${field.id}:${safePage}`;
      prefix = `admin:product:field-emoji:${product.id}:${field.id}`;
      back = `admin:product:field:${product.id}:${field.id}`;
      title = `Emoji do campo • ${field.name}`;
      description = "Escolha um emoji do pacote ou um emoji salvo pelo comando Salvar Emojis. Ele aparecerá no botão ou na opção do select.";
    } else if (mode === "ticket-panel" && target.panelId) {
      const panel = this.tickets.resolvePanel(target.panelId, gid);
      selected = panel.emojiSemantic;
      customId = `admin:ticket:emoji-select:${target.panelId}:${safePage}`;
      prefix = `admin:ticket:emoji:${target.panelId}`;
      back = `admin:ticket:${target.panelId}`;
      title = `Emoji do painel • ${panel.name}`;
      description = "O emoji será usado no título e na identificação do painel de tickets.";
    } else if (mode === "ticket-option" && target.panelId && target.optionId) {
      const panel = this.tickets.getPanelForOption(target.panelId, target.optionId, gid);
      const option = panel.options.find((item) => item.id === target.optionId);
      if (!option) throw new Error("Opção de ticket não encontrada.");
      selected = option.emojiSemantic;
      customId = `admin:ticket:option-emoji-select:${target.panelId}:${target.optionId}:${safePage}`;
      prefix = `admin:ticket:option-emoji:${target.panelId}:${target.optionId}`;
      back = `admin:ticket:options:${target.panelId}`;
      title = `Emoji da opção • ${option.name}`;
      description = "O emoji aparecerá no botão ou no menu de seleção do ticket.";
    } else if (mode === "mapping" && target.functional) {
      const functional = this.emojis.functionalOptions().find((item) => item.semantic === target.functional);
      if (!functional) throw new Error("Função de emoji não encontrada.");
      selected = this.db.guild(gid).emojiOverrides[target.functional]?.split(":")[0] ?? functional.currentAsset;
      customId = `admin:emoji:asset-select:${target.functional}:${safePage}`;
      prefix = `admin:emoji:assets:${target.functional}`;
      back = `admin:emoji:function:${target.functional}`;
      title = `Escolher emoji • ${functional.label}`;
      description = "A alteração será aplicada a todos os botões, títulos e painéis que usam essa função.";
    } else if (mode === "zcloud-button") {
      const z = this.zcloud.settings(gid);
      selected = z.buttonEmoji === "__none__" ? "" : (z.buttonEmoji || "shield");
      customId = `admin:zcloud:emoji-select:${safePage}`;
      prefix = "admin:zcloud:emoji";
      back = "admin:zcloud";
      title = "Emoji do botão de verificação";
      description = "Escolha qualquer emoji instalado ou salvo. Você também pode remover totalmente o emoji do botão ou adicionar um novo arquivo/GIF à aplicação.";
    }

    const select = new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder(mode === "catalog" ? "Selecione um emoji para ver detalhes" : "Selecione o emoji")
      .addOptions(slice.map((item) => new StringSelectMenuOptionBuilder()
        .setLabel(item.label.slice(0, 100))
        .setDescription(`Identificador: ${item.semantic}`.slice(0, 100))
        .setValue(item.semantic)
        .setEmoji(this.emojis.component(item.semantic, gid))
        .setDefault(mode !== "catalog" && selected === item.semantic)));

    return checkedDiscordPayload({
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`${this.emojis.text("emoji", gid)} ${title}`)
        .setDescription(`${description}

**${all.length} emojis disponíveis** • Página **${safePage + 1}/${maxPage + 1}**${selected ? `
Selecionado: ${this.emojis.text(selected, gid)} \`${selected}\`` : ""}`)],
      components: [
        new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `${prefix}:${Math.max(0, safePage - 1)}`, "Anterior", "back", ButtonStyle.Secondary, safePage === 0),
          this.views.button(gid, `${prefix}:${Math.min(maxPage, safePage + 1)}`, "Próxima", "arrow", ButtonStyle.Secondary, safePage === maxPage),
          ...(mode === "zcloud-button" ? [
            this.views.button(gid, "admin:zcloud:emoji-remove", "Remover emoji", "trash", ButtonStyle.Danger),
            this.views.button(gid, "admin:zcloud:emoji-add", "Adicionar emoji", "saved_emoji", ButtonStyle.Success)
          ] : []),
          this.views.button(gid, back, "Voltar", "home")
        )
      ]
    }, `biblioteca de emojis ${mode} página ${safePage}`);
  }

  private emojiFunctionDetail(gid: string, semantic: string) {
    const functional = this.emojis.functionalOptions().find((item) => item.semantic === semantic);
    if (!functional) throw new Error("Função de emoji não encontrada.");
    const override = this.db.guild(gid).emojiOverrides[semantic];
    const selected = override?.split(":")[0] ?? functional.currentAsset;
    const asset = this.emojis.option(selected);
    const installed = this.emojis.variant(selected);
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`${this.emojis.text(semantic, gid)} ${functional.label}`)
        .setDescription(`Função interna: \`${semantic}\`
Emoji atual: ${this.emojis.text(selected, gid)} **${asset?.label ?? selected}**
Arquivo do pacote: \`${selected}\`
Status: **${installed ? "instalado" : "aguardando sincronização"}**
Personalização: **${override ? "ativa" : "padrão do bot"}**`)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:emoji:assets:${semantic}:0`, "Trocar emoji", "customize", ButtonStyle.Primary),
        this.views.button(gid, `admin:emoji:reset:${semantic}`, "Restaurar padrão", "refresh", ButtonStyle.Danger, !override),
        this.views.button(gid, "admin:emoji:mapping:0", "Voltar", "back")
      )]
    };
  }

  private emojiCatalogDetail(gid: string, semantic: string, page: number) {
    const option = this.emojis.option(semantic);
    if (!option) throw new Error("Emoji não encontrado no pacote.");
    const installed = this.emojis.variant(semantic);
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`${this.emojis.text(semantic, gid)} ${option.label}`)
        .setDescription(`Identificador: \`${semantic}\`
Nome na aplicação: \`${option.name}\`
Status: **${installed ? "instalado" : "aguardando sincronização"}**
Origem: **pacote enviado pelo usuário**`)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:emoji:catalog:${Math.max(0, page)}`, "Voltar ao catálogo", "back"),
        this.views.button(gid, "admin:emoji:sync", "Sincronizar", "refresh", ButtonStyle.Success)
      )]
    };
  }

  private productDeliveryView(gid: string, product: ReturnType<ProductService["get"]>) {
    const typeLabel = product.deliveryType === "STOCK" ? "Automática" : product.deliveryType === "ROLE" ? "Por cargo" : "Manual";
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`Entrega e limites • ${product.name}`)
        .setDescription("Cada configuração é editada separadamente. Não é necessário digitar combinações de opções no mesmo campo.")
        .addFields(
          { name: "Tipo de entrega", value: typeLabel, inline: true },
          { name: "Cargo", value: product.roleId ? `<@&${product.roleId}>` : "Não definido", inline: true },
          { name: "Quantidade", value: `Mínima: **${product.minQuantity}**
Máxima: **${product.maxQuantity}**
Limite por usuário: **${product.perUserLimit || "sem limite"}**`, inline: true },
          { name: "Grupo de cupons", value: product.couponGroup || "Nenhum", inline: true },
          { name: "Termos obrigatórios", value: product.requireTerms ? "Ativados" : "Desativados", inline: true },
          { name: "Mensagem de entrega", value: truncate(product.deliveryMessage || "Não configurada", 1024) },
          { name: "Texto dos termos", value: truncate(product.termsText || "Não configurado", 1024) }
        )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:product:delivery-type:${product.id}`, "Tipo de entrega", "delivery", ButtonStyle.Primary),
          this.views.button(gid, `admin:product:delivery-role:${product.id}`, "Cargo entregue", "role", ButtonStyle.Secondary),
          this.views.button(gid, `admin:product:delivery-message:${product.id}`, "Mensagem de entrega", "message", ButtonStyle.Secondary),
          this.views.button(gid, `admin:product:delivery-limits:${product.id}`, "Limites e cupons", "settings", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:product:terms-toggle:${product.id}`, product.requireTerms ? "Desativar termos" : "Ativar termos", product.requireTerms ? "off" : "on", product.requireTerms ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, `admin:product:terms-text:${product.id}`, "Editar texto dos termos", "edit", ButtonStyle.Secondary),
          this.views.button(gid, `admin:product:${product.id}`, "Voltar ao produto", "back", ButtonStyle.Secondary)
        )
      ]
    };
  }

  private personalizeView(gid: string) {
    const b = this.db.brand(gid);
    const embed = new EmbedBuilder()
      .setTitle(`${this.emojis.text("customize", gid)} Personalização total`)
      .setDescription(`Nome: **${b.name}**
Cor: **${b.color}**
Bordas/cores laterais: **${b.showAccentColors ? "ativadas" : "desativadas"}**
Bio do perfil: **ZENYX institucional • bloqueada**
Presença: **${b.presenceType} ${b.presenceText || "desativada"}**
Status: **${b.status}**
Logo: ${b.logoUrl ? "configurado" : "padrão"}
Banner: ${b.bannerUrl ? "configurado" : "padrão interno"}

A Bio fixa usa os emojis oficiais e o convite ${ZENYX_BRAND_INVITE}.`)
      .setFooter({ text: b.footer });
    if (b.showAccentColors) embed.setColor(Number.parseInt(b.color.slice(1), 16));
    return {
      embeds: [embed],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:brand:edit", "Marca e visual", "color"),
          this.views.button(gid, "admin:bot:bio", "Bio ZENYX bloqueada", "lock", ButtonStyle.Secondary),
          this.views.button(gid, "admin:presence:edit", "Presença", "message"),
          this.views.button(gid, "admin:bot:identity", "Nome do bot", "edit"),
          this.views.button(gid, "admin:bot:avatar", "Avatar do bot", "image")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:bot:bio-sync", "Restaurar Bio ZENYX", "refresh", ButtonStyle.Success),
          this.views.button(gid, "admin:bot:bio-check", "Verificar Bio", "search", ButtonStyle.Secondary),
          this.views.button(gid, "admin:brand:logo-upload", "Logo por link", "upload"),
          this.views.button(gid, "admin:brand:banner-upload", "Banner por link", "image")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:brand:accent-toggle", b.showAccentColors ? "Desativar bordas" : "Ativar bordas", b.showAccentColors ? "off" : "on", b.showAccentColors ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, "admin:home", "Voltar", "back")
        )
      ]
    };
  }
  private automationsView(gid: string) {
    const settings = this.db.automations(gid);
    const components: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (settings.autoResponses.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("admin:automations:response-select")
          .setPlaceholder("Selecione uma resposta automática")
          .addOptions(settings.autoResponses.slice(0, 25).map((entry, index) => new StringSelectMenuOptionBuilder()
            .setLabel(truncate(entry.trigger, 100))
            .setDescription(truncate(`${entry.exact ? "Correspondência exata" : "Contém o texto"} • ${entry.response}`, 100))
            .setValue(String(index))
            .setEmoji(this.emojis.component("message", gid))))
      ));
    }
    components.push(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:automations:toggle:welcome", settings.welcomeEnabled ? "Desativar boas-vindas" : "Ativar boas-vindas", settings.welcomeEnabled ? "off" : "on", settings.welcomeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(gid, "admin:automations:welcome-message", "Mensagem de boas-vindas", "edit", ButtonStyle.Secondary),
        this.views.button(gid, "admin:automations:welcome-mode", settings.welcomeMode === "TEMPORARY" ? "Modo: temporária" : "Modo: embed", settings.welcomeMode === "TEMPORARY" ? "clock" : "message", ButtonStyle.Primary),
        this.views.button(gid, "admin:automations:welcome-duration", `${settings.welcomeDeleteAfterSeconds || 8}s`, "clock", ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:automations:toggle:goodbye", settings.goodbyeEnabled ? "Desativar saída" : "Ativar saída", settings.goodbyeEnabled ? "off" : "on", settings.goodbyeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(gid, "admin:automations:goodbye-message", "Mensagem de saída", "edit", ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:automations:toggle:autorole", settings.autoRoleEnabled ? "Desativar autorole" : "Ativar autorole", settings.autoRoleEnabled ? "off" : "on", settings.autoRoleEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(gid, "admin:automations:toggle:responses", settings.autoResponsesEnabled ? "Pausar respostas" : "Ativar respostas", settings.autoResponsesEnabled ? "pause" : "approve", settings.autoResponsesEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
        this.views.button(gid, "admin:automations:response-add", "Adicionar resposta", "plus", ButtonStyle.Primary),
        this.views.button(gid, "admin:channels", "Canais e cargos", "settings", ButtonStyle.Secondary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:automations:repeat", "Mensagens recorrentes", "message", ButtonStyle.Primary),
        this.views.button(gid, "admin:automations:mention", "Mensagens com menção", "users", ButtonStyle.Primary),
        this.views.button(gid, "admin:automations:reaction", "Reações automáticas", "reaction", ButtonStyle.Primary)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:automations:schedules", "Horários de canais", "clock", ButtonStyle.Primary),
        this.views.button(gid, "admin:home", "Voltar", "back", ButtonStyle.Secondary)
      )
    );
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("refresh", gid)} Automações`).setDescription(`Boas-vindas: **${settings.welcomeEnabled ? "ativa" : "desativada"}** • modo **${settings.welcomeMode === "TEMPORARY" ? `temporária (${settings.welcomeDeleteAfterSeconds || 8}s)` : "embed"}**
Mensagem de saída: **${settings.goodbyeEnabled ? "ativa" : "desativada"}**
Autorole: **${settings.autoRoleEnabled ? "ativo" : "desativado"}**
Respostas automáticas: **${settings.autoResponsesEnabled ? "ativas" : "pausadas"}** • ${settings.autoResponses.length} cadastrada(s)
Mensagens recorrentes: **${settings.repeatingMessages.filter((rule) => rule.enabled).length} ativa(s)** • ${settings.repeatingMessages.length} cadastrada(s)
Mensagens com menção: **${settings.mentionMessages.filter((rule) => rule.enabled).length} ativa(s)** • ${settings.mentionMessages.length} cadastrada(s)
Reações automáticas: **${settings.autoReactions.filter((rule) => rule.enabled).length} ativa(s)** • ${settings.autoReactions.length} cadastrada(s)
Horários de canais: **${settings.channelSchedules.filter((schedule) => schedule.enabled).length} ativo(s)** • ${settings.channelSchedules.length} cadastrado(s)`)],
      components
    };
  }

  private pagedAutomationList<T extends { id: string; name: string; enabled: boolean }>(gid: string, title: string, description: string, kind: "repeat" | "mention" | "reaction", rows: T[], page = 0) {
    const size = 25;
    const pages = Math.max(1, Math.ceil(rows.length / size));
    const safePage = Math.max(0, Math.min(page, pages - 1));
    const slice = rows.slice(safePage * size, safePage * size + size);
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (slice.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder().setCustomId(`admin:automations:${kind}-select:${safePage}`).setPlaceholder("Selecione uma automação").addOptions(
        slice.map((rule) => new StringSelectMenuOptionBuilder().setLabel(truncate(rule.name, 100)).setDescription(rule.enabled ? "Ativa" : "Pausada").setValue(rule.id).setEmoji(this.emojis.component(rule.enabled ? "approve" : "pause", gid)))
      )
    ));
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `admin:automations:${kind}-add`, "Criar", "plus", ButtonStyle.Success),
      this.views.button(gid, `admin:automations:${kind}-page:${safePage - 1}`, "Anterior", "back", ButtonStyle.Secondary, safePage <= 0),
      this.views.button(gid, `admin:automations:${kind}-page:${safePage + 1}`, "Próxima", "next", ButtonStyle.Secondary, safePage >= pages - 1),
      this.views.button(gid, "admin:automations", "Voltar", "back", ButtonStyle.Secondary)
    ));
    return { embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(title).setDescription(`${description}\n\n**${rows.length}** cadastrada(s) • página **${safePage + 1}/${pages}**`)], components };
  }

  private repeatingMessagesView(gid: string, page = 0) {
    return this.pagedAutomationList(gid, `${this.emojis.text("message", gid)} Mensagens recorrentes`, "O bot apaga a mensagem anterior e a envia novamente no intervalo escolhido. Ideal para feedbacks, avisos e lembretes fixos.", "repeat", this.db.automations(gid).repeatingMessages, page);
  }
  private mentionMessagesView(gid: string, page = 0) {
    return this.pagedAutomationList(gid, `${this.emojis.text("users", gid)} Mensagens com menção`, "Use **{user}**, **{username}**, **{server}** e **{count}**. Pode atingir novos membros, membros já presentes ou os dois modos.", "mention", this.db.automations(gid).mentionMessages, page);
  }
  private autoReactionsView(gid: string, page = 0) {
    return this.pagedAutomationList(gid, `${this.emojis.text("reaction", gid)} Reações automáticas`, "Escolha o canal e o emoji visualmente. O bot reage automaticamente às novas mensagens sem exigir ID manual.", "reaction", this.db.automations(gid).autoReactions, page);
  }

  private automationRuleChannelPicker(gid: string, kind: "repeat" | "mention" | "reaction", ruleId: string) {
    return {
      embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Selecionar canal").setDescription("Escolha o canal de texto em que esta automação deve funcionar.")],
      components: [
        new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(new ChannelSelectMenuBuilder().setCustomId(`admin:automations:${kind}-channel-set:${ruleId}`).setPlaceholder("Selecione um canal").setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1)),
        new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:automations:${kind}:${ruleId}`, "Cancelar", "back"))
      ]
    };
  }

  private repeatingMessageDetail(gid: string, ruleId: string) {
    const rule = this.db.automations(gid).repeatingMessages.find((item) => item.id === ruleId);
    if (!rule) throw new Error("Mensagem recorrente não encontrada.");
    return { embeds: [new EmbedBuilder().setColor(rule.enabled ? 0x22c55e : 0x64748b).setTitle(`Mensagem recorrente • ${rule.name}`).addFields(
      { name: "Status", value: rule.enabled ? "Ativa" : "Pausada", inline: true },
      { name: "Canal", value: rule.channelId ? `<#${rule.channelId}>` : "Não definido", inline: true },
      { name: "Intervalo", value: `${rule.intervalMinutes} minuto(s)`, inline: true },
      { name: "Mensagem", value: truncate(rule.content || "Sem conteúdo", 1024) },
      { name: "Último envio", value: rule.lastSentAt ? `<t:${Math.floor(Date.parse(rule.lastSentAt)/1000)}:R>` : "Ainda não enviada", inline: true }
    )], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:automations:repeat-toggle:${rule.id}`, rule.enabled ? "Pausar" : "Ativar", rule.enabled ? "pause" : "approve", rule.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
        this.views.button(gid, `admin:automations:repeat-channel:${rule.id}`, "Escolher canal", "message", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:repeat-edit:${rule.id}`, "Editar", "edit", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:repeat-delete:${rule.id}`, "Excluir", "trash", ButtonStyle.Danger)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:automations:repeat", "Voltar", "back"))
    ] };
  }

  private mentionMessageDetail(gid: string, ruleId: string) {
    const rule = this.db.automations(gid).mentionMessages.find((item) => item.id === ruleId);
    if (!rule) throw new Error("Mensagem com menção não encontrada.");
    const mode = rule.audience === "NEW_MEMBERS" ? "Somente quem acabou de entrar" : rule.audience === "EXISTING_MEMBERS" ? "Membros já presentes (um por intervalo)" : "Novos membros + membros já presentes";
    return { embeds: [new EmbedBuilder().setColor(rule.enabled ? 0x22c55e : 0x64748b).setTitle(`Mensagem com menção • ${rule.name}`).addFields(
      { name: "Status", value: rule.enabled ? "Ativa" : "Pausada", inline: true },
      { name: "Canal", value: rule.channelId ? `<#${rule.channelId}>` : "Não definido", inline: true },
      { name: "Público", value: mode },
      { name: "Intervalo para membros existentes", value: `${rule.intervalMinutes} minuto(s)`, inline: true },
      { name: "Mensagem", value: truncate(rule.content || "Sem conteúdo", 1024) }
    )], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:automations:mention-toggle:${rule.id}`, rule.enabled ? "Pausar" : "Ativar", rule.enabled ? "pause" : "approve", rule.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
        this.views.button(gid, `admin:automations:mention-channel:${rule.id}`, "Escolher canal", "message", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:mention-mode:${rule.id}`, "Alterar público", "users", ButtonStyle.Secondary),
        this.views.button(gid, `admin:automations:mention-edit:${rule.id}`, "Editar", "edit", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:mention-delete:${rule.id}`, "Excluir", "trash", ButtonStyle.Danger)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:automations:mention", "Voltar", "back"))
    ] };
  }

  private autoReactionDetail(gid: string, ruleId: string) {
    const rule = this.db.automations(gid).autoReactions.find((item) => item.id === ruleId);
    if (!rule) throw new Error("Reação automática não encontrada.");
    const guildEmoji = rule.emojiId ? this.client.guilds.cache.get(gid)?.emojis.cache.get(rule.emojiId) : undefined;
    const emojiLabel = guildEmoji
      ? `${guildEmoji.toString()} **:${guildEmoji.name}:**`
      : rule.emojiId
        ? `Emoji salvo não está mais disponível neste servidor.`
        : "Nenhum emoji selecionado.";
    return { embeds: [new EmbedBuilder().setColor(rule.enabled ? 0x22c55e : 0x64748b).setTitle(`Reação automática • ${rule.name}`).setDescription("Escolha o emoji visualmente; não é necessário copiar nenhum ID.").addFields(
      { name: "Status", value: rule.enabled ? "Ativa" : "Pausada", inline: true },
      { name: "Canal", value: rule.channelId ? `<#${rule.channelId}>` : "Não definido", inline: true },
      { name: "Emoji", value: emojiLabel }
    )], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:automations:reaction-toggle:${rule.id}`, rule.enabled ? "Pausar" : "Ativar", rule.enabled ? "pause" : "approve", rule.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
        this.views.button(gid, `admin:automations:reaction-channel:${rule.id}`, "Escolher canal", "message", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:reaction-emoji:${rule.id}:0`, "Escolher emoji", "reaction", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:reaction-edit:${rule.id}`, "Renomear", "edit", ButtonStyle.Secondary),
        this.views.button(gid, `admin:automations:reaction-delete:${rule.id}`, "Excluir", "trash", ButtonStyle.Danger)
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:automations:reaction-emoji-clear:${rule.id}`, "Remover emoji", "minus", ButtonStyle.Secondary, !rule.emojiId),
        this.views.button(gid, "admin:automations:reaction", "Voltar", "back")
      )
    ] };
  }

  private guildReactionEmojiPicker(gid: string, ruleId: string, page = 0, query = "") {
    const rule = this.db.automations(gid).autoReactions.find((item) => item.id === ruleId);
    if (!rule) throw new Error("Reação automática não encontrada.");
    const guild = this.client.guilds.cache.get(gid);
    if (!guild) throw new Error("Servidor indisponível para listar os emojis.");
    const normalizedQuery = query.trim().toLowerCase();
    const all = [...guild.emojis.cache.values()]
      .filter((emoji) => emoji.available !== false && (!normalizedQuery || (emoji.name ?? "").toLowerCase().includes(normalizedQuery)))
      .sort((a, b) => (a.name ?? "").localeCompare(b.name ?? ""));
    const pages = Math.max(1, Math.ceil(all.length / 25));
    const safePage = Math.max(0, Math.min(pages - 1, Math.trunc(page) || 0));
    const slice = all.slice(safePage * 25, safePage * 25 + 25);
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (slice.length) {
      const select = new StringSelectMenuBuilder()
        .setCustomId(`admin:automations:reaction-emoji-set:${rule.id}:${safePage}`)
        .setPlaceholder(`Escolha um emoji • página ${safePage + 1}/${pages}`)
        .setMinValues(1).setMaxValues(1)
        .addOptions(slice.map((emoji) => new StringSelectMenuOptionBuilder()
          .setLabel(truncate(`:${emoji.name ?? "emoji"}:`, 100))
          .setDescription("Emoji deste servidor")
          .setValue(emoji.id)
          .setEmoji({ id: emoji.id, name: emoji.name ?? "emoji", animated: emoji.animated ?? false })));
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `admin:automations:reaction-emoji:${rule.id}:${Math.max(0, safePage - 1)}`, "Anterior", "back", ButtonStyle.Secondary, safePage <= 0),
      this.views.button(gid, `admin:automations:reaction-emoji-search:${rule.id}`, "Pesquisar", "search", ButtonStyle.Primary),
      this.views.button(gid, `admin:automations:reaction-emoji:${rule.id}:${Math.min(pages - 1, safePage + 1)}`, "Próxima", "next", ButtonStyle.Secondary, safePage >= pages - 1),
      this.views.button(gid, `admin:automations:reaction:${rule.id}`, "Voltar", "back", ButtonStyle.Secondary)
    ));
    return {
      embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle("Escolher emoji da reação").setDescription(
        all.length
          ? `${all.length} emoji(s) disponível(is)${normalizedQuery ? ` para **${truncate(query, 60)}**` : ""}. Selecione visualmente abaixo.`
          : `Nenhum emoji${normalizedQuery ? ` com o nome **${truncate(query, 60)}**` : " personalizado"} foi encontrado neste servidor.`
      ).setFooter({ text: `Página ${safePage + 1}/${pages} • apenas emojis do servidor podem ser usados como reação` })],
      components
    };
  }

  private repeatingMessageModal(ruleId = "", rule?: import("../types.js").RepeatingMessageRule) {
    return modal(ruleId ? `modal:automations:repeat-edit:${ruleId}` : "modal:automations:repeat-add", ruleId ? "Editar mensagem recorrente" : "Criar mensagem recorrente", [
      input("name", "Nome", rule?.name ?? "Mensagem automática", TextInputStyle.Short, true, 80),
      input("content", "Mensagem", rule?.content ?? "", TextInputStyle.Paragraph, true, 1900, "Ex.: Deixe seu feedback para manter sua garantia ativa."),
      input("interval", "Intervalo em minutos", String(rule?.intervalMinutes ?? 30), TextInputStyle.Short, true, 6, "Ex.: 30")
    ]);
  }
  private mentionMessageModal(ruleId = "", rule?: import("../types.js").MentionMessageRule) {
    return modal(ruleId ? `modal:automations:mention-edit:${ruleId}` : "modal:automations:mention-add", ruleId ? "Editar mensagem com menção" : "Criar mensagem com menção", [
      input("name", "Nome", rule?.name ?? "Mensagem da loja", TextInputStyle.Short, true, 80),
      input("content", "Mensagem", rule?.content ?? "Olá {user}, confira as novidades da nossa loja!", TextInputStyle.Paragraph, true, 1900),
      input("interval", "Intervalo p/ membros existentes (min)", String(rule?.intervalMinutes ?? 60), TextInputStyle.Short, true, 6, "Ex.: 60")
    ]);
  }
  private autoReactionModal(ruleId = "", rule?: import("../types.js").AutoReactionRule) {
    return modal(ruleId ? `modal:automations:reaction-edit:${ruleId}` : "modal:automations:reaction-add", ruleId ? "Renomear reação automática" : "Criar reação automática", [
      input("name", "Nome", rule?.name ?? "Reação do canal", TextInputStyle.Short, true, 80)
    ]);
  }

  private channelScheduleModal(scheduleId = "", schedule?: import("../types.js").ChannelSchedule) {
    return modal(
      scheduleId ? `modal:automations:schedule-edit:${scheduleId}` : "modal:automations:schedule-add",
      scheduleId ? "Editar horário de canais" : "Criar horário de canais",
      [
        input("name", "Nome do horário", schedule?.name ?? "Horário principal", TextInputStyle.Short, true, 80),
        input("lock_time", "Horário para fechar (HH:mm)", schedule?.lockTime ?? "22:00", TextInputStyle.Short, true, 5),
        input("unlock_time", "Horário para abrir (HH:mm)", schedule?.unlockTime ?? "08:00", TextInputStyle.Short, true, 5),
        input("lock_message", "Mensagem ao fechar", schedule?.lockMessage ?? "Este canal foi fechado automaticamente.", TextInputStyle.Paragraph, false, 1800),
        input("unlock_message", "Mensagem ao abrir", schedule?.unlockMessage ?? "Este canal foi aberto automaticamente.", TextInputStyle.Paragraph, false, 1800)
      ]
    );
  }

  private channelSchedulesView(gid: string) {
    const schedules = this.db.automations(gid).channelSchedules;
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (schedules.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("admin:automations:schedule-select")
          .setPlaceholder("Selecione um horário para configurar")
          .addOptions(schedules.slice(0, 25).map((schedule) => new StringSelectMenuOptionBuilder()
            .setLabel(truncate(schedule.name, 100))
            .setDescription(truncate(`${schedule.enabled ? "Ativo" : "Pausado"} • fecha ${schedule.lockTime} • abre ${schedule.unlockTime} • ${schedule.channelIds.length} canal(is)`, 100))
            .setValue(schedule.id)
            .setEmoji(this.emojis.component(schedule.enabled ? "clock" : "pause", gid))))
      ));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, "admin:automations:schedule-add", "Criar horário", "plus", ButtonStyle.Success, schedules.length >= 25),
      this.views.button(gid, "admin:automations", "Voltar", "back", ButtonStyle.Secondary)
    ));
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("clock", gid)} Abertura e fechamento automático`).setDescription(
        schedules.length
          ? schedules.map((schedule) => `${schedule.enabled ? "🟢" : "⚫"} **${schedule.name}** — fecha **${schedule.lockTime}**, abre **${schedule.unlockTime}** • ${schedule.channelIds.length} canal(is)`).join("\n").slice(0, 4000)
          : "Crie um horário, defina quando os canais fecham e abrem e depois selecione os canais. O fuso padrão é America/Sao_Paulo."
      )],
      components
    };
  }

  private channelScheduleDetail(gid: string, scheduleId: string) {
    const schedule = this.db.automations(gid).channelSchedules.find((item) => item.id === scheduleId);
    if (!schedule) throw new Error("Horário automático não encontrado.");
    return {
      embeds: [new EmbedBuilder().setColor(schedule.enabled ? 0x22c55e : 0x64748b).setTitle(`${this.emojis.text("clock", gid)} ${schedule.name}`).addFields(
        { name: "Status", value: schedule.enabled ? "Ativo" : "Pausado", inline: true },
        { name: "Fechar", value: schedule.lockTime, inline: true },
        { name: "Abrir", value: schedule.unlockTime, inline: true },
        { name: "Fuso", value: schedule.timezone, inline: true },
        { name: "Canais", value: schedule.channelIds.map((id) => `<#${id}>`).join(" ") || "Nenhum canal selecionado" },
        { name: "Mensagem ao fechar", value: truncate(schedule.lockMessage || "Sem mensagem", 1024) },
        { name: "Mensagem ao abrir", value: truncate(schedule.unlockMessage || "Sem mensagem", 1024) }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:automations:schedule-toggle:${schedule.id}`, schedule.enabled ? "Pausar" : "Ativar", schedule.enabled ? "pause" : "approve", schedule.enabled ? ButtonStyle.Secondary : ButtonStyle.Success),
          this.views.button(gid, `admin:automations:schedule-channels:${schedule.id}`, "Selecionar canais", "message", ButtonStyle.Primary),
          this.views.button(gid, `admin:automations:schedule-edit:${schedule.id}`, "Editar horários e mensagens", "edit", ButtonStyle.Primary),
          this.views.button(gid, `admin:automations:schedule-delete:${schedule.id}`, "Excluir", "trash", ButtonStyle.Danger)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:automations:schedules", "Voltar", "back"))
      ]
    };
  }

  private channelScheduleChannelsView(gid: string, scheduleId: string) {
    const schedule = this.db.automations(gid).channelSchedules.find((item) => item.id === scheduleId);
    if (!schedule) throw new Error("Horário automático não encontrado.");
    const picker = new ChannelSelectMenuBuilder()
      .setCustomId(`admin:automations:schedule-channels-set:${schedule.id}`)
      .setPlaceholder("Selecione até 25 canais de texto")
      .setChannelTypes(ChannelType.GuildText)
      .setMinValues(1)
      .setMaxValues(25);
    if (schedule.channelIds.length) picker.setDefaultChannels(schedule.channelIds);
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`Canais • ${schedule.name}`).setDescription("Selecione todos os canais que devem ser fechados e abertos automaticamente por este horário.")],
      components: [
        new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(picker),
        new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:automations:schedules`, "Cancelar", "back"))
      ]
    };
  }

  private botMessageTemplate(gid: string, templateId: string): BotMessageTemplate {
    const template = this.db.state.messageTemplates[templateId];
    if (!template || template.guildId !== gid) throw new Error("Modelo de mensagem não encontrado.");
    return template;
  }

  private botMessageBasicModal(template?: BotMessageTemplate) {
    return modal(template ? `modal:message:basic:${template.id}` : "modal:message:create", template ? "Editar mensagem" : "Criar mensagem", [
      input("name", "Nome interno do modelo", template?.name ?? "Nova mensagem", TextInputStyle.Short, true, 80),
      input("content", "Texto superior", template?.content ?? "", TextInputStyle.Paragraph, false, 2000),
      input("title", "Título", template?.title ?? "", TextInputStyle.Short, false, 300),
      input("description", "Descrição", template?.description ?? "", TextInputStyle.Paragraph, false, 4000),
      input("color", "Cor hexadecimal", template?.color ?? this.db.state.brand.color, TextInputStyle.Short, true, 7)
    ]);
  }

  private botMessagesView(gid: string) {
    const templates = Object.values(this.db.state.messageTemplates).filter((item) => item.guildId === gid).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (templates.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder().setCustomId("admin:message:select").setPlaceholder("Selecione uma mensagem para editar").addOptions(
          templates.slice(0, 25).map((template) => new StringSelectMenuOptionBuilder()
            .setLabel(truncate(template.name, 100))
            .setDescription(truncate(`${template.title || "Sem título"} • ${template.links.length} botão(ões) • ${template.publications.length} publicação(ões)`, 100))
            .setValue(template.id)
            .setEmoji(this.emojis.component("message", gid)))
        )
      ));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, "admin:message:create", "Criar mensagem", "plus", ButtonStyle.Success, templates.length >= 25),
      this.views.button(gid, "admin:home", "Voltar", "back")
    ));
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("message", gid)} Mensagens do bot`).setDescription(
        `Crie mensagens completas em Components V2 com texto, título, descrição, banner, miniatura, rodapé, emojis e até cinco botões de link.\n\n**Modelos salvos:** ${templates.length}/25`
      )],
      components
    };
  }

  private botMessageDetail(gid: string, templateId: string) {
    const template = this.botMessageTemplate(gid, templateId);
    const publications = template.publications.map((item) => `<#${item.channelId}> • \`${item.messageId}\``).join("\n") || "Ainda não publicada";
    return {
      embeds: [new EmbedBuilder().setColor(colorNumber(template.color)).setTitle(`${this.emojis.text("message", gid)} ${template.name}`).setDescription(truncate(template.description || template.content || "Sem descrição", 4000)).addFields(
        { name: "Título", value: truncate(template.title || "Sem título", 1024), inline: true },
        { name: "Cor", value: template.color, inline: true },
        { name: "Botões", value: `${template.links.length}/5`, inline: true },
        { name: "Banner", value: template.bannerUrl ? "Configurado" : "Não definido", inline: true },
        { name: "Miniatura", value: template.thumbnailUrl ? "Configurada" : "Não definida", inline: true },
        { name: "Publicações", value: truncate(publications, 1024) },
        { name: "Links", value: template.links.map((link, index) => `${index + 1}. **${link.label}** — ${link.url}`).join("\n").slice(0, 1024) || "Nenhum botão de link" }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:message:basic:${template.id}`, "Texto e título", "edit", ButtonStyle.Primary),
          this.views.button(gid, `admin:message:visual:${template.id}`, "Banner e miniatura", "image", ButtonStyle.Primary),
          this.views.button(gid, `admin:message:link-add:${template.id}`, "Adicionar link", "link", ButtonStyle.Secondary, template.links.length >= 5),
          this.views.button(gid, `admin:message:links-clear:${template.id}`, "Limpar links", "trash", ButtonStyle.Secondary, !template.links.length)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:message:preview:${template.id}`, "Pré-visualizar", "search", ButtonStyle.Secondary),
          this.views.button(gid, `admin:message:publish:${template.id}`, "Publicar / atualizar", "announcement", ButtonStyle.Success),
          this.views.button(gid, `admin:message:delete:${template.id}`, "Excluir modelo", "trash", ButtonStyle.Danger),
          this.views.button(gid, "admin:messages", "Voltar", "back")
        )
      ]
    };
  }

  private automationResponseDetail(gid: string, index: number) {
    const response = this.db.automations(gid).autoResponses[index];
    if (!response) throw new Error("Resposta automática não encontrada.");
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle("Resposta automática").addFields(
        { name: "Gatilho", value: truncate(response.trigger, 1024) },
        { name: "Correspondência", value: response.exact ? "A mensagem deve ser exatamente igual" : "A mensagem pode apenas conter o gatilho" },
        { name: "Resposta", value: truncate(response.response, 1024) }
      )],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:automations:response-edit:${index}`, "Editar", "edit", ButtonStyle.Primary),
        this.views.button(gid, `admin:automations:response-exact:${index}`, response.exact ? "Usar correspondência parcial" : "Exigir correspondência exata", "settings", ButtonStyle.Secondary),
        this.views.button(gid, `admin:automations:response-delete:${index}`, "Excluir", "trash", ButtonStyle.Danger),
        this.views.button(gid, "admin:automations", "Voltar", "back", ButtonStyle.Secondary)
      )]
    };
  }
  private revenueView(gid: string) {
    const paidStatuses = new Set(["PAID", "DELIVERED", "AWAITING_DELIVERY"]);
    const paid = Object.values(this.db.state.orders).filter((order) => paidStatuses.has(order.status));
    const totalRevenue = paid.reduce((sum, order) => sum + order.totalCents, 0);
    const averageTicket = paid.length ? Math.round(totalRevenue / paid.length) : 0;
    const productTotals = new Map<string, { name: string; quantity: number; revenue: number }>();
    for (const order of paid) {
      for (const item of order.items) {
        const current = productTotals.get(item.productId) ?? { name: item.productName, quantity: 0, revenue: 0 };
        current.quantity += item.quantity;
        current.revenue += item.quantity * item.unitPriceCents;
        productTotals.set(item.productId, current);
      }
    }
    const top = [...productTotals.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 8);
    const stats = this.db.stats();
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`${this.emojis.text("analytics", gid)} Rendimento de vendas`)
        .setDescription(`Resumo financeiro baseado nos pedidos aprovados e entregues.`)
        .addFields(
          { name: "Hoje", value: formatMoney(stats.revenueToday), inline: true },
          { name: "Últimos 30 dias", value: formatMoney(stats.revenue30d), inline: true },
          { name: "Faturamento total", value: formatMoney(totalRevenue), inline: true },
          { name: "Pedidos pagos", value: String(paid.length), inline: true },
          { name: "Ticket médio", value: formatMoney(averageTicket), inline: true },
          { name: "Clientes", value: String(stats.customers), inline: true },
          { name: "Produtos mais vendidos", value: top.map((item, index) => `${index + 1}. **${truncate(item.name, 55)}** — ${item.quantity} un. • ${formatMoney(item.revenue)}`).join("\n") || "Ainda não há vendas aprovadas." }
        )
        .setTimestamp()],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, "admin:orders", "Ver pedidos", "invoice", ButtonStyle.Primary),
        this.views.button(gid, "admin:products", "Gerenciar produtos", "store"),
        this.views.button(gid, "admin:home", "Voltar", "back")
      )]
    };
  }

  private protectionView(gid: string) {
    const settings = this.db.protection(gid);
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("shield", gid)} Proteção do servidor`).setDescription(`Anti-link: **${settings.antiLink ? "ativo" : "desativado"}**
Domínios permitidos: **${settings.allowedDomains.length}**
Anti-spam: **${settings.antiSpam ? "ativo" : "desativado"}** • ${settings.spamMessages} mensagens em ${settings.spamWindowSeconds}s • timeout ${settings.spamTimeoutSeconds}s
Convites: **${settings.blockInvites ? "bloqueados" : "permitidos"}**
Log de mensagens apagadas: **${settings.logDeletedMessages ? "ativo" : "desativado"}**
Log de mensagens editadas: **${settings.logEditedMessages ? "ativo" : "desativado"}**`)],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:protection:toggle:links", settings.antiLink ? "Desativar anti-link" : "Ativar anti-link", settings.antiLink ? "off" : "on", settings.antiLink ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, "admin:protection:domains", "Domínios permitidos", "link", ButtonStyle.Secondary),
          this.views.button(gid, "admin:protection:toggle:spam", settings.antiSpam ? "Desativar anti-spam" : "Ativar anti-spam", settings.antiSpam ? "off" : "on", settings.antiSpam ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, "admin:protection:spam-limits", "Limites do anti-spam", "settings", ButtonStyle.Secondary)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:protection:toggle:invites", settings.blockInvites ? "Permitir convites" : "Bloquear convites", settings.blockInvites ? "off" : "on", settings.blockInvites ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, "admin:protection:toggle:deleted", settings.logDeletedMessages ? "Desativar log apagadas" : "Ativar log apagadas", "transcript", ButtonStyle.Secondary),
          this.views.button(gid, "admin:protection:toggle:edited", settings.logEditedMessages ? "Desativar log editadas" : "Ativar log editadas", "edit", ButtonStyle.Secondary),
          this.views.button(gid, "admin:home", "Voltar", "back", ButtonStyle.Secondary)
        )
      ]
    };
  }
  private ordersAdminView(gid: string) {
    const pending = Object.values(this.db.state.orders)
      .filter((order) => order.guildId === gid && ["PENDING", "AWAITING_DELIVERY"].includes(order.status))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const actionable = pending.filter((order) => order.provider === "MANUAL_PIX" || order.status === "AWAITING_DELIVERY").slice(0, 3);
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    for (const order of actionable) {
      const shortId = order.id.slice(-8);
      components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
        order.status === "AWAITING_DELIVERY"
          ? this.views.button(gid, `admin:order:complete:${order.id}`, `Concluir entrega • ${shortId}`, "approve", ButtonStyle.Success)
          : this.views.button(gid, `admin:order:approve:${order.id}`, `Aprovar pagamento • ${shortId}`, "approve", ButtonStyle.Success),
        ...(order.status === "PENDING" ? [this.views.button(gid, `admin:order:cancel:${order.id}`, `Cancelar • ${shortId}`, "reject", ButtonStyle.Danger)] : []),
        this.views.button(gid, `admin:order:${order.id}`, "Ver detalhes", "invoice", ButtonStyle.Secondary)
      ));
    }
    if (pending.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
      new StringSelectMenuBuilder().setCustomId("admin:order:select").setPlaceholder("Todos os pedidos pendentes").addOptions(
        pending.slice(0, 25).map((order) => new StringSelectMenuOptionBuilder()
          .setLabel(order.id)
          .setDescription(`${formatMoney(order.totalCents)} • ${order.status} • ${order.provider}`.slice(0, 100))
          .setValue(order.id)
          .setEmoji(this.emojis.component("invoice", gid)))
      )
    ));
    components.push(this.views.back(gid));
    return {
      embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("invoice", gid)} Pedidos`).setDescription(
        `Pendentes: **${pending.filter((order) => order.status === "PENDING").length}** • aguardando entrega manual: **${pending.filter((order) => order.status === "AWAITING_DELIVERY").length}**\n\nAs ações dos pedidos mais recentes aparecem diretamente abaixo.`
      )],
      components
    };
  }
  private orderAdminDetail(gid: string, orderId: string) {
    const order = this.orders.get(orderId, gid);
    const action = order.status === "AWAITING_DELIVERY"
      ? this.views.button(gid, `admin:order:complete:${order.id}`, "Concluir entrega manual", "approve", ButtonStyle.Success)
      : this.views.button(gid, `admin:order:approve:${order.id}`, "Aprovar pagamento manual", "approve", ButtonStyle.Success, order.status !== "PENDING" || order.provider !== "MANUAL_PIX");
    return { embeds: [this.views.orderView(gid, order)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      action,
      this.views.button(gid, `admin:order:cancel:${order.id}`, "Cancelar", "reject", ButtonStyle.Danger, order.status !== "PENDING"),
      this.views.button(gid, "admin:orders", "Voltar", "back")
    )] };
  }
  private giveawaysView(gid: string) { const active = Object.values(this.db.state.giveaways).filter((g) => g.status === "ACTIVE"); return { embeds: [new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("announcement", gid)} Sorteios`).setDescription(`Sorteios ativos: **${active.length}**\n${active.map((g) => `• ${g.prize} — <t:${Math.floor(Date.parse(g.endsAt) / 1000)}:R>`).join("\n") || "Nenhum sorteio ativo."}`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:giveaway:create", "Criar sorteio", "announcement", ButtonStyle.Success), this.views.button(gid, "admin:home", "Voltar", "back"))] }; }
  private permissionsView(gid: string) {
    const p = this.db.guild(gid).permissions;
    const locks = this.db.guild(gid).locks;
    const roleList = (ids: string[]) => ids.map((id) => `<@&${id}>`).join(" ") || "Nenhum";
    const userList = (ids: string[]) => ids.map((id) => `<@${id}>`).join(" ") || "Nenhum";
    return {
      embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("shield", gid)} Permissões e bloqueios`).setDescription("Configure o acesso sem editar arquivos. O proprietário configurado e o dono do servidor nunca perdem acesso.").addFields(
        { name: "Administradores", value: `Usuários: ${userList(p.adminUserIds)}
Cargos: ${roleList(p.adminRoleIds)}` },
        { name: "Autorizados", value: `Usuários: ${userList(p.authorizedUserIds)}
Cargos: ${roleList(p.authorizedRoleIds)}` },
        { name: "Equipes específicas", value: `Suporte: ${roleList(p.supportRoleIds)}
Tickets: ${roleList(p.ticketRoleIds)}
Pagamentos: ${roleList(p.paymentRoleIds)}
Produtos: ${roleList(p.productRoleIds)}
Comandos administrativos: ${roleList(p.adminCommandRoleIds)}` },
        { name: "Lock", value: `Canais ignorados: **${locks.ignoredChannelIds.length}**
Cargos que continuam falando: **${locks.speakingRoleIds.length}**
Snapshots ativos: **${Object.keys(locks.snapshots).length}**` }
      )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:permissions:user:admins", "Usuários admin", "admin", ButtonStyle.Primary),
          this.views.button(gid, "admin:permissions:role:admins", "Cargos admin", "shield", ButtonStyle.Primary),
          this.views.button(gid, "admin:permissions:user:authorized", "Usuários autorizados", "user"),
          this.views.button(gid, "admin:permissions:role:authorized", "Cargos autorizados", "role")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:permissions:role:support", "Suporte", "support"),
          this.views.button(gid, "admin:permissions:role:tickets", "Tickets", "ticket"),
          this.views.button(gid, "admin:permissions:role:payments", "Pagamentos", "payment"),
          this.views.button(gid, "admin:permissions:role:products", "Produtos", "products"),
          this.views.button(gid, "admin:permissions:role:commands", "Comandos", "settings")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, "admin:locks:ignored", "Canais ignorados", "lock"),
          this.views.button(gid, "admin:locks:speaking", "Cargos liberados", "unlock"),
          this.views.button(gid, "admin:home", "Voltar", "back")
        )
      ]
    };
  }

  private backupsView(gid: string) {
    const backups = this.backups.list(gid);
    const rows: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (backups.length) rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("admin:backup:select").setPlaceholder("Selecione um backup").addOptions(backups.slice(0, 25).map((backup) => new StringSelectMenuOptionBuilder().setLabel(truncate(backup.name, 100)).setDescription(truncate(`${new Date(backup.createdAt).toLocaleString("pt-BR")} • ${Object.values(backup.counts).reduce((a, b) => a + b, 0)} registros`, 100)).setValue(backup.id).setEmoji(this.emojis.component("backup", gid))))));
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:backup:create", "Criar backup", "backup", ButtonStyle.Success), this.views.button(gid, "admin:home", "Voltar", "back")));
    return { embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("backup", gid)} Backups do servidor`).setDescription(`Backups disponíveis: **${backups.length}**

O sistema salva estrutura, permissões, expressões, webhooks autorizados, dados do bot e mensagens acessíveis. Autoria, IDs e datas originais de mensagens não podem ser recriados exatamente.`)], components: rows };
  }

  private backupDetail(gid: string, backupId: string) {
    const backup = this.backups.get(gid, backupId);
    const counts = Object.entries(backup.counts).map(([key, value]) => `• ${key}: **${value}**`).join("\n") || "Sem contagens.";
    return { embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("backup", gid)} ${backup.name}`).setDescription(`ID: \`${backup.id}\`
Criado: <t:${Math.floor(Date.parse(backup.createdAt) / 1000)}:F>
Criado por: <@${backup.createdBy}>

${counts}

${backup.warnings.slice(0, 5).map((warning) => `⚠️ ${warning}`).join("\n")}`)], components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `admin:backup:restore-plan:${backup.id}`, "Restaurar", "restore", ButtonStyle.Success),
      this.views.button(gid, `admin:backup:rename:${backup.id}`, "Renomear", "edit", ButtonStyle.Primary),
      this.views.button(gid, `admin:backup:delete:${backup.id}`, "Excluir", "trash", ButtonStyle.Danger),
      this.views.button(gid, "admin:backups", "Voltar", "back")
    )] };
  }

  private couponsView(gid: string) {
    const coupons = Object.values(this.db.state.coupons).filter((coupon) => coupon.guildId === gid).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const rows: Array<ActionRowBuilder<ButtonBuilder | StringSelectMenuBuilder>> = [];
    if (coupons.length) rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(new StringSelectMenuBuilder().setCustomId("admin:coupon:select").setPlaceholder("Selecione um cupom").addOptions(coupons.slice(0, 25).map((coupon) => new StringSelectMenuOptionBuilder().setLabel(coupon.code).setDescription(truncate(`${coupon.active ? "Ativo" : "Desativado"} • ${coupon.type === "PERCENT" ? `${coupon.value}%` : formatMoney(coupon.value)} • ${coupon.uses}/${coupon.maxUses ?? "∞"}`, 100)).setValue(coupon.id).setEmoji(this.emojis.component("coupon", gid))))));
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, "admin:coupon:create", "Criar cupom", "coupon", ButtonStyle.Success), this.views.button(gid, "admin:products", "Voltar", "back")));
    return { embeds: [new EmbedBuilder().setColor(0x3155ff).setTitle(`${this.emojis.text("coupon", gid)} Cupons`).setDescription(`Cupons cadastrados: **${coupons.length}**
O uso é registrado somente depois que o pagamento for aprovado.`)], components: rows };
  }

  private couponDetail(gid: string, couponId: string) {
    const coupon = this.products.getCoupon(gid, couponId);
    const usages = this.db.state.couponUsages.filter((usage) => usage.guildId === gid && usage.couponId === coupon.id);
    return { embeds: [new EmbedBuilder().setColor(coupon.active ? 0x22c55e : 0x64748b).setTitle(`${this.emojis.text("coupon", gid)} ${coupon.code}`).addFields(
      { name: "Desconto", value: coupon.type === "PERCENT" ? `${coupon.value}%` : formatMoney(coupon.value), inline: true },
      { name: "Pedido mínimo", value: formatMoney(coupon.minOrderCents), inline: true },
      { name: "Status", value: coupon.active ? "Ativo" : "Desativado", inline: true },
      { name: "Limites", value: `Total: ${coupon.uses}/${coupon.maxUses ?? "∞"}
Por usuário: ${coupon.perUserLimit || "sem limite"}`, inline: true },
      { name: "Período", value: `Início: ${coupon.startsAt ? `<t:${Math.floor(Date.parse(coupon.startsAt) / 1000)}:f>` : "imediato"}
Expiração: ${coupon.expiresAt ? `<t:${Math.floor(Date.parse(coupon.expiresAt) / 1000)}:f>` : "sem expiração"}`, inline: true },
      { name: "Escopo", value: `Produtos: ${coupon.productIds.length ? coupon.productIds.map((id) => this.db.state.products[id]?.name ?? id).join(", ") : "todos"}
Grupos: ${coupon.productGroups.join(", ") || "todos"}`, inline: false },
      { name: "Usuários recentes", value: usages.slice(0, 10).map((usage) => `<@${usage.userId}> • pedido \`${usage.orderId}\` • ${formatMoney(usage.discountCents)}`).join("\n") || "Nenhum uso aprovado." }
    ).setTimestamp()], components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        this.views.button(gid, `admin:coupon:toggle:${coupon.id}`, coupon.active ? "Desativar" : "Ativar", coupon.active ? "pause" : "approve", coupon.active ? ButtonStyle.Secondary : ButtonStyle.Success),
        this.views.button(gid, `admin:coupon:edit-basic:${coupon.id}`, "Código e desconto", "edit", ButtonStyle.Primary),
        this.views.button(gid, `admin:coupon:edit-rules:${coupon.id}`, "Limites e datas", "settings"),
        this.views.button(gid, `admin:coupon:edit-scope:${coupon.id}`, "Produtos e grupos", "products")
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(this.views.button(gid, `admin:coupon:delete:${coupon.id}`, "Excluir", "trash", ButtonStyle.Danger), this.views.button(gid, "admin:coupons", "Voltar", "back"))
    ] };
  }

  private ticketOptionsView(gid: string, panel: ReturnType<TicketService["getPanel"]>) {
    const options = [...panel.options].sort((a, b) => a.position - b.position);
    const components: Array<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>> = [];
    if (options.length) {
      components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`admin:ticket:option-select:${panel.id}`)
          .setPlaceholder("Selecione uma opção para configurar")
          .addOptions(options.slice(0, 25).map((option) => {
            const item = new StringSelectMenuOptionBuilder()
              .setLabel(truncate(option.name, 100))
              .setDescription(truncate(`${option.active ? "Ativa" : "Desativada"} • limite ${option.maxOpenTicketsPerUser} • ${option.description || "Sem descrição"}`, 100))
              .setValue(option.id);
            if (option.emojiSemantic) item.setEmoji(this.emojis.component(option.emojiSemantic, gid));
            return item;
          }))
      ));
    }
    components.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
      this.views.button(gid, `admin:ticket:option:add:${panel.id}`, "Adicionar opção", "plus", ButtonStyle.Success, panel.options.length >= 25),
      this.views.button(gid, `admin:ticket:${panel.id}`, "Voltar ao painel", "back")
    ));
    return {
      embeds: [new EmbedBuilder()
        .setColor(0x7c3aed)
        .setTitle(`Opções de atendimento • ${panel.name}`)
        .setDescription(options.length
          ? options.map((option, index) => `${index + 1}. ${option.emojiSemantic ? this.emojis.text(option.emojiSemantic, gid) : ""} **${option.name}** — ${option.active ? "ativa" : "desativada"}`).join("\n").slice(0, 4000)
          : "Nenhuma opção configurada. Adicione ao menos uma antes de publicar o painel.")],
      components
    };
  }

  private ticketOptionDetail(gid: string, panelId: string, optionId: string) {
    const panel = this.tickets.getPanelForOption(panelId, optionId, gid);
    panelId = panel.id;
    const option = panel.options.find((item) => item.id === optionId);
    if (!option) throw new Error("Opção não encontrada.");
    const ordered = [...panel.options].sort((a, b) => a.position - b.position);
    const index = ordered.findIndex((item) => item.id === option.id);
    const emoji = option.emojiSemantic ? this.emojis.text(option.emojiSemantic, gid) : "Sem emoji";
    return {
      embeds: [new EmbedBuilder()
        .setColor(option.active ? 0x7c3aed : 0x64748b)
        .setTitle(`${option.emojiSemantic ? `${emoji} ` : ""}${option.name}`)
        .setDescription(option.description)
        .addFields(
          { name: "Status", value: option.active ? "Ativa" : "Desativada", inline: true },
          { name: "Posição", value: `${index + 1}/${ordered.length}`, inline: true },
          { name: "Emoji", value: option.emojiSemantic ? `${emoji}  \`${truncate(option.emojiSemantic, 80)}\`` : "Sem emoji", inline: true },
          { name: "Categoria", value: option.categoryId ? `<#${option.categoryId}>` : "Categoria geral", inline: true },
          { name: "Prefixo do canal", value: `\`${option.channelPrefix}\``, inline: true },
          { name: "Limite por usuário", value: String(option.maxOpenTicketsPerUser), inline: true },
          { name: "Pedir motivo", value: option.askSubject ? "Ativado" : "Desativado", inline: true },
          { name: "Mencionar equipe", value: option.mentionSupport ? "Ativado" : "Desativado", inline: true },
          { name: "Cargos responsáveis", value: option.supportRoleIds.map((id) => `<@&${id}>`).join(" ") || "Cargos gerais", inline: false },
          { name: "Mensagem inicial", value: truncate(option.openingDescription, 1024) },
          { name: "Mensagem ao fechar", value: truncate(option.closeMessage, 1024) }
        )],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:option-edit:${panelId}:${optionId}`, "Textos", "edit", ButtonStyle.Primary),
          this.views.button(gid, `admin:ticket:option-close-message:${panelId}:${optionId}`, "Mensagem ao fechar", "message"),
          this.views.button(gid, `admin:ticket:option-category:${panelId}:${optionId}`, "Categoria", "folder"),
          this.views.button(gid, `admin:ticket:option-roles:${panelId}:${optionId}`, "Cargos", "role"),
          this.views.button(gid, `admin:ticket:option-limit:${panelId}:${optionId}`, "Limite", "members")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:option-emoji:${panelId}:${optionId}:0`, "Biblioteca de emojis", "emoji"),
          this.views.button(gid, `admin:ticket:option-emoji-manual:${panelId}:${optionId}`, "Emoji manual", "reaction_add"),
          this.views.button(gid, `admin:ticket:option-emoji-clear:${panelId}:${optionId}`, "Remover emoji", "minus", ButtonStyle.Secondary, !option.emojiSemantic)
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:option-toggle:${panelId}:${optionId}:active`, option.active ? "Desativar opção" : "Ativar opção", option.active ? "off" : "on", option.active ? ButtonStyle.Danger : ButtonStyle.Success),
          this.views.button(gid, `admin:ticket:option-toggle:${panelId}:${optionId}:subject`, option.askSubject ? "Não pedir motivo" : "Pedir motivo", "question"),
          this.views.button(gid, `admin:ticket:option-toggle:${panelId}:${optionId}:mention`, option.mentionSupport ? "Não mencionar equipe" : "Mencionar equipe", "announcement")
        ),
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          this.views.button(gid, `admin:ticket:option-move:${panelId}:${optionId}:up`, "Mover para cima", "arrow", ButtonStyle.Secondary, index <= 0),
          this.views.button(gid, `admin:ticket:option-move:${panelId}:${optionId}:down`, "Mover para baixo", "arrow2", ButtonStyle.Secondary, index < 0 || index >= ordered.length - 1),
          this.views.button(gid, `admin:ticket:option-delete-request:${panelId}:${optionId}`, "Excluir", "trash", ButtonStyle.Danger),
          this.views.button(gid, `admin:ticket:options:${panelId}`, "Voltar", "back")
        )
      ]
    };
  }
  private userOrdersEmbed(gid: string, userId: string) { const orders = this.orders.userOrders(userId, gid).slice(0, 10); return new EmbedBuilder().setColor(0x7c3aed).setTitle(`${this.emojis.text("invoice", gid)} Meus pedidos`).setDescription(orders.map((o) => `• **${o.id}** — ${formatMoney(o.totalCents)} — ${o.status}`).join("\n") || "Você ainda não possui pedidos."); }
  private applyPresence(gid?: string) {
    const b = gid ? this.db.brand(gid) : this.db.state.brand;
    this.client.user?.setPresence({
      status: b.status,
      activities: b.presenceText ? [{ name: b.presenceText, type: ({ Playing: 0, Listening: 2, Watching: 3, Competing: 5 } as Record<string, number>)[b.presenceType] as never }] : []
    });
  }

  private async runQuickSetup(i: ButtonInteraction, gid: string) {
    if (!i.guild) throw new Error("Servidor indisponível.");
    await i.deferReply({ flags: MessageFlags.Ephemeral });
    const guild = i.guild;
    const current = this.db.guild(gid);

    const ensureRole = async (roleId: string, name: string) => {
      const existing = roleId ? await guild.roles.fetch(roleId).catch(() => undefined) : undefined;
      return existing ?? guild.roles.create({ name, reason: `Instalação rápida por ${i.user.tag}` });
    };
    const ensureCategory = async (channelId: string, name: string) => {
      const existing = channelId ? await guild.channels.fetch(channelId).catch(() => undefined) : undefined;
      if (existing?.type === ChannelType.GuildCategory) return existing;
      return guild.channels.create({ name, type: ChannelType.GuildCategory, reason: `Instalação rápida por ${i.user.tag}` });
    };
    const ensureText = async (channelId: string, name: string, privateToStaff = false) => {
      const existing = channelId ? await guild.channels.fetch(channelId).catch(() => undefined) : undefined;
      if (existing instanceof TextChannel) return existing;
      const botId = guild.members.me?.id ?? this.client.user?.id;
      const botOverwrite = botId ? [{ id: botId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages] }] : [];
      const overwrites = privateToStaff
        ? [
            { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: staffRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            ...botOverwrite
          ]
        : [
            { id: guild.roles.everyone.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: [PermissionFlagsBits.SendMessages] },
            ...botOverwrite
          ];
      const channel = await guild.channels.create({ name, type: ChannelType.GuildText, permissionOverwrites: overwrites, reason: `Instalação rápida por ${i.user.tag}` });
      if (!(channel instanceof TextChannel)) throw new Error(`Não foi possível criar o canal ${name}.`);
      return channel;
    };

    const staffRole = await ensureRole(current.staffRoleIds[0] ?? "", "Equipe");
    const customerRole = await ensureRole(current.customerRoleId, "Cliente");
    const openCategory = await ensureCategory(current.ticketCategoryId, "TICKETS ABERTOS");
    const closedCategory = await ensureCategory(current.closedTicketCategoryId, "TICKETS FECHADOS");
    const archiveCategory = await ensureCategory(current.archiveTicketCategoryId, "TICKETS ARQUIVADOS");
    const purchaseCategory = await ensureCategory(current.purchaseCategoryId, "COMPRAS PRIVADAS");
    const salesChannel = await ensureText(current.salesChannelId, "produtos");
    const salesLog = await ensureText(current.logChannelId, "logs-vendas", true);
    const ticketLog = await ensureText(current.ticketLogChannelId, "logs-tickets", true);
    const stockPanelChannel = await ensureText(current.stockRequest.panelChannelId ?? "", "pedir-stock");
    const stockRequestChannel = await ensureText(current.stockRequest.requestChannelId, "pedidos-de-stock", true);

    let panel = this.tickets.listPanels(gid)[0];
    if (!panel) panel = this.tickets.createPanel({ name: "Atendimento principal", title: this.db.brand(gid).ticketTitle, description: this.db.brand(gid).ticketDescription, mode: "SELECT", emojiSemantic: "ticket" }, i.user.id);
    if (!panel.options.length) {
      this.tickets.addOption(panel.id, { name: "Compras", description: "Dúvidas antes ou depois da compra", emojiSemantic: "store", supportRoleIds: [staffRole.id], channelPrefix: "compra" }, i.user.id);
      this.tickets.addOption(panel.id, { name: "Pagamentos", description: "Problemas ou confirmação de pagamento", emojiSemantic: "payment", supportRoleIds: [staffRole.id], channelPrefix: "pagamento" }, i.user.id);
      this.tickets.addOption(panel.id, { name: "Suporte", description: "Ajuda com produtos e entregas", emojiSemantic: "support", supportRoleIds: [staffRole.id], channelPrefix: "suporte" }, i.user.id);
      this.tickets.addOption(panel.id, { name: "Outros assuntos", description: "Falar diretamente com a equipe", emojiSemantic: "message", supportRoleIds: [staffRole.id], channelPrefix: "atendimento" }, i.user.id);
      panel = this.tickets.getPanel(panel.id);
    }
    const ticketChannel = await ensureText(panel.channelId ?? "", "abrir-ticket");

    const updateOrSend = async (channel: TextChannel, messageId: string | undefined, payload: Record<string, unknown>) => {
      if (messageId) {
        const existing = await channel.messages.fetch(messageId).catch(() => undefined);
        if (existing) { await existing.edit(payload as never); return existing; }
      }
      return channel.send(payload as never);
    };
    const ticketPayload = panel.messageId ? this.views.publicTicketPanelEdit(gid, panel) : this.views.publicTicketPanel(gid, panel);
    const ticketMessage = await updateOrSend(ticketChannel, panel.messageId, ticketPayload as never);
    const stockMessage = await updateOrSend(stockPanelChannel, current.stockRequest.panelMessageId, this.views.publicStockRequestPanel(gid) as never);

    this.db.updateGuild(gid, (settings) => {
      settings.staffRoleIds = [...new Set([...settings.staffRoleIds, staffRole.id])];
      settings.customerRoleId = customerRole.id;
      settings.ticketCategoryId = openCategory.id;
      settings.closedTicketCategoryId = closedCategory.id;
      settings.archiveTicketCategoryId = archiveCategory.id;
      settings.purchaseCategoryId = purchaseCategory.id;
      settings.salesChannelId = salesChannel.id;
      settings.logChannelId = salesLog.id;
      settings.ticketLogChannelId = ticketLog.id;
      settings.panelChannelId = undefined;
      settings.panelMessageId = undefined;
      settings.stockRequest.requestChannelId = stockRequestChannel.id;
      settings.stockRequest.panelChannelId = stockPanelChannel.id;
      settings.stockRequest.panelMessageId = stockMessage.id;
      settings.stockRequest.notifyRoleIds = [...new Set([...settings.stockRequest.notifyRoleIds, staffRole.id])];
      settings.stockRequest.enabled = true;
    });
    this.tickets.updatePanel(panel.id, { channelId: ticketChannel.id, messageId: ticketMessage.id }, i.user.id);
    void this.emojis.syncAutomatic(true).then(() => this.refreshPublishedMessages()).catch((error) => this.logger.warn("Falha ao atualizar painéis após sincronizar emojis.", error));

    await i.editReply({ embeds: [new EmbedBuilder().setColor(0x22c55e).setTitle("Estrutura criada com sucesso").setDescription(`Canal para painéis de produtos: ${salesChannel}
Tickets: ${ticketChannel}
Logs de vendas: ${salesLog}
Logs de tickets: ${ticketLog}
Painel Pedir Stock: ${stockPanelChannel}
Pedidos de stock: ${stockRequestChannel}
Equipe: ${staffRole}
Cliente: ${customerRole}

Agora use **/painel** para personalizar produtos, pagamentos, mensagens, imagens, emojis e automações.`).setTimestamp()] });
  }

  private async collectCertificate(i: ButtonInteraction) {
    if (!(i.channel instanceof TextChannel)) throw new Error("Use em um canal de texto.");
    await i.reply({ content: "Envie agora o arquivo **.p12** ou **.pfx** neste canal. A mensagem será apagada após o certificado ser salvo em `config/private-credentials.json`. Tempo: 2 minutos.", flags: MessageFlags.Ephemeral });
    const collected = await i.channel.awaitMessages({ filter: (m) => m.author.id === i.user.id && m.attachments.size > 0, max: 1, time: 120000 }); const message = collected.first(); if (!message) throw new Error("Tempo esgotado."); const attachment = message.attachments.first()!;
    if (!/\.(p12|pfx)$/i.test(attachment.name ?? "")) throw new Error("Envie um arquivo .p12 ou .pfx."); if (attachment.size > 2 * 1024 * 1024) throw new Error("Certificado maior que 2 MB.");
    const buffer = Buffer.from(await (await fetch(attachment.url)).arrayBuffer()); this.db.setSecret("efi_certificate_base64", buffer.toString("base64"), i.guildId ?? ""); if (i.guildId) this.db.payments(i.guildId).efiBank.certificateConfigured = true; this.db.save(); await message.delete().catch(() => undefined);
    if (i.guildId) await i.followUp({ ...this.views.adminPage(i.guildId, this.views.paymentProviderSettings(i.guildId, "EFI_BANK"), false), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 } as never);
  }

  private async collectAvatar(i: ButtonInteraction) {
    if (!(i.channel instanceof TextChannel)) throw new Error("Use em um canal de texto.");
    await i.reply({ content: "Envie agora uma imagem PNG/JPG para usar como avatar. A mensagem será apagada após a aplicação.", flags: MessageFlags.Ephemeral });
    const collected = await i.channel.awaitMessages({ filter: (m) => m.author.id === i.user.id && m.attachments.size > 0, max: 1, time: 120000 }); const message = collected.first(); if (!message) throw new Error("Tempo esgotado."); const attachment = message.attachments.first()!;
    if (!attachment.contentType?.startsWith("image/")) throw new Error("O arquivo precisa ser uma imagem."); if (attachment.size > 8 * 1024 * 1024) throw new Error("Imagem maior que 8 MB."); const buffer = Buffer.from(await (await fetch(attachment.url)).arrayBuffer()); await this.client.user?.setAvatar(buffer); await message.delete().catch(() => undefined); await i.followUp({ content: "✅ Avatar atualizado.", flags: MessageFlags.Ephemeral });
  }
}
