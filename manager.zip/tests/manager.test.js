const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');
const { Collection, MessagePayload, ActionRowBuilder, ButtonBuilder, MessageFlags } = require('discord.js');
const { normalize, install } = require('../Lib/visual');
process.env.OWNER_ID = '111111111111111111';
function interaction(owner = true) {
 const calls = [];
 const i = { calls, user: { id: owner ? process.env.OWNER_ID : '222222222222222222', username: 'Teste', displayName: 'Teste', displayAvatarURL: () => 'https://example.com/avatar.png' },
 guildId: '333333333333333333', guild: { channels: { cache: new Collection() }, roles: { cache: new Collection() }, iconURL: () => null, members: { fetch: async id => ({ id, user: { bot: false } }) } },
 client: { user: { id: '444444444444444444', displayAvatarURL: () => 'https://example.com/avatar.png' }, application: { id: '444444444444444444' }, ws: { ping: 40 }, guilds: { cache: new Collection() } },
 message: { id: '555555555555555555', flags: { has: flag => flag === MessageFlags.Ephemeral || flag === MessageFlags.IsComponentsV2 }, components: [] },
 replied: false, deferred: false,
 async reply(p) { assert.equal(this.replied || this.deferred, false, 'duplicate initial response'); this.replied = true; calls.push(['reply', p]); },
 async deferReply(p) { assert.equal(this.replied || this.deferred, false); this.deferred = true; calls.push(['deferReply', p]); },
 async editReply(p) { assert.ok(this.replied || this.deferred); calls.push(['editReply', p]); },
 async followUp(p) { calls.push(['followUp', p]); },
 async showModal(p) { assert.equal(this.replied || this.deferred, false); this.replied = true; calls.push(['showModal', p.toJSON()]); },
 options: { getUser: () => null, getString: () => null }
 };
 return i;
}
test('owner has access without being stored as a delegated admin', () => {
 const { isAdmin } = require('../Lib/permissions'); assert.equal(isAdmin(process.env.OWNER_ID), true); assert.equal(isAdmin('unknown'), false);
});
test('add_perm opens a valid modal when no user is supplied', async () => {
 const i = interaction(); await require('../Comandos/config/add_perm').run(i.client, i);
 assert.equal(i.calls[0][0], 'showModal'); assert.equal(i.calls[0][1].components[0].components[0].style, 1);
});
test('forged permission modal cannot write permissions', async () => {
 const i = interaction(false); i.customId = 'modalAddPerm'; i.isModalSubmit = () => true;
 await require('../Eventos/config/perms').run(i); assert.match(i.calls[0][1].content, /Apenas o dono/);
});
test('botconfig renders Components V2 without emoji API calls', async () => {
 const i = interaction(); await require('../Comandos/config/botconfig').run(i.client, i);
 assert.deepEqual(i.calls.map(c => c[0]), ['reply']);
 const body = i.calls[0][1]; for(const row of body.components) row.toJSON();
 assert.ok(body.flags & MessageFlags.IsComponentsV2);
});
test('setar-bot-gratis opens a valid configuration modal', async () => {
 const i = interaction();
 await require('../Comandos/config/gratis').run(i.client, i);
 assert.equal(i.calls[0][0], 'showModal');
 const modal = i.calls[0][1];
 assert.equal(modal.custom_id, 'setar_bot_gratis_config');
 assert.equal(modal.components.length, 3);
 assert.equal(modal.components[0].components[0].custom_id, 'banner_url');
 assert.equal(modal.components[0].components[0].required, false);
});
test('unknown old command receives a response instead of timing out', async () => {
 const i = interaction(); i.isCommand = () => true; i.commandName = 'obsolete'; i.client.slashCommands = new Collection();
 await require('../Eventos/bot/interactionCreate').run(i, i.client); assert.equal(i.calls[0][0], 'reply');
});
test('failed deferred command edits the pending response', async () => {
 const i = interaction(); await i.deferReply({}); await require('../Lib/interactions').fail(i, { code: 'TEST' });
 assert.deepEqual(i.calls.map(c=>c[0]), ['deferReply', 'editReply']);
});
test('keyboard emojis are removed when custom application emoji cache is unavailable', () => {
 const body = normalize({ content: '✅ OK :2check_Taxados: Erro', components: [{ type: 2, style: 2, custom_id: 'back', emoji: { name: '↩️' } }] }, 'missing');
 assert.equal(body.content.includes('✅'), false);
 assert.equal(body.content.includes(':2check_Taxados:'), false);
 assert.equal(String(body.components[0]?.emoji?.name || '').includes('↩'), false);
});
test('visual normalization never leaks unicode fallback through MessagePayload serialization', () => {
 install(); const target = { client: { options: { allowedMentions: { parse: [] } } }, guildId: 'missing' };
 const payload = new MessagePayload(target, { content: '✅ Concluído', components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back').setStyle(2).setEmoji('↩️'))] });
 payload.resolveBody();
 assert.equal(payload.body.content.includes('✅'), false);
 const emoji = payload.body.components[0].components[0].emoji;
 assert.equal(String(emoji?.name || '').includes('↩'), false);
});
test('ZenyxPro archive resolves old InPRO alias and disallows traversal', async () => {
 const t = require('../Lib/templates'); assert.equal(t.resolveTemplate('InPRO').id, 'ZenyxPro'); assert.throws(() => t.resolveTemplate('../../config'));
 const info = await t.inspectTemplate('ZenyxPro'); assert.equal(info.entrypoint, 'dist/index.js');
});
test('trial restores the original thread-first flow before requesting the token', async () => {
 const reviewers = require('../Lib/purchaseReviewers');
 const previousReviewers = reviewers.list();
 reviewers.clear();
 const i = interaction(false);
 i.user.id = '777777777777777777';
 i.customId = 'botfree';
 i.guild.members.me = { id: '999999999999999999' };
 const sent = [];
 const added = [];
 const thread = {
  id: '888888888888888888', name: 'teste-Teste', archived: false, url: 'https://discord.com/channels/1/2/888888888888888888', deletable: true,
  members: { add: async id => added.push(id) },
  send: async payload => { sent.push(payload); return { id: '999999999999999998' }; }
 };
 i.channel = {
  threads: { cache: new Collection(), fetchActive: async () => new Collection(), create: async () => thread },
  permissionsFor: () => ({ has: () => true })
 };
 const trialDb = new (require('wio.db').JsonDatabase)({ databasePath: path.join(__dirname, '../databases/trials.json') });
 trialDb.delete(i.user.id);
 try {
  await require('../Eventos/manager/gratis').run(i);
  assert.deepEqual(i.calls.map(c => c[0]), ['deferReply', 'editReply']);
  assert.deepEqual(added, [i.user.id]);
  const serialized = sent[0].components[0].toJSON();
  const row = serialized.components.find(c => c.type === 1);
  assert.ok(row.components[0].custom_id.startsWith('select_tipo_bot_trial:'));
  assert.equal(sent[0].flags, require('discord.js').MessageFlags.IsComponentsV2);
 } finally { trialDb.delete(i.user.id); reviewers.set(previousReviewers); }
});
test('command loader discovers all commands and registers aliases', () => {
 const client = new EventEmitter(); client.slashCommands = new Collection(); require('../handler')(client);
 for(const name of ['add_perm','ver_perms','rem_perm','perms','botconfig','setar-bot-gratis','key','vincular','recuperar','backup','app']) assert.ok(client.slashCommands.has(name),name);
 assert.equal(client.slashCommands.size, 34);
});
for (const customId of ['back','channelsRolesEdit','gerenciarApps','createBotAluguel','removeAluguel','diversesAluguel','gerenciamentDev','definitions','autoMsgPanel','editAutoMsgChannel','editAutoMsgMsg','editAutoMsgInterval','apiConfig','paymentsConfig','automaticConfig','nubankImapConfig','configureNubankImap','setAccessToken','editTempPay','semiAutoConfig','setAgenceSemi','editTempPay2','setConfigSemi','aprovedRoleSemi','antFraudSet','automationConfig','autoMsgConfig','autoRepostConfig','repostSetHour','statusRealtime','atualizarStatus','keyManagement','keyListActive','trialAdminPanel','managerDiagnostics','managerRefresh','earlyAccessToggle']) {
 test(`admin panel route ${customId} produces serializable response`, async () => {
  const i = interaction(); i.customId = customId; i.isModalSubmit = () => false;
  i.update = async function(p) { this.replied = true; this.calls.push(['update',p]); };
  await require('../Eventos/config/botconfig').run(i, i.client);
  assert.ok(i.calls.length, 'no response');
  for(const [,p] of i.calls) if(p && typeof p === 'object') {
    for(const row of p.components || []) if(row.toJSON)row.toJSON();
    for(const embed of p.embeds || []) if(embed.toJSON)embed.toJSON();
  }
 });
}
test('ZenyxPro receives Token.json and its own runtime configuration', async () => {
 const { configuredZip } = require('../Eventos/manager/gratis');
 const zip = await require('jszip').loadAsync(await configuredZip('test-token-only', '444444444444444444', '111111111111111111', '333333333333333333'));
 assert.equal(JSON.parse(await zip.file('Token.json').async('string')).token, 'test-token-only');
 const cfg = JSON.parse(await zip.file('config/runtime.json').async('string'));
 assert.deepEqual(cfg.ownerIds, ['111111111111111111']); assert.equal(cfg.guildId, '333333333333333333'); assert.equal(cfg.privilegedIntents, false);
});
test('HidenCloud adapter awaits preparation before start without Railway gate', async () => {
 const runtime = require('../source/runtime'); const sftp = require('../source/sftp');
 const originals = { extractZip: runtime.extractZip, prepare: runtime.prepare, start: runtime.start, uploadZip: sftp.uploadZip };
 const calls = [];
 try {
  runtime.extractZip = async () => { calls.push('extract'); };
  runtime.prepare = async () => { await new Promise(r => setTimeout(r, 5)); calls.push('prepare'); };
  runtime.start = async () => { calls.push('start'); return { ok: true }; };
  sftp.uploadZip = async () => { calls.push('upload'); return { ok: true }; };
  const app = await new (require('../source/hidencloud_api').SquareCloudAPI)().applications.create('test.zip');
  assert.ok(app.id); assert.deepEqual(calls, ['extract','prepare','start','upload']);
 } finally { Object.assign(runtime, { extractZip: originals.extractZip, prepare: originals.prepare, start: originals.start }); sftp.uploadZip = originals.uploadZip; }
});


test('visual sanitizer never places Application Emoji markup inside inline code', () => {
 const body = normalize({ content: '`✅ Ligado` fora ✅' }, 'missing');
 assert.equal(body.content.includes('`<:'), false);
 assert.equal(body.content.includes('✅'), false);
});

test('key system enforces plan, expiry, usage limit and revocation', () => {
 const store = require('../Lib/keys');
 const keysBefore = fs.readFileSync(store.KEYS_PATH, 'utf8');
 const entBefore = fs.readFileSync(store.ENTITLEMENTS_PATH, 'utf8');
 try {
  fs.writeFileSync(store.KEYS_PATH, JSON.stringify({version:1,keys:{}}));
  fs.writeFileSync(store.ENTITLEMENTS_PATH, JSON.stringify({version:1,users:{}}));
  const expiry = new Date(Date.now()+5*86400000).toISOString().slice(0,10);
  const key = store.createKey({ plan:'PRO', expiresAt:expiry, maxUses:2, createdBy:process.env.OWNER_ID });
  assert.match(key.code, /^ZENYX-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/);
  store.redeemKey(key.code, 'u1'); store.redeemKey(key.code, 'u2');
  assert.throws(() => store.redeemKey(key.code, 'u3'), /limite/);
  assert.equal(store.getUserEntitlements('u1').length, 1);
  store.revokeKey(key.code, process.env.OWNER_ID);
  assert.ok(store.getKey(key.code).revokedAt);
 } finally {
  fs.writeFileSync(store.KEYS_PATH, keysBefore); fs.writeFileSync(store.ENTITLEMENTS_PATH, entBefore);
 }
});

test('purchase provisioning configures Zenyx Sallers in the same format as trial', async () => {
 const JSZip = require('jszip');
 const zip = new JSZip();
 zip.file('Token.json', JSON.stringify({token:'placeholder'}));
 zip.file('config/runtime.json', JSON.stringify({clientId:'x',guildId:'x',ownerIds:['x'],privilegedIntents:true}));
 const { configureZip } = require('../Eventos/manager/enviarbot');
 await configureZip(zip, { token:'child-token', ownerId:'111111111111111111', clientId:'444444444444444444', guildId:'333333333333333333', days:30 });
 assert.equal(JSON.parse(await zip.file('Token.json').async('string')).token, 'child-token');
 const runtime = JSON.parse(await zip.file('config/runtime.json').async('string'));
 assert.equal(runtime.clientId,'444444444444444444');
 assert.equal(runtime.guildId,'333333333333333333');
 assert.deepEqual(runtime.ownerIds,['111111111111111111']);
 assert.equal(runtime.privilegedIntents,false);
});

test('embedded Zenyx Sallers child clears only its own globals and registers commands only to configured guild', async () => {
 const JSZip = require('jszip');
 const bytes = fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip'));
 const zip = await JSZip.loadAsync(bytes);
 const index = await zip.file('dist/index.js').async('string');
 assert.match(index, /Routes\.applicationCommands\(applicationId\), \{ body: \[\] \}/);
 assert.match(index, /Routes\.applicationGuildCommands\(applicationId, config\.guildId\)/);
 assert.match(index, /Powered by Zenyx Applications/);
 assert.match(index, /bioGuardTimer = setInterval/);
});

test('botconfig no longer uses the old panel screenshot', () => {
 const command = fs.readFileSync(path.join(__dirname,'../Comandos/config/botconfig.js'),'utf8');
 const event = fs.readFileSync(path.join(__dirname,'../Eventos/config/botconfig.js'),'utf8');
 assert.equal(command.includes('painel_manager_v2.png'), false);
 assert.equal(event.includes('painel_manager_v2.png'), false);
});


test('purchase metadata survives missing carrinhos entry and reconstructs session', () => {
 const { db1 } = require('../databases/index');
 const ps = require('../Lib/purchaseSessions');
 const channelId = '199999999999999991';
 db1.delete(channelId);
 try {
  const original = { aluguel:'ZenyxPro', plano:'Trimensal', quantia:2, dias:180 };
  const id = ps.paymentId('auto', original);
  const i = { customId:id, channel:{id:channelId,parentId:'188888888888888888'}, guildId:'177777777777777777', user:{id:'166666666666666666'}, message:{id:'155555555555555555',components:[]} };
  const session = ps.resolve(i);
  assert.equal(session.aluguel,'ZenyxPro');
  assert.equal(session.plano,'Trimensal');
  assert.equal(session.quantia,2);
  assert.equal(session.dias,180);
  assert.equal(db1.get(channelId).userid,'166666666666666666');
 } finally { db1.delete(channelId); }
});

test('legacy Quase lá buttons can recover a lost purchase session', () => {
 const { db1 } = require('../databases/index');
 const ps = require('../Lib/purchaseSessions');
 const channelId='199999999999999992';
 db1.delete(channelId);
 try {
  const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ZenyxPro_Mensal_cancel').setLabel('Discordar e Sair').setStyle(2));
  const session = ps.resolve({ customId:'ZenyxPro_automaticPay', channel:{id:channelId}, guildId:'177777777777777777', user:{id:'166666666666666666'}, message:{id:'155555555555555556',components:[row]} });
  assert.equal(session.aluguel,'ZenyxPro');
  assert.equal(session.plano,'Mensal');
  assert.equal(session.quantia,1);
 } finally { db1.delete(channelId); }
});

test('early access is configurable and visible in botconfig operation page', () => {
 const early = require('../Lib/earlyAccess');
 const before = early.isEnabled();
 try {
  early.setEnabled(false); assert.equal(early.isEnabled(), false);
  const { pagePayload } = require('../Lib/botconfigPages');
  const i=interaction();
  const json=pagePayload(i.client,i,2).components[0].toJSON();
  const raw=JSON.stringify(json);
  assert.match(raw,/earlyAccessToggle/);
  assert.match(raw,/Acesso antecipado/);
 } finally { early.setEnabled(before); }
});

test('disabled early access selector replies instead of opening checkout', async () => {
 const early = require('../Lib/earlyAccess');
 const before = early.isEnabled();
 try {
  early.setEnabled(false);
  const i=interaction(false); i.customId='ZenyxPro_buy'; i.values=['ZenyxPro_buy_ant']; i.isStringSelectMenu=()=>true; i.channel={id:'199999999999999993'};
  await require('../Eventos/manager/cart').run(i,i.client);
  assert.equal(i.calls[0][0],'reply');
  assert.match(i.calls[0][1].content,/Acesso antecipado está desativado/);
 } finally { early.setEnabled(before); }
});

test('runtime auto-corrects CJS dist under package type module', () => {
 const runtime=require('../source/runtime');
 const id='compat_test_r13';
 const dir=runtime.appDir(id);
 fs.rmSync(dir,{recursive:true,force:true}); fs.mkdirSync(path.join(dir,'dist'),{recursive:true});
 try {
  fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify({type:'module',main:'dist/index.js'}));
  fs.writeFileSync(path.join(dir,'dist/index.js'),'"use strict"; Object.defineProperty(exports, "__esModule", { value: true });');
  const result=runtime.ensureNodeModuleCompatibility(id,'dist/index.js');
  assert.equal(result.changed,true);
  assert.equal(JSON.parse(fs.readFileSync(path.join(dir,'package.json'),'utf8')).type,'commonjs');
 } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});

test('embedded Zenyx Sallers package matches its CommonJS dist', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const pkg=JSON.parse(await zip.file('package.json').async('string'));
 const index=await zip.file('dist/index.js').async('string');
 assert.equal(pkg.type,'commonjs');
 assert.match(index,/Object\.defineProperty\(exports/);
 assert.ok(zip.file('R13_CHANGELOG.txt'));
});



test('R16 recovery accepts only Gmail, Outlook and Yahoo and blocks temporary/other domains', () => {
 const recovery = require('../Lib/supabaseRecovery');
 assert.equal(recovery.normalizeEmail(' User.Name@GMAIL.COM '), 'user.name@gmail.com');
 assert.equal(recovery.normalizeEmail('cliente@outlook.com'), 'cliente@outlook.com');
 assert.equal(recovery.normalizeEmail('cliente@yahoo.com'), 'cliente@yahoo.com');
 assert.equal(recovery.emailProvider('a@gmail.com'), 'Gmail');
 assert.equal(recovery.emailProvider('a@outlook.com'), 'Outlook');
 assert.equal(recovery.emailProvider('a@yahoo.com'), 'Yahoo');
 for (const email of ['x@tempmail.com','x@10minutemail.com','x@proton.me','x@hotmail.com','x@empresa.com']) {
  assert.throws(() => recovery.normalizeEmail(email), /Gmail.*Outlook.*Yahoo|somente Gmail/i, email);
 }
});

test('R16 checkout no longer uses the legacy P-logo QR overlay', () => {
 const files = ['../Eventos/manager/cartAutomatic.js','../Eventos/manager/cartSemiAuto.js','../Eventos/manager/cartEvoPay.js','../Eventos/manager/renovar.js'];
 for (const relative of files) {
  const source = fs.readFileSync(path.join(__dirname, relative), 'utf8');
  assert.equal(source.includes('QRCodeLib'), false, relative);
  assert.equal(source.includes('aaaaa.png'), false, relative);
 }
});

test('R18 embedded Zenyx Sallers keeps V2 and legacy admin navigation compatible', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const pkg=JSON.parse(await zip.file('package.json').async('string'));
 const router=await zip.file('dist/discord/router.js').async('string');
 const views=await zip.file('dist/discord/views.js').async('string');
 assert.equal(pkg.version,'18.9.87');
 assert.match(router,/sourceIsV2/);
 assert.match(router,/views\.adminPageEdit\(guildId, payload, hasDefaultBanner\)/);
 assert.match(router,/!sourceIsV2/);
 assert.match(router,/target\.editReply/);
 assert.doesNotMatch(router,/await target\.deferUpdate\(\);\s*return target\.message\.edit\(views\.adminPage\(/);
 assert.match(views,/setLabel\("Robux"\)[\s\S]{0,700}?setValue\("robux"\)[\s\S]{0,700}?component\("robux", guildId\)/);
 assert.match(views,/this\.button\(guildId, "admin:robux", "Robux", "robux"/);
});

test('R16 embedded Zenyx Sallers treats Robux emojis as critical assets', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const manager=await zip.file('dist/emojis/manager.js').async('string');
 for (const semantic of ['brand_robot','brand_crown','robux','robux_buy','robux_calc']) assert.ok(manager.includes(`\"${semantic}\"`), semantic);
 assert.match(manager,/attempt <= 3/);
 assert.ok(zip.file('assets/emojis/pack/zenyx_robux.png'));
 assert.ok(zip.file('assets/emojis/pack/zenyx_robux_buy.png'));
 assert.ok(zip.file('assets/emojis/pack/zenyx_robux_calc.png'));
 assert.ok(zip.file('R16_CHANGELOG.txt'));
});


test('R18.8 Manager boot no longer calls a non-function personalizados module and banner is current', () => {
 const index = fs.readFileSync(path.join(__dirname,'../index.js'),'utf8');
 const personal = require('../Functions/personalizados');
 assert.equal(typeof personal, 'function');
 assert.match(index,/ASTRA APPLICATION MANAGER R18\.9\.56/);
});

test('R18.8 child calculator requests Message Content and sends PNG to configured channel', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const index=await zip.file('dist/index.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 const router=await zip.file('dist/discord/router.js').async('string');
 assert.match(index,/gatewayIntents\.push\(discord_js_1\.GatewayIntentBits\.MessageContent\)/);
 assert.match(robux,/await message\.channel\.send\(/);
 assert.match(router,/calculatorChannelId: channelId, calculatorEnabled: true/);
});


test('R18.8 client center resolves wio.db uppercase ID and legacy idapp without undefined app ids', () => {
 const source = fs.readFileSync(path.join(__dirname,'../Lib/clientCenter.js'),'utf8');
 const eventSource = fs.readFileSync(path.join(__dirname,'../Eventos/manager/clientCenter.js'),'utf8');
 assert.match(source,/row\?\.ID \?\? row\?\.id \?\? row\?\.data\?\.idapp/);
 assert.match(source,/function findOwnedApp\(userId, appId\)/);
 assert.match(eventSource,/center\.findOwnedApp\(userId, appId\)/);
 assert.doesNotMatch(source,/id:String\(r\.id\)/);
});

test('R18.8 embedded Zenyx Sallers contains recurring messages, mention campaigns and auto reactions', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const pkg=JSON.parse(await zip.file('package.json').async('string'));
 const router=await zip.file('dist/discord/router.js').async('string');
 const automations=await zip.file('dist/services/automations.js').async('string');
 const db=await zip.file('dist/core/json-db.js').async('string');
 assert.equal(pkg.version,'18.9.87');
 for (const marker of ['repeatingMessagesView','mentionMessagesView','autoReactionsView','repeat-channel-set','mention-channel-set','reaction-channel-set']) {
   assert.ok(router.includes(marker), marker);
 }
 assert.match(automations,/runMessageAutomations/);
 assert.match(automations,/previous\.delete/);
 assert.match(automations,/message\.react\(emoji\)/);
 assert.match(automations,/NEW_MEMBERS/);
 assert.match(automations,/EXISTING_MEMBERS/);
 assert.match(db,/repeatingMessages/);
 assert.match(db,/mentionMessages/);
 assert.match(db,/autoReactions/);
});

test('R18.8 Robux buy and calculator use independent fixed emoji assets', async () => {
 const JSZip=require('jszip'); const crypto=require('crypto');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const buy=await zip.file('assets/emojis/pack/zenyx_robux_buy.png').async('nodebuffer');
 const calc=await zip.file('assets/emojis/pack/zenyx_robux_calc.png').async('nodebuffer');
 const em=await zip.file('dist/emojis/manager.js').async('string');
 const digest=(b)=>crypto.createHash('sha256').update(b).digest('hex');
 assert.notEqual(digest(buy),digest(calc));
 assert.match(em,/\["robux", "robux_buy", "robux_calc", "robux_manual"\]\.includes\(semantic\)/);
 const router=await zip.file('dist/discord/router.js').async('string');
 assert.match(router,/robux:calc:money[\s\S]{0,180}?"coin"/);
 assert.match(router,/robux:calc:robux[\s\S]{0,180}?"robux"/);
});


test('R18.8 Robux manual flow advances seller from PIX to Game Pass and only announces after delivery', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 assert.match(router,/robux:seller-confirm-payment:/);
 assert.match(router,/Confirmar PIX • vendedor/);
 assert.match(router,/robux:seller-confirm-delivery:/);
 assert.match(router,/Confirmar entrega • vendedor/);
 assert.match(router,/Abrir Game Pass no Roblox/i);
 assert.match(robux,/sendDeliveryReceipt/);
 assert.match(robux,/deliveryAnnouncementAt/);
 assert.match(robux,/deliveryReceiptSentAt/);
 assert.match(robux,/finalizeDelivered\(order\)/);
 const processPaid=robux.slice(robux.indexOf('async processPaid'), robux.indexOf('async announcePurchase'));
 assert.doesNotMatch(processPaid,/announcePurchase\(order\)/);
});

test('R18.8 post-delivery sale card includes Roblox display name and compact avatar card', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const image=await zip.file('dist/services/robux-image.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 assert.match(image,/width="960" height="520"/);
 assert.match(image,/robloxDisplayName/);
 assert.match(image,/saleAvatar/);
 assert.match(robux,/setLabel\("Comprar"\)/);
 assert.match(robux,/Compra Realizada|Robux • entrega concluída/);
});

test('R18.8 every automatic message family carries disabled Mensagem Automática badge', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const automations=await zip.file('dist/services/automations.js').async('string');
 assert.match(automations,/Mensagem Automática/);
 assert.match(automations,/setDisabled\(true\)/);
 const uses=(automations.match(/automaticBadge\(\)/g)||[]).length;
 assert.ok(uses >= 6, `expected badge in all automatic message flows, found ${uses}`);
});


test('R18.8 Robux manual confirmation advances to Game Pass and has link fallback', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 assert.match(router,/seller-confirm-payment:[\s\S]{0,2200}?deferReply[\s\S]{0,2200}?refreshRobuxOrderMessage/);
 assert.match(router,/Game Pass necessária/);
 assert.match(robux,/handlePurchaseThreadMessage/);
 assert.match(robux,/attachGamepassLink/);
 assert.match(robux,/awaitingGamepassLink/);
});

test('R18.8 Robux delivery supports manual assisted cookie-auto and HTTPS modes safely', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 for (const mode of ['MANUAL','ASSISTED','COOKIE_AUTO','WEBHOOK']) assert.ok(router.includes(mode), mode);
 assert.match(robux,/deliveryLocks/);
 assert.match(robux,/configureCookie/);
 assert.match(robux,/O preço da Game Pass mudou/);
 assert.match(router,/robux:seller-auto-deliver:/);
});

test('R18.8 Robux checkout keeps manual PIX identity-free and IMAP asks bank with optional CPF', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 assert.match(router,/selectedProvider === "MANUAL_PIX"[\s\S]{0,2200}?email: ""[\s\S]{0,400}?document: ""/);
 assert.match(router,/checkout-imap/);
 assert.match(router,/Banco usado para pagar/);
 assert.match(router,/CPF \(opcional\)/);
});


test('R18.8 Robux manual fallback can skip automatic username lookup', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 assert.match(router,/robux:manual/);
 assert.match(router,/modal:robux-public:manual/);
 assert.match(router,/Quantidade de Robux/);
 assert.match(router,/Link Game Pass ou jogo \(opcional\)/);
 assert.match(robux,/requestedRobuxOverride/);
 assert.match(robux,/normalizeRobloxReferenceUrl/);
});

test('R18.8 calculator can cycle OFF PNG EMBED and message handler honors format', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const router=await zip.file('dist/discord/router.js').async('string');
 const robux=await zip.file('dist/services/robux.js').async('string');
 assert.match(router,/admin:robux:calculator-mode/);
 assert.match(robux,/calculatorFormat/);
 assert.match(robux,/calculationEmbed/);
 assert.match(robux,/settings\.calculatorFormat === "EMBED"/);
});

test('R18.9.5 hosted app branding is neutral while updater keeps internal package id', async () => {
 const JSZip=require('jszip');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'../source/ZenyxPro.zip')));
 const pkg=JSON.parse(await zip.file('package.json').async('string'));
 const router=await zip.file('dist/discord/router.js').async('string');
 assert.equal(pkg.name,'zenyx-pro-professional');
 assert.equal(pkg.version,'18.9.87');
 assert.doesNotMatch(router,/Zenyx Sallers/);
 assert.match(router,/Minha Aplicação|Aplicação/);
});
test('trial select opens the configuration modal immediately for ordinary users', async () => {
 const reviewers = require('../Lib/purchaseReviewers');
 const previousReviewers = reviewers.list(); reviewers.clear();
 const userId = '788888888888888887';
 const threadId = '888888888888888887';
 const trialDb = new (require('wio.db').JsonDatabase)({ databasePath: path.join(__dirname, '../databases/trials.json') });
 trialDb.delete(userId);
 const sent=[];
 const thread={ id:threadId, name:'teste-Teste', archived:false, url:`https://discord.com/channels/1/2/${threadId}`, deletable:true,
  members:{add:async()=>{}}, send:async payload=>{sent.push(payload);return{id:'999999999999999997'};} };
 const open=interaction(false); open.user.id=userId; open.customId='botfree'; open.guild.members.me={id:'999999999999999999'};
 open.channel={threads:{cache:new Collection(),fetchActive:async()=>new Collection(),create:async()=>thread},permissionsFor:()=>({has:()=>true})};
 try {
  const handler=require('../Eventos/manager/gratis');
  await handler.run(open);
  const json=sent[0].components[0].toJSON();
  let selectId='';
  const walk=node=>{if(!node||selectId)return;if(node.custom_id?.startsWith('select_tipo_bot_trial:'))selectId=node.custom_id;for(const child of node.components||[])walk(child);};
  walk(json); assert.ok(selectId,'trial select id missing');
  const choose=interaction(false); choose.user.id=userId; choose.customId=selectId; choose.values=['ZenyxPro']; choose.channelId=threadId; choose.message={id:'999999999999999997'};
  choose.channel={isThread:()=>true}; choose.isStringSelectMenu=()=>true;
  await handler.run(choose);
  assert.deepEqual(choose.calls.map(c=>c[0]),['showModal']);
  assert.ok(choose.calls[0][1].custom_id.startsWith('zenyx_trial_submit:'), 'modal did not open');
 } finally { trialDb.delete(userId); reviewers.set(previousReviewers); }
});
