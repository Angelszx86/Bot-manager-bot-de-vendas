const fs = require('fs');
const assert = require('assert');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');

const index = read('index.js');
assert(index.includes('ZENYX MANAGER R18.9.52'));
assert(index.includes("desiredState === 'stopped'"));
assert(index.includes('Boolean(data.userStoppedAt)'));
assert(!index.includes("savedStatus === 'stopped' && desiredState !== 'running'"));
assert(index.includes("runtime.start(appId, { bootWaitMs: 2200 })"));
const restore = index.slice(index.indexOf('async function restoreActiveChildRuntimes'), index.indexOf('client.once(Events.ClientReady'));
assert(!restore.includes('maybeUpgradeZenyxPro'), 'boot restore não pode forçar upgrade');
assert(index.includes("restoreActiveChildRuntimes('retry-20s')"));
assert(index.includes("restoreActiveChildRuntimes('retry-90s')"));

const api = read('source/hidencloud_api.js');
assert(api.includes('ZENYX_AUTO_UPGRADE_ON_START'));
assert(api.includes('runtime.start(this.id)'));

const runtime = read('source/runtime.js');
assert(runtime.includes('async function startInternal(appId, options = {})'));
assert(runtime.includes('bootWaitMs'));

const imap = read('Lib/nubankImap.js');
assert(imap.includes("INTER_OFFICIAL_DOMAINS = Object.freeze(['inter.co'])"));
assert(imap.includes("domain === 'gmail.com'"));
assert(imap.includes("host: 'imap.gmail.com'"));
assert(imap.includes("host: 'outlook.office365.com'"));
assert(imap.includes("host: 'imap.mail.yahoo.com'"));
assert(imap.includes('passesInterEmailAuthentication'));
assert(imap.includes('SPF/DKIM/DMARC'));

const cfg = read('Eventos/config/botconfig.js');
assert(cfg.includes('O remetente do Banco Inter já foi configurado automaticamente'));
assert(cfg.includes("allowedFrom: interSenderDefaults(['inter.co'])"));
assert(cfg.includes('hostManual: Boolean(explicitHost)'));
assert(cfg.includes('HOST IMAP (OPCIONAL)'));

const apps = read('Eventos/manager/apps.js');
assert(apps.includes("db2.set(`${ids}.desiredState`, 'stopped')"));
assert(apps.includes("db2.set(`${ids}.desiredState`, 'running')"));
const center = read('Eventos/manager/clientCenter.js');
assert(center.includes("desiredState`,'stopped'"));
assert(center.includes("desiredState`,'running'"));
console.log('R18.9.52 regression: PASS');
