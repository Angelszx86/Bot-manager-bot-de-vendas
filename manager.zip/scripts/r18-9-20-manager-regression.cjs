const fs=require('fs');
const path=require('path');
const JSZip=require('jszip');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const must=(c,m)=>{if(!c)throw new Error(m)};
const checkRouter=(text,label)=>{
  must(text.includes('return views.adminPageEdit(guildId, payload, hasDefaultBanner);'),`${label}: navegação admin não força V2`);
  must(text.includes('await target.deferUpdate();'),`${label}: migração legacy->V2 sem deferUpdate`);
  must(text.includes('content: null, embeds: [], attachments: [], poll: null'),`${label}: migração não limpa campos legados`);
  must((text.match(/this\.views\.adminPage\(gid, this\.ticketOptionDetail\(/g)||[]).length>=5,`${label}: modais de opção de ticket ainda legados`);
};
(async()=>{
  const pkg=JSON.parse(read('package.json'));
  must(['18.9.20','18.9.21','18.9.22','18.9.23'].includes(pkg.version),'versão manager incorreta');
  checkRouter(read('child_src/src/discord/router.ts'),'child src');
  checkRouter(read('child_src/dist/discord/router.js'),'child dist');

  const z=await JSZip.loadAsync(fs.readFileSync(path.join(root,'source','ZenyxPro.zip')));
  checkRouter(await z.file('src/discord/router.ts').async('string'),'template src');
  checkRouter(await z.file('dist/discord/router.js').async('string'),'template dist');
  const zp=JSON.parse(await z.file('package.json').async('string'));
  must(['18.9.20','18.9.21','18.9.22','18.9.23'].includes(zp.version),'template package fora da linha R18.9.20+');

  for(const name of fs.readdirSync(path.join(root,'source','runtime')).filter(x=>x.startsWith('sh_'))){
    const base=path.join('source','runtime',name);
    checkRouter(read(path.join(base,'src','discord','router.ts')),`runtime ${name} src`);
    checkRouter(read(path.join(base,'dist','discord','router.js')),`runtime ${name} dist`);
    const rp=JSON.parse(read(path.join(base,'package.json')));
    must(['18.9.20','18.9.21','18.9.22','18.9.23'].includes(rp.version),`runtime ${name} package fora da linha R18.9.20+`);
  }

  for(const hostDir of fs.readdirSync(root).filter(x=>x.startsWith('zenyx-sh_'))){
    const abs=path.join(root,hostDir);
    if(!fs.statSync(abs).isDirectory()) continue;
    for(const trialName of fs.readdirSync(abs).filter(x=>/^trial-.*\.zip$/i.test(x))){
      const tz=await JSZip.loadAsync(fs.readFileSync(path.join(abs,trialName)));
      const srcFile=tz.file('src/discord/router.ts');
      const distFile=tz.file('dist/discord/router.js');
      const pkgFile=tz.file('package.json');
      must(srcFile && distFile && pkgFile,`trial ${trialName}: estrutura do bot incompleta`);
      checkRouter(await srcFile.async('string'),`trial ${trialName} src`);
      checkRouter(await distFile.async('string'),`trial ${trialName} dist`);
      const tp=JSON.parse(await pkgFile.async('string'));
      must(['18.9.20','18.9.21','18.9.22','18.9.23'].includes(tp.version),`trial ${trialName}: package fora da linha R18.9.20+`);
    }
  }
  console.log('R18.9.20 manager ticket admin V2 regression: OK');
})().catch(e=>{console.error(e);process.exit(1)});
