const fs=require('fs');
const path=require('path');
const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
let failed=0;
function ok(value,message){if(!value){console.error('FAIL',message);failed++;}else console.log('OK',message);}

const key=read('Eventos/manager/keyBot.js');
const send=read('Eventos/manager/enviarbot.js');
const apps=read('Eventos/manager/apps.js');
const sessions=read('Lib/purchaseSessions.js');
const feed=read('Lib/salesFeed.js');
const cfg=read('Eventos/config/botconfig.js');
const center=read('Lib/clientCenter.js');

ok(key.includes('MessageFlags.IsComponentsV2'),'Key usa Components V2');
ok(key.includes('keybot:close:'),'Key possui botão/handler de fechar tópico');
ok(key.includes('clientBoundAt'),'Key persiste vínculo antes do runtime');
ok(key.includes('assertClientBinding'),'Key valida Client ID vinculado');
ok(key.includes('prepareRecoverableGrant'),'Key suporta recuperação do mesmo bot após remoção');
ok(center.includes('pronto para recuperar'),'Central sinaliza Key vinculada recuperável');

ok(send.includes('bindPaidEntitlement'),'Plano pago possui trava de entitlement por Client ID');
ok(send.includes('boundRuntimeId'),'Plano impede runtime paralelo no mesmo entitlement');
ok(send.includes('entitlementExpiresAt'),'Recuperação do plano preserva validade');
ok(sessions.includes('boundChildClientId')&&sessions.includes('entitlementExpiresAt'),'purchaseSessions preserva campos de binding');
ok(apps.includes("require('./enviarbot')")&&apps.includes('boundClientId'),'Troca de token valida Client ID da aplicação existente');

ok(feed.includes("'Adquirir Plano'"),'Feed possui botão Adquirir Plano');
ok(feed.includes('imageEnabled'),'Feed possui toggle persistente de imagem');
ok(feed.includes('MediaGalleryBuilder'),'Feed usa imagem/banner em Components V2');
ok(cfg.includes('salesFeedImageToggle'),'botconfig expõe toggle de imagem');
ok(cfg.includes('salesFeedPreviewPurchase')&&cfg.includes('salesFeedPreviewTrial'),'botconfig possui prévias de compra e teste');

for(const file of ['Eventos/manager/keyBot.js','Eventos/manager/enviarbot.js','Eventos/manager/apps.js','Lib/purchaseSessions.js','Lib/salesFeed.js','Eventos/config/botconfig.js','Lib/clientCenter.js']){
  try{require('child_process').execFileSync(process.execPath,['--check',path.join(root,file)],{stdio:'pipe'});ok(true,`Sintaxe ${file}`);}catch(e){ok(false,`Sintaxe ${file}: ${e.stderr||e.message}`);}
}
if(failed){console.error(`R18.9.13 regression: ${failed} falha(s)`);process.exit(1);}
console.log('R18.9.13 regression: OK');
