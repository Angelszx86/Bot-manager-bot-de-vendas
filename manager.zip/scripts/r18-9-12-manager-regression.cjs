const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const readZip = (zip, file) => cp.execFileSync('unzip', ['-p', zip, file], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
ok(pkg.version === '18.9.12', 'manager version must be 18.9.12');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.12-gamepass-tax-flow', 'manager build mismatch');

function inspectChild(label, pkgText, robux, router, robuxDist, routerDist) {
  const childPkg = JSON.parse(pkgText);
  ok(childPkg.version === '18.9.12', `${label}: child version must be 18.9.12`);
  ok(childPkg.zenyxBuild === '2026-09-09-r18.9.12-gamepass-tax-flow', `${label}: child build mismatch`);
  for (const [name, text] of [['robux src', robux], ['robux dist', robuxDist]]) {
    ok(text.includes('assertGamepassMatchesRequested'), `${label} ${name}: missing centralized Game Pass validation`);
    ok(text.includes('recommendedGamepassPrice'), `${label} ${name}: missing recommended Game Pass price helper`);
    ok(text.includes('parece uma quantidade/preço'), `${label} ${name}: numeric-only message can still be accepted as username`);
    ok(text.includes('taxa de 30%'), `${label} ${name}: missing fee explanation`);
    ok(!text.includes('Math.abs(estimated - order.requestedRobux) > 1'), `${label} ${name}: legacy tolerance validation still present`);
  }
  for (const [name, text] of [['router src', router], ['router dist', routerDist]]) {
    ok(text.includes('crie ou ajuste sua Game Pass para'), `${label} ${name}: required Game Pass price is not shown in delivery flow`);
    ok(text.includes('assertGamepassMatchesRequested'), `${label} ${name}: early Game Pass URL validation bypasses central rule`);
    ok(!text.includes('A Game Pass informada entrega cerca de'), `${label} ${name}: old misleading validation error still present`);
  }
}

const child = path.join(root, 'child_src');
inspectChild(
  'child_src',
  fs.readFileSync(path.join(child, 'package.json'), 'utf8'),
  fs.readFileSync(path.join(child, 'src/services/robux.ts'), 'utf8'),
  fs.readFileSync(path.join(child, 'src/discord/router.ts'), 'utf8'),
  fs.readFileSync(path.join(child, 'dist/services/robux.js'), 'utf8'),
  fs.readFileSync(path.join(child, 'dist/discord/router.js'), 'utf8')
);

const zip = path.join(root, 'source', 'ZenyxPro.zip');
ok(fs.existsSync(zip), 'embedded ZenyxPro.zip missing');
inspectChild(
  'embedded template',
  readZip(zip, 'package.json'),
  readZip(zip, 'src/services/robux.ts'),
  readZip(zip, 'src/discord/router.ts'),
  readZip(zip, 'dist/services/robux.js'),
  readZip(zip, 'dist/discord/router.js')
);

for (const id of ['sh_38e93ea72f96', 'sh_f2b3cd2f2777']) {
  const runtime = path.join(root, 'source', 'runtime', id);
  inspectChild(
    `runtime ${id}`,
    fs.readFileSync(path.join(runtime, 'package.json'), 'utf8'),
    fs.readFileSync(path.join(runtime, 'src/services/robux.ts'), 'utf8'),
    fs.readFileSync(path.join(runtime, 'src/discord/router.ts'), 'utf8'),
    fs.readFileSync(path.join(runtime, 'dist/services/robux.js'), 'utf8'),
    fs.readFileSync(path.join(runtime, 'dist/discord/router.js'), 'utf8')
  );
}

const requested = 500;
const recommended = Math.ceil(requested / 0.7);
const net = Math.floor(recommended * 0.7);
ok(recommended === 715, `500 Robux must recommend 715, got ${recommended}`);
ok(net === 500, `715 Robux must estimate 500 net, got ${net}`);
ok(Math.floor(500 * 0.7) === 350, '500 Robux Game Pass must estimate 350 net under current 30% fee rule');

console.log('R18_9_12_MANAGER_GAMEPASS_TAX_FLOW_REGRESSION_OK');
