'use strict';
const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');
const root = path.resolve(__dirname,'..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const must = (c,m) => { if(!c) throw new Error(m); };
(async()=>{
  const pkg=JSON.parse(read('package.json'));
  const index=read('index.js');
  const brand=read('Lib/brandEnforcer.js');
  const childIndex=read('child_src/dist/index.js');
  const childRouter=read('child_src/dist/discord/router.js');
  const title='𝙕𝙀𝙉𝙔𝙓 𝘼𝙋𝙋𝙇𝙄𝘾𝘼𝙏𝙄𝙊𝙉𝙎';
  const invite='https://discord.gg/V2v8JnwdgR';
  must(/^18\.9\.(?:17|18|19)$/.test(pkg.version),'versão manager incompatível com R18.9.17');
  must(index.includes("brandEnforcer.start(client)"),'Manager não inicia proteção externa');
  must(brand.includes("reason: 'token do Manager'"),'proteção pode atingir o próprio Manager');
  must(brand.includes("'/applications/@me'"),'Manager não valida a Application dos bots filhos');
  must(brand.includes("method: 'PATCH'"),'Manager não restaura bio dos filhos');
  must(brand.includes('CHILD_BIO_GUARD_MS') && (brand.includes('30_000') || brand.includes('60_000')),'guard externo ausente');
  must(brand.includes(title) && brand.includes(invite),'bio oficial incorreta no Manager');
  must(childIndex.includes(title) && childRouter.includes('Bio ZENYX bloqueada'),'child_src não corrigido');
  const zip=await JSZip.loadAsync(fs.readFileSync(path.join(root,'source','ZenyxPro.zip')));
  const zi=await zip.file('dist/index.js').async('string');
  const zr=await zip.file('dist/discord/router.js').async('string');
  must(zi.includes(title),'template ZenyxPro sem título institucional');
  must(zr.includes('Bio ZENYX bloqueada para bots filhos'),'template ZenyxPro permite bio antiga');
  for (const name of fs.readdirSync(path.join(root,'source','runtime')).filter(x=>x.startsWith('sh_'))) {
    const ri=read(path.join('source','runtime',name,'dist','index.js'));
    const rr=read(path.join('source','runtime',name,'dist','discord','router.js'));
    must(ri.includes(title),`runtime ${name} sem bio oficial`);
    must(rr.includes('Bio ZENYX bloqueada para bots filhos'),`runtime ${name} com UI antiga de bio`);
  }
  console.log('R18.9.17 manager regression: OK');
})().catch(e=>{console.error(e);process.exit(1)});
