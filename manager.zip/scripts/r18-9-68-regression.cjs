const assert=require('assert');
const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}
(async()=>{
  const worker=read('source/partner_manager_worker.js');
  const pkg=JSON.parse(read('package.json'));

  await test('confirmar compra recebe ACK imediato com tela própria de progresso',()=>{
    const begin=worker.slice(worker.indexOf('async function beginPaymentCheckout'),worker.indexOf('async function paidMessage'));
    assert(begin.includes("await i.update(updatePayload(checkoutProgressPayload(plan,mode)))"));
    assert(!begin.includes('await deferPrivate(i)'));
    assert(worker.includes("Preparando sua compra"));
    assert(worker.includes("Confirmação recebida"));
    assert(worker.includes("Não clique novamente"));
  });

  await test('checkout só abre após confirmação e mantém anti-duplicação',()=>{
    assert(worker.includes("pm:checkout:confirm:"));
    assert(worker.includes("pm:checkout:abort:"));
    assert(worker.includes('function activeCheckoutFor(userId,guildId)'));
    assert(worker.includes('checkoutLocks.has(lockKey)'));
    assert(worker.includes("await rpc('payment-ready',{},15000)"));
    const select=worker.match(/if\(i\.customId==='pm:buy'\)[^\n]+/s)?.[0]||'';
    assert(select.includes('createCheckoutIntent'));
    assert(!select.includes('createCheckoutThread'));
  });

  await test('tela de progresso substitui o estado nativo de pensando antes de operações lentas',()=>{
    const begin=worker.slice(worker.indexOf('async function beginPaymentCheckout'),worker.indexOf('async function paidMessage'));
    const ack=begin.indexOf('await i.update(updatePayload(checkoutProgressPayload(plan,mode)))');
    const ready=begin.indexOf("await rpc('payment-ready'");
    const thread=begin.indexOf('createCheckoutThread(i,plan,mode)');
    const payment=begin.indexOf("rpc('create-payment'");
    assert(ack>=0 && ready>ack && thread>ready && payment>thread);
  });

  await test('cores laterais dos Containers V2 foram removidas sem alterar estilos dos botões',()=>{
    assert(!worker.includes('.setAccentColor('));
    assert(worker.includes('ButtonStyle.Success'));
    assert(worker.includes('ButtonStyle.Danger'));
    assert(worker.includes('ButtonStyle.Primary'));
    assert(worker.includes('ButtonStyle.Secondary'));
  });

  await test('loading genérico também usa UI neutra e informativa',()=>{
    assert(worker.includes('Processando sua solicitação'));
    assert(worker.includes('Executando com segurança'));
    assert(worker.includes('Esta tela será atualizada automaticamente'));
  });

  await test('falha ainda fecha tópico criado antes da cobrança e não duplica checkout',()=>{
    assert(worker.includes('if(created?.thread&&!orderCreated) await closeFailedCheckoutThread(created.thread)'));
    assert(worker.includes("thread.delete('Checkout abortado antes da criação da cobrança.')"));
  });

  await test('versão atualizada',()=>{
    assert.equal(pkg.version,'18.9.68');
    assert.equal(pkg.zenyxBuild,'R18.9.68');
    assert(pkg.scripts['test:r18.9.68']);
  });

  console.log(`\nR18.9.68: ${ok}/${ok+fail} testes passaram.`);
  if(fail)process.exit(1);
})();
