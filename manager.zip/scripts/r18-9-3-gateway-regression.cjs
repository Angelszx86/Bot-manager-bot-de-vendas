const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const host = fs.readFileSync(path.join(root, 'Lib/zcloudHost.js'), 'utf8');
const gateway = fs.readFileSync(path.join(root, 'Lib/zcloudGateway.js'), 'utf8');
const child = fs.readFileSync(path.join(root, 'child_src/src/services/zcloud.ts'), 'utf8');
function ok(v, m){ if(!v) throw new Error(m); }
ok(host.includes("delete out['content-encoding']"), 'proxy does not strip content-encoding');
ok(host.includes("out['content-type'] = 'text/html; charset=utf-8'"), 'callback does not force HTML UTF-8');
ok(host.includes("delete out['content-disposition']"), 'proxy does not strip content-disposition');
ok(gateway.includes('zcloudHost.start()'), 'HidenCloud Manager gateway not started');
ok(child.includes('return this.authorizeUrl(guildId, this.panelState(guildId));'), 'published panel no longer opens Discord OAuth directly');
console.log('R18_9_3_GATEWAY_COMPAT_OK');
