const fs=require('fs');
const path=require('path');
const must=(v,m)=>{if(!v)throw new Error(m)};
const read=p=>fs.readFileSync(path.join(process.cwd(),p),'utf8');
const pkg=JSON.parse(read('package.json'));
const childPkg=JSON.parse(read('child_src/package.json'));
must(pkg.version==='18.9.24','manager version');
must(childPkg.version==='18.9.24','child version');

const pages=read('Lib/botconfigPages.js');
const config=read('Eventos/config/botconfig.js');
const store=read('Lib/storefrontConfig.js');
const panel=read('Lib/refreshSalesPanel.js');
const plans=read('Lib/managerPlans.js');
const trial=read('Lib/trialSettings.js');
const center=read('Lib/clientCenter.js');
must(pages.includes('const PAGE_COUNT = 6'),'botconfig must have 6 pages');
must(config.includes('page >= PAGE_COUNT'),'mgrnav must support every page');
must(store.includes("style:'DETAILED'")&&store.includes("'VELTRIX'"),'storefront styles missing');
must(panel.includes("setCustomId(`${productId}_selectPlano`)")&&panel.includes('`plan:${plan.id}`'),'public panel must list plans directly');
must(panel.includes('showInfo')&&panel.includes('showDemo')&&panel.includes('showTrial')&&panel.includes('showSupport'),'button visibility flags missing');
must(plans.includes('function upsert')&&plans.includes('function remove')&&plans.includes('function toggle'),'dynamic plan CRUD missing');
must(trial.includes('durationMinutes')&&trial.includes('60*24*365'),'configurable trial duration missing');
must(center.includes('hasActiveKey')&&center.includes("if(activeKey) primary.push(button('center:view-bot'"),'expired key must hide Ver bot');

const z=read('child_src/src/services/zcloud.ts');
const types=read('child_src/src/types.ts');
must(types.includes('backupTransferEnabled')&&types.includes('backupGuildId')&&types.includes('backupTransferLimit'),'zcloud backup fields missing');
must(z.includes('transferVerifiedMembersToBackup')&&z.includes('guilds.join'),'authorized zcloud backup transfer missing');
must(z.includes('.bar{height:100%;width:0%'),'zcloud progress must begin at 0%');

const idx=read('child_src/src/index.ts');
const router=read('child_src/src/discord/router.ts');
const invites=read('child_src/src/services/invites.ts');
const views=read('child_src/src/discord/views.ts');
must(idx.includes('InviteTrackerService')&&idx.includes('Events.GuildMemberAdd')&&idx.includes('Events.GuildMemberRemove')&&idx.includes('Events.InviteCreate')&&idx.includes('Events.InviteDelete'),'invite gateway integration missing');
must(idx.includes('GatewayIntentBits.GuildInvites'),'GuildInvites intent missing');
must(router.includes('private invitesAdminView')&&router.includes('admin:invites:toggle')&&router.includes('modal:invites:settings')&&router.includes('admin:invites:channel-set'),'invite admin UI incomplete');
must(views.includes('.setLabel("Invites")')&&views.includes('"admin:invites"'),'invite entry missing from /painel');
must(invites.includes('{member}')&&invites.includes('{inviter}')&&invites.includes('{invites}')&&invites.includes('handleMemberAdd'),'invite tracker service incomplete');

for(const p of ['child_src/dist/index.js','child_src/dist/discord/router.js','child_src/dist/services/invites.js','child_src/dist/services/zcloud.js'])must(fs.existsSync(p),`missing compiled file ${p}`);
console.log('R18.9.24 regression: OK');
