'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const Module = require('module');
const ROOT = path.join(__dirname, '..');
const read = p => fs.readFileSync(path.join(ROOT,p),'utf8');
let passed=0;
function test(name,fn){ Promise.resolve().then(fn).then(()=>{passed++;console.log(`ok ${passed} - ${name}`);}).catch(e=>{console.error(`not ok - ${name}\n${e.stack||e}`);process.exitCode=1;}); }
function staticChecks(){
  const manager=read('Lib/partnerManagers.js');
  const worker=read('source/partner_manager_worker.js');
  const store=read('Lib/partnerManagerStore.js');
  const runtime=read('source/runtime.js');
  const pkg=JSON.parse(read('package.json'));
  assert.equal(pkg.version,'18.9.61');
  assert.equal(pkg.zenyxBuild,'R18.9.61');
  assert(!/plans:\s*\[\{id:'mensal',label:'Mensal',days:30,price:\.90/.test(manager));
  assert(manager.includes("plans:[],createdAt"));
  assert(store.includes('isLegacySeededPlan'));
  assert(store.includes('CURRENT_VERSION = 3'));
  assert(worker.includes('Routes.applicationCommands(client.user.id),{body:[]}'));
  assert(worker.includes("name:'sacar'"));
  assert(!worker.includes("name:'pix',description:'Chave PIX que receberá o saque'"));
  assert(worker.includes("pm:guild-config"));
  assert(worker.includes("pm:config:staff-role"));
  assert(worker.includes("pm:pix:modal"));
  assert(worker.includes('PartnerManagerEmojiRegistry'));
  assert(worker.includes("emojiText('loading'"));
  assert(worker.includes('Events.ClientReady'));
  assert(!worker.includes("client.once('ready'"));
  assert(runtime.includes("running:true, pid:0, remoteProvider:'shardcloud'"));
  assert(runtime.includes('status:label, running:alive'));
  assert(fs.existsSync(path.join(ROOT,'assets/partner-manager-emojis/manifest.json')));
  const manifest=JSON.parse(read('assets/partner-manager-emojis/manifest.json'));
  assert(manifest.some(x=>x.semantic==='loading'));
  assert(manifest.some(x=>x.semantic==='pix'));
  assert(manifest.some(x=>x.semantic==='settings'));
}

async function dynamicChildZip(){
  const originalLoad=Module._load;
  const JSZip=require('jszip');
  Module._load=function(request,parent,isMain){
    if(request==='./partnerManagerStore')return {get(){},all(){return[]},patch(){}};
    if(request==='../databases/index')return {db2:{all(){return[]}}};
    if(request==='../source/runtime')return {};
    if(request==='./evopay')return {};
    if(request==='./discordChildValidation')return {};
    if(request==='./brandEnforcer')return {};
    return originalLoad.call(this,request,parent,isMain);
  };
  let mod;
  try { mod=require(path.join(ROOT,'Lib/partnerManagers.js')); }
  finally { Module._load=originalLoad; }
  const bytes=await mod._internals.configuredChildZip({token:'TEST_TOKEN_ABCDEFGHIJKLMNOPQRSTUVWXYZ',ownerId:'123456789012345678',clientId:'223456789012345678',guildId:'323456789012345678',expiresAt:new Date(Date.now()+86400000).toISOString(),partnerManagerId:'pm_test'});
  const zip=await JSZip.loadAsync(bytes);
  assert(zip.file('Token.json'),'Token.json ausente');
  assert(zip.file('config/runtime.json'),'runtime ausente');
  const token=JSON.parse(await zip.file('Token.json').async('string'));
  const runtime=JSON.parse(await zip.file('config/runtime.json').async('string'));
  assert.equal(token.token,'TEST_TOKEN_ABCDEFGHIJKLMNOPQRSTUVWXYZ');
  assert.equal(runtime.clientId,'223456789012345678');
  assert.equal(runtime.guildId,'323456789012345678');
  assert.deepEqual(runtime.ownerIds,['123456789012345678']);
  assert.equal(runtime.autoInstallEmojis,true);
  assert.equal(runtime.emojiInstallLimit,0);
}
async function templateCheck(){
  const JSZip=require('jszip');
  const zip=await JSZip.loadAsync(fs.readFileSync(path.join(ROOT,'source/ZenyxPro.zip')));
  assert(zip.file('Token.json'));
  assert(zip.file('config/runtime.json'));
  assert(zip.file('R18_9_61_CHANGELOG.txt'));
  const childPkg=JSON.parse(await zip.file('package.json').async('string'));
  assert.equal(childPkg.version,'18.9.61');
  const childIndex=await zip.file('src/index.ts').async('string');
  assert(childIndex.includes('Routes.applicationCommands(applicationId), { body: [] }'));
  assert(childIndex.includes('Routes.applicationGuildCommands(applicationId, config.guildId)'));
}
async function providerNormalizer(){
  const originalLoad=Module._load;
  Module._load=function(request,parent,isMain){
    if(request==='./partnerManagerStore')return {};
    if(request==='../databases/index')return {db2:{all(){return[]}}};
    if(request==='../source/runtime')return {};
    if(request==='./evopay')return {};
    if(request==='./discordChildValidation')return {};
    if(request==='./brandEnforcer')return {};
    return originalLoad.call(this,request,parent,isMain);
  };
  let mod;
  try { delete require.cache[require.resolve(path.join(ROOT,'Lib/partnerManagers.js'))]; mod=require(path.join(ROOT,'Lib/partnerManagers.js')); }
  finally { Module._load=originalLoad; }
  const c=mod._internals.normalizeCharge({data:[{transactionId:'tx1',pixCode:'000201TEST',status:'PENDING'}]});
  assert.equal(c.id,'tx1'); assert.equal(c.qrCodeText,'000201TEST');
  assert.equal(mod._internals.normalizeProviderStatus({transaction:{transactionStatus:'COMPLETED'}}),'COMPLETED');
}

(async()=>{
  try { staticChecks(); passed++; console.log(`ok ${passed} - invariantes estáticas R18.9.61`); } catch(e){console.error(`not ok - invariantes estáticas\n${e.stack||e}`);process.exit(1);}
  try { await dynamicChildZip(); passed++; console.log(`ok ${passed} - ZIP filho recebe token/runtime reais`); } catch(e){console.error(`not ok - ZIP filho\n${e.stack||e}`);process.exit(1);}
  try { await templateCheck(); passed++; console.log(`ok ${passed} - template filho endurecido e comandos isolados`); } catch(e){console.error(`not ok - template filho\n${e.stack||e}`);process.exit(1);}
  try { await providerNormalizer(); passed++; console.log(`ok ${passed} - normalizador EvoPay compatível`); } catch(e){console.error(`not ok - normalizador EvoPay\n${e.stack||e}`);process.exit(1);}
  console.log(`R18.9.61 regression: ${passed}/4 grupos OK`);
})();
