const fs=require('fs');
const path=require('path');
function must(x,m){ if(!x) throw new Error(m); }
const root=path.resolve(__dirname,'..');
const manager=fs.readFileSync(path.join(root,'Lib/brandEnforcer.js'),'utf8');
const runtime=fs.readFileSync(path.join(root,'source/runtime.js'),'utf8');
const child=fs.readFileSync(path.join(root,'child_src/src/index.ts'),'utf8');
const router=fs.readFileSync(path.join(root,'child_src/src/discord/router.ts'),'utf8');
const old='Automação completa para Discord • vendas, tickets e pagamentos 24/7.';
const invite='https://discord.gg/V2v8JnwdgR';
must(manager.includes('zenyx_brand_robot_v23')&&manager.includes('zenyx_brand_zy_v23'),'Manager não provisiona emojis de marca por Application filha');
must(manager.includes('CHILD_BIO_GUARD_MS = 30_000'),'watchdog Manager não está em 30s');
must(manager.includes("entry?.ID || data?.idapp"),'wio.db ID não corrigido');
must(manager.includes("Token.json"),'self-heal por runtime ausente');
must(!manager.includes('1546213417180733542')&&!manager.includes('1546213212934906007'),'Manager ainda contém IDs antigos na Bio');
must(runtime.includes('enforceChildBioFromRuntime'),'runtime não reforça Bio ao iniciar');
must(!child.includes('1546213417180733542')&&!child.includes('1546213212934906007'),'child ainda usa IDs antigos');
must(!router.includes('1546213417180733542')&&!router.includes('1546213212934906007'),'router ainda usa IDs antigos');
must(!child.includes('if (!desired) return;'),'guard child ainda pode pular Bio');
must(child.includes(invite)&&router.includes(invite),'convite novo ausente');
for(const file of ['child_src/src/core/json-db.ts','child_src/database/modelo/loja/marca.json']){
 const t=fs.readFileSync(path.join(root,file),'utf8'); must(!t.includes(old),`${file} ainda contém bio genérica antiga`);
}
console.log('R18.9.19 bio canonical regression: OK');
