const fs = require('fs');
function read(file){ return fs.readFileSync(file,'utf8'); }
function ok(value,message){ if(!value) throw new Error(message); }

const index = read('index.js');
const renew = read('Eventos/manager/renewalCenter.js');
const apps = read('Eventos/manager/apps.js');

// Restart / auto-restore
ok(index.includes("['stopped','recoverable','removed','suspended','revoked','expired','expiration_stop_failed']"), 'boot deve ignorar somente estados explicitamente não executáveis');
ok(!index.includes("['stopped','offline','recoverable','removed','suspended','revoked','expired','expiration_stop_failed']"), 'offline não pode bloquear restauração automática');
ok(index.includes("db2.set(`${appId}.status`, 'online')"), 'boot deve sincronizar status online após restaurar o runtime');
ok(index.includes('reconciliação tardia falhou') && index.includes('30000'), 'deve existir segunda reconciliação tardia de runtimes');
ok(apps.includes("db2.set(`${ids}.status`, 'stopped')"), 'desligamento explícito legado deve persistir stopped');
ok(apps.includes("db2.set(`${ids}.status`, 'online')"), 'reinício explícito legado deve persistir online');

// Renewal checkout
ok(renew.includes('ChannelType.PrivateThread'), 'renovação precisa abrir tópico privado');
ok(renew.includes("renew:pay:mp") && renew.includes("renew:pay:evo") && renew.includes("renew:pay:vyv") && renew.includes("renew:pay:mag") && renew.includes("renew:pay:semi"), 'renovação deve oferecer os mesmos gateways disponíveis do checkout');
ok(renew.includes('Nenhum método de pagamento está ativado e configurado'), 'deve falhar genericamente quando nenhum método existir');
ok(!renew.includes('A renovação automática está indisponível porque o **Mercado Pago** não está configurado'), 'renovação não pode exigir Mercado Pago');
ok(renew.includes('lastRenewalSessionId'), 'renovação deve ser idempotente contra dupla extensão');
ok(renew.includes("customId('renew:check')") || renew.includes("setCustomId('renew:check')"), 'deve existir revalidação manual de cobrança automática');
ok(renew.includes("renew:manual:approve"), 'PIX manual deve ter confirmação de equipe');
ok(renew.includes('purchaseReviewers.isReviewer'), 'aprovação manual deve validar equipe/reviewer');
ok(renew.includes('tryStartRenewedRuntime'), 'renovação expirada deve tentar religar a aplicação automaticamente');
ok(renew.includes("db2.set(`${session.appId}.status`, 'offline')"), 'falha transitória ao religar deve ficar elegível ao boot automático');

console.log('R18.9.47 manager regression OK');
