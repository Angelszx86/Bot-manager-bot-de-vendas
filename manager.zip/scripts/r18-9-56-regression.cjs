const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');
function read(rel){ return fs.readFileSync(path.join(__dirname,'..',rel),'utf8'); }
function must(value,msg){ if(!value) throw new Error(msg); console.log('PASS:',msg); }
(async()=>{
  const pkg = JSON.parse(read('package.json'));
  must(pkg.version === '18.9.56', 'manager version 18.9.56');
  const index = read('index.js');
  must(index.includes('R18.9.56') && index.includes('rollout'), 'manager announces resilient child rollout');
  const cc = read('Eventos/manager/clientCenter.js');
  must(/deferUpdate\(\)/.test(cc), 'client center acknowledges component before heavy work');
  const botconfig = read('Eventos/config/botconfig.js');
  must(botconfig.includes('Desativar PIX manual') && botconfig.includes('Ativar PIX manual'), 'manager has explicit manual PIX enable/disable control');
  const imap = read('Lib/nubankImap.js');
  must(imap.includes('inter.co') && imap.includes('bancointer.com.br'), 'Inter IMAP recognizes current and legacy official Inter domains');
  must(/app password|senha de aplicativo|authentication/i.test(imap), 'IMAP reports provider authentication errors instead of masking them');
  const runtime = read('source/runtime.js');
  must(runtime.includes('maybeUpgradeZenyxPro') && runtime.includes('rollback'), 'child update remains transactional with rollback');
  must(runtime.includes('async function syncZcloudFeatureForAll()') && runtime.includes('async function syncWalletFeatureForAll(options = {})'), 'runtime sync helpers are implemented, not only exported');
  const runtimeModule = require(path.join(__dirname,'..','source','runtime.js'));
  must(typeof runtimeModule.syncZcloudFeatureForAll === 'function' && typeof runtimeModule.syncWalletFeatureForAll === 'function' && typeof runtimeModule.logs === 'function', 'runtime exports are loadable functions');
  const zip = await JSZip.loadAsync(fs.readFileSync(path.join(__dirname,'..','source','ZenyxPro.zip')));
  const cpkg = JSON.parse(await zip.file('package.json').async('string'));
  must(cpkg.version === '18.9.56', 'embedded child template is 18.9.56');
  const views = await zip.file('src/discord/views.ts').async('string');
  must(views.indexOf('admin:voice') < views.indexOf('admin:products'), 'Conectar/Comandos remain at start of child panel source');
  const payments = await zip.file('src/services/payments.ts').async('string');
  must(payments.includes('manualPixEnabled !== false'), 'embedded child respects disabled manual PIX');
  const voice = await zip.file('src/services/voice.ts').async('string');
  must(voice.includes('handleVoiceStateUpdate') && voice.includes('scheduleReconnect'), 'embedded child has voice reconnect monitoring');
  console.log('R18.9.56 manager regression OK');
})().catch((e)=>{ console.error(e); process.exit(1); });
