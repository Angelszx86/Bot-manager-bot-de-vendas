const fs=require('fs');
function ok(v,m){if(!v)throw new Error(m)}
const billing=fs.readFileSync('Eventos/bot/cobranca.js','utf8');
const runtime=fs.readFileSync('source/runtime.js','utf8');
const sftp=fs.readFileSync('source/sftp.js','utf8');
const renew=fs.readFileSync('Eventos/manager/renewalCenter.js','utf8');
ok(/15 \* 24 \* 60 \* 60 \* 1000/.test(billing),'retenção deve ser exatamente 15 dias');
ok(/isPurgeDue\(current/.test(billing)&&/isPurgeDue\(latest/.test(billing),'purge deve reler validade antes de excluir');
ok(/application\.delete\(\)/.test(billing)&&/db2\.delete\(row\.ID\)/.test(billing),'purge deve remover runtime e registro');
ok(/unlinkOwnerApplication/.test(billing),'índice do proprietário deve ser limpo');
ok(/purgeAfter/.test(billing),'prazo de retenção deve ficar persistido');
ok(/delete next\.purgeAfter/.test(renew)&&/notify:false/.test(renew),'renovação deve cancelar estado de retenção');
ok(/\.persist-\$\{appId\}-/.test(runtime),'remoção deve limpar backup transacional órfão');
ok(/async function removeApp\(appId\)/.test(sftp),'SFTP precisa de limpeza por app');
console.log('R18.9.44 manager regression OK');
