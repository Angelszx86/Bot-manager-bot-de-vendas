const fs=require('fs');
const must=(v,m)=>{if(!v)throw new Error(m)};
const read=p=>fs.readFileSync(p,'utf8');
const rootPkg=JSON.parse(read('package.json'));
const childPkg=JSON.parse(read('child_src/package.json'));
const router=read('child_src/src/discord/router.ts');
const views=read('child_src/src/discord/views.ts');
const distRouter=read('child_src/dist/discord/router.js');
const distViews=read('child_src/dist/discord/views.js');

must(rootPkg.version==='18.9.29','manager version must be 18.9.29');
must(childPkg.version==='18.9.29','child version must be 18.9.29');
must(childPkg.zenyxBuild==='2026-09-11-r18.9.29-zcloud-emoji-purchase-speed','child build mismatch');

must(router.includes('admin:zcloud:emoji:0'),'ZCloud emoji picker button missing');
must(router.includes('admin:zcloud:emoji-select:'),'ZCloud emoji select handler missing');
must(router.includes('admin:zcloud:emoji-remove'),'ZCloud remove emoji action missing');
must(router.includes('admin:zcloud:emoji-add'),'ZCloud add emoji action missing');
must(router.includes('mode === "zcloud-button"'),'ZCloud picker mode missing');
must(router.includes('buttonEmoji:"__none__"'),'ZCloud no-emoji sentinel missing');
must(router.includes('emojiChoice !== "__none__"'),'public ZCloud no-emoji handling missing');

must(router.includes('new ButtonBuilder().setCustomId("admin:product:create-type:MANUAL").setLabel("Entrega manual")'),'manual product create button should not force headset emoji');
must(router.includes('setEmoji(this.emojis.component("delivery", gid)).setDefault(product.deliveryType === "MANUAL")'),'manual delivery selector should use neutral delivery emoji');
must(!views.includes('`${this.emojis.text("support", guildId)} ENTREGA MANUAL`'),'headset/support emoji still used in manual delivery header');
must(views.includes('const manualLabel = product.deliveryType === "ROLE" ? `${this.emojis.text("role", guildId)} Cargo automático` : "Entrega manual"'),'manual delivery public header refinement missing');

must(router.includes('i.guild.channels.cache.get(cart.channelId) ?? await i.guild.channels.fetch(cart.channelId)'),'purchase channel cache fast path missing');
must(router.includes('i.guild.channels.cache.get(settings.purchaseCategoryId) ?? await i.guild.channels.fetch(settings.purchaseCategoryId)'),'purchase category cache fast path missing');

must(distRouter.includes('admin:zcloud:emoji-remove') && distRouter.includes('__none__'),'compiled ZCloud emoji changes are stale');
must(distViews.includes('Entrega manual'),'compiled manual delivery view missing');

console.log('R18_9_29_REGRESSION_OK');
