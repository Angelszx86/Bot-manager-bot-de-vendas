const fs=require('fs');const path=require('path');const assert=require('assert');const cp=require('child_process');
const root=path.resolve(__dirname,'..');const read=p=>fs.readFileSync(path.join(root,p),'utf8');const must=(v,m)=>assert.ok(v,m);
const pkg=require(path.join(root,'package.json'));must(pkg.version==='18.9.37','manager version mismatch');must(String(pkg.zenyxBuild).includes('r18.9.37'),'manager build id mismatch');
const index=read('index.js');must(index.includes('ZENYX MANAGER R18.9.37'),'boot banner mismatch');
const templates=read('Lib/templates.js');must(templates.includes("Aplicação hospedada 18.9.37"),'template label mismatch');
const template=path.join(root,'source','ZenyxPro.zip');must(fs.existsSync(template),'embedded ZenyxPro.zip missing');
const child=JSON.parse(cp.execFileSync('unzip',['-p',template,'package.json'],{encoding:'utf8'}));must(child.version==='18.9.37','embedded child version mismatch');must(String(child.zenyxBuild).includes('r18.9.37'),'embedded child build mismatch');
const views=cp.execFileSync('unzip',['-p',template,'src/discord/views.ts'],{encoding:'utf8'});must(views.includes('**ENTREGA MANUAL**'),'embedded manual delivery label mismatch');must(views.includes('Checkout privado'),'embedded checkout visual mismatch');
console.log('[R18.9.37 MANAGER] regression OK');
