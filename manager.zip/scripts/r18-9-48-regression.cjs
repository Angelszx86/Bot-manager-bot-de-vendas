const fs = require('fs');
function read(p){ return fs.readFileSync(p,'utf8'); }
function must(v,m){ if(!v) throw new Error(m); }
const renew=read('Eventos/manager/renewalCenter.js');
const apps=read('Eventos/manager/apps.js');
const index=read('index.js');
must(!renew.includes('A renovação automática está indisponível porque o **Mercado Pago** não está configurado'), 'Mensagem legada de Mercado Pago ainda existe');
must(renew.includes('createRenewalThread'), 'Fluxo de tópico privado ausente');
must(renew.includes("available.mp") && renew.includes("available.evo") && renew.includes("available.semi"), 'Seleção dinâmica de gateways ausente');
must(index.includes("'offline' é tratado como estado transitório") || index.includes("'offline' é tratado como estado transitório"), 'Restauração de offline não encontrada');
must(index.includes('for (let attempt = 1; attempt <= 3; attempt++)'), 'Retries de restauração ausentes');
must(apps.includes("db2.set(`${ids}.status`, 'stopped')"), 'Parada explícita não persiste stopped');
must(index.includes('[ZENYX R18.9.48]'), 'Marcador de build ausente');
console.log('R18.9.48 regression: OK');
