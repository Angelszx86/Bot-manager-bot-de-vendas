const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const readZip = (zip, file) => cp.execFileSync('unzip', ['-p', zip, file], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
ok(pkg.version === '18.9.11', 'manager version must be 18.9.11');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.11-robux-pix-checkout', 'manager build mismatch');

const zip = path.join(root, 'source', 'ZenyxPro.zip');
ok(fs.existsSync(zip), 'embedded ZenyxPro.zip missing');
const childPkg = JSON.parse(readZip(zip, 'package.json'));
ok(childPkg.version === '18.9.11', 'embedded child version must be 18.9.11');
ok(childPkg.zenyxBuild === '2026-09-09-r18.9.11-robux-pix-checkout', 'embedded child build mismatch');
const router = readZip(zip, 'src/discord/router.ts');
const validator = readZip(zip, 'src/discord/payload-validator.ts');
const distRouter = readZip(zip, 'dist/discord/router.js');
const distValidator = readZip(zip, 'dist/discord/payload-validator.js');

ok(router.includes('Discord Components V2 exige `accessory` em todo Section (type 9).'), 'embedded child missing invalid Section fix');
ok(router.includes('components.push({ type: 10, content: checkoutText });'), 'embedded child missing no-avatar Text Display fallback');
ok(router.includes('robux:pix-key:${userId}:${order.id}'), 'embedded child missing PIX key button');
ok(router.includes('robux:pix-code:${userId}:${order.id}'), 'embedded child missing PIX code button');
ok(router.includes('**Chave PIX:**'), 'embedded child does not display PIX key');
ok(validator.includes('Section exige um accessory (Button ou Thumbnail)'), 'embedded validator missing Section accessory rule');
ok(distRouter.includes('robux:pix-key:') && distRouter.includes('robux:pix-code:'), 'embedded compiled router is stale');
ok(distValidator.includes('Section exige um accessory'), 'embedded compiled validator is stale');

for (const id of ['sh_38e93ea72f96', 'sh_f2b3cd2f2777']) {
  const runtime = path.join(root, 'source', 'runtime', id);
  const runtimePkg = JSON.parse(fs.readFileSync(path.join(runtime, 'package.json'), 'utf8'));
  ok(runtimePkg.version === '18.9.11', `bundled runtime ${id} was not upgraded`);
  ok(runtimePkg.zenyxBuild === '2026-09-09-r18.9.11-robux-pix-checkout', `bundled runtime ${id} build mismatch`);
  const runtimeRouter = fs.readFileSync(path.join(runtime, 'dist', 'discord', 'router.js'), 'utf8');
  const runtimeValidator = fs.readFileSync(path.join(runtime, 'dist', 'discord', 'payload-validator.js'), 'utf8');
  ok(runtimeRouter.includes('Section (type 9)') && runtimeRouter.includes('robux:pix-key:'), `bundled runtime ${id} compiled checkout fix is stale`);
  ok(runtimeValidator.includes('Section exige um accessory'), `bundled runtime ${id} compiled validator is stale`);
}

console.log('R18_9_11_MANAGER_ROBUX_PIX_CHECKOUT_REGRESSION_OK');
