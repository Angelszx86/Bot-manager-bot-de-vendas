const fs=require('fs'); const path=require('path'); const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
function must(ok,msg){ if(!ok){console.error('FAIL:',msg);process.exitCode=1}else console.log('PASS:',msg) }
const idx=read('index.js'); const rt=read('source/runtime.js'); const cc=read('Eventos/manager/clientCenter.js'); const imap=read('Lib/nubankImap.js'); const expiry=read('Eventos/bot/cobranca.js');
must(idx.includes('}, 6000).unref?.();'), 'child rollout begins after 6 seconds');
must(idx.includes('setTimeout(resolve, 1200)'), 'rollout stays sequential without 8-second artificial delay');
must(rt.includes('canReuseNodeModules') && rt.includes('rollout rápido com dependências reutilizadas'), 'runtime supports low-resource fast-path rollout');
must(cc.indexOf('await interaction.deferUpdate();') < cc.indexOf("const appId=interaction.values[0]"), 'client center select ACKs before app lookup');
must(imap.includes("'inter.co', 'bancointer.com.br'"), 'Inter current and legacy sender domains supported');
must(imap.includes('const recentIds = await client.search({ since });'), 'IMAP scans recent mail even when already read');
must(expiry.includes('10 * 24 * 60 * 60 * 1000'), 'expired runtimes retain for 10 days');
if(process.exitCode) process.exit(process.exitCode); else console.log('R18.9.55 manager regression OK');
