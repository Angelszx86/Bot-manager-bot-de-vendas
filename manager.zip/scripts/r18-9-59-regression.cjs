const fs=require('fs'),path=require('path'),JSZip=require('jszip');
const root=path.resolve(__dirname,'..');
const ok=(v,m)=>{if(!v)throw new Error(m)};
(async()=>{
 const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')); ok(pkg.version==='18.9.59','manager version');
 const rt=fs.readFileSync(path.join(root,'source/runtime.js'),'utf8');
 ok(rt.includes('startOnShardCloud')&&rt.includes("remoteProvider:'shardcloud'"),'ShardCloud runtime fallback missing');
 const imap=fs.readFileSync(path.join(root,'Lib/nubankImap.js'),'utf8');
 ok(imap.includes('nextAllowedAt')&&imap.includes('Falha controlada no watcher'),'IMAP backoff/unhandled guard missing');
 const bc=fs.readFileSync(path.join(root,'Eventos/config/botconfig.js'),'utf8'); ok(bc.includes('shardcloudFallback')&&bc.includes('shardcloudTokenSubmit'),'ShardCloud botconfig missing');
 const zip=await JSZip.loadAsync(fs.readFileSync(path.join(root,'source/ZenyxPro.zip')));
 const cp=JSON.parse(await zip.file('package.json').async('string')); ok(cp.version==='18.9.59','child version');
 ok(!zip.file('package-lock.json'),'stale child package-lock');
 const router=await zip.file('src/discord/router.ts').async('string');
 ok(router.includes('Sistema de ticket publicado')&&router.includes('ACK de segurança'),'ticket/ACK patch missing');
 const voice=router.match(/if \(id === "admin:voice:channel-set"\) \{([\s\S]*?)\n    \}/)?.[1]||''; ok(!voice.includes('deferUpdate()'),'voice double-defer returned');
 console.log('R18.9.59 manager regression PASS');
})().catch(e=>{console.error(e);process.exit(1)});
