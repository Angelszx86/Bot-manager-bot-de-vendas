'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const Module=require('module');
const ROOT=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(ROOT,p),'utf8');
let passed=0;
function ok(name,fn){ try{fn();passed++;console.log(`ok ${passed} - ${name}`);}catch(e){console.error(`not ok - ${name}\n${e.stack||e}`);process.exit(1);} }

ok('versão 18.9.72',()=>{const p=JSON.parse(read('package.json'));assert.equal(p.version,'18.9.72');assert.equal(p.zenyxBuild,'R18.9.72');});
ok('adaptador PIX central é enviado no patch',()=>{const s=read('Lib/evopay.js');assert(s.includes("safeGet('evopay.token')"));assert(s.includes("process.env.EVOPAY_TOKEN"));assert(s.includes("enabledRaw===undefined ? Boolean(token)"));assert(s.includes("Idempotency-Key"));});
ok('checkout parceiro diferencia credencial ausente e gateway desativado',()=>{const s=read('Lib/partnerManagers.js');assert(s.includes("central.token && central.enabled===false"));assert(s.includes('credencial do PIX central não foi localizada'));});

// Simula exatamente uma instalação antiga: token salvo no banco, sem evopay.enabled.
const originalLoad=Module._load;
const fakeApi={get(k){ if(k==='evopay.token') return 'TOKEN_JA_CONFIGURADO_123456'; if(k==='evopay.expiresIn') return 600; return undefined; }};
Module._load=function(req,parent,isMain){ if(req==='../databases/index' && parent?.filename?.endsWith(path.join('Lib','evopay.js'))) return {api:fakeApi}; return originalLoad.call(this,req,parent,isMain); };
try{
  delete require.cache[require.resolve(path.join(ROOT,'Lib/evopay.js'))];
  const evo=require(path.join(ROOT,'Lib/evopay.js'));
  ok('token legado já configurado é detectado automaticamente',()=>{const s=evo.settings();assert.equal(s.token,'TOKEN_JA_CONFIGURADO_123456');assert.equal(s.enabled,true);assert.equal(s.configured,true);assert.equal(s.expiresIn,600);});
} finally { Module._load=originalLoad; }
console.log(`R18.9.72 regression: ${passed}/4 OK`);
