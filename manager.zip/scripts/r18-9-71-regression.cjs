const assert=require('assert');
const fs=require('fs');
const path=require('path');
const cp=require('child_process');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
const pricing=require(path.join(ROOT,'Lib/planPricing'));
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}
(async()=>{
 const worker=read('source/partner_manager_worker.js');
 const partners=read('Lib/partnerManagers.js');
 const store=read('Lib/partnerManagerStore.js');
 const event=read('Eventos/manager/partnerManagers.js');
 const proxy=read('Lib/discordRestProxy.js');
 const pkg=JSON.parse(read('package.json'));
 await test('preço mínimo proporcional continua obrigatório',()=>{
   assert.equal(pricing.minimumPrice(30),6); assert.equal(pricing.minimumPrice(31),12); assert.equal(pricing.minimumPrice(150),30);
   assert(pricing.validatePlan(30,6).ok); assert(!pricing.validatePlan(150,6).ok);
 });
 await test('checkout cria tópico e pedido provisório antes do provedor',()=>{
   const begin=worker.slice(worker.indexOf('async function beginPaymentCheckout'),worker.indexOf('async function paidMessage'));
   assert(begin.includes('created=await createCheckoutThread(i,plan,mode)'));
   assert(begin.includes('const provisional=store.saveOrder'));
   assert(begin.includes("status:'CREATING'"));
   assert(begin.indexOf('createCheckoutThread(i,plan,mode)') < begin.indexOf("rpc('create-payment'"));
   assert(!begin.includes("rpc('payment-ready',{},8000)"));
 });
 await test('falha de PIX preserva mesmo tópico com retry',()=>{
   assert(worker.includes('checkoutPaymentErrorPayload'));
   assert(worker.includes("pm:checkout:retry:"));
   assert(worker.includes("new Set(['CREATING','PENDING','PAYMENT_ERROR'])"));
   assert(worker.includes('O tópico foi mantido'));
 });
 await test('backend grava PAYMENT_ERROR inclusive sem credencial central',()=>{
   const create=partners.slice(partners.indexOf("if(op==='create-payment')"),partners.indexOf("if(op==='cancel-payment')"));
   assert(create.includes("status:'CREATING'"));
   assert(create.includes("if(!evopay.configured()) throw new Error"));
   assert(create.includes("status:'PAYMENT_ERROR'"));
   assert(create.indexOf("status:'CREATING'") < create.indexOf("if(!evopay.configured())"));
 });
 await test('um checkout e um Manager por usuário permanecem protegidos',()=>{
   assert(worker.includes('checkoutLocks.has(lockKey)'));
   assert(worker.includes('activeCheckoutFor(i.user.id,i.guildId)'));
   assert(partners.includes('Cada usuário pode ter apenas 1 Manager parceiro'));
   assert(event.includes('Cada usuário pode ter apenas **1 Manager parceiro**'));
 });
 await test('bridge REST continua usando prioridade e backoff em vez de bypass',()=>{
   assert(proxy.includes('/\\/channels\\/[^/]+\\/threads'));
   assert(proxy.includes('retry_after')||proxy.includes('Retry-After')||proxy.includes('blockedUntil'));
 });
 await test('template filho foi atualizado para 18.9.71',()=>{
   const zip=path.join(ROOT,'source','ZenyxPro.zip');
   assert(fs.existsSync(zip));
   const childPkg=JSON.parse(cp.execFileSync('unzip',['-p',zip,'package.json'],{encoding:'utf8'}));
   assert.equal(childPkg.version,'18.9.71');
   const router=cp.execFileSync('unzip',['-p',zip,'src/discord/router.ts'],{encoding:'utf8'});
   assert(router.includes('/^admin:stock:(?:add|ghost):/'));
   assert(router.includes('Estoque salvo; sincronização visual parcial ficou pendente.'));
   assert(router.includes('await i.reply({ content: `✅ ${added} unidade(s) adicionada(s) ao estoque.'));
 });
 await test('template filho compilado contém correção de estoque',()=>{
   const zip=path.join(ROOT,'source','ZenyxPro.zip');
   const dist=cp.execFileSync('unzip',['-p',zip,'dist/discord/router.js'],{encoding:'utf8'});
   assert(dist.includes('Estoque salvo; sincronização visual parcial ficou pendente.'));
   assert(dist.includes('admin:stock:(?:add|ghost):'));
 });
 await test('store e pricing atuais continuam presentes',()=>{
   assert(store.includes('planPricing.minimumPrice'));
   assert(store.includes('CURRENT_VERSION'));
 });
 await test('build do Manager marcado R18.9.71',()=>{
   assert.equal(pkg.version,'18.9.71'); assert.equal(pkg.zenyxBuild,'R18.9.71'); assert(pkg.scripts['test:r18.9.71']);
 });
 console.log(`\nR18.9.71: ${ok}/${ok+fail} testes passaram.`); if(fail)process.exit(1);
})();
