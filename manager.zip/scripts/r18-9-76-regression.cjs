'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');

const root=path.join(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
let passed=0;
const test=(name,fn)=>{fn(); passed++; console.log(`✅ ${name}`);};

test('versão Manager 18.9.76',()=>assert.equal(require('../package.json').version,'18.9.76'));

test('feed corrige Anual/30d para Mensal',()=>{
  const feed=require('../Lib/salesFeed');
  assert.equal(feed.normalizedPlan({plan:'Anual',days:30}),'Mensal');
  assert.equal(feed.normalizedPlan({plan:'Mensal',days:365}),'Anual');
  assert.equal(feed.normalizedPlan({plan:'Plano VIP',days:30}),'Plano VIP');
});

test('sessão legada Anual/30d é canonizada para Mensal',()=>{
  const ps=require('../Lib/purchaseSessions');
  const out=ps.canonicalize({plano:'Anual',planId:'anual',baseDays:30,dias:30,quantia:1});
  assert.equal(out.plano,'Mensal');
  assert.equal(out.planId,'mensal');
  assert.equal(out.dias,30);
});

test('embeds/DM de compra usam sessão canonizada',()=>{
  const purchase=require('../Lib/planPurchase');
  const embed=purchase.purchaseApprovedEmbed({session:{plano:'Anual',planId:'anual',baseDays:30,dias:30,quantia:1},amount:6,provider:'PIX'}).toJSON();
  const assinatura=embed.fields.find(x=>x.name==='Assinatura')?.value||'';
  assert.match(assinatura,/Mensal/);
  assert.doesNotMatch(assinatura,/Anual/);
});

test('toggle IMAP do Manager original é isolado do verificador global',()=>{
  const imap=require('../Lib/nubankImap');
  const base={enabled:true,lastTestOk:true,host:'imap.gmail.com',user:'conta@gmail.com',pass:'senhaapp',allowedFrom:['inter.co'],pixKey:'chave'};
  assert.equal(imap.paymentReady({...base,managerCheckoutEnabled:false}),true,'watcher/global deve continuar pronto');
  assert.equal(imap.managerPaymentReady({...base,managerCheckoutEnabled:false}),false,'checkout original deve ocultar IMAP');
  assert.equal(imap.managerPaymentReady({...base,managerCheckoutEnabled:true}),true);
});

test('checkout e renovação respeitam toggle IMAP apenas do Manager original',()=>{
  const cart=read('Eventos/manager/cart.js');
  const renewal=read('Eventos/manager/renewalCenter.js');
  const semi=read('Eventos/manager/cartSemiAuto.js');
  assert.match(cart,/managerCheckoutEnabled !== false/);
  assert.match(cart,/managerPaymentReady\(imapCfg\)/);
  assert.match(renewal,/managerCheckoutEnabled !== false/);
  assert.match(semi,/managerPaymentReady\(cfg\)/);
});

test('/botconfig expõe controle exclusivo do IMAP original',()=>{
  const src=read('Eventos/config/botconfig.js');
  assert.match(src,/toggleManagerOriginalImap/);
  assert.match(src,/Ocultar no Manager original/);
  assert.match(src,/Exibir no Manager original/);
});

test('provisionamento final usa plano canonizado, evitando feed Anual/30d',()=>{
  const src=read('Eventos/manager/enviarbot.js');
  assert.match(src,/purchaseSessions\.canonicalize\(rawSession\)/);
  assert.match(src,/session\.plano/);
  assert.match(src,/session\.dias/);
});

test('bot filho sai de guild não autorizada e avisa proprietário',()=>{
  const src=read('child_src/src/index.ts');
  assert.match(src,/Events\.GuildCreate/);
  assert.match(src,/enforceConfiguredGuildOnly/);
  assert.match(src,/owner\.send/);
  assert.match(src,/guild\.leave\(\)/);
  assert.match(src,/attempt >= 5/);
});

test('feed de cadastro de Manager parceiro é configurável e sem token',()=>{
  const panel=read('Lib/partnerManagerPanel.js');
  const handler=read('Eventos/manager/partnerManagers.js');
  assert.match(panel,/registrationFeed/);
  assert.match(panel,/Novo Manager parceiro conectado/);
  assert.match(panel,/Token e credenciais privadas nunca são enviados ao feed/);
  assert.match(handler,/partner:admin:registration-feed-channel/);
  assert.match(handler,/announcePartnerRegistration/);
});

test('template filho está na versão 18.9.76',()=>{
  assert.equal(require('../child_src/package.json').version,'18.9.76');
  const dist=read('child_src/dist/index.js');
  assert.match(dist,/Servidor não autorizado removido/);
});

console.log(`\nR18.9.76: ${passed}/${passed} verificações passaram.`);
