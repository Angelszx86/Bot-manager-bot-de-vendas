const path=require('path');
const calls=[];
let remote='Automação completa para Discord • vendas, tickets e pagamentos 24/7.';
global.fetch=async (url,init={})=>{
  const u=String(url); const method=String(init.method||'GET').toUpperCase(); calls.push({u,method,body:init.body});
  const body=(obj,status=200)=>({ok:status>=200&&status<300,status,text:async()=>JSON.stringify(obj)});
  if(u.endsWith('/users/@me')) return body({id:'1524352151491444887',bot:true,username:'SASUKE'});
  if(u.endsWith('/applications/@me')&&method==='GET') return body({id:'1524352151491444887',description:remote});
  if(u.endsWith('/applications/@me')&&method==='PATCH') { const parsed=JSON.parse(init.body); remote=parsed.description; return body({id:'1524352151491444887',description:remote}); }
  if(u.includes('/emojis')) throw new Error('R18.9.19 não deve depender de endpoint de emoji para a Bio');
  return body({message:'unexpected'},404);
};
(async()=>{
  const mod=require(path.resolve(__dirname,'../Lib/brandEnforcer.js'));
  const result=await mod.enforceOne({id:'sh_test',token:'fake-child-token'},'1485373239436906758');
  if(!result.ok||!result.changed) throw new Error('enforceOne não atualizou child');
  if(!remote.includes('1546213417180733542')||!remote.includes('1546213212934906007')) throw new Error('Bio não usa os emojis do Manager');
  if(!remote.includes('https://discord.gg/V2v8JnwdgR')) throw new Error('Convite incorreto');
  if(calls.some(c=>c.u.includes('/emojis'))) throw new Error('Bio ainda depende de Application Emoji do child');
  console.log('R18.9.19 brand enforcer mock: OK');
})().catch(e=>{console.error(e);process.exit(1)});
