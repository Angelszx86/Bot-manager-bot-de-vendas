const fs=require('fs'),path=require('path'),assert=require('assert'),cp=require('child_process');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8'),must=(v,m)=>assert.ok(v,m);
const pkg=require(path.join(root,'package.json')); must(pkg.version==='18.9.39','manager version mismatch'); must(String(pkg.zenyxBuild).includes('r18.9.39'),'manager build mismatch');
must(read('index.js').includes('ZENYX MANAGER R18.9.39'),'boot banner mismatch');
const bc=read('Eventos/config/botconfig.js'); for(const x of ['vyvenceConfig','magnusConfig','externalPix.testConnection','externalGatewayModal']) must(bc.includes(x),`botconfig missing ${x}`);
const cart=read('Eventos/manager/cart.js'); for(const x of ["paymentId('vyv'","paymentId('mag'",'externalPix.configured("vyvence")','externalPix.configured("magnus")']) must(cart.includes(x),`checkout missing ${x}`);
const ext=read('Eventos/manager/cartExternalPix.js'); must(ext.includes('Pagamento confirmado • ativando plano'),'external loading step missing'); must(ext.includes('linkingReadyEmbed'),'external linking screen missing');
must(read('Eventos/manager/cartAutomatic.js').includes('purchase-loading-panel'),'Mercado Pago loading step missing'); must(read('Eventos/manager/cartEvoPay.js').includes('evopay-loading-edit'),'EvoPay loading step missing');
must(read('Lib/managerEmojis.js').includes("file: 'zenyx_wallet.png'"),'wallet custom emoji asset not fixed'); must(fs.existsSync(path.join(root,'assets/emojis/zenyx_wallet.png')),'wallet emoji file missing');
const template=path.join(root,'source','ZenyxPro.zip'); must(fs.existsSync(template),'embedded child missing');
if (fs.existsSync(template)) { const child=JSON.parse(cp.execFileSync('unzip',['-p',template,'package.json'],{encoding:'utf8'})); must(child.version==='18.9.39','embedded child version mismatch'); }
console.log('[R18.9.39 MANAGER] regression OK');
