'use strict';
const fs=require('fs'),path=require('path'); const root=path.join(__dirname,'..');
const w=fs.readFileSync(path.join(root,'source','partner_manager_worker.js'),'utf8');
const m=fs.readFileSync(path.join(root,'Lib','partnerManagers.js'),'utf8');
const s=fs.readFileSync(path.join(root,'Lib','partnerManagerStore.js'),'utf8');
let n=0; function ok(v,msg){if(!v)throw new Error(msg);console.log('OK',msg);n++;}
ok(w.includes('ChannelType.PrivateThread')&&w.includes('thread.members.add'),'Compra usa tópico privado e adiciona participantes');
ok(w.includes('pm:config:staff-users')&&w.includes('staffUserIds'),'ADMs configuráveis nos tópicos');
ok(w.includes('pmc:apps')&&w.includes('customerCentralPayload'),'Central do cliente presente');
ok(m.includes("String(row.data?.owner||'')!==String(args.requestUserId||'')"),'Ações do cliente isoladas por proprietário');
ok(w.includes('pm:config:plan-sales-channel')&&w.includes('sendApprovedSale'),'Canal de vendas aprovadas presente');
ok(w.includes('pm:config:customer-panel-channel')&&w.includes('publishCustomerCentral'),'Canal da central configurável');
ok(w.includes("days<30||days>90||Math.abs(price-6)>0.001")&&m.includes('plan.days<30'),'Plano 30–90 dias / R$6 validado em duas camadas');
ok(s.includes('price: 6')&&s.includes('CURRENT_VERSION = 4'),'Persistência migra planos antigos para regra nova');
ok(m.includes('Recuperando automaticamente')&&m.includes('runtime.start(appId'),'Auto-recovery de runtime desejado online');
ok(!w.includes('content:'),'Worker Components V2 não envia legacy content');
console.log(`R18.9.62 ${n}/${n}`);
