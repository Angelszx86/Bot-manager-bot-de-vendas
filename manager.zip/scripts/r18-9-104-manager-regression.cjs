const fs=require('fs'); const assert=require('assert');
const s=fs.readFileSync('index.js','utf8');
assert(s.includes("HIDENCLOUD_START_CONCURRENCY = '1'"));
assert(s.includes("HIDENCLOUD_CHILD_MAX_OLD_SPACE_MB = '192'"));
assert(s.includes('Options.cacheWithLimits'));
assert(s.includes('ZENYX_RUNTIME_GUARD_VERBOSE'));
assert(!s.includes('if (checked || restarted || failed) console.log(`[RUNTIME GUARD:'));
console.log('R18.9.104 manager regression: OK');
