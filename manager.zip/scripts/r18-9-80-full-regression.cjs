'use strict';
const fs=require('fs');
const path=require('path');
const assert=require('assert');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const exists=p=>fs.existsSync(path.join(root,p));
const index=read('index.js');
const pkg=JSON.parse(read('package.json'));
const checks=[];
function check(name,fn){fn(); checks.push(name); console.log(`✅ ${name}`)}
check('build identificado como R18.9.80 FULL',()=>{
  assert.equal(pkg.version,'18.9.80');
  assert.equal(pkg.zenyxBuild,'R18.9.80');
  assert.match(index,/R18\.9\.80 FULL/);
});
check('lock/handover R18.9.78/79 removido do boot',()=>{
  assert.doesNotMatch(index,/managerInstanceLock|acquireManagerInstanceLock|Aguardando handover|Encerrando rapidamente a instância anterior/);
  assert.equal(exists('Lib/managerInstanceLock.js'),false);
});
check('estrutura completa do Manager presente',()=>{
  for(const p of ['Lib','Eventos','Comandos','Functions','handler','source','child','child_src','assets','databases','node_modules','index.js','package.json']) assert.ok(exists(p),`ausente: ${p}`);
});
check('config e bancos atuais presentes',()=>{
  for(const p of ['config.json','databases/index.js']) assert.ok(exists(p),`ausente: ${p}`);
});
check('credenciais .env não são sobrescritas pelo ZIP',()=>{
  assert.equal(exists('.env'),false);
  assert.ok(exists('.env.example'));
});
check('correções recentes mantidas',()=>{
  for(const p of ['Lib/partnerManagers.js','Lib/partnerManagerPanel.js','Lib/botconfigPages.js','Lib/externalPixGateway.js','Lib/nubankImap.js','Lib/planPricing.js']) assert.ok(exists(p),`ausente: ${p}`);
});
console.log(`\nR18.9.80 FULL: ${checks.length}/${checks.length} verificações aprovadas.`);
