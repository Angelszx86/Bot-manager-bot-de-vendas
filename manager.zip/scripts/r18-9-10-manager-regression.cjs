const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const readZip = (zip, file) => cp.execFileSync('unzip', ['-p', zip, file], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 });

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
ok(pkg.version === '18.9.10', 'manager version must be 18.9.10');
ok(pkg.zenyxBuild === '2026-09-09-r18.9.10-admin-v2-ticket-panels', 'manager build mismatch');

const zip = path.join(root, 'source', 'ZenyxPro.zip');
ok(fs.existsSync(zip), 'embedded ZenyxPro.zip missing');
const childPkg = JSON.parse(readZip(zip, 'package.json'));
ok(childPkg.version === '18.9.10', 'embedded child version must be 18.9.10');
ok(childPkg.zenyxBuild === '2026-09-09-r18.9.10-admin-v2-ticket-panels', 'embedded child build mismatch');
const router = readZip(zip, 'src/discord/router.ts');
const views = readZip(zip, 'src/discord/views.ts');
const tickets = readZip(zip, 'src/services/tickets.ts');
const validator = readZip(zip, 'src/discord/payload-validator.ts');
ok(router.includes('Painel do Atendente') && router.includes('Painel do Usuário'), 'embedded child missing private ticket panels');
ok(router.includes('Você não possui o cargo ou a permissão de atendimento necessária'), 'embedded child missing staff permission guard');
ok(router.includes('const { content: _content, embeds: _embeds, stickers: _stickers, poll: _poll, ...safe } = payload;'), 'embedded child missing V2 payload normalization');
ok(tickets.includes('ticket:staff-panel:${ticket.id}') && tickets.includes('ticket:user-panel:${ticket.id}'), 'embedded child missing modern ticket controls');
ok(validator.includes('Object.prototype.hasOwnProperty.call(json, field)'), 'embedded child validator does not reject empty legacy V2 fields');
ok(!/publicTicketPanelEdit[\s\S]{0,400}embeds:\s*\[\]/.test(views), 'embedded child still sends embeds: [] on V2 ticket edit');

for (const id of ['sh_38e93ea72f96', 'sh_f2b3cd2f2777']) {
  const runtimePkg = JSON.parse(fs.readFileSync(path.join(root, 'source', 'runtime', id, 'package.json'), 'utf8'));
  ok(runtimePkg.version === '18.9.10', `bundled runtime ${id} was not upgraded`);
  ok(runtimePkg.zenyxBuild === '2026-09-09-r18.9.10-admin-v2-ticket-panels', `bundled runtime ${id} build mismatch`);
  const runtimeRouter = fs.readFileSync(path.join(root, 'source', 'runtime', id, 'dist', 'discord', 'router.js'), 'utf8');
  ok(runtimeRouter.includes('Painel do Atendente') && runtimeRouter.includes('Painel do Usuário'), `bundled runtime ${id} compiled code is stale`);
}

console.log('R18_9_10_MANAGER_REGRESSION_OK');
