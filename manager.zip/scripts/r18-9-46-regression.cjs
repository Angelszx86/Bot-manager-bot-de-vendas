const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
function ok(v,m){if(!v)throw new Error(m);}
const index=read('index.js');
const anti=read('Functions/antiRaidHandler.js');
const cart=read('Eventos/manager/cart.js');
ok(index.includes('attempt <= 3'),'restore de runtimes não possui retry limitado');
ok(index.includes('attempt * 1500'),'restore sem backoff');
ok(index.includes("'recoverable','removed','suspended','revoked','expired'"),'estados intencionalmente offline não estão protegidos');
ok(anti.includes('PermissionFlagsBits.ViewAuditLog'),'anti-raid sem preflight de auditoria');
ok(anti.includes('botMember.bannable'),'anti-raid sem checagem de hierarquia');
ok(anti.includes("Number(error?.code) === 50013"),'anti-raid não trata Missing Permissions');
ok(anti.includes('5 * 60_000'),'anti-raid sem throttle de logs');
ok(cart.includes('deferReply({ flags: MessageFlags.Ephemeral })'),'ACK antecipado do checkout R18.9.45 foi perdido');
ok(cart.includes('Abrir tópico da compra'),'botão para tópico da compra foi perdido');
console.log('R18.9.46 manager regression: OK');
