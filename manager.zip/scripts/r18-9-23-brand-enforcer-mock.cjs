const path=require('path');
const fs=require('fs');
let remoteDesc='old';
let emojis=[];
let next=900000000000000001n;
const calls=[];
global.fetch=async (url,init={})=>{
  const u=String(url); const method=String(init.method||'GET').toUpperCase(); calls.push({u,method,body:init.body});
  const body=(obj,status=200)=>({ok:status>=200&&status<300,status,text:async()=>JSON.stringify(obj)});
  if(u.endsWith('/users/@me')) return body({id:'1524352151491444887',bot:true,username:'SASUKE'});
  if(u.endsWith('/applications/@me')&&method==='GET') return body({id:'1524352151491444887',description:remoteDesc});
  if(u.endsWith('/applications/@me')&&method==='PATCH'){remoteDesc=JSON.parse(init.body).description;return body({id:'1524352151491444887',description:remoteDesc});}
  if(u.endsWith('/applications/1524352151491444887/emojis')&&method==='GET') return body({items:emojis});
  if(u.endsWith('/applications/1524352151491444887/emojis')&&method==='POST'){
    const j=JSON.parse(init.body); const e={id:String(next++),name:j.name}; emojis.push(e); return body(e,201);
  }
  const del=u.match(/\/applications\/1524352151491444887\/emojis\/(\d+)$/);
  if(del&&method==='DELETE'){emojis=emojis.filter(e=>e.id!==del[1]);return body({},204);}
  return body({message:'unexpected '+method+' '+u},404);
};
(async()=>{
  const state=path.resolve(__dirname,'../databases/brand_assets.json');
  const backup=fs.existsSync(state)?fs.readFileSync(state):null;
  try{
    if(fs.existsSync(state))fs.unlinkSync(state);
    const mod=require(path.resolve(__dirname,'../Lib/brandEnforcer.js'));
    const r=await mod.enforceOne({id:'sh_test',token:'fake'},'1485373239436906758');
    if(!r.ok)throw new Error('enforceOne failed');
    if(!emojis.find(e=>e.name==='zenyx_brand_robot_v23'))throw new Error('robot v23 missing');
    if(!emojis.find(e=>e.name==='zenyx_brand_zy_v23'))throw new Error('ZY v23 missing');
    if(remoteDesc.includes('1546213417180733542')||remoteDesc.includes('1546213212934906007'))throw new Error('old canonical IDs returned');
    if(!remoteDesc.includes('𝙕𝙀𝙉𝙔𝙓 𝘼𝙋𝙋𝙇𝙄𝘾𝘼𝙏𝙄𝙊𝙉𝙎'))throw new Error('title missing');
    if(!remoteDesc.includes('Powered by Zenyx Applications'))throw new Error('powered text missing');
    if(!remoteDesc.includes('https://discord.gg/V2v8JnwdgR'))throw new Error('invite missing');
    console.log('R18.9.23 brand enforcer mock: OK');
  } finally { if(backup)fs.writeFileSync(state,backup); else if(fs.existsSync(state))fs.unlinkSync(state); }
})().catch(e=>{console.error(e);process.exit(1)});
