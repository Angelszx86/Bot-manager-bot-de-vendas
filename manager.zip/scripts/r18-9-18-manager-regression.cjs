'use strict';
const fs=require('fs');
const path=require('path');
const JSZip=require('jszip');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const must=(c,m)=>{if(!c)throw new Error(m)};
(async()=>{
  const pkg=JSON.parse(read('package.json'));
  must(/^18\.9\.(?:18|19|20|21|22|23)$/.test(pkg.version),'versão manager incorreta');
  const childSvc=read('child_src/src/services/tickets.ts');
  const childDb=read('child_src/src/core/json-db.ts');
  const childRouter=read('child_src/src/discord/router.ts');
  const childDistSvc=read('child_src/dist/services/tickets.js');
  must(childSvc.includes('resolvePanel(id: string, guildId?: string, relatedOptionId?: string, relatedFieldId?: string)'), 'resolver autocorretivo ausente');
  must(childSvc.includes('getPanelForOption'), 'resolver por opção ausente');
  must(childDb.includes('normalizedPanels'), 'reindexação de ticketPanels ausente');
  must(childDb.includes('panelAliases'), 'migração de referências de painel ausente');
  must(childRouter.includes('getPanelForOption(panelId, optionId'), 'roteador público não usa resolução por opção');
  must(childRouter.includes('option-category-set'), 'categoria de opção ausente');
  must(childDistSvc.includes('resolvePanel(id, guildId, relatedOptionId, relatedFieldId)'), 'dist de tickets não atualizado');
  const z=await JSZip.loadAsync(fs.readFileSync(path.join(root,'source','ZenyxPro.zip')));
  const zs=await z.file('dist/services/tickets.js').async('string');
  const zr=await z.file('dist/discord/router.js').async('string');
  const zd=await z.file('dist/core/json-db.js').async('string');
  must(zs.includes('getPanelForOption'),'template sem resolver de opção');
  must(zr.includes('getPanelForOption'),'template sem roteamento robusto');
  must(zd.includes('normalizedPanels'),'template sem normalização de painel');
  for(const name of fs.readdirSync(path.join(root,'source','runtime')).filter(x=>x.startsWith('sh_'))){
    const svc=read(path.join('source','runtime',name,'dist','services','tickets.js'));
    const router=read(path.join('source','runtime',name,'dist','discord','router.js'));
    const db=read(path.join('source','runtime',name,'dist','core','json-db.js'));
    must(svc.includes('getPanelForOption'),`runtime ${name} sem resolver`);
    must(router.includes('getPanelForOption'),`runtime ${name} sem roteamento`);
    must(db.includes('normalizedPanels'),`runtime ${name} sem normalização`);
  }
  console.log('R18.9.18 manager regression: OK');
})().catch(e=>{console.error(e);process.exit(1)});
