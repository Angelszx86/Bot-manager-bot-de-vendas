const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
function must(v, m) { if (!v) throw new Error(m); }

const renew = read('Eventos/manager/renewalCenter.js');
const imap = read('Lib/nubankImap.js');
const cart = read('Eventos/manager/cart.js');
const semi = read('Eventos/manager/cartSemiAuto.js');
const sessions = read('Lib/purchaseSessions.js');
const botconfig = read('Eventos/config/botconfig.js');
const pages = read('Lib/botconfigPages.js');
const feed = read('Lib/salesFeed.js');
const giveaway = read('child_src/src/services/giveaways.ts');
const router = read('child_src/src/discord/router.ts');
const index = read('index.js');

must(index.includes('[ZENYX R18.9.49]'), 'marcador R18.9.49 ausente');
must(renew.includes("renew:pay:imap") && renew.includes("renew:imap:name"), 'IMAP PIX ausente na renovação');
must(renew.includes('finalizeImapRenewal'), 'finalizador IMAP de renovação ausente');
must(renew.includes("renew:close:confirm") && renew.includes("status: 'cancelled'"), 'fechamento seguro da renovação ausente');
must(renew.includes('const memberReady = thread.members.add') && renew.includes('Promise.resolve(memberReady)'), 'hidratação paralela do tópico ausente');
must(renew.includes('Aprovar manualmente') && renew.includes("['semi', 'imap']"), 'aprovação manual do IMAP ausente');

must(imap.includes('containsExactPayerName') && imap.includes('candidateMatchesMessageTime'), 'match nome/horário IMAP ausente');
must(imap.includes('authenticationLooksValid'), 'checagem de autenticação de e-mail ausente');
must(imap.includes("client.search({ since })"), 'lookback IMAP de mensagens recentes ausente');
must(!imap.includes("client.search({ seen: false })"), 'IMAP ainda depende apenas de e-mails não lidos');
must(cart.includes("paymentId('imap', session)") && sessions.includes('auto|semi|imap|evo|vyv|mag|cancel'), 'IMAP ausente do checkout principal');
must(semi.includes("zenyximap:name") && semi.includes('payerFullName') && semi.includes('imapCheckPayment'), 'nome/verificação IMAP ausentes no checkout');

must(pages.includes("renewalFeedConfig") && pages.includes('Feed de Renovações'), 'atalho do feed de renovações ausente');
must(botconfig.includes('renewalFeedChannel') && botconfig.includes('renewalFeedPreview'), 'configuração do feed de renovações ausente');
must(feed.includes("type==='renewal'") && feed.includes('renewalChannelId'), 'publicação de renovação ausente no salesFeed');

must(giveaway.includes('already: boolean') && giveaway.includes('async refresh(id: string)'), 'serviço de sorteio sem dedupe/refresh');
must(giveaway.includes('new Set(giveaway.entries.map(String))'), 'normalização de participantes ausente');
must(router.includes('já está participando') && router.includes('this.giveaways.refresh'), 'router não trata segundo clique/refresh público');

console.log('R18.9.49 regression: OK');
