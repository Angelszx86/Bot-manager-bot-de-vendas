const assert=require('assert');
const fs=require('fs');
const path=require('path');
const http=require('http');
const Module=require('module');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}

(async()=>{
  const idx=read('index.js');
  const proxy=read('Lib/discordRestProxy.js');
  const managers=read('Lib/partnerManagers.js');
  const runtime=read('source/runtime.js');
  const panelText=read('Lib/partnerManagerPanel.js');
  const eventText=read('Eventos/manager/partnerManagers.js');

  await test('Manager principal não passa ACK pelo bridge local',()=>{
    assert(idx.includes('PARTNER_REST_API_BASE'));
    assert(idx.includes('PARTNER_MANAGER_REST_API_BASE'));
    assert(idx.includes('...(EXTERNAL_REST_API_BASE ? { api: EXTERNAL_REST_API_BASE } : {})'));
    assert(!idx.includes('if (REST_API_BASE) process.env.DISCORD_REST_API_BASE = REST_API_BASE'));
  });

  await test('Managers parceiros e bots filhos continuam limitados pelo bridge',()=>{
    assert(managers.includes("process.env.PARTNER_MANAGER_REST_API_BASE || process.env.DISCORD_REST_API_BASE"));
    assert(managers.includes("DISCORD_REST_API_BASE:String(process.env.PARTNER_MANAGER_REST_API_BASE||process.env.DISCORD_REST_API_BASE||'')"));
    assert(runtime.includes("process.env.PARTNER_MANAGER_REST_API_BASE||process.env.DISCORD_REST_API_BASE"));
    assert(runtime.includes('env.DISCORD_REST_API_BASE=childRestBase'));
  });

  await test('Callbacks de interação ignoram fila/backoff local',()=>{
    assert(proxy.includes('if(priority===0)'));
    assert(proxy.includes('if(job.priority>1'));
    assert(proxy.includes('ACK de interação tem janela curta'));
  });

  await test('Bridge encaminha callback mesmo com backoff de background',async()=>{
    const oldFetch=global.fetch;
    const oldPort=process.env.ZENYX_LOCAL_REST_PROXY_PORT;
    const oldRps=process.env.ZENYX_HOST_REST_RPS;
    const oldEnabled=process.env.ZENYX_LOCAL_REST_PROXY;
    process.env.ZENYX_LOCAL_REST_PROXY='true';
    process.env.ZENYX_LOCAL_REST_PROXY_PORT=String(25000+Math.floor(Math.random()*1000));
    process.env.ZENYX_HOST_REST_RPS='30';
    let calls=[];
    global.fetch=async(url,opts)=>{
      calls.push(String(url));
      if(String(url).includes('/applications/123/commands')){
        return new Response(JSON.stringify({message:'limited',retry_after:60,global:true}),{status:429,headers:{'content-type':'application/json','retry-after':'60'}});
      }
      return new Response(JSON.stringify({ok:true}),{status:200,headers:{'content-type':'application/json'}});
    };
    const modPath=path.join(ROOT,'Lib/discordRestProxy.js');
    delete require.cache[modPath];
    const bridge=require(modPath).startDiscordRestProxy();
    await new Promise(r=>setTimeout(r,60));
    const req=(pathname)=>new Promise((resolve,reject)=>{
      const u=new URL(bridge.apiBase+pathname);
      const q=http.request({host:u.hostname,port:u.port,path:u.pathname,method:'POST',headers:{authorization:'Bot TEST','content-type':'application/json'}},res=>{let b='';res.on('data',d=>b+=d);res.on('end',()=>resolve({status:res.statusCode,body:b}));});
      q.on('error',reject);q.end('{}');
    });
    const bg=await req('/v10/applications/123/commands');
    assert.equal(bg.status,429);
    const t=Date.now();
    const ack=await req('/v10/interactions/1/token/callback');
    assert.equal(ack.status,200);
    assert(Date.now()-t<1200,'callback ficou preso no backoff local');
    bridge.server.close();
    global.fetch=oldFetch;
    if(oldPort===undefined)delete process.env.ZENYX_LOCAL_REST_PROXY_PORT;else process.env.ZENYX_LOCAL_REST_PROXY_PORT=oldPort;
    if(oldRps===undefined)delete process.env.ZENYX_HOST_REST_RPS;else process.env.ZENYX_HOST_REST_RPS=oldRps;
    if(oldEnabled===undefined)delete process.env.ZENYX_LOCAL_REST_PROXY;else process.env.ZENYX_LOCAL_REST_PROXY=oldEnabled;
  });

  await test('Painel Partner ficou compacto e CTAs vieram antes do banner',()=>{
    assert(panelText.includes("'partner:register','Cadastrar meu Manager'"));
    assert(panelText.includes("'partner:manage','Abrir meus Managers'"));
    assert(panelText.includes('addMediaGalleryComponents'));
    assert(panelText.includes('Banner opcional sempre fica ABAIXO das opções principais'));
    const p=panelText.indexOf("'partner:register','Cadastrar meu Manager'");
    const b=panelText.indexOf('addMediaGalleryComponents',p);
    const c=panelText.indexOf('### Central completa',b);
    assert(p>0&&b>p&&c>b,'ordem CTAs -> banner -> resumo incorreta');
  });

  await test('Banner público é configurável e persistente sem tocar config.json',()=>{
    for(const needle of ['partner-manager-public-panel.json','setPublicBanner','rememberPublication','refreshPublicPanels'])assert(panelText.includes(needle),needle);
    for(const needle of ['partner:admin:banner','partner:admin:banner:modal','panel.setPublicBanner','panel.refreshPublicPanels'])assert(eventText.includes(needle),needle);
    assert(!panelText.includes("require('../config.json')"));
  });

  await test('Payload público Components V2 é válido com e sem banner',()=>{
    const originalLoad=Module._load;
    const fakePartners={list:()=>[],withdrawals:()=>[],metrics:()=>({total:0,online:0}),readLogs:()=>'',snapshot:x=>x};
    Module._load=function(req,parent){
      if(parent?.filename?.endsWith(path.join('Lib','partnerManagerPanel.js'))&&req==='./partnerManagers')return fakePartners;
      if(parent?.filename?.endsWith(path.join('Lib','partnerManagerPanel.js'))&&req==='./managerEmojis')return {readCache:()=>({})};
      return originalLoad.apply(this,arguments);
    };
    const file=path.join(ROOT,'databases','partner-manager-public-panel.json');
    let backup=null,exists=fs.existsSync(file); if(exists)backup=fs.readFileSync(file);
    try{
      const panelPath=path.join(ROOT,'Lib','partnerManagerPanel.js'); delete require.cache[panelPath];
      const panel=require(panelPath);
      panel.setPublicBanner('');
      let json=panel.publicPayload('123').components[0].toJSON();
      assert(json.components.length>=3);
      panel.setPublicBanner('https://cdn.example.com/banner.png');
      json=panel.publicPayload('123').components[0].toJSON();
      const raw=JSON.stringify(json);
      assert(raw.includes('https://cdn.example.com/banner.png'));
      assert(raw.includes('Cadastrar meu Manager'));
      assert(raw.includes('Abrir meus Managers'));
    } finally {
      Module._load=originalLoad;
      if(exists)fs.writeFileSync(file,backup);else try{fs.rmSync(file,{force:true});}catch{}
    }
  });

  await test('Versão do pacote atualizada',()=>{
    const pkg=JSON.parse(read('package.json'));
    assert.equal(pkg.version,'18.9.65');
    assert.equal(pkg.zenyxBuild,'R18.9.65');
    assert(pkg.scripts['test:r18.9.65']);
  });

  console.log(`\nR18.9.65: ${ok}/${ok+fail} testes passaram.`);
  if(fail)process.exit(1);
})();
