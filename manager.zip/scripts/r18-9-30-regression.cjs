const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const must = (value, message) => { if (!value) throw new Error(message); };

const pkg = JSON.parse(read('package.json'));
const child = JSON.parse(read('child_src/package.json'));
const runtime = read('source/runtime.js');
const botconfig = read('Eventos/config/botconfig.js');
const evo = read('Lib/evopay.js');

must(Number(pkg.version.split('.')[2]) >= 30, 'manager version older than R18.9.30');
must(Number(child.version.split('.')[2]) >= 30, 'child version older than R18.9.30');
must(String(pkg.zenyxBuild || '').includes('r18.9.'), 'manager build id missing');
must(child.zenyxBuild === pkg.zenyxBuild, 'manager/child build diverged');
must(runtime.includes('snapshotPersistentRuntime') && runtime.includes('restorePersistentRuntime'), 'proteção de estado persistente ausente');
must(runtime.includes('database/storage/uploads') || runtime.includes('database/storage/uploads e mescla configs persistentes'), 'documentação de persistência do runtime ausente');
must(botconfig.includes('evopaySetToken') && botconfig.includes('evopayTest') && botconfig.includes('evopaySetExpiry'), '/botconfig sem configuração EvoPay');
must(evo.includes("https://api.evopay.cash/v1") && evo.includes('axios.post'), 'Manager sem contrato EvoPay');

const zip = path.join(root, 'source', 'ZenyxPro.zip');
must(fs.existsSync(zip), 'template ZenyxPro.zip ausente');
const templatePkg = JSON.parse(cp.execFileSync('unzip', ['-p', zip, 'package.json'], { encoding: 'utf8' }));
must(Number(templatePkg.version.split('.')[2]) >= 30, `template ainda está em ${templatePkg.version}`);
must(templatePkg.zenyxBuild === child.zenyxBuild, 'template build divergiu do child_src');

console.log('R18_9_30_MANAGER_REGRESSION_OK');
