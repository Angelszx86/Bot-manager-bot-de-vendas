const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
function ok(v,m){if(!v)throw new Error(m);}
const imap=read('Lib/nubankImap.js');
const botconfig=read('Eventos/config/botconfig.js');
const index=read('index.js');
ok(imap.includes("raw.replace(/\\s+/g, '')"),'senha de app do Gmail não remove espaços');
ok(imap.includes('AUTHENTICATIONFAILED') || imap.includes('authenticationfailed'),'diagnóstico de autenticação IMAP ausente');
ok(imap.includes('config?.lastTestOk === true'),'checkout ainda aceita IMAP sem conexão validada');
ok(imap.includes("cfg.enabled || cfg.lastTestOk !== true") || imap.includes("!cfg.enabled || cfg.lastTestOk !== true"),'watcher IMAP não exige teste válido');
ok(imap.includes("replace(/^@/, '')"),'remetente em formato @dominio não é normalizado');
ok(botconfig.includes('Login e caixa INBOX validados antes da ativação'),'ativação IMAP não testa conexão primeiro');
ok(botconfig.includes('Último teste falhou') && botconfig.includes('Conexão validada'),'painel não mostra saúde da conexão');
ok(botconfig.includes('Por segurança, o pagamento IMAP foi desativado'),'teste com falha não desativa IMAP');
ok(index.includes('[ZENYX R18.9.50]'),'marcador R18.9.50 ausente');
console.log('R18.9.50 regression: OK');
