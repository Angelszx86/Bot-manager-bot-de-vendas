const assert=require('assert');
const fs=require('fs');
const path=require('path');
const Module=require('module');
const http=require('http');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}

(async()=>{
  const panelText=read('Lib/partnerManagerPanel.js');
  const eventText=read('Eventos/manager/partnerManagers.js');
  const workerText=read('source/partner_manager_worker.js');
  const proxyText=read('Lib/discordRestProxy.js');
  const managersText=read('Lib/partnerManagers.js');
  const botconfig=read('Eventos/config/botconfig.js');
  const pages=read('Lib/botconfigPages.js');

  await test('tópico de checkout recebe conteúdo antes da cobrança',()=>{
    const prep=workerText.indexOf('sendCheckoutPreparing(thread,plan,i.user.id)');
    const pay=workerText.indexOf("rpc('create-payment'",prep);
    assert(prep>0 && pay>prep,'mensagem inicial precisa existir antes da criação da cobrança');
    assert(workerText.includes('starterMessageId'));
    assert(workerText.includes('checkoutMessageId:String(created.starterMessageId||\'\')'));
    assert(workerText.includes('checkout falhou e aviso no tópico também falhou'));
  });

  await test('mensagens urgentes não ficam congeladas pelo backoff local',()=>{
    assert(proxyText.includes('queue.sort((a,b)=>a.priority-b.priority||a.seq-b.seq);'));
    assert(proxyText.includes('Number(next?.priority??9)>3'));
    assert(proxyText.includes('essenciais de checkout')); 
  });

  await test('bridge deixa mensagem do checkout passar mesmo com backoff de background',async()=>{
    const oldFetch=global.fetch;
    const oldPort=process.env.ZENYX_LOCAL_REST_PROXY_PORT;
    const oldRps=process.env.ZENYX_HOST_REST_RPS;
    const oldEnabled=process.env.ZENYX_LOCAL_REST_PROXY;
    process.env.ZENYX_LOCAL_REST_PROXY='true';
    process.env.ZENYX_LOCAL_REST_PROXY_PORT=String(27000+Math.floor(Math.random()*1000));
    process.env.ZENYX_HOST_REST_RPS='30';
    global.fetch=async(url)=>{
      if(String(url).includes('/applications/123/commands')) return new Response(JSON.stringify({message:'limited',retry_after:60,global:true}),{status:429,headers:{'content-type':'application/json','retry-after':'60'}});
      return new Response(JSON.stringify({ok:true}),{status:200,headers:{'content-type':'application/json'}});
    };
    const modPath=path.join(ROOT,'Lib/discordRestProxy.js');delete require.cache[modPath];
    const bridge=require(modPath).startDiscordRestProxy();
    const request=(pathname)=>new Promise((resolve,reject)=>{
      const u=new URL(bridge.apiBase+pathname);
      const q=http.request({host:u.hostname,port:u.port,path:u.pathname,method:'POST',headers:{authorization:'Bot TEST','content-type':'application/json'}},res=>{let b='';res.on('data',d=>b+=d);res.on('end',()=>resolve({status:res.statusCode,body:b}));});
      q.on('error',reject);q.end('{}');
    });
    try{
      await new Promise(r=>setTimeout(r,50));
      const limited=await request('/v10/applications/123/commands');
      assert.equal(limited.status,429);
      assert(bridge.state().blockedUntil>Date.now());
      const t=Date.now();
      const msg=await request('/v10/channels/321/messages');
      assert.equal(msg.status,200);
      assert(Date.now()-t<1200,'mensagem prioritária ficou presa no blockedUntil');
    }finally{
      bridge.server.close();
      global.fetch=oldFetch;
      if(oldPort===undefined)delete process.env.ZENYX_LOCAL_REST_PROXY_PORT;else process.env.ZENYX_LOCAL_REST_PROXY_PORT=oldPort;
      if(oldRps===undefined)delete process.env.ZENYX_HOST_REST_RPS;else process.env.ZENYX_HOST_REST_RPS=oldRps;
      if(oldEnabled===undefined)delete process.env.ZENYX_LOCAL_REST_PROXY;else process.env.ZENYX_LOCAL_REST_PROXY=oldEnabled;
    }
  });

  await test('botão público abre somente o Manager do próprio usuário',()=>{
    assert(panelText.includes("'partner:manage','Abrir meu Manager'"));
    assert(!panelText.includes("'partner:manage','Abrir meus Managers'"));
    const start=eventText.indexOf("if(id==='partner:manage'&&interaction.isButton())");
    const end=eventText.indexOf("if(id==='partner:manage:select'",start);
    const block=eventText.slice(start,end);
    assert(block.includes('ownedManagers(interaction.user.id)'));
    assert(!block.includes('adminPayload'));
  });

  await test('administração global continua exclusiva do dono original',()=>{
    for(const marker of ["partner:admin:publish-channel","partner:admin:title","partner:admin:banner","partner:admin:refresh","partner:admin:withdrawals"]){
      const token=`if(id==='${marker}'`;
      const pos=eventText.indexOf(token); assert(pos>=0,marker);
      const near=eventText.slice(pos,Math.min(eventText.length,pos+500));
      assert(near.includes('requireMainOwner(interaction)'),`${marker} sem gate do dono`);
    }
    assert(botconfig.includes("if (!require('../../Lib/permissions').isOwner(interaction.user.id))"));
    assert(botconfig.includes("customId === 'partnerManagersAdmin'"));
  });

  await test('título público é configurável e persiste junto do banner',()=>{
    for(const n of ['title:', 'setPublicTitle', 'partner:admin:title', 'partner:admin:title:modal']) assert((panelText+eventText).includes(n),n);
    assert(panelText.includes('`# ${settings.title}\\n`'));
  });

  await test('payload público Components V2 aceita título e banner customizados',()=>{
    const originalLoad=Module._load;
    const fakePartners={list:()=>[],withdrawals:()=>[],metrics:()=>({total:0,online:0}),readLogs:()=>'',snapshot:x=>x};
    Module._load=function(req,parent){
      if(parent?.filename?.endsWith(path.join('Lib','partnerManagerPanel.js'))&&req==='./partnerManagers')return fakePartners;
      if(parent?.filename?.endsWith(path.join('Lib','partnerManagerPanel.js'))&&req==='./managerEmojis')return {readCache:()=>({})};
      return originalLoad.apply(this,arguments);
    };
    const dbDir=path.join(ROOT,'databases');fs.mkdirSync(dbDir,{recursive:true});
    const file=path.join(dbDir,'partner-manager-public-panel.json');
    let backup=null,exists=fs.existsSync(file);if(exists)backup=fs.readFileSync(file);
    try{
      const pp=path.join(ROOT,'Lib','partnerManagerPanel.js');delete require.cache[pp];
      const panel=require(pp);
      panel.setPublicTitle('Minha Host Premium');
      panel.setPublicBanner('https://cdn.example.com/painel.png');
      const raw=JSON.stringify(panel.publicPayload('123').components[0].toJSON());
      assert(raw.includes('Minha Host Premium'));
      assert(raw.includes('https://cdn.example.com/painel.png'));
      assert(raw.includes('Abrir meu Manager'));
      assert(!raw.includes('EvoPay'));
      const settings=panel.readPublicSettings();
      assert.equal(settings.title,'Minha Host Premium');
    }finally{
      Module._load=originalLoad;
      if(exists)fs.writeFileSync(file,backup);else try{fs.rmSync(file,{force:true});}catch{}
    }
  });

  await test('nome comercial do gateway não aparece nas telas desta revisão',()=>{
    for(const [name,text] of Object.entries({panelText,workerText,managersText,botconfig,pages})){
      assert(!text.includes('EvoPay'),`${name} ainda contém nome comercial visível`);
    }
    assert(workerText.includes('gateway central'));
    assert(panelText.includes('gateway central'));
  });

  await test('versão e script de regressão atualizados',()=>{
    const pkg=JSON.parse(read('package.json'));
    assert.equal(pkg.version,'18.9.66');
    assert.equal(pkg.zenyxBuild,'R18.9.66');
    assert(pkg.scripts['test:r18.9.66']);
  });

  console.log(`\nR18.9.66: ${ok}/${ok+fail} testes passaram.`);
  if(fail)process.exit(1);
})();
