const fs=require('fs'); const path=require('path'); const cp=require('child_process');
const root=path.resolve(__dirname,'..');
function read(p){return fs.readFileSync(path.join(root,p),'utf8')}
function must(v,m){if(!v)throw new Error(m)}
const pkg=JSON.parse(read('package.json')); const child=JSON.parse(read('child_src/package.json'));
must(pkg.version==='18.9.28','manager version'); must(child.version==='18.9.28','child version');
const router=read('child_src/src/discord/router.ts');
must(!router.includes('Compra iniciada por <@${i.user.id}>'),'public duplicate notice');
must(router.includes('publishSaleAnnouncement(order)'),'sale publisher');
must(router.includes('saleAnnouncementMessageId'),'sale idempotency');
const views=read('child_src/src/discord/views.ts'); must(views.includes('Pós-venda de produtos'),'post-sale admin UI');
for(const dir of fs.readdirSync(path.join(root,'source/runtime')).filter(n=>n.startsWith('sh_'))){const p=JSON.parse(read(`source/runtime/${dir}/package.json`)); must(p.version==='18.9.28',`runtime ${dir}`)}
const z=JSON.parse(cp.execFileSync('unzip',['-p',path.join(root,'source/ZenyxPro.zip'),'package.json'],{encoding:'utf8'})); must(z.version==='18.9.28','template version');
console.log('R18.9.28 manager regression OK');
