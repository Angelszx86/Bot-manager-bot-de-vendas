const fs=require('fs'),path=require('path'),assert=require('assert'); const R=path.join(__dirname,'..');
const read=f=>fs.readFileSync(path.join(R,f),'utf8');
const w=read('source/partner_manager_worker.js'),e=read('Eventos/manager/partnerManagers.js'),p=read('Lib/partnerManagerPanel.js');
assert(w.includes('commandFingerprint')); assert(w.includes('partner-command-state-')); assert(w.includes("body:commands")); assert(w.includes("body:[]")); assert(w.includes("rate-limit"));
assert(e.includes("admin?partners.list():ownedManagers")); assert(e.includes("start|restart|stop|logs|apps|delete")); assert(p.includes("'Aplicações'"));
assert(w.includes('createCheckoutThread')); assert(w.includes('Gerando cobrança PIX automática')); assert(w.includes("price obrigatório")||w.includes('Preço obrigatório'));
console.log('R18.9.63 regression: OK');
