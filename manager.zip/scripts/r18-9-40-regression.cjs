const fs=require('fs');const path=require('path');
const read=(p)=>fs.readFileSync(path.join(process.cwd(),p),'utf8');const must=(c,m)=>{if(!c)throw new Error(m)};
const bc=read('Eventos/config/botconfig.js');
must(bc.includes("customId === 'walletManagerToggle'")&&bc.includes('await interaction.deferUpdate()'),'wallet toggle must ACK before sync');
must(bc.includes("syncWalletFeatureForAll().catch(() => [])")&&bc.includes('EvoPay configurada e ativada'),'EvoPay credential propagation missing');
const idx=read('index.js'); must(idx.includes("[ZWALLET] Instâncias sincronizadas")&&idx.includes('syncWalletFeatureForAll'),'wallet boot sync missing');
console.log('R18.9.40 manager regression OK');
