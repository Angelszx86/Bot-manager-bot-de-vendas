'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const template = path.join(root, 'source', 'ZenyxPro.zip');
assert(fs.existsSync(template), 'source/ZenyxPro.zip ausente');
const pkg = JSON.parse(cp.execFileSync('unzip', ['-p', template, 'package.json'], { encoding: 'utf8' }));
assert.equal(pkg.version, '18.9.106');
assert.equal(pkg.zenyxBuild, 'R18.9.106');
const magnus = cp.execFileSync('unzip', ['-p', template, 'dist/payments/providers/magnus-pay.js'], { encoding: 'utf8' });
assert(magnus.includes('/api/v1/pagamentos'), 'rota oficial MagnusPay ausente');
assert(!magnus.includes('/api/transactions/create'), 'rota MagnusPay antiga ainda presente');
const router = cp.execFileSync('unzip', ['-p', template, 'dist/discord/router.js'], { encoding: 'utf8' });
for (const marker of ['product-ticket:name:', 'isAssistedSaleSeller', 'isAssistedSaleConfirmer', 'simplePixKeyVisible', 'simplePixQrEnabled']) {
  assert(router.includes(marker), `recurso ausente no runtime: ${marker}`);
}
assert(fs.existsSync(path.join(root, 'Lib', 'childRuntimeConverger.js')), 'convergedor de runtimes ausente');
console.log('R18.9.106 manager regression: OK');
