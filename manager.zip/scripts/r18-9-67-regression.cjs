const assert=require('assert');
const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}
(async()=>{
  const worker=read('source/partner_manager_worker.js');
  const managers=read('Lib/partnerManagers.js');
  const pkg=JSON.parse(read('package.json'));

  await test('selecionar plano apenas abre confirmação e não cria tópico/cobrança',()=>{
    const select=worker.match(/if\(i\.customId==='pm:buy'\)[^\n]+/s)?.[0]||'';
    assert(select.includes('createCheckoutIntent'));
    assert(select.includes('checkoutConfirmPayload'));
    assert(!select.includes('beginPaymentCheckout'));
    assert(worker.includes('Nenhum tópico ou cobrança foi criado ainda.'));
    assert(worker.includes("pm:checkout:confirm:"));
    assert(worker.includes("pm:checkout:abort:"));
  });

  await test('confirmação é validada por usuário, servidor e expiração',()=>{
    assert(worker.includes("Date.now()-Number(intent.createdAt||0)>5*60*1000"));
    assert(worker.includes("String(intent.userId)!==String(i.user.id)"));
    assert(worker.includes("String(intent.guildId)!==String(i.guildId||'')"));
  });

  await test('um cliente só mantém um checkout pendente por Manager/servidor',()=>{
    assert(worker.includes('function activeCheckoutFor(userId,guildId)'));
    assert(worker.includes("String(o.status||'').toUpperCase()==='PENDING'"));
    assert(worker.includes('Você já possui um checkout aberto'));
    assert(worker.includes('só é permitido **1 checkout pendente por cliente**'));
    assert(worker.includes('checkoutLockKey(i.user.id,i.guildId)'));
  });

  await test('gateway é validado antes da criação do tópico',()=>{
    const start=worker.indexOf("await rpc('payment-ready'"), thread=worker.indexOf('createCheckoutThread(i,plan,mode)',start);
    assert(start>0 && thread>start);
    assert(managers.includes("if(op==='payment-ready')"));
  });

  await test('falha antes da cobrança remove/arquiva o tópico recém-criado',()=>{
    assert(worker.includes('async function closeFailedCheckoutThread(thread)'));
    assert(worker.includes("thread.delete('Checkout abortado antes da criação da cobrança.')"));
    assert(worker.includes('if(created?.thread&&!orderCreated) await closeFailedCheckoutThread(created.thread)'));
  });

  await test('checkout pago pode ser cancelado somente antes da confirmação',()=>{
    assert(worker.includes("pm:checkout:cancel:"));
    assert(managers.includes("if(op==='cancel-payment')"));
    assert(managers.includes("if(String(order.status||'').toUpperCase()==='PAID') throw new Error('Pagamento já confirmado.')"));
    assert(managers.includes("status:'CANCELED'"));
    assert(managers.includes("CANCELED_LOCAL"));
  });

  await test('status local cancelado é terminal e não aprova depois',()=>{
    const pos=managers.indexOf("if(op==='payment-status')");
    const block=managers.slice(pos,pos+1200);
    assert(block.includes("['CANCELED','CANCELLED','EXPIRED','FAILED','ERROR','REFUNDED','REJECTED']"));
    assert(block.includes('return {paid:false,status:String(order.status||\'\').toUpperCase(),order}'));
  });

  await test('aprovação automática continua ativa',()=>{
    assert(worker.includes("setInterval(()=>void check(),8000)"));
    assert(worker.includes("rpc('payment-status'"));
    assert(managers.includes('paidStatus(status)'));
    assert(managers.includes("store.patchOrder(order.id,{status:'PAID'"));
  });

  await test('versão do patch atualizada',()=>{
    assert.equal(pkg.version,'18.9.67');
    assert.equal(pkg.zenyxBuild,'R18.9.67');
    assert(pkg.scripts['test:r18.9.67']);
  });

  console.log(`\nR18.9.67: ${ok}/${ok+fail} testes passaram.`);
  if(fail)process.exit(1);
})();
