const assert=require('assert');
const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');
const read=f=>fs.readFileSync(path.join(ROOT,f),'utf8');
const pricing=require(path.join(ROOT,'Lib/planPricing'));
let ok=0,fail=0;
async function test(name,fn){try{await fn();console.log('✓',name);ok++;}catch(e){console.error('✗',name,'\n ',e.stack||e);fail++;}}
(async()=>{
 const worker=read('source/partner_manager_worker.js');
 const partners=read('Lib/partnerManagers.js');
 const store=read('Lib/partnerManagerStore.js');
 const botconfig=read('Eventos/config/botconfig.js');
 const event=read('Eventos/manager/partnerManagers.js');
 const proxy=read('Lib/discordRestProxy.js');
 const panel=read('Lib/partnerManagerPanel.js');
 const pkg=JSON.parse(read('package.json'));
 await test('preço mínimo proporcional por blocos iniciados de 30 dias',()=>{
   assert.equal(pricing.minimumPrice(30),6); assert.equal(pricing.minimumPrice(31),12);
   assert.equal(pricing.minimumPrice(60),12); assert.equal(pricing.minimumPrice(150),30);
   assert(pricing.validatePlan(30,6).ok); assert(pricing.validatePlan(150,30).ok);
   assert(!pricing.validatePlan(150,6).ok); assert(!pricing.validatePlan(29,6).ok);
 });
 await test('Manager original valida preço antes de persistir e usa ACK próprio',()=>{
   assert(botconfig.includes("const planPricing = require('../../Lib/planPricing')"));
   assert(botconfig.includes('managerPlanLoadingPayload'));
   assert(botconfig.includes('await ackManagerPlan(interaction'));
   assert(botconfig.includes('planPricing.validatePlan(days,price)'));
   assert(botconfig.includes('R$ 6,00 por cada bloco iniciado de 30 dias'));
 });
 await test('Manager parceiro usa mesma política de preço no worker e backend',()=>{
   assert(worker.includes("require('../Lib/planPricing')"));
   assert(worker.includes('planPricing.validatePlan(days,price)'));
   assert(worker.includes('max_value:36500'));
   assert(partners.includes("require('./planPricing')"));
   assert(partners.includes('planPricing.validatePlan(plan.days,plan.price)'));
 });
 await test('store migra planos antigos sem baratear durações longas',()=>{
   assert(store.includes('const CURRENT_VERSION = 5'));
   assert(store.includes('planPricing.minimumPrice'));
   assert(store.includes('planPricing.MAX_DAYS'));
 });
 await test('checkout faz preflight antes de criar tópico e reduz updates REST',()=>{
   const begin=worker.slice(worker.indexOf('async function beginPaymentCheckout'),worker.indexOf('async function paidMessage'));
   assert(begin.includes("rpc('payment-ready',{},8000)"));
   assert(begin.indexOf("rpc('payment-ready',{},8000)") < begin.indexOf('createCheckoutThread(i,plan,mode)'));
   assert(!begin.includes("checkoutProgressPayload(plan,mode,'opening')"));
   assert(!begin.includes("checkoutProgressPayload(plan,mode,'payment')"));
   assert(begin.includes('checkoutProgressPayload(plan,mode)'));
 });
 await test('thread de checkout recebe prioridade no bridge REST',()=>{
   assert(proxy.includes("/\\/channels\\/[^/]+\\/threads"));
   assert(proxy.includes('return 2'));
 });
 await test('anti-duplicação e limite de um Manager por usuário continuam ativos',()=>{
   assert(worker.includes('activeCheckoutFor(userId,guildId)'));
   assert(worker.includes('checkoutLocks.has(lockKey)'));
   assert(partners.includes('Cada usuário pode ter apenas 1 Manager parceiro'));
   assert(event.includes('Cada usuário pode ter apenas **1 Manager parceiro**'));
 });
 await test('vitrine parceira profissional e publicação em background',()=>{
   assert(worker.includes('Selecionar plano e revisar compra'));
   assert(worker.includes('### Próximas etapas'));
   assert(worker.includes('void refreshPublications().catch'));
   assert(panel.includes('mínimo de **R$ 6,00 por bloco iniciado de 30 dias**'));
 });
 await test('schema de comandos e build atualizados',()=>{
   assert(worker.includes("pm-r18.9.70-v1"));
   assert.equal(pkg.version,'18.9.70'); assert.equal(pkg.zenyxBuild,'R18.9.70');
   assert(pkg.scripts['test:r18.9.70']);
 });
 console.log(`\nR18.9.70: ${ok}/${ok+fail} testes passaram.`); if(fail)process.exit(1);
})();
