const fs = require('fs');
const path = require('path');
const assert = require('assert');
const cp = require('child_process');
const Module = require('module');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');

function addComponentsArgCounts(text){
  const out=[];
  const re=/\.addComponents\s*\(/g;
  let m;
  while((m=re.exec(text))){
    let i=m.index+m[0].length, depth=1, commas=0, quote=null, esc=false, line=false, block=false;
    for(; i<text.length && depth>0; i++){
      const c=text[i], n=text[i+1]||'';
      if(line){ if(c==='\n') line=false; continue; }
      if(block){ if(c==='*'&&n==='/'){ block=false; i++; } continue; }
      if(quote){ if(esc) esc=false; else if(c==='\\') esc=true; else if(c===quote) quote=null; continue; }
      if(c==='/'&&n==='/'){ line=true; i++; continue; }
      if(c==='/'&&n==='*'){ block=true; i++; continue; }
      if(c==='\''||c==='"'||c==='`'){ quote=c; continue; }
      if(c==='('||c==='['||c==='{') depth++;
      else if(c===')'||c===']'||c==='}') depth--;
      else if(c===','&&depth===1) commas++;
    }
    out.push(commas+1);
  }
  return out;
}

let passed=0;
const test=(name,fn)=>{ fn(); passed++; console.log('OK',name); };
const pagesText=read('Lib/botconfigPages.js');
const botconfig=read('Eventos/config/botconfig.js');
const pkg=JSON.parse(read('package.json'));

test('build 18.9.73',()=>{assert.equal(pkg.version,'18.9.73');assert.equal(pkg.zenyxBuild,'R18.9.73');});
test('helper limita ActionRows',()=>assert(pagesText.includes('function buttonRows(buttons = [])')));
test('Operação usa linhas fatiadas',()=>assert(pagesText.includes('...buttonRows([')));
test('nenhuma chamada literal addComponents passa de 5 componentes',()=>{
  for(const file of ['Lib/botconfigPages.js','Eventos/config/botconfig.js']){
    const counts=addComponentsArgCounts(read(file));
    assert(!counts.some(n=>n>5),`${file} possui ActionRow com >5 componentes: ${counts.filter(n=>n>5)}`);
  }
});
test('Operação preserva todos os atalhos',()=>{
  for(const id of ['definitions','statusRealtime','earlyAccessToggle','zcloudManagerToggle','walletManagerToggle','magnusGlobalToggle']) assert(pagesText.includes(`'${id}'`));
});
test('filtro antigolpe retorna à página correta',()=>assert(botconfig.includes("pagePayload(client, interaction, 3, { forUpdate: true })")));
test('mgrnav monta payload antes do update',()=>assert(botconfig.includes('const payload = pagePayload(client, interaction, page, { forUpdate: true });')));
test('seletor Operação continua presente',()=>assert(pagesText.includes("['Operação', 'Pagamentos, automações, moderação e feed', 'payment']")));

test('compatibilidade R18.9.72 do PIX central permanece',()=>{
  const evo=read('Lib/evopay.js');
  assert(evo.includes("safeGet('evopay.token')"));
  assert(evo.includes('process.env.EVOPAY_TOKEN'));
  assert(evo.includes('Idempotency-Key'));
});
test('proteções do checkout parceiro continuam presentes',()=>{
  const worker=read('source/partner_manager_worker.js');
  const partners=read('Lib/partnerManagers.js');
  assert(worker.includes('activeCheckoutFor(i.user.id,i.guildId)'));
  assert(worker.includes('pm:checkout:retry:'));
  assert(partners.includes('Cada usuário pode ter apenas 1 Manager parceiro'));
});
test('correção de estoque do filho permanece no template',()=>{
  const zip=path.join(root,'source','ZenyxPro.zip');
  assert(fs.existsSync(zip));
  const router=cp.execFileSync('unzip',['-p',zip,'src/discord/router.ts'],{encoding:'utf8'});
  assert(router.includes('/^admin:stock:(?:add|ghost):/'));
  assert(router.includes('Estoque salvo; sincronização visual parcial ficou pendente.'));
});
test('preço proporcional continua ativo',()=>{
  const pricing=require(path.join(root,'Lib/planPricing'));
  assert.equal(pricing.minimumPrice(30),6);
  assert.equal(pricing.minimumPrice(31),12);
  assert.equal(pricing.minimumPrice(150),30);
});

// Serialização real das seis páginas com discord.js: garante que o payload enviado
// ao Discord não contém ActionRow acima do limite de cinco componentes.
test('as 6 páginas do /botconfig serializam dentro dos limites do Discord',()=>{
  const original=Module._load;
  const fakeDb={all:()=>[],get:()=>undefined};
  const fakeLogs={get:k=>k==='sistema'?true:undefined};
  const stubs={
    './managerEmojis':{readCache:()=>({})},
    '../databases/index':{logs:fakeLogs,db2:fakeDb,clientes:{get:()=>[],all:()=>[]},db:fakeDb},
    './keys':{stats:()=>({active:0,redemptions:0,total:0})},
    '../source/sftp':{status:()=>({ok:true})},
    './earlyAccess':{isEnabled:()=>false},
    './zcloudControl':{isEnabled:()=>false,effectivePublicBaseUrl:()=>''},
    './walletControl':{isEnabled:()=>false},
    './shardcloudControl':{settings:()=>({enabled:false,token:'',memoryRatio:.8})},
    './magnusControl':{isEnabled:()=>false},
    './partnerManagerPanel':{},
    './storefrontConfig':{settings:()=>({style:'COMPACT',bannerUrl:'',showInfo:true,showDemo:true,showTrial:true,showSupport:true,showEarlyAccess:false})},
    './managerPlans':{all:()=>[]},
    './trialSettings':{settings:()=>({durationMinutes:4320,bannerUrl:'',showSupport:true}),label:()=> '3 dias'},
    './salesFeed':{settings:()=>({channelId:null,imageEnabled:true,renewalChannelId:null})}
  };
  const pagesFile=path.join(root,'Lib','botconfigPages.js');
  Module._load=function(req,parent,isMain){
    if(parent?.filename===pagesFile && Object.prototype.hasOwnProperty.call(stubs,req)) return stubs[req];
    return original.call(this,req,parent,isMain);
  };
  try{
    delete require.cache[require.resolve(pagesFile)];
    const pages=require(pagesFile);
    const client={application:{id:'123'},user:{id:'123'},ws:{ping:50},guilds:{cache:{size:2}}};
    const interaction={guildId:'guild-test'};
    const walk=x=>{
      if(!x||typeof x!=='object') return;
      if(x.type===1&&Array.isArray(x.components)) assert(x.components.length<=5,`ActionRow com ${x.components.length} componentes`);
      for(const v of Object.values(x)) if(v&&typeof v==='object') walk(v);
    };
    for(let page=0;page<6;page++) walk(JSON.parse(JSON.stringify(pages.pagePayload(client,interaction,page,{forUpdate:true}))));
  } finally { Module._load=original; }
});

console.log(`R18.9.73 regression: ${passed}/13 OK`);
