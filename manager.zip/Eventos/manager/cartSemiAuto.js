const { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const QRCode = require('qrcode');
const { QrCodePix } = require('qrcode-pix');
const { db1, logs, clientes } = require('../../databases/index');
const purchaseSessions = require('../../Lib/purchaseSessions');
const { amountForSession, expirationForSession, notifyBuyer, money, linkingReadyEmbed } = require('../../Lib/planPurchase');
const { logError } = require('../../Lib/interactions');
const { ensureAndReport: ensureClientRole } = require('../../Lib/clientRole');
const purchaseReviewers = require('../../Lib/purchaseReviewers');
const bankImap = require('../../Lib/nubankImap');

const watchers = new Map();
const finalizing = new Set();
function clearWatch(channelId) {
  const item = watchers.get(channelId);
  if (item?.interval) clearInterval(item.interval);
  if (item?.timeout) clearTimeout(item.timeout);
  watchers.delete(channelId);
}

async function finalizeApprovedPurchase(client, channelId) {
  channelId = String(channelId || '');
  if (!channelId || finalizing.has(channelId)) return false;
  let session = db1.get(channelId);
  if (!session || String(session.status || '').toLowerCase() !== 'aprovado') return false;
  if (session.payment?.finalizedAt) return true;
  finalizing.add(channelId);
  try {
    session = purchaseSessions.persist(channelId, session);
    const channel = client.channels.cache.get(channelId) || await client.channels.fetch(channelId).catch(() => null);
    if (!channel?.isTextBased?.() || !channel?.guild) throw new Error('Tópico da compra não encontrado para finalizar o IMAP.');
    const guild = channel.guild;
    await ensureClientRole(guild, session.userid, { reason: 'Cliente ASTRA APPLICATION • pagamento confirmado' });
    const amount = Number(db1.get(`${channelId}.payment.expectedAmount`) || amountForSession(session));
    const expiration = expirationForSession(session);
    const confirmedBy = db1.get(`${channelId}.payment.confirmedBy`) || 'aprovação manual';
    const configuredBank = db1.get(`${channelId}.payment.bankLabel`) || 'Banco Inter';
    const isImap = ['nubank_imap','bank_imap','imap'].includes(String(confirmedBy)) || ['nubank_imap','bank_imap','imap'].includes(String(db1.get(`${channelId}.payment.provider`) || ''));
    const providerLabel = isImap ? `${configuredBank} • IMAP` : 'PIX manual';
    const payload = {
      content: `<@${session.userid}>`,
      embeds: [linkingReadyEmbed({ session, amount, provider: providerLabel, expiration, confirmedBy })],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`${session.dias}_${session.aluguel}_uparbot`).setLabel('Vincular bot').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setURL('https://discord.com/developers/applications').setLabel('Discord Developer').setStyle(ButtonStyle.Link)
      )],
      files: [], attachments: []
    };
    let message = null;
    if (session.msg?.id && channel.messages?.fetch) message = await channel.messages.fetch(String(session.msg.id)).catch(() => null);
    if (message) await message.edit(payload);
    else if (channel.send) {
      message = await channel.send(payload);
      purchaseSessions.persist(channelId, { ...session, msg: { ...(session.msg || {}), id: message.id } });
    } else throw new Error('Não foi possível localizar nem recriar a mensagem do checkout.');

    const buyer = await client.users.fetch(String(session.userid)).catch(() => null);
    await notifyBuyer(client, session.userid, { session, amount, provider: providerLabel, expiration });
    await require('../../Lib/salesFeed').announce(client, {
      type: 'purchase', user: buyer || { toString: () => `<@${session.userid}>` }, guildId: guild.id,
      plan: session.plano, days: session.dias
    }).catch(error => logError(error, 'semi-sales-feed'));
    db1.set(`${channelId}.payment.finalizedAt`, Date.now());
    clearWatch(channelId);
    return true;
  } finally {
    finalizing.delete(channelId);
  }
}

async function finish(interaction, session) {
  if (session && String(session.status || '').toLowerCase() !== 'aprovado') db1.set(`${interaction.channel.id}.status`, 'aprovado');
  return finalizeApprovedPurchase(interaction.client, interaction.channel.id);
}

module.exports = {
  finalizeApprovedPurchase,
  name: 'interactionCreate',
  run: async (interaction) => {
    const customId = interaction.customId || '';
    const channelId = interaction.channel?.id;
    if (!channelId) return;

    if (customId === 'copyPix') {
      const code = db1.get(`${channelId}.copyCola`);
      return interaction.reply({ content: code || 'Código PIX indisponível ou expirado.', flags: MessageFlags.Ephemeral });
    }

    if (customId === 'aproveCarrin') {
      const roleId = logs.get('semi.roleAprove');
      const member = interaction.member;
      const byRole = Boolean(roleId && member?.roles?.cache?.has?.(roleId));
      const byReviewer = purchaseReviewers.isReviewer(interaction.user.id);
      if (!byRole && !byReviewer) {
        return interaction.reply({ content: roleId ? 'Você não possui permissão para aprovar pagamentos.' : 'Nenhum cargo aprovador foi configurado e você não faz parte da equipe dos tópicos.', flags: 64 });
      }
      if (db1.get(`${channelId}.status`) === 'aprovado') return interaction.reply({ content: 'Este pagamento já foi aprovado.', flags: 64 });
      db1.set(`${channelId}.status`, 'aprovado');
      db1.set(`${channelId}.payment.confirmedBy`, `aprovado por ${interaction.user.username}`);
      return interaction.reply({ content: 'Pagamento aprovado. O checkout será atualizado automaticamente.', flags: 64 });
    }

    if (customId.startsWith('zenyxpay:imap:')) {
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão de compra expirou ou já foi encerrada.', flags: 64 });
      const cfg = await bankImap.getStoredConfig();
      if (!bankImap.managerPaymentReady(cfg)) return interaction.reply({ content: 'O **Inter IMAP** não está disponível no checkout do Manager original agora.', flags: 64 });
      const modal = new ModalBuilder().setCustomId('purchase:imap:payer').setTitle(`${String(cfg.bankLabel || 'Banco Inter').slice(0, 35)} • confirmar pagador`);
      const input = new TextInputBuilder()
        .setCustomId('payerName')
        .setLabel('NOME EXATO DO TITULAR/PAGADOR')
        .setPlaceholder('Digite exatamente como aparece no seu banco')
        .setStyle(TextInputStyle.Short).setRequired(true).setMinLength(3).setMaxLength(100);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      return interaction.showModal(modal);
    }

    if (customId === 'purchase:imap:payer' && interaction.isModalSubmit?.()) {
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão de compra expirou. Reabra o carrinho.', flags: 64 });
      const cfg = await bankImap.getStoredConfig();
      if (!bankImap.managerPaymentReady(cfg)) return interaction.reply({ content: 'O Inter IMAP foi ocultado/desativado para o Manager original. Escolha outro método.', flags: 64 });
      const payerName = interaction.fields.getTextInputValue('payerName').trim().replace(/\s+/g, ' ');
      if (payerName.length < 3) return interaction.reply({ content: 'Informe o nome completo exatamente como aparece no banco.', flags: 64 });
      const amount = amountForSession(session);
      const minutes = Math.max(3, Math.min(120, Number(logs.get('semi.tempoPay')) || 15));
      let payload;
      try { payload = QrCodePix({ version: '01', key: cfg.pixKey, name: 'ASTRO SOLUTION', city: 'BRASILIA', value: amount }).payload(); }
      catch (error) { return interaction.reply({ content: `Não foi possível montar o PIX do Banco Inter: ${String(error?.message || error).slice(0, 500)}`, flags: 64 }); }
      const png = await QRCode.toBuffer(payload, { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
      const attachment = new AttachmentBuilder(png, { name: 'zenyx-bank-imap-pix.png' });
      const expiresAt = Date.now() + minutes * 60000;
      const unix = Math.floor(expiresAt / 1000);
      db1.set(`${channelId}.status`, 'pendente');
      db1.set(`${channelId}.copyCola`, payload);
      db1.set(`${channelId}.payment`, { provider: 'bank_imap', bankLabel: cfg.bankLabel || 'Banco Inter', expectedAmount: amount, expectedPayerName: payerName, createdAt: Date.now(), expiresAt, status: 'pending' });
      await interaction.deferUpdate();
      await interaction.message.edit({
        content: `<@${session.userid}>`,
        embeds: [new EmbedBuilder().setColor('#3155ff').setTitle(`${cfg.bankLabel || 'Banco Inter'} • PIX com confirmação IMAP`)
          .setDescription('Faça o PIX usando uma conta cujo **nome do pagador seja exatamente o informado abaixo**. O Manager só aprova automaticamente quando o e-mail do banco contém **o mesmo valor e o mesmo nome**. A equipe também pode aprovar manualmente.')
          .addFields(
            { name: 'Plano', value: `**${session.plano}** • ${session.dias} dias`, inline: true },
            { name: 'Valor esperado', value: `**${money(amount)}**`, inline: true },
            { name: 'Pagador esperado', value: `**${payerName.slice(0,100)}**`, inline: false },
            { name: 'Chave PIX', value: `\`${String(cfg.pixKey).slice(0,180)}\``, inline: false },
            { name: 'Prazo', value: `<t:${unix}:F>
<t:${unix}:R>`, inline: false }
          ).setImage('attachment://zenyx-bank-imap-pix.png').setFooter({ text: 'ASTRO SOLUTION • IMAP confere valor + nome; nunca apenas o valor' }).setTimestamp()],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('copyPix').setLabel('Copiar PIX').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('aproveCarrin').setLabel('Aprovar manualmente').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(purchaseSessions.paymentId('cancel', session)).setLabel('Cancelar').setStyle(ButtonStyle.Danger)
        )],
        files: [attachment], attachments: []
      });
      clearWatch(channelId);
      const interval = setInterval(async () => {
        const current = db1.get(String(channelId));
        if (!current) return clearWatch(channelId);
        if (current.status === 'aprovado') return finish(interaction, current);
      }, 1500);
      interval.unref?.();
      const timeout = setTimeout(async () => {
        const current = db1.get(String(channelId));
        if (!current || current.status === 'aprovado') return;
        clearWatch(channelId);
        await interaction.message.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Confirmação IMAP expirada').setDescription('Nenhum e-mail compatível com **valor + nome** foi identificado dentro do prazo. Gere uma nova cobrança ou peça aprovação manual à equipe.')], components: [], files: [], attachments: [] }).catch(() => null);
        db1.delete(channelId);
      }, minutes * 60000);
      timeout.unref?.();
      watchers.set(channelId, { interval, timeout });
      return;
    }

    if (!(customId.endsWith('_semiAutoPay') || customId.startsWith('zenyxpay:semi:'))) return;
    const session = purchaseSessions.resolve(interaction);
    if (!session) return interaction.reply({ content: 'Esta sessão de compra expirou ou já foi encerrada.', flags: 64 });
    const key = String(logs.get('semi.chave') || '').trim();
    const type = String(logs.get('semi.tipo') || '').trim();
    if (!logs.get('semi.sistema') || !key || !type) return interaction.reply({ content: 'O PIX manual ainda não foi configurado pelo proprietário.', flags: 64 });

    const amount = amountForSession(session);
    const minutes = Math.max(3, Math.min(120, Number(logs.get('semi.tempoPay')) || 15));
    let payload;
    try {
      payload = QrCodePix({ version: '01', key, name: 'ASTRO SOLUTION', city: 'BRASILIA', value: amount }).payload();
    } catch (error) {
      return interaction.reply({ content: `Não foi possível montar o PIX com a chave configurada: ${String(error?.message || error).slice(0, 500)}`, flags: 64 });
    }
    const png = await QRCode.toBuffer(payload, { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
    const attachment = new AttachmentBuilder(png, { name: 'zenyx-pix-manual.png' });
    const expiresAt = Date.now() + minutes * 60000;
    const unix = Math.floor(expiresAt / 1000);
    db1.set(`${channelId}.status`, 'pendente');
    db1.set(`${channelId}.copyCola`, payload);
    db1.set(`${channelId}.payment`, { provider: 'pix_manual', expectedAmount: amount, createdAt: Date.now(), expiresAt });

    await interaction.update({
      content: `<@${session.userid}>`,
      embeds: [new EmbedBuilder()
        .setColor('#3155ff')
        .setTitle('ASTRA APPLICATION • Checkout PIX')
        .setDescription('Realize o pagamento pelo QR Code e aguarde a **aprovação manual da equipe**. Para confirmação automática por e-mail, escolha o método **Inter IMAP** no checkout.')
        .addFields(
          { name: 'Produto', value: '**bot de vendas**', inline: true },
          { name: 'Valor', value: `**${money(amount)}**`, inline: true },
          { name: 'Plano', value: `**${session.plano}** • ${session.dias} dias`, inline: true },
          { name: 'Chave PIX', value: `\`${key.slice(0, 180)}\``, inline: false },
          { name: 'Prazo', value: `<t:${unix}:F>\n<t:${unix}:R>`, inline: false }
        )
        .setImage('attachment://zenyx-pix-manual.png')
        .setFooter({ text: 'ASTRO SOLUTION • checkout sem logotipo sobre o QR Code' })],
      components: [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('copyPix').setLabel('Copiar PIX').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('aproveCarrin').setLabel('Confirmar pagamento').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(purchaseSessions.paymentId('cancel', session)).setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
      )],
      files: [attachment], attachments: []
    });

    clearWatch(channelId);
    const interval = setInterval(async () => {
      const current = db1.get(String(channelId));
      if (!current) return clearWatch(channelId);
      if (current.status === 'aprovado') return finish(interaction, current);
    }, 2000);
    interval.unref?.();
    const timeout = setTimeout(async () => {
      const current = db1.get(String(channelId));
      if (!current || current.status === 'aprovado') return;
      clearWatch(channelId);
      await interaction.message.edit({
        content: `<@${session.userid}>`,
        embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Checkout expirado').setDescription('O prazo para pagamento terminou. Abra uma nova compra para gerar outro PIX.')],
        components: [], files: [], attachments: []
      }).catch(() => null);
      db1.delete(channelId);
    }, minutes * 60000);
    timeout.unref?.();
    watchers.set(channelId, { interval, timeout });
  }
};
