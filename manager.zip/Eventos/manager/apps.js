const mercadopago = require("mercadopago");
const axios = require("axios");
const { JsonDatabase } = require("wio.db");
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");
const schedule = require('node-schedule');
const JSZip = require('jszip');
const path = require('path');
const fs = require("fs");
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const pix = new JsonDatabase({ databasePath: "./config.json" });
const Discord = require("discord.js");
const { StringSelectMenuBuilder, EmbedBuilder, ActionRowBuilder, ApplicationCommandType, ApplicationCommandOptionType, ButtonBuilder, ComponentType, ModalBuilder, TextInputBuilder } = require(`discord.js`);
const { validateChildToken } = require('./enviarbot');
const center = require('../../Lib/clientCenter');

module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        let produto;
        let nome;
        let vencimento;
        const id = interaction.customId;

        if (interaction.isButton() && interaction.customId.endsWith('_removerapp')) {
            const ids = id.slice(0, -'_removerapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.reply({ content: 'Este bot não pertence a você.', ephemeral: true });
            const modal = new ModalBuilder()
                .setCustomId(`${ids}_removerapp_modal`)
                .setTitle('ASTRA APPLICATION • Remover Bot')
                .addComponents(new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('confirm').setLabel('DIGITE REMOVER PARA CONFIRMAR').setPlaceholder('REMOVER').setStyle(1).setRequired(true).setMaxLength(10)
                ));
            return interaction.showModal(modal);
        }

        if (interaction.isModalSubmit() && interaction.customId.endsWith('_removerapp_modal')) {
            const ids = id.slice(0, -'_removerapp_modal'.length);
            const record = db2.get(ids);
            if (!record || interaction.user.id !== record.owner) return interaction.reply({ content: 'Aplicação não encontrada ou sem permissão.', ephemeral: true });
            if (interaction.fields.getTextInputValue('confirm').trim().toUpperCase() !== 'REMOVER') {
                return interaction.reply({ content: 'Remoção cancelada. Digite exatamente **REMOVER** para confirmar.', ephemeral: true });
            }
            await interaction.deferReply({ ephemeral: true });
            try {
                const application = await new SquareCloudAPI(api.get('square')).applications.get(ids);
                const result = await application.stop();
                if (result?.ok === false) throw new Error(result.msg || 'O runtime não confirmou o desligamento.');
                db2.set(`${ids}.status`, 'recoverable');
                db2.set(`${ids}.desiredState`, 'stopped');
                db2.set(`${ids}.userStopped`, true);
                db2.set(`${ids}.recoverable`, true);
                db2.set(`${ids}.removedAt`, new Date().toISOString());
                return interaction.editReply('`✅` Bot removido da execução. Os arquivos e configurações foram preservados; use **Ver bot** para recuperar e ligar novamente.');
            } catch (error) {
                return interaction.editReply(`\`❌\` Não foi possível remover o bot: ${String(error?.message || error).slice(0, 800)}`);
            }
        }
        if (interaction.isButton() && interaction.customId.endsWith("_outrasapp")) {
            const ids = id.slice(0, -'_outrasapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate();
            interaction.reply({
                content: `Em qual parte das outras ações você deseja usar para gerenciar?`,
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${ids}_alterarnomeapp`)
                                .setLabel(`Nome Aplicação`)
                                .setStyle(1)
                                .setEmoji(`🔧`),
                            new ButtonBuilder()
                                .setCustomId(`${ids}_alterartokenapp`)
                                .setLabel(`Token Aplicação`)
                                .setStyle(1)
                                .setEmoji(`🔧`),
                            new ButtonBuilder()
                                .setCustomId(`${ids}_transferirposseapp`)
                                .setLabel(`Doar Posse`)
                                .setStyle(1)
                                .setEmoji(`🔧`)
                        )
                ],
                ephemeral: true
            })
        };

        if (interaction.isButton() && interaction.customId.endsWith("_transferirposseapp")) {
            const ids = id.slice(0, -'_transferirposseapp'.length);
            const kk = await db2.get(`${ids}`);

            if (interaction.user.id !== kk.owner) return interaction.deferUpdate();

            const modal = new ModalBuilder()
                .setCustomId(`${ids}_transferirposseapp_modal`)
                .setTitle(`${kk.nome} - Transferir Posse`);

            const text = new TextInputBuilder()
                .setCustomId(`text`)
                .setLabel(`Qual é o id do usuario?`)
                .setStyle(1)
                .setPlaceholder(`⚠️ Você irá perder o acesso completo.`)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text));

            await interaction.showModal(modal);

        };

        if (interaction.isModalSubmit() && interaction.customId.endsWith("_transferirposseapp_modal")) {
            const ids = id.slice(0, -'_transferirposseapp_modal'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.reply({ content: 'Esta aplicação não pertence a você.', ephemeral: true });
            const text = interaction.fields.getTextInputValue(`text`).trim();
            const users = await interaction.guild.members.fetch(text).catch(() => null);
            if (!users || users.user?.bot) {
                return interaction.reply({ content: '`⚠️` O destino precisa ser uma pessoa que esteja neste servidor do Manager.', ephemeral: true });
            }
            await interaction.deferReply({ ephemeral: true });
            try {
                center.transferOwnership(ids, interaction.user.id, text);
                const applied = await center.applyTransferredOwnerRuntime(ids);
                if (applied?.stoppedForSafety) return interaction.editReply({ content: `\`⚠️\` A posse foi transferida para <@${text}>, mas o bot foi desligado por segurança porque não conseguiu recarregar o novo proprietário. Ligue-o novamente pela Central.` });
                return interaction.editReply({ content: `\`✅\` Aplicação transferida para <@${text}>. O novo proprietário já possui os comandos${applied?.restarted ? ' e o bot foi reiniciado para aplicar a posse' : ''}; runtime, validade e configurações foram preservados.` });
            } catch (error) {
                return interaction.editReply({ content: `\`❌\` ${String(error?.message || error).slice(0, 700)}` });
            }
        };

        if (interaction.isButton() && interaction.customId.endsWith("_alterartokenapp")) {
            const ids = id.slice(0, -'_alterartokenapp'.length);

            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate();

            const modal = new ModalBuilder()
                .setCustomId(`${ids}_alterartokenapp_modal`)
                .setTitle(`Alterar Token do Bot`);
            const text = new TextInputBuilder()
                .setCustomId(`text`)
                .setLabel(`Coloque Token Bot`)
                .setStyle(1)
                .setRequired(true)
                .setPlaceholder(`Coloque o Token Certo!`)

            modal.addComponents(new ActionRowBuilder().addComponents(text));
            await interaction.showModal(modal);

        };

        if (interaction.isModalSubmit() && interaction.customId.endsWith("_alterartokenapp_modal")) {
            const ids = id.slice(0, -'_alterartokenapp_modal'.length);

            const record = db2.get(ids);
            if (!record || String(record.owner) !== String(interaction.user.id)) {
                return interaction.reply({ content: 'Esta aplicação não pertence a você.', ephemeral: true });
            }

            const msgas = await interaction.reply({
                content: `⏳ Carregando...`,
                ephemeral: true
            });

            const token = interaction.fields.getTextInputValue(`text`).trim();
            let botInfo;
            try {
                botInfo = await validateChildToken(token, String(record.guildId || ''), interaction.client.application?.id || interaction.client.user.id);
            } catch (error) {
                return msgas.edit(`❌ ${String(error?.message || error).slice(0, 800)}`);
            }
            const boundClientId = String(record.childClientId || '').trim();
            if (boundClientId && boundClientId !== String(botInfo.id)) {
                return msgas.edit(`❌ Esta aplicação está vinculada ao Client ID \`${boundClientId}\`. Você pode atualizar o token **somente do mesmo bot**; outro Client ID não pode assumir este plano/Key.`);
            }
            if (!boundClientId) db2.set(`${ids}.childClientId`, String(botInfo.id));
            let nomeZipBanco = db2.get(`${ids}.nome`);
            let zipPathDefault = `source/client/${ids}.zip`;
            let appId = db2.get(`${ids}.idapp`);
            let zipPathByAppId = appId ? `source/client/${appId}.zip` : null;
            let zipPathByNome = nomeZipBanco ? `source/client/${nomeZipBanco}.zip` : null;
            let zipPath = zipPathDefault;
            if (!fs.existsSync(zipPath) && zipPathByAppId && fs.existsSync(zipPathByAppId)) {
                zipPath = zipPathByAppId;
            }
            if (!fs.existsSync(zipPath) && zipPathByNome && fs.existsSync(zipPathByNome)) {
                zipPath = zipPathByNome;
            }
            if (!fs.existsSync(zipPath)) {
                return msgas.edit(`❌ Arquivo do bot não encontrado para alteração de token.`);
            }
            try {
                const zip = await JSZip.loadAsync(fs.readFileSync(zipPath));
                let alterado = false;
                if (zip.file('config.json')) {
                    const configData = JSON.parse(await zip.file('config.json').async('string'));
                    configData.token = token;
                    zip.file('config.json', JSON.stringify(configData));
                    alterado = true;
                }
                if (zip.file('token.json')) {
                    const tokenData = JSON.parse(await zip.file('token.json').async('string'));
                    tokenData.token = token;
                    zip.file('token.json', JSON.stringify(tokenData));
                    alterado = true;
                }
                if (zip.file('Token.json')) {
                    const tokenData = JSON.parse(await zip.file('Token.json').async('string'));
                    tokenData.token = token;
                    zip.file('Token.json', JSON.stringify(tokenData, null, 2));
                    alterado = true;
                }
                if (zip.file('config/runtime.json')) {
                    const runtimeData = JSON.parse(await zip.file('config/runtime.json').async('string'));
                    runtimeData.clientId = String(botInfo.id);
                    zip.file('config/runtime.json', JSON.stringify(runtimeData, null, 2));
                }
                if (!alterado) {
                    return msgas.edit('❌ Nenhum arquivo de token compatível foi encontrado no ZIP para alterar o token.');
                }
                const content = await zip.generateAsync({ type: 'nodebuffer' });
                await fs.promises.writeFile(zipPath, content);
                const api1 = new SquareCloudAPI(api.get(`square`));
                const appId = db2.get(`${ids}.idapp`);
                if (!appId) {
                  return msgas.edit('❌ Não foi possível encontrar o ID da aplicação na Square Cloud.');
                }
                const application = await api1.applications.get(appId);
                const zipPathAppId = `source/client/${appId}.zip`;
                if (zipPath !== zipPathAppId) {
                  await fs.promises.copyFile(zipPath, zipPathAppId);
                }
                await application.commit(zipPathAppId, `${appId}.zip`, true);
                db2.set(`${ids}.token`, token);
                db2.set(`${ids}.childClientId`, String(botInfo.id));
                const configJsonPath = `source/client/config.json`;
                const tokenJsonPath = `source/client/token.json`;
                if (fs.existsSync(configJsonPath)) {
                  try {
                    const configData = JSON.parse(fs.readFileSync(configJsonPath, 'utf8'));
                    configData.token = token;
                    fs.writeFileSync(configJsonPath, JSON.stringify(configData));
                  } catch {}
                }
                if (fs.existsSync(tokenJsonPath)) {
                  try {
                    const tokenData = JSON.parse(fs.readFileSync(tokenJsonPath, 'utf8'));
                    tokenData.token = token;
                    fs.writeFileSync(tokenJsonPath, JSON.stringify(tokenData));
                  } catch {}
                }
                msgas.edit(`\`✅\` Token alterado com sucesso. O Client ID protegido continua sendo \`${botInfo.id}\`.`);
            } catch (err) {
                msgas.edit('`❌` Ocorreu um erro ao alterar o token no ZIP ou ao enviar para a Square Cloud.');
                console.error(err);
            }
            return;
        }

        if (interaction.isButton() && interaction.customId.endsWith("_alterarnomeapp")) {
            const ids = id.slice(0, -'_alterarnomeapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate()

            const modal = new ModalBuilder()
                .setCustomId(`${ids}_alterarnomeapp_modal`)
                .setTitle(`Alterar Nome da Aplicação`);

            const text = new TextInputBuilder()
                .setCustomId(`text`)
                .setLabel(`Qual será o novo nome?`)
                .setStyle(1)
                .setPlaceholder(`Coloque o nome que ira ser trocado!`)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(text))
            await interaction.showModal(modal)
        };

        if (interaction.isModalSubmit() && interaction.customId.endsWith("_alterarnomeapp_modal")) {
            const ids = id.slice(0, -'_alterarnomeapp_modal'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate()
            const text = interaction.fields.getTextInputValue(`text`);
            const msg1 = await interaction.reply({
                content: `⏳ Carregando...`,
                ephemeral: true
            })

            const idToModify = ids;
            db2.set(`${idToModify}.nome`, `${text}`);

            editSquareCloud(ids);
        };

        if (interaction.isButton() && interaction.customId.endsWith("_ligarapp")) {
            const ids = id.slice(0, -'_ligarapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate()
            const msgs = await interaction.update({
                content: `⏳ Carregando...`,
                embeds: [],
                components: []
            });

            try {
                const api1 = new SquareCloudAPI(api.get(`square`));
                const application = await api1.applications.get(ids);
                await application.start();
                db2.set(`${ids}.status`, 'online');
                db2.set(`${ids}.desiredState`, 'running');
                db2.set(`${ids}.userStopped`, false);
                db2.delete(`${ids}.userStoppedAt`);
                db2.set(`${ids}.recoverable`, false);
                db2.delete(`${ids}.removedAt`);
                editSquareCloud(ids);
            } catch (err) {
                console.log(err)
                interaction.followUp({
                    content: `\`❌\` Ocorre um erro...`,
                    ephemeral: true
                })
            }
        }


        if (interaction.isButton() && interaction.customId.endsWith("_desligarapp")) {
            const ids = id.slice(0, -'_desligarapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate()
            const msgs = await interaction.update({
                content: `⏳ Carregando...`,
                embeds: [],
                components: []
            });

            try {
                const api1 = new SquareCloudAPI(api.get(`square`));
                const application = await api1.applications.get(ids);
                await application.stop();
                // R18.9.48: 'stopped' é a intenção explícita do usuário. O boot
                // automático respeita esse estado e não religa o bot sozinho.
                db2.set(`${ids}.status`, 'stopped');
                db2.set(`${ids}.desiredState`, 'stopped');
                db2.set(`${ids}.userStopped`, true);
                db2.set(`${ids}.userStoppedAt`, new Date().toISOString());
                editSquareCloud(ids);
            } catch (err) {
                console.log(err)
                interaction.followUp({
                    content: `\`❌\` Ocorre um erro...`,
                    ephemeral: true
                })
            }

        }


        if (interaction.isButton() && interaction.customId.endsWith("_reiniciarapp")) {
            const ids = id.slice(0, -'_reiniciarapp'.length);
            if (interaction.user.id !== await db2.get(`${ids}.owner`)) return interaction.deferUpdate()
            const msgs = await interaction.update({
                content: `⏳ Carregando...`,
                embeds: [],
                components: []
            });

            try {
                const api1 = new SquareCloudAPI(api.get(`square`));
                const application = await api1.applications.get(ids);
                await application.restart();
                // Reiniciar é uma intenção explícita de manter a aplicação online.
                db2.set(`${ids}.status`, 'online');
                db2.set(`${ids}.desiredState`, 'running');
                db2.set(`${ids}.userStopped`, false);
                db2.delete(`${ids}.userStoppedAt`);
                db2.set(`${ids}.recoverable`, false);
                db2.delete(`${ids}.removedAt`);
                editSquareCloud(ids);
            } catch (err) {
                console.log(err)
                interaction.followUp({
                    content: `\`❌\` Ocorre um erro...`,
                    ephemeral: true
                })
            }
        }

        if (interaction.isStringSelectMenu() && interaction.customId === `appsconfig`) {
            const msgs = await interaction.update({
                content: `⏳ Carregando...`,
                embeds: [],
                components: []
            });
            const ids = interaction.values[0];
            editSquareCloud(ids);
        }

        async function editSquareCloud(ids) {
            const auto = db2.get(ids);

            if (!auto) {
                console.error(`\`❌\` Application data not found for ID: ${ids}`);
                return;
            }

            const api1 = new SquareCloudAPI(api.get(`square`));
            const application = await api1.applications.get(ids);

            const { produto, nome, dataExpiracao } = auto;
            const status = await application.getStatus();

            const timestamp = Math.floor(new Date(dataExpiracao).getTime() / 1000);

            const tokenbot = db2.get(`${ids}.token`);

            const response = await axios.get("https://discord.com/api/v10/users/@me", {
                headers: {
                    Authorization: `Bot ${tokenbot}`
                }
            }).catch(() => { });

            let addBotButton;
            if (response && response.data && response.data.id) {
                addBotButton = new ButtonBuilder()
                    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${response.data.id}&permissions=8&scope=bot`)
                    .setLabel(`Adicionar Aplicação`)
                    .setEmoji(`➕`)
                    .setStyle(5);
            } else {
                addBotButton = new ButtonBuilder()
                    .setCustomId(`donthavetoken`)
                    .setLabel(`Token não configurado`)
                    .setEmoji(`➕`)
                    .setStyle(2)
                    .setDisabled(true);
            }

            await interaction.editReply({
                content: "",
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando ${nome}`, iconURL: 'https://cdn.discordapp.com/avatars/1394084878202572961/e5e4730833f74cb21cbf0af6c9454744.webp?size=1024' })
                        .addFields(
                            {
                                name: `🛡️ | Aplicação atual`,
                                value: `\`${db2.get(`${ids}.nome`)}\``,
                                inline: true
                            },
                            {
                                name: `⏰ | Uptime da Aplicação`,
                                value: `${status.uptimeTimestamp === undefined ? `\`🔴 Bot está desligado.\`` : `<t:${Math.floor(status.uptimeTimestamp / 1000)}:R>`}`,
                                inline: true
                            },
                            {
                                name: `🌐 | Status da Aplicação`,
                                value: `${status.status === `running` ? `\`🟢 Online\`` : `\`🔴 Offline\``}`,
                                inline: true
                            },
                            {
                                name: `🛠️ | ID da Aplicação`,
                                value: `\`${db2.get(`${ids}.idapp`)}\``,
                                inline: false
                            },
                            {
                                name: `☁️ | Plano atual`,
                                value: `\`${db2.get(`${ids}.plano`)} | ${db2.get(`${ids}.dias`)}d\``,
                                inline: false
                            },
                            {
                                name: `⏰ | Aluguel Termina`,
                                value: `<t:${timestamp}:f> (<t:${timestamp}:R>)`,
                                inline: false
                            }
                        )
                        .setColor(`#00FFFF`)
                        .setFooter({ text: `${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(new StringSelectMenuBuilder()
                            .setCustomId(`appsconfig`)
                            .setPlaceholder(`📡 - Outras Aplicações`)
                            .addOptions([{
                                label: `${nome} - ${ids}`,
                                description: `${produto}`,
                                value: `${ids}`,
                                emoji: '🤖'
                            }])
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${status.status !== `running` ? `${ids}_ligarapp` : `${ids}_desligarapp`}`)
                                .setLabel(`${status.status !== `running` ? `Ligar App` : `Desligar App`}`)
                                .setEmoji(`🎫`)
                                .setStyle(`${status.status !== `running` ? 3 : 4}`),
                            new ButtonBuilder()
                                .setCustomId(`${ids}_reiniciarapp`)
                                .setLabel(`Reiniciar Aplicação`)
                                .setStyle(1)
                                .setEmoji(`📦`),
                            new ButtonBuilder()
                                .setCustomId(`${ids}_outrasapp`)
                                .setLabel(`Outras Ações`)
                                .setStyle(1)
                                .setEmoji(`💳`),
                            new ButtonBuilder()
                                .setCustomId(`${ids}_removerapp`)
                                .setLabel(`Remover Bot`)
                                .setStyle(4)
                                .setEmoji(`🗑️`)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`${produto}_${ids}_renovApp`)
                                .setLabel(`Renovar App`)
                                .setStyle(1)
                                .setEmoji(`💰`)
                                .setDisabled(!api.get("mp")),
                            addBotButton
                        )
                ]
            });
        };
    }
}