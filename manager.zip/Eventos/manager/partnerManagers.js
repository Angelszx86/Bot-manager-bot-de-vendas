const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags, ModalBuilder,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder, TextInputBuilder, TextInputStyle
}=require('discord.js');
const partners=require('../../Lib/partnerManagers');
const panel=require('../../Lib/partnerManagerPanel');
const { isOwner } = require('../../Lib/permissions');
function field(id,label,placeholder='',required=true,max=1000){return new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label.slice(0,45)).setStyle(TextInputStyle.Short).setRequired(required).setMaxLength(Math.min(4000,max)).setPlaceholder(placeholder.slice(0,100)));}
function registerModal(){return new ModalBuilder().setCustomId('partner:register:modal').setTitle('Cadastrar Manager parceiro').addComponents(field('token','Token do bot Manager','Cole o token da aplicação',true,1000),field('owner','ID do proprietário','123456789012345678',true,22));}
function ownedManagers(userId){return partners.list().filter(x=>String(x.ownerId)===String(userId));}
function picker(interaction,items){
  if(!items.length)return {content:'Você ainda não possui nenhum Manager parceiro cadastrado.',flags:MessageFlags.Ephemeral};
  const select=new StringSelectMenuBuilder().setCustomId('partner:manage:select').setPlaceholder('Escolha seu Manager').setMinValues(1).setMaxValues(1).addOptions(...items.slice(0,25).map(x=>new StringSelectMenuOptionBuilder().setLabel(`${x.botUsername} • ${x.processOnline?'online':'offline'}`.slice(0,100)).setDescription(`${x.online}/${x.total} aplicações online`.slice(0,100)).setValue(x.id)));
  return {content:'Escolha o Manager que deseja administrar.',components:[new ActionRowBuilder().addComponents(select)],flags:MessageFlags.Ephemeral};
}
async function safeAck(i){if(i.isButton?.()||i.isAnySelectMenu?.()){if(!i.deferred&&!i.replied)await i.deferUpdate().catch(()=>null);}else if(!i.deferred&&!i.replied)await i.deferReply({flags:MessageFlags.Ephemeral}).catch(()=>null);}
module.exports={
  name:'interactionCreate',
  run:async(interaction,client)=>{
    const id=String(interaction.customId||''); if(!id.startsWith('partner:'))return;
    try{
      if(id==='partner:admin:publish-channel'&&interaction.isChannelSelectMenu()){
        if(!isOwner(interaction.user.id))throw new Error('Somente um proprietário do Manager original pode publicar este painel.');
        await interaction.deferReply({flags:MessageFlags.Ephemeral});
        const channel=await interaction.guild.channels.fetch(interaction.values[0]); if(!channel?.isTextBased?.()||!channel.send)throw new Error('Selecione um canal de texto válido.');
        await channel.send(panel.publicPayload(interaction.guildId));
        return interaction.editReply('Painel de Managers parceiros publicado com sucesso.');
      }
      if(id==='partner:admin:refresh'&&interaction.isButton()){
        if(!isOwner(interaction.user.id))throw new Error('Acesso restrito.'); await safeAck(interaction); return interaction.editReply(panel.adminPayload(interaction.guildId));
      }
      if(id==='partner:admin:withdrawals'&&interaction.isButton()){
        if(!isOwner(interaction.user.id))throw new Error('Acesso restrito.'); await safeAck(interaction); return interaction.editReply(panel.withdrawalsPayload(interaction.guildId));
      }
      if(id==='partner:admin:withdrawal-select'&&interaction.isStringSelectMenu()){
        if(!isOwner(interaction.user.id))throw new Error('Acesso restrito.'); await safeAck(interaction); const wd=partners.withdrawals().find(x=>x.id===interaction.values[0]); if(!wd)throw new Error('Saque não encontrado.'); return interaction.editReply(panel.withdrawalDetailPayload(interaction.guildId,wd));
      }
      const wdAction=id.match(/^partner:admin:withdrawal:(approve|reject):(.+)$/);
      if(wdAction&&interaction.isButton()){
        if(!isOwner(interaction.user.id))throw new Error('Acesso restrito.'); await safeAck(interaction);
        const [,op,wdId]=wdAction; const wd=partners.withdrawals().find(x=>x.id===wdId); if(!wd)throw new Error('Saque não encontrado.');
        if(op==='approve') partners.store.updateWithdrawal(wdId,{status:'APPROVED',approvedAt:new Date().toISOString(),approvedBy:interaction.user.id});
        else { const rec=partners.get(wd.managerId); if(rec) partners.patch(wd.managerId,{balanceCents:(rec.balanceCents||0)+(wd.amountCents||0)}); partners.store.updateWithdrawal(wdId,{status:'REJECTED',rejectedAt:new Date().toISOString(),rejectedBy:interaction.user.id}); }
        return interaction.editReply(panel.withdrawalsPayload(interaction.guildId));
      }
      if(id==='partner:admin:select'&&interaction.isStringSelectMenu()){
        if(!isOwner(interaction.user.id))throw new Error('Acesso restrito.'); await safeAck(interaction); const rec=partners.get(interaction.values[0]); if(!rec)throw new Error('Manager não encontrado.'); return interaction.editReply(panel.managePayload(interaction.guildId,rec,true));
      }
      if(id==='partner:register'&&interaction.isButton()) return interaction.showModal(registerModal());
      if(id==='partner:register:modal'&&interaction.isModalSubmit()){
        await interaction.deferReply({flags:MessageFlags.Ephemeral});
        const token=interaction.fields.getTextInputValue('token').trim(); let requestedOwner=interaction.fields.getTextInputValue('owner').trim();
        if(!/^\d{15,22}$/.test(requestedOwner))return interaction.editReply('ID do proprietário inválido.');
        if(!isOwner(interaction.user.id)&&requestedOwner!==String(interaction.user.id)) requestedOwner=String(interaction.user.id);
        const rec=await partners.create({token,ownerId:requestedOwner});
        return interaction.editReply({content:`Manager **${rec.botUsername}** cadastrado e iniciado. O token foi salvo de forma protegida e não será exibido novamente.`,components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`partner:action:logs:${rec.id}`).setLabel('Ver logs').setStyle(ButtonStyle.Secondary))]});
      }
      if(id==='partner:manage'&&interaction.isButton()) return interaction.reply(picker(interaction,ownedManagers(interaction.user.id)));
      if(id==='partner:manage:select'&&interaction.isStringSelectMenu()){
        await safeAck(interaction); const rec=partners.get(interaction.values[0]); if(!rec||String(rec.ownerId)!==String(interaction.user.id))throw new Error('Manager não encontrado ou sem permissão.'); return interaction.editReply(panel.managePayload(interaction.guildId,rec,false));
      }
      const action=id.match(/^partner:action:(start|restart|stop|logs|delete):(.+)$/); if(action){
        const [,op,managerId]=action; const rec=partners.get(managerId); const admin=isOwner(interaction.user.id); if(!rec||(!admin&&String(rec.ownerId)!==String(interaction.user.id)))throw new Error('Manager não encontrado ou sem permissão.');
        await safeAck(interaction);
        if(op==='start'){const r=await partners.start(managerId); if(!r.ok)throw new Error(r.msg);}
        if(op==='restart'){const r=await partners.restart(managerId); if(!r.ok)throw new Error(r.msg);}
        if(op==='stop')await partners.stop(managerId);
        if(op==='delete'){await partners.remove(managerId,{removeApps:true}); return interaction.editReply({content:'Manager parceiro removido. Aplicações vinculadas foram encerradas e apagadas.',components:[],embeds:[]});}
        if(op==='logs'){
          const text=partners.readLogs(managerId,80).slice(-3800).replace(/```/g,'');
          const embed=new EmbedBuilder().setTitle(`Logs • ${rec.botUsername}`).setDescription(`\`\`\`\n${text||'Nenhum log disponível.'}\n\`\`\``).setColor(0x3155ff);
          return interaction.editReply({content:'',embeds:[embed],components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(admin?'partner:admin:refresh':'partner:manage').setLabel('Voltar').setStyle(ButtonStyle.Secondary))]});
        }
        const updated=partners.get(managerId); return interaction.editReply(panel.managePayload(interaction.guildId,updated,admin));
      }
    }catch(error){
      const message=`❌ ${String(error?.message||error).slice(0,1800)}`;
      if(interaction.deferred)return interaction.editReply({content:message,components:[],embeds:[]}).catch(()=>null);
      if(interaction.replied)return interaction.followUp({content:message,flags:MessageFlags.Ephemeral}).catch(()=>null);
      return interaction.reply({content:message,flags:MessageFlags.Ephemeral}).catch(()=>null);
    }
  }
};
