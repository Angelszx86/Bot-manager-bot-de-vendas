const {
  ModalBuilder,
  TextInputBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MessageFlags
} = require('discord.js');
const { JsonDatabase } = require('wio.db');
const { resolveTemplate } = require('../../Lib/templates');
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const { auto, db2 } = require('../../databases');
const { readCache, fmt, id: emojiId } = require('../../Lib/managerEmojis');
const JSZip = require('jszip');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const referrals = require('../../Lib/referrals');
const trialSettings = require('../../Lib/trialSettings');
const { getBotIdentity, getApplication, validateGuildMembership, messageContentIntent, waitForRuntimeGuildReady } = require('../../Lib/discordChildValidation');

const trials = new JsonDatabase({ databasePath: path.join(__dirname, '../../databases/trials.json') });
const config = require('../../databases/config.json');
const busy = new Set();
const threadLocks = new Map();
// Sessão de formulário é separada do banco de trials. Um usuário NÃO ganha
// trial só por abrir thread/select/modal. O registro definitivo só é gravado
// depois que token + guild são validados e o processo filho está vivo.
const pendingSessions = new Map();
const SESSION_TTL = 20 * 60 * 1000;
const purchaseReviewers = require('../../Lib/purchaseReviewers');

function withEmoji(builder, value) {
  if (value) builder.setEmoji(typeof value === 'string' && /^\d{15,25}$/.test(value) ? { id: value } : value);
  return builder;
}
function cacheFor(interaction) { return readCache(interaction.guildId); }
function icon(interaction, key) { return fmt(cacheFor(interaction), key); }
function randomId(bytes = 6) { return crypto.randomBytes(bytes).toString('hex'); }
function now() { return Date.now(); }
function fresh(session) { return session && now() - session.createdAt < SESSION_TTL; }
function cleanSession(userId) {
  const session = pendingSessions.get(userId);
  if (session && !fresh(session)) pendingSessions.delete(userId);
  return fresh(session) ? session : null;
}

function isReferralSession(session) { return session?.source === 'referral'; }
function sessionMinutes(session) { return Math.max(1, Math.trunc(Number(session?.durationMinutes) || trialSettings.settings().durationMinutes)); }
function sessionDurationLabel(session) { return referrals.formatMinutes(sessionMinutes(session)); }

function trialModal(sessionId, nonce, durationLabel = trialSettings.label()) {
  return new ModalBuilder()
    .setCustomId(`zenyx_trial_submit:${sessionId}:${nonce}`.slice(0, 100))
    .setTitle(`Teste da aplicação • ${String(durationLabel).slice(0, 24)}`)
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('tokenapp')
          .setLabel('Token do seu bot')
          .setPlaceholder('Cole somente o token do bot de teste')
          .setStyle(1)
          .setRequired(true)
          .setMaxLength(200)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('guildapp')
          .setLabel('ID do servidor do seu bot')
          .setPlaceholder('Exemplo: 123456789012345678')
          .setStyle(1)
          .setRequired(true)
          .setMinLength(17)
          .setMaxLength(20)
      )
    );
}

async function configuredZip(token, botId, ownerId, guildId) {
  const template = resolveTemplate('ZenyxPro');
  if (!template?.file || !fs.existsSync(template.file)) throw new Error('Template da aplicação não encontrado');
  const zip = await JSZip.loadAsync(fs.readFileSync(template.file));
  zip.file('Token.json', JSON.stringify({ token }, null, 2));

  const runtimeFile = zip.file('config/runtime.json');
  if (!runtimeFile) throw new Error('config/runtime.json ausente no template da aplicação');
  const runtime = JSON.parse(await runtimeFile.async('string'));
  Object.assign(runtime, {
    clientId: botId,
    ownerIds: [String(ownerId)],
    guildId: String(guildId),
    // Trial sempre inicia em modo compatível. Recursos que dependem de intents
    // privilegiados podem ser ativados depois pelo dono no Developer Portal.
    privilegedIntents: false
  });
  zip.file('config/runtime.json', JSON.stringify(runtime, null, 2));
  return zip.generateAsync({ type: 'nodebuffer' });
}

function threadName(user) {
  const safe = (user?.username || 'usuario')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 70) || 'usuario';
  return `teste-${safe}`.slice(0, 100);
}

function trialMenuCustomId(sessionId) {
  return `select_tipo_bot_trial:${sessionId}:${randomId(3)}`.slice(0, 100);
}
function parseSelectSession(customId) {
  if (!customId?.startsWith('select_tipo_bot_trial:')) return null;
  return customId.split(':')[1] || null;
}
function parseSubmit(customId) {
  if (!customId?.startsWith('zenyx_trial_submit:')) return null;
  const [, sessionId, nonce] = customId.split(':');
  return sessionId && nonce ? { sessionId, nonce } : null;
}

function trialSelectRow(interaction, sessionId) {
  // O seletor do trial é uma etapa crítica. Emojis customizados antigos ou sem
  // acesso pela aplicação fazem o Discord rejeitar a mensagem inteira com
  // Invalid Form Body. Por isso esta UI usa somente texto/Unicode no componente.
  const option = new StringSelectMenuOptionBuilder()
    .setLabel('Zenyx Sellers • Teste')
    .setDescription('Informe token e servidor na próxima etapa')
    .setValue('ZenyxPro');

  const select = new StringSelectMenuBuilder()
    .setCustomId(trialMenuCustomId(sessionId))
    .setPlaceholder('Selecione a aplicação para continuar')
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(option);
  return new ActionRowBuilder().addComponents(select);
}

function trialThreadPayload(interaction, sessionId, includeFlags = true) {
  const activeSession = cleanSession(interaction.user.id);
  const durationLabel = sessionDurationLabel(activeSession);
  const container = new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## 🧪 Teste gratuito • ${durationLabel}`),
      new TextDisplayBuilder().setContent(
        `Olá ${interaction.user}. **Nenhuma aplicação foi criada ainda.**\n\n` +
        `### Como continuar\n` +
        `1. Selecione **Zenyx Sellers • Teste** abaixo.\n` +
        `2. Informe o **token do seu bot** e o **ID do servidor** no formulário.\n` +
        `3. O Manager valida os dados e confirma o bot no servidor.\n` +
        `4. Só depois da validação o período de teste começa.\n\n` +
        `Se fechar o formulário, você pode usar este menu novamente.`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addActionRowComponents(trialSelectRow(interaction, sessionId))
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`trial_close:${interaction.user.id}`)
        .setLabel('Fechar tópico')
        .setStyle(ButtonStyle.Danger)
    ));
  const payload = { components: [container], allowedMentions: { parse: [] } };
  if (includeFlags) payload.flags = MessageFlags.IsComponentsV2;
  return payload;
}

function trialLegacyPayload(interaction, sessionId) {
  const activeSession = cleanSession(interaction.user.id);
  const durationLabel = sessionDurationLabel(activeSession);
  const close = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`trial_close:${interaction.user.id}`)
      .setLabel('Fechar tópico')
      .setStyle(ButtonStyle.Danger)
  );
  return {
    embeds: [new EmbedBuilder()
      .setTitle(`🧪 Teste gratuito • ${durationLabel}`)
      .setDescription(
        `Olá ${interaction.user}. **Nenhuma aplicação foi criada ainda.**\n\n` +
        `**1.** Selecione **Zenyx Sellers • Teste** abaixo.\n` +
        `**2.** Informe o token do bot e o ID do servidor.\n` +
        `**3.** O Manager valida tudo antes de iniciar o teste.\n\n` +
        `Se fechar o formulário, o menu continua disponível.`
      )],
    components: [trialSelectRow(interaction, sessionId), close],
    allowedMentions: { parse: [] }
  };
}

async function sendTrialPanel(thread, interaction, session) {
  let firstError = null;
  try {
    const sent = await thread.send(trialThreadPayload(interaction, session.id, true));
    if (sent?.id) return sent;
  } catch (error) {
    firstError = error;
    require('../../Lib/interactions').logError(error, 'trial-panel-v2');
  }

  // Fallback compatível: se Components V2 for rejeitado por versão do Discord,
  // payload antigo ou qualquer validação de componente, ainda entregamos o
  // embed + menu select funcional no MESMO tópico, sem criar outro trial.
  try {
    const sent = await thread.send(trialLegacyPayload(interaction, session.id));
    if (sent?.id) return sent;
  } catch (error) {
    require('../../Lib/interactions').logError(error, 'trial-panel-legacy');
    const detail = String(error?.message || firstError?.message || error || firstError || 'Falha desconhecida').slice(0, 300);
    throw new Error(`O tópico foi criado, mas o painel do teste não pôde ser enviado: ${detail}`);
  }
  throw firstError || new Error('O painel do teste não retornou uma mensagem válida.');
}

function trialFinishedPayload(interaction, appId, sessionOverride = null) {
  const emojis = cacheFor(interaction);
  const activeSession = sessionOverride || cleanSession(interaction.user.id);
  const durationLabel = sessionDurationLabel(activeSession);
  const container = new ContainerBuilder()
    .setAccentColor(0x57F287)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${fmt(emojis, 'success')} Aplicação online`),
      new TextDisplayBuilder().setContent(
        `O token e o servidor foram validados e a instância de ${interaction.user} está com processo ativo.\n` +
        `Runtime: \`${appId}\`\n` +
        `Validade deste teste: **${durationLabel}**. Use **/apps** para status e logs.`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(withEmoji(new ButtonBuilder().setCustomId(`trial_close:${interaction.user.id}`).setLabel('Fechar tópico').setStyle(ButtonStyle.Secondary), emojiId(emojis,'lock',null))));
  return { components: [container] };
}

async function cleanupLegacyTrialMessages(thread, clientId) {
  if (!thread?.messages?.fetch) return;
  const msgs = await thread.messages.fetch({ limit: 50 }).catch(() => null);
  if (!msgs) return;
  for (const msg of msgs.values()) {
    if (msg.author?.id !== clientId) continue;
    const componentText = (() => { try { return JSON.stringify((msg.components || []).map(c => c?.toJSON ? c.toJSON() : c)); } catch { return ''; } })();
    const text = [msg.content, ...msg.embeds.map(e => `${e.title || ''} ${e.description || ''}`), componentText].join(' ');
    if (/(NexusPro|Astra Application online|Teste Astra Application|Nada foi provisionado|provisionado|select_tipo_bot_trial|trial_close)/i.test(text)) await msg.delete().catch(() => null);
  }
}

async function findExistingTrialThread(interaction) {
  const channel = interaction.channel;
  if (!channel?.threads) return null;
  const pending = cleanSession(interaction.user.id);
  if (pending?.threadId) {
    let byId = channel.threads.cache.get(pending.threadId) || interaction.guild?.channels?.cache?.get(pending.threadId);
    if (!byId && interaction.guild?.channels?.fetch) byId = await interaction.guild.channels.fetch(pending.threadId).catch(() => null);
    if (byId?.isThread?.() && !byId.archived) return byId;
  }
  const fetched = await channel.threads.fetchActive().catch(() => null);
  const collections = [channel.threads.cache, fetched?.threads, fetched].filter(c => c?.find);
  for (const collection of collections) {
    const match = collection.find(t => t?.name === threadName(interaction.user) && !t.archived);
    if (match) return match;
  }
  return null;
}

function linkRow(interaction, url, label) {
  const emojis = cacheFor(interaction);
  const button = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(url).setLabel(label);
  withEmoji(button, emojiId(emojis, 'link', null));
  return new ActionRowBuilder().addComponents(button);
}

function hasDeliveredTrial(userId) {
  const previous = trials.get(userId);
  // Trial gratuito é um benefício de uso único. Depois que uma instância foi
  // validada e registrada como entregue, remover o runtime NÃO devolve outro
  // período de 24h. Só registros que nunca chegaram ao estado delivered podem
  // ser ignorados como tentativas antigas/incompletas.
  if (previous && (previous.status === 'delivered' || previous.consumedAt || previous.deliveredAt)) return true;
  const ownerApps = auto.get(`${userId}_owner.butecos`) || [];
  return ownerApps.some(app => app?.plano === 'Grátis' && app?.idapp && db2.get(String(app.idapp)));
}

function deliveredTrialAppId(userId) {
  const previous = trials.get(userId);
  if (previous?.idapp && db2.get(String(previous.idapp))) return String(previous.idapp);
  const ownerApps = auto.get(`${userId}_owner.butecos`) || [];
  const found = ownerApps.find(app => app?.plano === 'Grátis' && app?.idapp && db2.get(String(app.idapp)));
  return found?.idapp ? String(found.idapp) : null;
}

async function createTrialThread(interaction) {
  const userId = interaction.user.id;
  const requestedSession = cleanSession(userId);
  const referralMode = isReferralSession(requestedSession);
  if (!interaction.guild || !interaction.channel?.threads?.create) {
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} O teste precisa ser iniciado em um canal de texto do servidor.` });
  }

  const existing = await findExistingTrialThread(interaction);
  if (existing) {
    await purchaseReviewers.addToThread(existing, { includeBuyerId: userId }).catch(() => null);
    await cleanupLegacyTrialMessages(existing, interaction.client.user.id);
    if (!referralMode && hasDeliveredTrial(userId)) {
      pendingSessions.delete(userId);
      const appId = deliveredTrialAppId(userId);
      if (appId) await existing.send({ ...trialFinishedPayload(interaction, appId), flags: MessageFlags.IsComponentsV2 }).catch(() => null);
      return interaction.editReply({ content: `${icon(interaction, 'info')} Seu trial já está registrado. O tópico foi limpo e agora mostra somente o estado atual: ${existing.url}`, components: [linkRow(interaction, existing.url, 'Abrir status do trial')] });
    }
    let session = cleanSession(userId);
    const needsFreshPanel = !session || session.threadId !== existing.id || !session.menuMessageId;
    if (!session || session.threadId !== existing.id) {
      session = { id: randomId(), userId, threadId: existing.id, menuMessageId: null, createdAt: now(), modalNonce: null, source: requestedSession?.source || 'free', durationMinutes: sessionMinutes(requestedSession) };
      pendingSessions.set(userId, session);
    }
    if (needsFreshPanel) {
      const freshMessage = await sendTrialPanel(existing, interaction, session).catch(() => null);
      if (freshMessage?.id) session.menuMessageId = freshMessage.id;
    } else {
      await refreshTrialMenu(interaction, session).catch(() => null);
    }
    return interaction.editReply({
      content: `${icon(interaction, 'science')} Seu tópico já existia e recebeu o **painel R11 atualizado**. Nada foi provisionado até você concluir token + servidor: ${existing.url}`,
      components: [linkRow(interaction, existing.url, 'Continuar configuração')]
    });
  }

  if (!referralMode && hasDeliveredTrial(userId)) {
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} Você já utilizou seu teste gratuito. Este benefício é de uso único. Use **/apps** para acompanhar a aplicação existente.` });
  }

  const me = interaction.guild.members.me;
  const permissions = interaction.channel.permissionsFor(me);
  const canPrivate = Boolean(permissions?.has(PermissionFlagsBits.CreatePrivateThreads));
  const canPublic = Boolean(permissions?.has(PermissionFlagsBits.CreatePublicThreads));
  const canSendThread = Boolean(permissions?.has(PermissionFlagsBits.SendMessagesInThreads));
  if (!canSendThread || (!canPrivate && !canPublic)) {
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} O **Manager** precisa de **Criar Tópicos Privados** (ou públicos) e **Enviar Mensagens em Tópicos** neste canal. O usuário comum não precisa receber permissão administrativa.` });
  }

  let thread;
  let privateThread = false;
  try {
    if (canPrivate) {
      try {
        thread = await interaction.channel.threads.create({
          name: threadName(interaction.user),
          type: ChannelType.PrivateThread,
          autoArchiveDuration: 60,
          invitable: true,
          reason: `Configuração do trial por ${interaction.user.tag || interaction.user.username}`
        });
        await thread.members.add(userId);
        await purchaseReviewers.addToThread(thread, { includeBuyerId: userId });
        privateThread = true;
      } catch (privateError) {
        require('../../Lib/interactions').logError(privateError, 'trial-private-thread');
        if (thread?.deletable) await thread.delete('Fallback do trial').catch(() => null);
        thread = null;
      }
    }
    if (!thread && canPublic) {
      thread = await interaction.channel.threads.create({
        name: threadName(interaction.user),
        type: ChannelType.PublicThread,
        autoArchiveDuration: 60,
        reason: `Fallback público do trial por ${interaction.user.tag || interaction.user.username}`
      });
      await purchaseReviewers.addToThread(thread, { includeBuyerId: userId });
    }
    if (!thread) throw new Error('Nenhum tipo de tópico pôde ser criado.');
  } catch (error) {
    require('../../Lib/interactions').logError(error, 'trial-thread');
    if (thread?.deletable) await thread.delete('Falha ao preparar trial').catch(() => null);
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} Não consegui abrir o tópico de configuração. Revise as permissões do Manager neste canal.` });
  }

  const session = { id: randomId(), userId, threadId: thread.id, menuMessageId: null, createdAt: now(), modalNonce: null, privateThread, source: requestedSession?.source || 'free', durationMinutes: sessionMinutes(requestedSession) };
  pendingSessions.set(userId, session);
  let menuMessage;
  try {
    menuMessage = await sendTrialPanel(thread, interaction, session);
    session.menuMessageId = menuMessage.id;
  } catch (panelError) {
    require('../../Lib/interactions').logError(panelError, 'trial-panel-final');
    pendingSessions.delete(userId);
    // Nunca deixe um tópico vazio parecendo checkout quebrado. Se até o fallback
    // falhar, arquivamos o tópico e devolvemos uma mensagem clara ao usuário.
    await thread.send({ content: '⚠️ Não consegui carregar o painel do teste. Nenhum teste foi consumido. Tente novamente em alguns instantes.' }).catch(() => null);
    setTimeout(() => thread.setArchived?.(true, 'Falha ao carregar painel do trial').catch(() => null), 1200);
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} Não consegui carregar o painel de teste. **Seu benefício não foi consumido.** Tente novamente; nenhum novo tópico será reaproveitado como trial ativo.` });
  }

  const logChannel = config.logs_trial ? interaction.guild.channels.cache.get(config.logs_trial) : null;
  if (logChannel?.isTextBased()) {
    logChannel.send({
      embeds: [new EmbedBuilder()
        .setTitle('ASTRA APPLICATION • Configuração de trial aberta')
        .setDescription(`Usuário ${interaction.user} abriu ${thread}. **Nenhuma instância foi criada ainda.**`)
        .setColor('#3155ff')
        .setTimestamp()]
    }).catch(() => null);
  }

  return interaction.editReply({
    content: `${icon(interaction, 'success')} Tópico de configuração criado: ${thread.url}${privateThread ? '' : '\nFoi usado tópico público por limitação de permissão; token e IDs continuam sendo enviados apenas no modal efêmero.'}`,
    components: [linkRow(interaction, thread.url, 'Configurar aplicação')]
  });
}

async function openTrialThread(interaction) {
  if (!interaction.deferred && !interaction.replied) await interaction.deferReply({ flags: 64 });
  const userId = interaction.user.id;
  const current = threadLocks.get(userId);
  if (current) {
    await current.catch(() => null);
    const existing = await findExistingTrialThread(interaction);
    if (existing) { await cleanupLegacyTrialMessages(existing, interaction.client.user.id); return interaction.editReply({ content: `${icon(interaction, 'science')} Seu tópico já está aberto: ${existing.url}`, components: [linkRow(interaction, existing.url, 'Abrir configuração')] }); }
    return interaction.editReply({ content: `${icon(interaction, 'loading')} O tópico ainda está sendo preparado.` });
  }
  const task = createTrialThread(interaction);
  threadLocks.set(userId, task);
  try { return await task; }
  finally { if (threadLocks.get(userId) === task) threadLocks.delete(userId); }
}

async function openReferralTrialThread(interaction, durationMinutes) {
  const minutes = Math.max(1, Math.trunc(Number(durationMinutes) || 0));
  const cfg = referrals.settings(interaction.guildId);
  const st = referrals.stats(interaction.guildId, interaction.user.id);
  if (!cfg.enabled) {
    if (!interaction.replied && !interaction.deferred) return interaction.reply({ content: `${icon(interaction, 'warn')} O programa de indicação está desativado.`, flags: 64 });
    return interaction.editReply({ content: `${icon(interaction, 'warn')} O programa de indicação está desativado.` });
  }
  if (st.remainingMinutes < minutes) {
    if (!interaction.replied && !interaction.deferred) return interaction.reply({ content: `${icon(interaction, 'wrong')} Seu saldo de indicação mudou e não é mais suficiente.`, flags: 64 });
    return interaction.editReply({ content: `${icon(interaction, 'wrong')} Seu saldo de indicação mudou e não é mais suficiente.` });
  }
  const activeReferral = (auto.get(`${interaction.user.id}_owner.butecos`) || []).find(app => app?.plano === 'Indicação' && app?.idapp && db2.get(String(app.idapp)) && Date.parse(db2.get(`${app.idapp}.dataExpiracao`) || '') > Date.now() && String(db2.get(`${app.idapp}.status`) || '').toLowerCase() !== 'expired');
  if (activeReferral) {
    if (!interaction.replied && !interaction.deferred) return interaction.reply({ content: `${icon(interaction, 'info')} Você já possui um teste por indicação ativo: \`${activeReferral.idapp}\`. Use **/apps** para acompanhar.`, flags: 64 });
    return interaction.editReply({ content: `${icon(interaction, 'info')} Você já possui um teste por indicação ativo: \`${activeReferral.idapp}\`.` });
  }
  pendingSessions.set(interaction.user.id, { id: randomId(), userId: interaction.user.id, threadId: '', menuMessageId: null, createdAt: now(), modalNonce: null, source: 'referral', durationMinutes: minutes });
  return openTrialThread(interaction);
}

async function getMenuMessage(interaction, session) {
  if (!session?.menuMessageId) return null;
  const channel = interaction.channel?.isThread?.() ? interaction.channel : await interaction.guild?.channels?.fetch(session.threadId).catch(() => null);
  if (!channel?.messages?.fetch) return null;
  return channel.messages.fetch(session.menuMessageId).catch(() => null);
}

async function refreshTrialMenu(interaction, session) {
  const message = interaction.message?.edit ? interaction.message : await getMenuMessage(interaction, session);
  if (message?.edit) {
    try {
      await message.edit(trialThreadPayload(interaction, session.id, false));
      return message;
    } catch (error) {
      require('../../Lib/interactions').logError(error, 'trial-menu-reset');
    }
  }
  const channel = interaction.channel?.isThread?.()
    ? interaction.channel
    : await interaction.guild?.channels?.fetch(session.threadId).catch(() => null);
  if (!channel?.send) return null;
  const replacement = await sendTrialPanel(channel, interaction, session).catch(() => null);
  if (replacement?.id) session.menuMessageId = replacement.id;
  return replacement;
}


async function healthCheck(api, appId, { token = '', guildId = '', botId = '' } = {}) {
  const app = await api.applications.get(appId);
  await new Promise(resolve => setTimeout(resolve, 1200));
  const status = await app.getStatus();
  if (!status?.pid || Number(status.pid) <= 0) throw new Error('O processo da aplicação não permaneceu ativo após a inicialização.');
  await waitForRuntimeGuildReady(api, appId, { timeoutMs: 60000, token, guildId, botId });
  return status;
}

module.exports = {
  name: 'interactionCreate',
  trialModal,
  configuredZip,
  openTrialThread,
  openReferralTrialThread,
  trialThreadPayload,
  trialLegacyPayload,
  sendTrialPanel,

  async run(interaction) {
    const id = interaction.customId;
    const isTrialSelect = id === 'select_tipo_bot_trial' || id?.startsWith('select_tipo_bot_trial:');
    const isTrialSubmit = id === 'zenyx_trial_submit' || id?.startsWith('zenyx_trial_submit:');
    const isTrialClose = id?.startsWith('trial_close:');
    if (!['botfree'].includes(id) && !isTrialSubmit && !isTrialSelect && !isTrialClose && !id?.endsWith('_uparbot_modalfree')) return;
    if (isTrialClose) {
      const expected=id.split(':')[1]; if(expected!==interaction.user.id) return interaction.reply({content:'Este tópico pertence a outro usuário.',flags:64});
      if(!interaction.channel?.isThread?.()) return interaction.reply({content:'Este botão só funciona dentro do tópico de teste.',flags:64});
      pendingSessions.delete(interaction.user.id);
      await interaction.reply({content:`${icon(interaction,'success')} Tópico fechado. Você poderá voltar ao painel de teste quando precisar.`,flags:64});
      setTimeout(()=>{ interaction.channel.setLocked?.(true,'Fechado pelo usuário').catch(()=>null); interaction.channel.setArchived?.(true,'Fechado pelo usuário').catch(()=>null); },700);
      return;
    }
    if (id === 'botfree') return openTrialThread(interaction);

    const userId = interaction.user.id;

    if (isTrialSelect) {
      if (!interaction.isStringSelectMenu()) return;
      const selected = interaction.values?.[0];
      if (!['ZenyxPro', 'NexusPro'].includes(selected)) return interaction.reply({ content: 'Este produto não está disponível para trial.', flags: 64 });
      if (!interaction.channel?.isThread?.()) return interaction.reply({ content: `${icon(interaction, 'wrong')} Use esta opção dentro do tópico privado de teste.`, flags: 64 });

      const sessionFromId = parseSelectSession(id);
      let session = cleanSession(userId);
      if (!isReferralSession(session) && hasDeliveredTrial(userId)) return interaction.reply({ content: `${icon(interaction, 'wrong')} Você já possui um trial registrado. Use **/apps** para acompanhar a instância existente.`, flags: 64 });

      // Um restart do Manager, painel duplicado ou uma sessão antiga não deve
      // deixar o select morto. Como a própria interação veio da mensagem dentro
      // do tópico acessível ao usuário, reconstruímos somente a sessão de UI.
      // Isso NÃO cria entitlement nem consome o teste.
      if (!session || session.threadId !== interaction.channelId || (sessionFromId && session.id !== sessionFromId)) {
        const previous = session;
        session = {
          id: sessionFromId || randomId(),
          userId,
          threadId: interaction.channelId,
          menuMessageId: interaction.message?.id || null,
          createdAt: now(),
          modalNonce: null,
          source: previous?.source || 'free',
          durationMinutes: sessionMinutes(previous)
        };
        pendingSessions.set(userId, session);
      }

      const nonce = randomId(5);
      session.modalNonce = nonce;
      session.menuMessageId = interaction.message?.id || session.menuMessageId || null;
      session.createdAt = now();

      // showModal precisa ser a PRIMEIRA resposta desta interação. Não fazemos
      // fetch/sync/edição remota antes nem depois dela, eliminando o select que
      // ficava carregando ou expirava antes de abrir a próxima etapa.
      return interaction.showModal(trialModal(session.id, nonce, sessionDurationLabel(session)));
    }

    if (!isTrialSubmit) {
      if (!interaction.replied && !interaction.deferred) return interaction.reply({ content: 'Use o painel de teste atualizado para continuar.', flags: 64 });
      return;
    }

    const parsed = parseSubmit(id);
    if (!parsed) return interaction.reply({ content: `${icon(interaction, 'warn')} Este formulário é de uma versão antiga. Selecione **Aplicação de teste** novamente no tópico.`, flags: 64 });
    const session = cleanSession(userId);
    if (!session || session.id !== parsed.sessionId || session.modalNonce !== parsed.nonce || session.threadId !== interaction.channelId) {
      return interaction.reply({ content: `${icon(interaction, 'warn')} Este formulário expirou ou foi substituído. Selecione **Aplicação de teste** novamente e preencha o formulário mais recente.`, flags: 64 });
    }
    if (!isReferralSession(session) && hasDeliveredTrial(userId)) return interaction.reply({ content: `${icon(interaction, 'wrong')} Você já possui um trial registrado. Use **/apps** para acompanhar a instância existente.`, flags: 64 });
    if (busy.has(userId)) return interaction.reply({ content: `${icon(interaction, 'loading')} Sua aplicação já está sendo preparada.`, flags: 64 });

    await interaction.deferReply({ flags: 64 });
    const token = interaction.fields.getTextInputValue('tokenapp').trim();
    const guildId = interaction.fields.getTextInputValue('guildapp').trim();
    if (!/^\d{17,20}$/.test(guildId)) {
      session.modalNonce = null;
      await refreshTrialMenu(interaction, session);
      return interaction.editReply({ content: `${icon(interaction, 'wrong')} ID de servidor inválido. O trial **não foi criado**; corrija e tente novamente.` });
    }

    busy.add(userId);
    let temp;
    let createdAppId = null;
    const api = new SquareCloudAPI();
    try {
      const botIdentity = await getBotIdentity(token);
      if (botIdentity.id === interaction.client.user.id) throw new Error('Use o token do bot filho, nunca o token do Manager.');
      const application = await getApplication(token);
      const contentIntent = messageContentIntent(application);
      const intentWarning = !contentIntent.ok && !contentIntent.unknown
        ? 'MESSAGE CONTENT INTENT está desativado. O bot ainda pode ser testado normalmente; apenas recursos que leem mensagens comuns, como a calculadora por texto, ficam limitados até você ativá-lo no Developer Portal.'
        : '';
      // Preflight com múltiplos endpoints e retry. Mesmo se a API REST não
      // confirmar imediatamente o guild, o trial continua até a validação final
      // do próprio runtime, evitando falso negativo logo após o convite do bot.
      await validateGuildMembership(token, guildId, botIdentity.id);

      await interaction.editReply({ content: `${icon(interaction, 'loading')} Token validado. Preparando a **aplicação** e confirmando o servidor pelo próprio runtime...` });
      const bytes = await configuredZip(token, botIdentity.id, userId, guildId);
      const dir = path.join(__dirname, '../../source/client');
      fs.mkdirSync(dir, { recursive: true });
      temp = path.join(dir, `trial-${crypto.randomUUID()}.zip`);
      fs.writeFileSync(temp, bytes, { mode: 0o600 });

      const data = await api.applications.create(temp);
      createdAppId = data.id;
      await healthCheck(api, data.id, { token, guildId, botId: botIdentity.id });

      const durationMinutes = sessionMinutes(session);
      const expiration = new Date(Date.now() + durationMinutes * 60_000);
      const record = {
        nome: botIdentity.username,
        dias: Number((durationMinutes / 1440).toFixed(4)),
        durationMinutes,
        plano: isReferralSession(session) ? 'Indicação' : 'Grátis',
        quantia: 0,
        dataExpiracao: expiration,
        idapp: data.id,
        token,
        produto: 'ZenyxPro',
        owner: userId,
        guildId,
        childClientId: botIdentity.id,
        notify: true,
        status: 'online'
      };
      db2.set(data.id, record);
      const owner = auto.get(`${userId}_owner`) || { owner: userId, butecos: [] };
      owner.butecos = [...(owner.butecos || []).filter(app => app.idapp !== data.id), record];
      auto.set(`${userId}_owner`, owner);
      if (isReferralSession(session)) {
        referrals.consumeMinutes(interaction.guildId, userId, durationMinutes, data.id);
      } else {
        trials.set(userId, {
          user: userId,
          idapp: data.id,
          product: 'ZenyxPro',
          guildId,
          childClientId: botIdentity.id,
          threadId: session.threadId,
          status: 'delivered',
          consumedAt: new Date().toISOString(),
          deliveredAt: new Date().toISOString(),
          timestamp: Date.now(),
          expiresAt: expiration.toISOString()
        });
      }
      pendingSessions.delete(userId);
      await require('../../Lib/salesFeed').announce(interaction.client,{type:'trial',user:interaction.user,guildId:interaction.guildId,plan:isReferralSession(session)?`Indicação ${sessionDurationLabel(session)}`:`Teste ${sessionDurationLabel(session)}`,days:Number((durationMinutes/1440).toFixed(4)),appId:data.id}).catch(()=>null);

      await interaction.editReply({ content: `${icon(interaction, 'success')} **Aplicação online.** Teste confirmado por **${sessionDurationLabel(session)}**. Use **/apps** para status e logs.${intentWarning ? `\n\n${icon(interaction, 'warn')} ${intentWarning}` : ''}` });
      const menuMessage = await getMenuMessage(interaction, session);
      if (menuMessage) await menuMessage.edit(trialFinishedPayload(interaction, data.id, session)).catch(() => null);
    } catch (error) {
      const { logError, safeMessage } = require('../../Lib/interactions');
      logError(error, 'trial');
      // Se chegou a criar um runtime mas a verificação final falhou, remove para
      // não deixar processo órfão nem consumir o trial do usuário.
      if (createdAppId) {
        const app = await api.applications.get(createdAppId).catch(() => null);
        await app?.delete?.().catch(() => null);
      }
      session.modalNonce = null;
      session.createdAt = now();
      await refreshTrialMenu(interaction, session);
      const detail = safeMessage(error, 650);
      const reason = detail ? `\n\nMotivo detectado:\n\`${detail.replace(/`/g, "'")}\`` : '';
      await interaction.editReply({
        content: `${icon(interaction, 'wrong')} Não foi possível concluir o trial. **Nada foi marcado como entregue.**${reason}\n\nO menu foi liberado novamente para corrigir os dados.`
      });
    } finally {
      busy.delete(userId);
      if (temp) fs.rmSync(temp, { force: true });
    }
  }
};
