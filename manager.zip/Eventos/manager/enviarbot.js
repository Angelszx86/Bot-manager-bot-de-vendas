const { SquareCloudAPI } = require('../../source/hidencloud_api');
const Discord = require('discord.js');
const JSZip = require('jszip');
const path = require('path');
const fs = require('fs');
const { EmbedBuilder } = Discord;
const { api, db2, auto, db1, logs } = require('../../databases/index');
const { readCache, fmt } = require('../../Lib/managerEmojis');
const { getBotIdentity, getApplication, validateGuildMembership, messageContentIntent, waitForRuntimeGuildReady } = require('../../Lib/discordChildValidation');
const purchaseSessions = require('../../Lib/purchaseSessions');

const BRAND_BANNER = path.join(__dirname, '../../assets/branding/astra-applications-panel.png');

function safeName(value) {
  const text = String(value || 'Aplicação').replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 40);
  return text || 'Aplicação';
}
function readJsonFromZip(zip, name) {
  const file = zip.file(name);
  return file ? file.async('string').then(text => { try { return JSON.parse(text); } catch { return {}; } }) : Promise.resolve(null);
}
async function configureZip(zip, { token, ownerId, clientId, guildId, days, expiresAt: explicitExpiresAt }) {
  const expiresAt = explicitExpiresAt ? new Date(explicitExpiresAt).toISOString() : new Date(Date.now() + Number(days) * 86400000).toISOString();

  if (zip.file('Token.json')) zip.file('Token.json', JSON.stringify({ token }, null, 2));
  if (zip.file('config/runtime.json')) {
    const current = await readJsonFromZip(zip, 'config/runtime.json') || {};
    zip.file('config/runtime.json', JSON.stringify({ ...current, clientId, guildId, ownerIds: [String(ownerId)], privilegedIntents: false }, null, 2));
  }

  for (const fileName of ['config.json', 'token.json']) {
    if (!zip.file(fileName)) continue;
    const current = await readJsonFromZip(zip, fileName) || {};
    zip.file(fileName, JSON.stringify({ ...current, token, owner: String(ownerId), botid: clientId, CLIENT_ID: clientId, guildId, EXPIRATION: expiresAt }, null, 2));
  }
  return zip;
}
async function identifyChildToken(token, managerId) {
  const me = await getBotIdentity(token);
  if (String(me.id) === String(managerId)) throw new Error('O token do Manager não pode ser usado em um bot filho. Crie/selecione outra aplicação no Discord Developer Portal.');
  const application = await getApplication(token);
  const intent = messageContentIntent(application);
  const intentWarning = !intent.ok && !intent.unknown
    ? 'MESSAGE CONTENT INTENT está desativado; o bot pode ser provisionado, mas recursos que leem mensagens comuns ficam limitados até a ativação no Developer Portal.'
    : '';
  return { ...me, intentWarning };
}
async function validateChildToken(token, guildId, managerId) {
  const me = await identifyChildToken(token, managerId);
  const guildValidation = await validateGuildMembership(token, guildId, me.id, { attempts: 4, delayMs: 1200 });
  if (!guildValidation.ok) {
    if (guildValidation.reason === 'membership_missing') throw new Error('O token é válido, mas este bot ainda não aparece no servidor informado. Confira o ID do servidor ou adicione a mesma aplicação ao servidor e tente novamente.');
    throw new Error('O Discord não confirmou a presença do bot no servidor agora. Tente novamente em alguns segundos.');
  }
  return { ...me, guildValidation };
}
function inviteUrl(clientId, guildId = '') {
  const params = new URLSearchParams({ client_id: String(clientId), scope: 'bot applications.commands', permissions: '8' });
  if (/^\d{15,22}$/.test(String(guildId || ''))) params.set('guild_id', String(guildId));
  return `https://discord.com/oauth2/authorize?${params.toString()}`;
}
function retryComponents(Dias, id, botId, guildId) {
  const row = new Discord.ActionRowBuilder().addComponents(
    new Discord.ButtonBuilder().setCustomId(`${Dias}_${id}_uparbot`.slice(0,100)).setLabel('Corrigir token / servidor').setStyle(Discord.ButtonStyle.Primary)
  );
  if (/^\d{15,22}$/.test(String(botId || ''))) row.addComponents(new Discord.ButtonBuilder().setStyle(Discord.ButtonStyle.Link).setURL(inviteUrl(botId, guildId)).setLabel('Adicionar bot ao servidor'));
  return [row];
}
function bindPaidEntitlement(channelId, session, childClientId, days) {
  const channelKey = String(channelId);
  const current = db1.get(channelKey) || session || {};
  const wanted = String(childClientId || '');
  const bound = String(current.boundChildClientId || '');
  if (bound && bound !== wanted) {
    throw new Error(`Este plano já está vinculado ao bot de Client ID ${bound}. Para recuperar/religar o plano, use o token desse mesmo bot. Outro bot não pode assumir esta assinatura.`);
  }

  const activeRuntimeId = String(current.boundRuntimeId || '');
  if (activeRuntimeId && db2.get(activeRuntimeId)) {
    throw new Error(`Este plano já possui uma aplicação ativa (runtime ${activeRuntimeId}). Remova a instância atual antes de tentar recuperar o mesmo bot.`);
  }

  const now = new Date().toISOString();
  const expiration = current.entitlementExpiresAt && Number.isFinite(Date.parse(current.entitlementExpiresAt))
    ? new Date(current.entitlementExpiresAt)
    : new Date(Date.now() + Math.max(1, Number(days) || 30) * 86400000);

  db1.set(`${channelKey}.boundChildClientId`, wanted);
  if (!current.clientBoundAt) db1.set(`${channelKey}.clientBoundAt`, now);
  if (!current.entitlementExpiresAt) db1.set(`${channelKey}.entitlementExpiresAt`, expiration.toISOString());
  return { ...current, boundChildClientId: wanted, clientBoundAt: current.clientBoundAt || now, entitlementExpiresAt: expiration.toISOString() };
}
function bannerAttachment(name = 'zenyx-applications-banner.png') {
  return new Discord.AttachmentBuilder(BRAND_BANNER, { name });
}

module.exports = {
  name: 'interactionCreate',
  configureZip,
  validateChildToken,
  identifyChildToken,
  run: async (interaction, client) => {
    if (interaction.isModalSubmit() && interaction.customId.endsWith('_uparbot_modal')) {
      let [Dias, id] = interaction.customId.split('_');
      if (id === 'NexusPro') id = 'ZenyxPro';
      const nome = safeName(interaction.fields.getTextInputValue('nomeapp'));
      const iddono = interaction.user.id;
      const tokenbot = interaction.fields.getTextInputValue('tokenapp').trim();
      const guildId = interaction.fields.getTextInputValue('guildapp').trim();
      const emojis = readCache(interaction.guildId);

      if (!/^\d{17,20}$/.test(guildId)) return interaction.reply({ content: `${fmt(emojis,'wrong')} ID do servidor inválido.`, flags: 64 });
      const sourceFile = path.join(__dirname, '../../source', `${id}.zip`);
      if (!fs.existsSync(sourceFile)) return interaction.reply({ content: `${fmt(emojis,'wrong')} O arquivo do produto não foi encontrado.`, flags: 64 });
      const rawSession = db1.get(interaction.channel.id);
      if (!rawSession) return interaction.reply({ content: `${fmt(emojis,'wrong')} Esta sessão de compra expirou. Abra uma nova compra e tente novamente.`, flags: 64 });
      // R18.9.76: normalize novamente a sessão antes de provisionar. Isso corrige
      // registros legados onde o rótulo podia ficar "Anual" mesmo com 30 dias.
      // A validade e o feed passam a usar a MESMA fonte de verdade persistida.
      const session = purchaseSessions.persist(interaction.channel.id, purchaseSessions.canonicalize(rawSession), interaction);
      Dias = String(Math.max(1, Number(session.dias) || Number(Dias) || 30));

      await interaction.deferReply({ flags: 64 });
      let botInfo;
      try {
        // Primeiro valida somente o TOKEN e trava o Client ID. Assim, mesmo que
        // o servidor esteja errado/atrasado, o plano não pode ser trocado por outro bot.
        botInfo = await identifyChildToken(tokenbot, client.application?.id || client.user.id);
      } catch (error) {
        return interaction.editReply({ content: `${fmt(emojis,'wrong')} ${error.message}` });
      }

      let boundSession;
      try {
        boundSession = bindPaidEntitlement(interaction.channel.id, session, botInfo.id, Dias);
      } catch (error) {
        return interaction.editReply({ content: `${fmt(emojis,'wrong')} ${error.message}` });
      }

      const guildValidation = await validateGuildMembership(tokenbot, guildId, botInfo.id, { attempts: 4, delayMs: 1200 }).catch(() => null);
      if (!guildValidation?.ok) {
        return interaction.editReply({
          content: `${fmt(emojis,'warn')} **Client ID protegido:** \`${botInfo.id}\`\nO token é válido, mas o Discord ainda não confirmou este bot no servidor \`${guildId}\`.\n\nUse os botões abaixo para adicionar **essa mesma aplicação** ao servidor ou corrigir token/ID. Seu plano continua vinculado e não será perdido.`,
          components: retryComponents(Dias, id, botInfo.id, guildId)
        });
      }
      botInfo.guildValidation = guildValidation;
      const entitlementExpiresAt = new Date(boundSession.entitlementExpiresAt);
      if (!Number.isFinite(entitlementExpiresAt.getTime()) || entitlementExpiresAt.getTime() <= Date.now()) {
        return interaction.editReply({ content: `${fmt(emojis,'warn')} A validade deste plano terminou. Renove antes de tentar ligar o bot novamente.` });
      }
      const remainingDays = Math.max(0.0007, (entitlementExpiresAt.getTime() - Date.now()) / 86400000);

      let zip;
      try {
        zip = await JSZip.loadAsync(fs.readFileSync(sourceFile));
        await configureZip(zip, { token: tokenbot, ownerId: iddono, clientId: botInfo.id, guildId, days: remainingDays, expiresAt: entitlementExpiresAt.toISOString() });
      } catch (error) {
        console.error('[ZENYX PURCHASE] Falha ao configurar template:', error);
        return interaction.editReply({ content: `${fmt(emojis,'wrong')} Não foi possível preparar a aplicação: ${error.message}` });
      }

      const plano = String(session.plano || db1.get(`${interaction.channel.id}.plano`) || 'plano');
      let usuario = (interaction.user?.username || 'Usuario').replace(/[^a-zA-Z0-9 _-]/g, '').slice(0, 14) || 'Usuario';
      let displayName = `ZENYX - ${usuario} - ${plano}`.slice(0, 32);
      const configFileName = zip.files['camposcloud.config'] ? 'camposcloud.config'
        : zip.files['squarecloud.config'] ? 'squarecloud.config'
        : zip.files['squarecloud.app'] ? 'squarecloud.app'
        : zip.files['discloud.config'] ? 'discloud.config' : null;
      if (configFileName) {
        const current = await zip.file(configFileName).async('string');
        zip.file(configFileName, /^DISPLAY_NAME=/m.test(current) ? current.replace(/^DISPLAY_NAME=.*$/m, `DISPLAY_NAME=${displayName}`) : `${current.trim()}\nDISPLAY_NAME=${displayName}\n`);
      }

      const clientDir = path.join(__dirname, '../../source/client');
      await fs.promises.mkdir(clientDir, { recursive: true });
      const filePath = path.join(clientDir, `${safeName(nome)}-${botInfo.id}.zip`);
      await fs.promises.writeFile(filePath, await zip.generateAsync({ type: 'nodebuffer' }));

      await interaction.editReply({ content: `${fmt(emojis,'loading')} Preparando a **aplicação**. O primeiro boot pode levar alguns minutos.` });
      const api1 = new SquareCloudAPI(api.get('square'));
      let data;
      try {
        data = await api1.applications.create(filePath);
        await interaction.editReply({ content: `${fmt(emojis,'loading')} Aplicação conectada. Confirmando acesso ao servidor e registrando os comandos...` });
        await waitForRuntimeGuildReady(api1, data.id, { timeoutMs: 60000, token: tokenbot, guildId, botId: botInfo.id });
      } catch (error) {
        console.error(`[ZENYX PURCHASE] Falha ao iniciar/validar ${id}:`, error?.message || error);
        const failedId = data?.id || error?.applicationId || '';
        if (failedId) {
          // Não destrói o runtime: manter os arquivos permite corrigir token/servidor
          // e recuperar a mesma aplicação sem perder as configurações.
          const failedApp = await api1.applications.get(String(failedId)).catch(() => null);
          await failedApp?.stop?.().catch(() => null);
          const recoverableRecord = {
            nome, dias: Number(Dias), plano, quantia: Number(session.quantia || 1),
            dataExpiracao: entitlementExpiresAt, idapp: String(failedId), token: tokenbot,
            produto: id, owner: iddono, guildId, childClientId: String(botInfo.id), notify: true,
            source: 'plan', purchaseThreadId: String(interaction.channel.id), status: 'recoverable',
            recoverable: true, removedAt: new Date().toISOString()
          };
          db2.set(String(failedId), recoverableRecord);
          const ownerKey = `${iddono}_owner`;
          const ownerData = auto.get(ownerKey) || { owner: iddono, butecos: [] };
          ownerData.butecos = [...(ownerData.butecos || []).filter(app => String(app?.idapp || '') !== String(failedId)), recoverableRecord];
          auto.set(ownerKey, ownerData);
          db1.set(`${interaction.channel.id}.boundRuntimeId`, String(failedId));
        }
        const techId = failedId ? `\nRuntime preservado: \`${failedId}\` • disponível em **Ver bot**` : '';
        return interaction.editReply({
          content: `${fmt(emojis,'wrong')} **Não foi possível concluir a validação do servidor.**\n${String(error?.message || error).slice(0, 900)}${techId}\n\nO Client ID \`${botInfo.id}\` continua protegido. Corrija o token/servidor e tente novamente.`,
          components: retryComponents(Dias, id, botInfo.id, guildId)
        });
      }

      const quantia = db1.get(`${interaction.channel.id}.quantia`) || 1;
      const record = {
        nome, dias: Number(Dias), plano, quantia,
        dataExpiracao: entitlementExpiresAt,
        idapp: data.id, token: tokenbot, produto: id, owner: iddono, guildId, childClientId: botInfo.id, notify: true,
        source: 'plan', purchaseThreadId: String(interaction.channel.id), status: 'online'
      };
      if (!auto.get(`${iddono}_owner`)) auto.set(`${iddono}_owner`, { butecos: [], owner: iddono });
      auto.push(`${iddono}_owner.butecos`, record);
      db2.set(data.id, record);
      db1.set(`${interaction.channel.id}.boundRuntimeId`, String(data.id));
      db1.set(`${interaction.channel.id}.runtimeBoundAt`, new Date().toISOString());
      await require('../../Lib/salesFeed').announce(client,{type:'purchase',user:interaction.user,guildId:interaction.guildId,plan: plano,days:Number(Dias),appId:data.id}).catch(()=>null);

      await interaction.editReply({
        content: `${fmt(emojis,'success')} **Aplicação provisionada com sucesso.**\nAplicação: **${nome}**\nClient ID protegido: \`${botInfo.id}\`\nServidor destino: \`${guildId}\`\nPlano: **${plano} • ${Dias}d**\nValidade atual: <t:${Math.floor(entitlementExpiresAt.getTime()/1000)}:F> (<t:${Math.floor(entitlementExpiresAt.getTime()/1000)}:R>)\nComandos: **isolados somente no servidor configurado**${botInfo.intentWarning ? `\n\n${fmt(emojis,'warn')} ${botInfo.intentWarning}` : ''}`,
        files: [bannerAttachment()]
      });

      const backupChannel = client.channels.cache.get(logs.get('logs_backup'));
      if (backupChannel?.isTextBased()) {
        const archive = new Discord.AttachmentBuilder(filePath, { name: `zenyx-backup-${data.id}.zip` });
        backupChannel.send({
          content: 'ASTRO SOLUTION • BACKUP',
          embeds: [new EmbedBuilder().setTitle('ASTRA APPLICATION • Backup de aplicação').setDescription(`Aplicação **${nome}** salva após o provisionamento.`).addFields(
            { name:'Produto', value:'Aplicação hospedada', inline:true }, { name:'App ID', value:`\`${data.id}\``, inline:true }, { name:'Servidor', value:`\`${guildId}\``, inline:true }
          ).setImage('attachment://astra-applications-panel.png').setColor('#5865F2').setTimestamp()],
          files: [archive, bannerAttachment()]
        }).catch(error => console.warn('[ZENYX LOG] backup:', error?.message || error));
      }
      const hostChannel = client.channels.cache.get(logs.get('logs_hospedagem'));
      if (hostChannel?.isTextBased()) {
        hostChannel.send({
          content: 'ZENYX HOST • NOVA APLICAÇÃO',
          embeds: [new EmbedBuilder().setTitle('ASTRA APPLICATION • Bot online').setDescription('Um bot filho foi provisionado e validado pelo runtime.').addFields(
            { name:'Produto', value:'Aplicação hospedada', inline:true }, { name:'Plano', value:`${plano} • ${Dias}d`, inline:true }, { name:'Dono', value:`<@${iddono}>`, inline:true },
            { name:'Application ID filho', value:`\`${botInfo.id}\``, inline:true }, { name:'Servidor destino', value:`\`${guildId}\``, inline:true }, { name:'Runtime ID', value:`\`${data.id}\``, inline:true }
          ).setImage('attachment://astra-applications-panel.png').setColor('#57F287').setTimestamp()],
          files: [bannerAttachment()]
        }).catch(error => console.warn('[ZENYX LOG] hospedagem:', error?.message || error));
      }

      db1.delete(interaction.channel.id);
      if (id !== 'botfree') {
        // A compra já foi vinculada e o runtime está online: o tópico de checkout
        // não deve continuar aberto. Em threads, arquivamos e bloqueamos; em
        // canais normais, removemos depois da confirmação final.
        const purchaseChannel = interaction.channel;
        setTimeout(async () => {
          try {
            if (purchaseChannel?.isThread?.()) {
              await purchaseChannel.setLocked(true, 'ASTRA APPLICATION • bot vinculado com sucesso').catch(() => null);
              await purchaseChannel.setArchived(true, 'ASTRA APPLICATION • checkout concluído').catch(() => null);
            } else if (purchaseChannel?.deletable) {
              await purchaseChannel.delete('ASTRA APPLICATION • checkout concluído').catch(() => null);
            }
          } catch {}
        }, 2500);
      }
      return;
    }

    if (interaction.isButton() && interaction.customId.endsWith('_uparbot')) {
      let [Dias, id] = interaction.customId.split('_');
      if (id === 'NexusPro') id = 'ZenyxPro';
      const modal = new Discord.ModalBuilder().setTitle('ASTRA APPLICATION • Configurar aplicação').setCustomId(`${Dias}_${id}_uparbot_modal`);
      modal.addComponents(
        new Discord.ActionRowBuilder().addComponents(new Discord.TextInputBuilder().setCustomId('nomeapp').setLabel('NOME DA APLICAÇÃO').setPlaceholder('Ex: Loja principal').setStyle(1).setRequired(true).setMaxLength(40)),
        new Discord.ActionRowBuilder().addComponents(new Discord.TextInputBuilder().setCustomId('tokenapp').setLabel('TOKEN DO BOT FILHO').setPlaceholder('Token da aplicação que será hospedada').setStyle(1).setRequired(true)),
        new Discord.ActionRowBuilder().addComponents(new Discord.TextInputBuilder().setCustomId('guildapp').setLabel('ID DO SERVIDOR DESTINO').setPlaceholder('Ex: 123456789012345678').setStyle(1).setRequired(true).setMinLength(17).setMaxLength(20)),
        new Discord.ActionRowBuilder().addComponents(new Discord.TextInputBuilder().setCustomId('feedback').setLabel('AVALIAÇÃO / OBSERVAÇÃO').setPlaceholder('Opcional').setStyle(1).setRequired(false).setMaxLength(200))
      );
      return interaction.showModal(modal);
    }
  }
};
