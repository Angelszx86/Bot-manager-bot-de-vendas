const {
  Events, MessageFlags, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ButtonBuilder, ButtonStyle, EmbedBuilder, AttachmentBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const axios = require('axios');
const crypto = require('crypto');
const QRCode = require('qrcode');
const { QrCodePix } = require('qrcode-pix');
const { api, db, db2, auto, logs, db1 } = require('../../databases/index');
const center = require('../../Lib/clientCenter');
const { readCache, id: emojiId, fmt } = require('../../Lib/managerEmojis');
const { notifyBuyer, money } = require('../../Lib/planPurchase');
const managerPlans = require('../../Lib/managerPlans');
const evopay = require('../../Lib/evopay');
const externalPix = require('../../Lib/externalPixGateway');
const purchaseReviewers = require('../../Lib/purchaseReviewers');
const bankImap = require('../../Lib/nubankImap');
const { logError, safeMessage } = require('../../Lib/interactions');
const { ensureAndReport: ensureClientRole } = require('../../Lib/clientRole');

// R18.9.48
// Renovação deixou de depender do Mercado Pago. O fluxo agora replica o checkout
// do Manager: plano -> tópico privado -> método disponível -> confirmação -> renovação.
// As sessões ficam persistidas em db1 pelo ID do tópico para não depender apenas
// de Maps em memória; a cobrança automática também pode ser revalidada por botão.

const chargeLocks = new Set();
const finalizeLocks = new Set();
const watchers = new Map();

function em(gid) { return readCache(gid); }
function icon(gid, key) { return fmt(em(gid), key); }
function owned(appId, userId) { return center.findOwnedApp(userId, appId); }
function productKey(app) { const raw = String(app?.produto || 'ZenyxPro'); return raw === 'NexusPro' ? 'ZenyxPro' : raw; }
function appIdOf(app) { return String(app?.idapp || app?.id || '').trim(); }
function sessionOf(channelId) {
  const s = channelId ? db1.get(String(channelId)) : null;
  return s && s.kind === 'renewal' ? s : null;
}
function saveSession(channelId, patch) {
  const current = sessionOf(channelId) || {};
  const next = { ...current, ...patch, kind: 'renewal', updatedAt: Date.now() };
  db1.set(String(channelId), next);
  return next;
}
function clearWatch(threadId) {
  const item = watchers.get(String(threadId));
  if (item?.interval) clearInterval(item.interval);
  if (item?.timeout) clearTimeout(item.timeout);
  watchers.delete(String(threadId));
}
function productPlans(app) {
  const key = productKey(app);
  if (key === 'ZenyxPro') return managerPlans.enabled().map(p => ({ key: p.id, label: p.label, days: p.days, price: p.price, productKey: key }));
  const product = db.get(key); if (!product) return [];
  const legacy = [['mensal', 'Mensal', 30], ['trimensal', 'Trimestral', 90], ['anual', 'Anual', 365]];
  return legacy.flatMap(([planKey, label, days]) => {
    const cfg = product?.preco?.[planKey]; const price = Number(cfg?.preco);
    return cfg?.onoff === false || !Number.isFinite(price) || price < 0 ? [] : [{ key: planKey, label, days, price, productKey: key }];
  });
}
function planSelectPayload(app, userId, gid) {
  const plans = productPlans(app);
  if (!plans.length) return { content: `${icon(gid, 'warn')} Nenhum plano de renovação está habilitado para esta aplicação. Configure os preços no **/botconfig**.`, components: [] };
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`renew:center:plan:${appIdOf(app)}:${userId}`.slice(0, 100))
    .setPlaceholder('Escolha o novo plano de renovação')
    .setMinValues(1).setMaxValues(1);
  for (const p of plans.slice(0, 25)) {
    const o = new StringSelectMenuOptionBuilder()
      .setLabel(`${p.label} • ${p.days} dias`.slice(0, 100))
      .setDescription(`${money(p.price)} • a validade será estendida após a confirmação`.slice(0, 100))
      .setValue(String(p.key).slice(0, 100));
    const eid = emojiId(em(gid), 'clock', null); if (eid) o.setEmoji({ id: eid });
    menu.addOptions(o);
  }
  return {
    content: `${icon(gid, 'clock')} **Renovar aplicação**\nEscolha o plano. Depois será aberto um **tópico privado**, igual ao checkout de compra, para você escolher um método de pagamento realmente ativado no Manager.`,
    components: [new ActionRowBuilder().addComponents(menu)]
  };
}
function paymentAvailability() {
  const imap = logs.get('nubankImap.config') || {};
  const allowed = Array.isArray(imap.allowedFrom) ? imap.allowedFrom : String(imap.allowedFrom || '').split(',').map(v => v.trim()).filter(Boolean);
  const imapPixKey = String(imap.pixKey || logs.get('semi.chave') || '').trim();
  return {
    mp: Boolean(api.get('sistemaMp') && String(api.get('mp') || '').trim()),
    evo: evopay.configured(),
    vyv: externalPix.configured('vyvence'),
    mag: externalPix.configured('magnus'),
    pro: externalPix.configured('promisse'),
    imap: Boolean(imap.managerCheckoutEnabled !== false && imap.enabled && imap.lastTestOk === true && imap.host && imap.user && imap.pass && allowed.length && imapPixKey),
    semi: Boolean(logs.get('semi.sistema') && String(logs.get('semi.chave') || '').trim() && String(logs.get('semi.tipo') || '').trim())
  };
}
function anyPaymentAvailable(plan) {
  if (Number(plan?.price) <= 0) return true;
  return Object.values(paymentAvailability()).some(Boolean);
}
function methodRows(session) {
  const available = paymentAvailability();
  const buttons = [];
  if (available.mp) buttons.push(new ButtonBuilder().setCustomId('renew:pay:mp').setLabel('Mercado Pago PIX').setStyle(ButtonStyle.Success));
  if (available.evo) buttons.push(new ButtonBuilder().setCustomId('renew:pay:evo').setLabel('EvoPay PIX').setStyle(ButtonStyle.Primary));
  if (available.vyv) buttons.push(new ButtonBuilder().setCustomId('renew:pay:vyv').setLabel('VyvencePay').setStyle(ButtonStyle.Primary));
  if (available.mag) buttons.push(new ButtonBuilder().setCustomId('renew:pay:mag').setLabel('MagnusPay').setStyle(ButtonStyle.Primary));
  if (available.pro) buttons.push(new ButtonBuilder().setCustomId('renew:pay:pro').setLabel('PromissePay').setStyle(ButtonStyle.Primary));
  if (available.imap) buttons.push(new ButtonBuilder().setCustomId('renew:pay:imap').setLabel('Inter IMAP').setStyle(ButtonStyle.Success));
  if (available.semi) buttons.push(new ButtonBuilder().setCustomId('renew:pay:semi').setLabel('PIX manual').setStyle(ButtonStyle.Secondary));

  const rows = [];
  for (let i = 0; i < buttons.length; i += 5) rows.push(new ActionRowBuilder().addComponents(...buttons.slice(i, i + 5)));
  rows.push(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('renew:close').setLabel('Fechar tópico').setStyle(ButtonStyle.Danger)
  ));
  return rows;
}
function renewalPanel(session) {
  const plan = session.plan;
  const expiresPreview = Math.floor((Date.now() + Number(plan.days || 0) * 86400000) / 1000);
  return {
    content: `<@${session.userId}>`,
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle('🔄 Renovar aplicação • ZENYX')
      .setDescription('Seu tópico privado está pronto. Escolha **somente um método de pagamento disponível** abaixo. Nenhum gateway é forçado e a validade só muda após a confirmação.')
      .addFields(
        { name: '🤖 Aplicação', value: `\`${session.appId}\``, inline: false },
        { name: '📦 Plano escolhido', value: `**${plan.label}**`, inline: true },
        { name: '💰 Valor', value: `**${money(plan.price)}**`, inline: true },
        { name: '🗓️ Período', value: `**${plan.days} dias**`, inline: true },
        { name: '✅ Depois da confirmação', value: `A validade será estendida e o Manager tentará manter/recolocar a aplicação online.`, inline: false },
        { name: '⏱️ Referência', value: `Se renovado agora, o período acrescentado corresponde a <t:${expiresPreview}:R>.`, inline: false }
      )
      .setFooter({ text: 'ASTRO SOLUTION • pagamento seguro • tópico privado' })
      .setTimestamp()],
    components: methodRows(session)
  };
}
async function createRenewalThread(interaction, app, plan, onThreadReady = null) {
  if (!interaction.guild || !interaction.channel?.threads?.create) throw new Error('Abra a Central em um canal de texto onde o Manager possa criar tópicos privados.');
  if (!anyPaymentAvailable(plan)) throw new Error('Nenhum método de pagamento está ativado e configurado no Manager neste momento.');

  await interaction.channel.threads.fetchActive().catch(() => null);
  const appId = appIdOf(app);
  const existing = interaction.channel.threads.cache.find(thread => {
    const s = sessionOf(thread.id);
    return !thread.archived && s && s.userId === interaction.user.id && s.appId === appId && !['approved', 'cancelled'].includes(String(s.status));
  });
  if (existing) return { thread: existing, existing: true, session: sessionOf(existing.id) };

  const safeUser = String(interaction.user.username || interaction.user.id).replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 35);
  const suffix = appId.slice(-6).replace(/[^a-zA-Z0-9_-]/g, '');
  const thread = await interaction.channel.threads.create({
    name: `renovacao-${safeUser}-${suffix || 'app'}`.slice(0, 90),
    autoArchiveDuration: 60,
    type: ChannelType.PrivateThread,
    invitable: false,
    reason: `Renovação ZENYX de ${interaction.user.id}`
  });
  await thread.members.add(interaction.user.id).catch(() => null);

  const session = {
    kind: 'renewal',
    sessionId: crypto.randomBytes(10).toString('hex'),
    userId: String(interaction.user.id),
    appId,
    productKey: productKey(app),
    guildId: String(interaction.guildId || ''),
    parentId: String(interaction.channel.id || ''),
    plan: { key: String(plan.key), label: String(plan.label), days: Number(plan.days), price: Number(plan.price), productKey: String(plan.productKey || productKey(app)) },
    status: 'selecting_payment',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  db1.set(String(thread.id), session);
  if (typeof onThreadReady === 'function') await onThreadReady(thread, session);
  await purchaseReviewers.addToThread(thread, { includeBuyerId: interaction.user.id }).catch(() => null);
  const message = await thread.send(renewalPanel(session));
  saveSession(thread.id, { panelMessageId: message.id });
  return { thread, existing: false, session: sessionOf(thread.id) };
}
function qrFromBase64(base64, name) {
  const raw = String(base64 || '').includes(',') ? String(base64).split(',').pop() : String(base64 || '');
  if (!raw) return null;
  try { return new AttachmentBuilder(Buffer.from(raw, 'base64'), { name }); } catch { return null; }
}
async function buildQrAttachment({ qrText, qrBase64, name }) {
  const direct = qrFromBase64(qrBase64, name);
  if (direct) return direct;
  if (!qrText) throw new Error('O gateway não retornou um PIX Copia e Cola válido.');
  const png = await QRCode.toBuffer(String(qrText), { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
  return new AttachmentBuilder(png, { name });
}
function paymentButtons(payment) {
  const buttons = [];
  if (payment.qrText) buttons.push(new ButtonBuilder().setCustomId('renew:copy').setLabel('Copiar PIX').setStyle(ButtonStyle.Primary));
  if (payment.url && /^https:\/\//i.test(payment.url)) buttons.push(new ButtonBuilder().setURL(payment.url).setLabel('Abrir cobrança').setStyle(ButtonStyle.Link));
  if (!['semi'].includes(payment.provider)) buttons.push(new ButtonBuilder().setCustomId('renew:check').setLabel('Verificar pagamento').setStyle(ButtonStyle.Success));
  if (['semi','imap'].includes(payment.provider)) buttons.push(new ButtonBuilder().setCustomId('renew:manual:approve').setLabel('Aprovar manualmente').setStyle(ButtonStyle.Success));
  buttons.push(new ButtonBuilder().setCustomId('renew:close').setLabel('Fechar tópico').setStyle(ButtonStyle.Danger));
  return new ActionRowBuilder().addComponents(...buttons.slice(0, 5));
}
function paymentTitle(provider) {
  return ({ mp: 'Mercado Pago', evo: 'EvoPay', vyv: 'VyvencePay', mag: 'MagnusPay', pro: 'PromissePay', imap: 'Banco Inter • IMAP', semi: 'PIX manual' })[provider] || 'PIX';
}
async function createMpCharge(session, interaction) {
  const token = String(api.get('mp') || '').trim();
  if (!api.get('sistemaMp') || !token) throw new Error('Mercado Pago não está ativado/configurado. Escolha outro método disponível.');
  const idempotency = crypto.randomUUID();
  const { data } = await axios.post('https://api.mercadopago.com/v1/payments', {
    transaction_amount: Number(Number(session.plan.price).toFixed(2)),
    description: `Renovação ZENYX ${session.appId}`.slice(0, 250),
    payment_method_id: 'pix',
    payer: { email: `${interaction.user.id}@example.com` }
  }, { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': idempotency }, timeout: 20000 });
  const tx = data?.point_of_interaction?.transaction_data || {};
  const qrText = String(tx.qr_code || '');
  if (!data?.id || !qrText) throw new Error('Mercado Pago respondeu sem ID ou PIX Copia e Cola.');
  const expiresMinutes = Math.max(5, Math.min(60, Number(api.get('tempoPay')) || 15));
  return { provider: 'mp', providerLabel: 'Mercado Pago PIX', id: String(data.id), qrText, qrBase64: String(tx.qr_code_base64 || ''), url: String(tx.ticket_url || ''), expiresAt: Date.now() + expiresMinutes * 60000, idempotency };
}
async function createEvoCharge(session, interaction) {
  if (!evopay.configured()) throw new Error('EvoPay está indisponível no momento.');
  const cfg = evopay.settings();
  const reference = evopay.reference(`RENOV-${session.appId}`);
  const data = await evopay.createPix({
    amount: session.plan.price,
    clientReference: reference,
    generatedName: interaction.user.globalName || interaction.user.username,
    expiresIn: cfg.expiresIn
  });
  return { provider: 'evo', providerLabel: 'EvoPay PIX', id: String(data.id), reference, qrText: String(data.qrCodeText || ''), qrBase64: String(data.qrCodeBase64 || ''), url: String(data.qrCodeUrl || ''), expiresAt: Date.now() + cfg.expiresIn * 1000 };
}
async function createExternalCharge(provider, session, interaction) {
  const key = provider === 'vyv' ? 'vyvence' : (provider === 'mag' ? 'magnus' : 'promisse');
  if (!externalPix.configured(key)) throw new Error(`${externalPix.settings(key).label} está indisponível no momento.`);
  const cfg = externalPix.settings(key);
  const reference = externalPix.reference(`RENOV-${session.appId}`);
  const data = await externalPix.createPix(key, {
    amount: session.plan.price,
    clientReference: reference,
    customerName: interaction.user.globalName || interaction.user.username,
    expiresIn: cfg.expiresIn
  });
  return { provider, externalKey: key, providerLabel: `${cfg.label} PIX`, id: String(data.id), reference, qrText: String(data.qrCodeText || ''), qrBase64: String(data.qrCodeBase64 || ''), url: String(data.qrCodeUrl || ''), expiresAt: Date.now() + cfg.expiresIn * 1000 };
}
async function createManualCharge(session) {
  const key = String(logs.get('semi.chave') || '').trim();
  const type = String(logs.get('semi.tipo') || '').trim();
  if (!logs.get('semi.sistema') || !key || !type) throw new Error('PIX manual não está ativado/configurado no Manager.');
  const minutes = Math.max(3, Math.min(120, Number(logs.get('semi.tempoPay')) || 15));
  const qrText = QrCodePix({ version: '01', key, name: 'ASTRO SOLUTION', city: 'BRASILIA', value: Number(session.plan.price) }).payload();
  return { provider: 'semi', providerLabel: 'PIX manual', id: `manual-${session.sessionId}`, qrText, qrBase64: '', url: '', pixKey: key, expiresAt: Date.now() + minutes * 60000 };
}
async function createImapCharge(session, payerName) {
  const cfg = await bankImap.getStoredConfig();
  if (!bankImap.managerPaymentReady(cfg)) throw new Error('Inter IMAP não está disponível no checkout do Manager original.');
  const cleanName = String(payerName || '').trim().replace(/\s+/g, ' ');
  if (cleanName.length < 3) throw new Error('Informe o nome do pagador exatamente como aparece no banco.');
  const minutes = Math.max(3, Math.min(120, Number(logs.get('semi.tempoPay')) || 15));
  const qrText = QrCodePix({ version: '01', key: cfg.pixKey, name: 'ASTRO SOLUTION', city: 'BRASILIA', value: Number(session.plan.price) }).payload();
  return { provider: 'imap', providerLabel: `${cfg.bankLabel || 'Banco Inter'} • IMAP`, id: `imap-${session.sessionId}`, qrText, qrBase64: '', url: '', pixKey: cfg.pixKey, bankLabel: cfg.bankLabel || 'Banco Inter', expectedPayerName: cleanName, expectedAmount: Number(session.plan.price), expiresAt: Date.now() + minutes * 60000 };
}

async function sendPaymentMessage(interaction, session, payment) {
  const name = `renovacao-${payment.provider}-pix.png`;
  const attachment = await buildQrAttachment({ qrText: payment.qrText, qrBase64: payment.qrBase64, name });
  const unix = Math.floor(Number(payment.expiresAt || (Date.now() + 15 * 60000)) / 1000);
  const fields = [
    { name: 'Aplicação', value: `\`${session.appId}\``, inline: true },
    { name: 'Plano', value: `**${session.plan.label}** • ${session.plan.days} dias`, inline: true },
    { name: 'Valor', value: `**${money(session.plan.price)}**`, inline: true },
    { name: 'Cobrança expira', value: `<t:${unix}:F>\n<t:${unix}:R>`, inline: false }
  ];
  if (payment.provider === 'semi' || payment.provider === 'imap') fields.push({ name: 'Chave PIX', value: `\`${String(payment.pixKey || '').slice(0, 180)}\``, inline: false });
  if (payment.provider === 'imap') fields.push({ name: 'Nome do pagador', value: `**${String(payment.expectedPayerName || '').slice(0, 100)}**`, inline: false });
  const msg = await interaction.channel.send({
    content: `<@${session.userId}>`,
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle(`ASTRA APPLICATION • Renovação via ${paymentTitle(payment.provider)}`)
      .setDescription(payment.provider === 'semi'
        ? 'Realize o pagamento e aguarde a confirmação da equipe. Somente aprovadores configurados podem confirmar.'
        : payment.provider === 'imap'
          ? 'Faça o PIX com uma conta cujo **nome do pagador seja exatamente o informado**. O Manager só aprova automaticamente quando o e-mail do banco contém **o mesmo valor + o mesmo nome**. A equipe também pode aprovar manualmente.'
          : 'Realize o pagamento pelo QR Code. A confirmação é consultada automaticamente; o botão **Verificar pagamento** também funciona após uma reinicialização do Manager.')
      .addFields(...fields)
      .setImage(`attachment://${name}`)
      .setFooter({ text: 'ASTRO SOLUTION • a validade só é alterada após confirmação' })
      .setTimestamp()],
    components: [paymentButtons(payment)],
    files: [attachment]
  });
  return msg;
}
async function syncOwnerCopy(userId, appId, next) {
  const ownerKey = `${userId}_owner`;
  const ownerData = auto.get(ownerKey) || { owner: userId, butecos: [] };
  ownerData.butecos = (Array.isArray(ownerData.butecos) ? ownerData.butecos : []).map(item => String(item?.idapp || item?.id) === String(appId) ? { ...item, ...next } : item);
  if (!ownerData.butecos.some(item => String(item?.idapp || item?.id) === String(appId))) ownerData.butecos.push(next);
  auto.set(ownerKey, ownerData);
}
async function tryStartRenewedRuntime(appId) {
  try {
    const runtime = require('../../source/runtime');
    if (!runtime?.appDir || !runtime?.start) return { ok: false, msg: 'runtime local indisponível' };
    const fs = require('fs');
    if (!fs.existsSync(runtime.appDir(appId))) return { ok: false, msg: 'arquivos do runtime não encontrados' };
    if (typeof runtime.maybeUpgradeZenyxPro === 'function') await runtime.maybeUpgradeZenyxPro(appId).catch(() => null);
    const result = await runtime.start(appId);
    return result?.ok ? { ok: true, msg: result.msg || 'online' } : { ok: false, msg: result?.msg || 'falha ao iniciar' };
  } catch (error) { return { ok: false, msg: String(error?.message || error).slice(0, 260) }; }
}
async function finalizeRenewal(client, threadId, providerLabel, paymentMessage, bankName = '') {
  const key = String(threadId);
  if (finalizeLocks.has(key)) return null;
  finalizeLocks.add(key);
  try {
    const session = sessionOf(key);
    if (!session) throw new Error('Sessão de renovação não encontrada.');
    if (session.status === 'approved') return { expiration: new Date(session.finalExpiration || Date.now()), already: true };
    const current = db2.get(session.appId);
    if (!current) throw new Error('Aplicação não encontrada ao confirmar a renovação.');

    let expiration;
    const alreadyApplied = String(current.lastRenewalSessionId || '') === String(session.sessionId);
    if (alreadyApplied && Number.isFinite(Date.parse(current.dataExpiracao || ''))) {
      expiration = new Date(current.dataExpiracao);
    } else {
      const oldExp = Date.parse(current.dataExpiracao || '');
      const base = Number.isFinite(oldExp) && oldExp > Date.now() ? oldExp : Date.now();
      expiration = new Date(base + Number(session.plan.days) * 86400000);
    }

    const oldStatus = String(current.status || '').toLowerCase();
    const explicitlyStopped = ['stopped', 'recoverable', 'removed', 'suspended', 'revoked'].includes(oldStatus);
    const next = {
      ...current,
      plano: session.plan.label,
      dias: session.plan.days,
      quantia: 1,
      dataExpiracao: expiration.toISOString(),
      status: explicitlyStopped ? (oldStatus === 'stopped' ? 'stopped' : oldStatus) : 'online',
      notify:false,
      lastRenewalSessionId: session.sessionId,
      lastRenewalAt: new Date().toISOString(),
      lastRenewalProvider: providerLabel
    };
    delete next.expiredAt; delete next.purgeAfter; delete next.lastPurgeAttemptAt; delete next.lastRuntimeError;
    db2.set(session.appId, next);
    await syncOwnerCopy(session.userId, session.appId, next);

    let runtimeResult = { ok: false, msg: 'mantido desligado por escolha anterior' };
    if (!explicitlyStopped) {
      runtimeResult = await tryStartRenewedRuntime(session.appId);
      if (!runtimeResult.ok) {
        // "offline" aqui é transitório. O boot R18.9.47 volta a tentar ligar
        // automaticamente aplicações válidas com esse status.
        db2.set(`${session.appId}.status`, 'offline');
        const refreshed = db2.get(session.appId) || { ...next, status: 'offline' };
        await syncOwnerCopy(session.userId, session.appId, refreshed);
      }
    }

    saveSession(key, { status: 'approved', payment: session.payment ? { ...session.payment, status: 'approved' } : session.payment, finalizedAt: Date.now(), finalExpiration: expiration.toISOString(), providerLabel, bankName, runtimeStarted: Boolean(runtimeResult.ok), runtimeMessage: runtimeResult.msg });
    clearWatch(key);
    const guild = client.guilds.cache.get(String(session.guildId || '')) || await client.guilds.fetch(String(session.guildId || '')).catch(() => null);
    await ensureClientRole(guild, session.userId, { reason: 'Cliente ASTRA APPLICATION • renovação confirmada' });
    await notifyBuyer(client, session.userId, {
      session: { plano: session.plan.label, dias: session.plan.days, aluguel: session.productKey || 'ZenyxPro', quantia: 1 },
      amount: session.plan.price,
      provider: `${providerLabel} • renovação`,
      expiration
    }).catch(() => null);

    const embed = new EmbedBuilder()
      .setColor('#57f287')
      .setTitle('Renovação confirmada')
      .setDescription(runtimeResult.ok
        ? 'Pagamento confirmado. A validade foi estendida e a aplicação foi colocada online automaticamente.'
        : explicitlyStopped
          ? 'Pagamento confirmado. A validade foi estendida; a aplicação permaneceu desligada porque estava parada explicitamente antes da renovação.'
          : 'Pagamento confirmado. A validade foi estendida. O runtime não conseguiu subir agora, mas ficou marcado para restauração automática no próximo ciclo/boot do Manager.')
      .addFields(
        { name: 'Plano', value: `**${session.plan.label}** • ${session.plan.days} dias`, inline: true },
        { name: 'Valor', value: `**${money(session.plan.price)}**`, inline: true },
        { name: 'Nova validade', value: `<t:${Math.floor(expiration.getTime() / 1000)}:F>\n<t:${Math.floor(expiration.getTime() / 1000)}:R>`, inline: false }
      )
      .setFooter({ text: `ASTRO SOLUTION • ${providerLabel}` })
      .setTimestamp();
    const closeRow = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('renew:close').setLabel('Fechar tópico').setStyle(ButtonStyle.Secondary));
    if (paymentMessage) await paymentMessage.edit({ content: `<@${session.userId}>`, embeds: [embed], components: [closeRow], files: [], attachments: [] }).catch(error => logError(error, 'renewal-success-edit'));
    const feedUser = await client.users.fetch(String(session.userId)).catch(() => null);
    if (feedUser) require('../../Lib/salesFeed').announce(client, { type: 'renewal', user: feedUser, guildId: session.guildId, plan: session.plan.label, days: session.plan.days, amount: session.plan.price, appId: session.appId }).catch(error => logError(error, 'renewal-sales-feed'));
    return { expiration, runtimeResult };
  } finally { finalizeLocks.delete(key); }
}
async function checkAutomaticPayment(client, threadId, { paymentMessage = null, manualTrigger = false } = {}) {
  const session = sessionOf(threadId);
  if (!session?.payment) return { state: session?.status === 'approved' ? 'approved' : 'missing' };
  const p = session.payment;
  if (p.provider === 'imap' && p.status === 'approved' && session.status !== 'approved') {
    await finalizeRenewal(client, threadId, `${p.bankLabel || 'Banco Inter'} • IMAP`, paymentMessage);
    return { state: 'approved' };
  }
  if (p.status !== 'pending') return { state: session?.status === 'approved' ? 'approved' : 'missing' };
  try {
    if (p.provider === 'mp') {
      const token = String(api.get('mp') || '').trim();
      if (!token) throw new Error('Token do Mercado Pago não está mais configurado.');
      const { data } = await axios.get(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(String(p.id))}`, { headers: { Authorization: `Bearer ${token}` }, timeout: 12000 });
      const state = String(data?.status || '').toLowerCase();
      if (state === 'approved') {
        const bankName = String(data?.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name || 'Não identificado');
        const blocked = Array.isArray(api.get('banksOff')) ? api.get('banksOff') : [];
        if (blocked.some(name => bankName.toLowerCase().includes(String(name).toLowerCase()))) {
          await axios.post(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(String(p.id))}/refunds`, {}, { headers: { Authorization: `Bearer ${token}` }, timeout: 12000 }).catch(() => null);
          saveSession(threadId, { payment: { ...p, status: 'refunded', bankName } });
          clearWatch(threadId);
          if (paymentMessage) await paymentMessage.edit({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('Renovação cancelada pelo antifraude').setDescription('O banco identificado corresponde a uma regra de bloqueio do Manager. A tentativa de reembolso foi enviada ao provedor.')], components: [], files: [], attachments: [] }).catch(() => null);
          return { state: 'terminal', label: 'REFUNDED' };
        }
        await finalizeRenewal(client, threadId, 'Mercado Pago PIX', paymentMessage, bankName);
        return { state: 'approved' };
      }
      if (['cancelled', 'canceled', 'rejected', 'refunded', 'charged_back'].includes(state)) return { state: 'terminal', label: state.toUpperCase() };
      return { state: 'pending' };
    }
    if (p.provider === 'evo') {
      const data = await evopay.getPix({ id: p.id, clientReference: p.reference });
      const state = String(data?.status || '').toUpperCase();
      if (state === 'COMPLETED') { await finalizeRenewal(client, threadId, 'EvoPay PIX', paymentMessage); return { state: 'approved' }; }
      if (['CANCELED', 'EXPIRED', 'ERROR', 'REFUNDED'].includes(state)) return { state: 'terminal', label: state };
      return { state: 'pending' };
    }
    if (p.provider === 'vyv' || p.provider === 'mag' || p.provider === 'pro') {
      const extKey = p.externalKey || (p.provider === 'vyv' ? 'vyvence' : (p.provider === 'mag' ? 'magnus' : 'promisse'));
      const data = await externalPix.getPix(extKey, { id: p.id, clientReference: p.reference });
      if (externalPix.isPaidStatus(data?.status)) { await finalizeRenewal(client, threadId, `${externalPix.settings(extKey).label} PIX`, paymentMessage); return { state: 'approved' }; }
      if (externalPix.isTerminalStatus(data?.status)) return { state: 'terminal', label: String(data?.status || 'ENCERRADO').toUpperCase() };
      return { state: 'pending' };
    }
    return { state: 'missing' };
  } catch (error) {
    logError(error, `renewal-check-${p.provider}`);
    if (manualTrigger) throw error;
    return { state: 'error' };
  }
}
async function paymentMessageFor(client, threadId) {
  const s = sessionOf(threadId);
  if (!s?.paymentMessageId) return null;
  const channel = await client.channels.fetch(String(threadId)).catch(() => null);
  return channel?.messages?.fetch ? channel.messages.fetch(String(s.paymentMessageId)).catch(() => null) : null;
}
function startWatcher(client, threadId) {
  clearWatch(threadId);
  const s = sessionOf(threadId);
  if (!s?.payment || s.payment.provider === 'semi' || !['pending', 'approved'].includes(String(s.payment.status || 'pending'))) return;
  const interval = setInterval(async () => {
    const current = sessionOf(threadId);
    if (!current || current.status === 'approved') return clearWatch(threadId);
    const msg = await paymentMessageFor(client, threadId);

    // O watcher IMAP é externo ao fluxo de renovação: ele marca payment.status=approved
    // quando valor + nome conferem. Não podemos encerrar este intervalo antes de
    // transformar essa aprovação em renovação efetiva.
    if (current.payment?.provider === 'imap' && current.payment?.status === 'approved') {
      const result = await checkAutomaticPayment(client, threadId, { paymentMessage: msg });
      if (result.state === 'approved') clearWatch(threadId);
      return;
    }
    if (current.payment?.status !== 'pending') return clearWatch(threadId);

    const result = await checkAutomaticPayment(client, threadId, { paymentMessage: msg });
    if (result.state === 'terminal') {
      clearWatch(threadId);
      saveSession(threadId, { payment: { ...current.payment, status: 'terminal', terminalLabel: result.label } });
      if (msg) await msg.edit({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('Cobrança encerrada').setDescription(`O gateway retornou **${String(result.label || 'ENCERRADO').slice(0, 80)}**. Você pode escolher outro método no painel de renovação.`)], components: [], files: [], attachments: [] }).catch(() => null);
    }
  }, 2500);
  interval.unref?.();
  const remaining = Math.max(30_000, Number(s.payment.expiresAt || 0) - Date.now() + 5000);
  const timeout = setTimeout(async () => {
    const current = sessionOf(threadId);
    if (!current || current.status === 'approved' || current.payment?.status !== 'pending') return clearWatch(threadId);
    clearWatch(threadId);
    saveSession(threadId, { payment: { ...current.payment, status: 'expired' } });
    const msg = await paymentMessageFor(client, threadId);
    if (msg) await msg.edit({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('Cobrança expirada').setDescription('O prazo desta cobrança terminou. Você pode escolher outro método no painel de renovação.')], components: [], files: [], attachments: [] }).catch(() => null);
  }, Math.min(2 * 60 * 60 * 1000, remaining));
  timeout.unref?.();
  watchers.set(String(threadId), { interval, timeout });
}
async function beginPayment(interaction, provider, payerName = '') {
  const threadId = String(interaction.channel?.id || '');
  let session = sessionOf(threadId);
  if (!session) return interaction.reply({ content: 'Esta sessão de renovação expirou. Reabra **Renovar plano**.', flags: MessageFlags.Ephemeral });
  if (session.userId !== interaction.user.id) return interaction.reply({ content: 'Este checkout pertence a outro usuário.', flags: MessageFlags.Ephemeral });
  if (session.status === 'approved') return interaction.reply({ content: 'Esta renovação já foi concluída.', flags: MessageFlags.Ephemeral });
  if (session.payment?.status === 'pending') return interaction.reply({ content: `Já existe uma cobrança **${paymentTitle(session.payment.provider)}** pendente neste tópico. Use o PIX exibido ou **Verificar pagamento**.`, flags: MessageFlags.Ephemeral });

  const lockKey = `${threadId}:${provider}`;
  if (chargeLocks.has(lockKey)) return interaction.reply({ content: 'A cobrança já está sendo criada. Aguarde alguns segundos.', flags: MessageFlags.Ephemeral });
  chargeLocks.add(lockKey);
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });
  try {
    if (Number(session.plan.price) <= 0) {
      await finalizeRenewal(interaction.client, threadId, 'Plano gratuito', null);
      return interaction.editReply('Plano gratuito renovado com sucesso.');
    }
    let payment;
    if (provider === 'mp') payment = await createMpCharge(session, interaction);
    else if (provider === 'evo') payment = await createEvoCharge(session, interaction);
    else if (provider === 'vyv' || provider === 'mag' || provider === 'pro') payment = await createExternalCharge(provider, session, interaction);
    else if (provider === 'imap') payment = await createImapCharge(session, payerName);
    else if (provider === 'semi') payment = await createManualCharge(session);
    else throw new Error('Método de pagamento desconhecido.');

    payment = { ...payment, status: 'pending', amount: Number(session.plan.price), createdAt: Date.now() };
    session = saveSession(threadId, { status: 'payment_pending', payment });
    const message = await sendPaymentMessage(interaction, session, payment);
    saveSession(threadId, { paymentMessageId: message.id });
    if (provider !== 'semi') startWatcher(interaction.client, threadId);
    return interaction.editReply(`Cobrança **${paymentTitle(provider)}** criada no tópico. Nenhum gateway não configurado foi forçado.`);
  } catch (error) {
    logError(error, `renewal-create-${provider}`);
    return interaction.editReply(`Não foi possível gerar a cobrança: ${safeMessage(error, 700)}`);
  } finally { chargeLocks.delete(lockKey); }
}
async function closeRenewalThread(interaction, reason) {
  const threadId = String(interaction.channel?.id || '');
  const s = sessionOf(threadId);
  if (!s) {
    if (interaction.channel?.isThread?.() && !interaction.channel.archived) { await interaction.deferUpdate().catch(() => null); await interaction.channel.setArchived(true, reason || 'Tópico encerrado').catch(() => null); return; }
    return interaction.reply({ content: 'Este tópico já foi encerrado.', flags: MessageFlags.Ephemeral });
  }
  if (s.userId !== interaction.user.id && !purchaseReviewers.isReviewer(interaction.user.id)) return interaction.reply({ content: 'Você não pode encerrar a renovação de outro usuário.', flags: MessageFlags.Ephemeral });
  await interaction.deferUpdate().catch(() => null);
  clearWatch(threadId);
  if (s.status !== 'approved') saveSession(threadId, { status: 'cancelled', cancelledAt: Date.now(), payment: s.payment ? { ...s.payment, status: s.payment.status === 'approved' ? 'approved' : 'cancelled' } : s.payment });
  else saveSession(threadId, { closedAt: Date.now() });
  await interaction.message.edit({ content: s.status === 'approved' ? `${icon(interaction.guildId, 'success')} Renovação concluída. Fechando o tópico...` : `${icon(interaction.guildId, 'success')} Renovação encerrada. Fechando o tópico...`, components: [] }).catch(() => null);
  setTimeout(async () => { try { if (interaction.channel?.isThread?.() && !interaction.channel.archived) await interaction.channel.setArchived(true, reason || 'Renovação encerrada'); } catch {} }, 800).unref?.();
}

module.exports = {
  name: Events.InteractionCreate,
  run: async (interaction) => {
    const cid = interaction.customId || '';

    const open = cid.match(/^center:app:renew:(.*?):(\d{15,25})$/);
    if (open) {
      const [, appId, expected] = open;
      if (expected !== interaction.user.id) return interaction.reply({ content: 'Este controle pertence a outro usuário.', flags: MessageFlags.Ephemeral });
      const app = owned(appId, interaction.user.id);
      if (!app) return interaction.reply({ content: `${icon(interaction.guildId, 'wrong')} Aplicação não encontrada ou sem permissão.`, flags: MessageFlags.Ephemeral });
      return interaction.reply({ ...planSelectPayload(app, interaction.user.id, interaction.guildId), flags: MessageFlags.Ephemeral });
    }

    const select = cid.match(/^renew:center:plan:(.*?):(\d{15,25})$/);
    if (select && interaction.isStringSelectMenu?.()) {
      const [, appId, expected] = select;
      if (expected !== interaction.user.id) return interaction.reply({ content: 'Este menu pertence a outro usuário.', flags: MessageFlags.Ephemeral });
      const app = owned(appId, interaction.user.id);
      if (!app) return interaction.reply({ content: 'Aplicação não encontrada.', flags: MessageFlags.Ephemeral });
      const plan = productPlans(app).find(x => x.key === interaction.values[0]);
      if (!plan) return interaction.reply({ content: 'Este plano não está mais disponível.', flags: MessageFlags.Ephemeral });

      await interaction.deferUpdate();
      await interaction.editReply({
        content: `${icon(interaction.guildId, 'clock')} **Criando seu tópico privado de renovação...**\n-# O link aparece assim que o Discord terminar de criar o tópico; o restante do painel carrega lá dentro.`,
        components: []
      }).catch(() => null);
      try {
        let quickLinkShown = false;
        const { thread, existing } = await createRenewalThread(interaction, app, plan, async (createdThread) => {
          quickLinkShown = true;
          await interaction.editReply({
            content: `${icon(interaction.guildId, 'success')} **Tópico criado.** Você já pode entrar enquanto o Manager termina de carregar o painel de renovação.`,
            components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setURL(createdThread.url).setLabel('Abrir tópico agora').setStyle(ButtonStyle.Link))]
          });
        });
        if (Number(plan.price) <= 0 && !existing) {
          const result = await finalizeRenewal(interaction.client, thread.id, 'Plano gratuito', null);
          const panelId = sessionOf(thread.id)?.panelMessageId;
          if (panelId) {
            const panel = await thread.messages.fetch(String(panelId)).catch(() => null);
            if (panel) await panel.edit({
              content: `<@${interaction.user.id}>`,
              embeds: [new EmbedBuilder().setColor('#57f287').setTitle('✅ Renovação concluída').setDescription('Este plano não exige cobrança. A validade foi renovada imediatamente.').addFields({ name: '🗓️ Nova validade', value: result?.expiration ? `<t:${Math.floor(result.expiration.getTime()/1000)}:F>\n<t:${Math.floor(result.expiration.getTime()/1000)}:R>` : 'atualizada' }).setFooter({ text: 'ASTRO SOLUTION • renovação concluída' }).setTimestamp()],
              components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('renew:close').setLabel('Fechar tópico').setStyle(ButtonStyle.Secondary))]
            }).catch(() => null);
          }
        }
        if (quickLinkShown && !existing) return;
        return interaction.editReply({
          content: existing
            ? `${icon(interaction.guildId, 'warn')} Você já possui uma renovação aberta para esta aplicação. Continue no tópico abaixo.`
            : `${icon(interaction.guildId, 'success')} **Renovação iniciada.** O tópico privado foi criado; escolha lá um método de pagamento disponível.`,
          components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setURL(thread.url).setLabel('Abrir tópico da renovação').setStyle(ButtonStyle.Link))]
        });
      } catch (error) {
        return interaction.editReply({ content: `${icon(interaction.guildId, 'wrong')} Não foi possível iniciar a renovação: ${safeMessage(error, 700)}`, components: [] });
      }
    }

    const pay = cid.match(/^renew:pay:(mp|evo|vyv|mag|pro|imap|semi)$/);
    if (pay && interaction.isButton?.()) {
      if (pay[1] === 'imap') {
        const modal = new ModalBuilder().setCustomId('renew:imap:payer').setTitle('Banco Inter • nome do pagador').addComponents(
          new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('payerName').setLabel('NOME EXATO DO TITULAR/PAGADOR').setPlaceholder('Exatamente como aparece no banco').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(3).setMaxLength(100))
        );
        return interaction.showModal(modal);
      }
      return beginPayment(interaction, pay[1]);
    }
    if (cid === 'renew:imap:payer' && interaction.isModalSubmit?.()) return beginPayment(interaction, 'imap', interaction.fields.getTextInputValue('payerName'));

    if (cid === 'renew:copy' && interaction.isButton?.()) {
      const s = sessionOf(interaction.channel?.id);
      if (!s || s.userId !== interaction.user.id) return interaction.reply({ content: 'Esta cobrança não pertence a você ou já expirou.', flags: MessageFlags.Ephemeral });
      return interaction.reply({ content: s.payment?.qrText || 'Código PIX indisponível.', flags: MessageFlags.Ephemeral });
    }

    if (cid === 'renew:check' && interaction.isButton?.()) {
      const s = sessionOf(interaction.channel?.id);
      if (!s || s.userId !== interaction.user.id) return interaction.reply({ content: 'Esta cobrança não pertence a você ou já expirou.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const result = await checkAutomaticPayment(interaction.client, interaction.channel.id, { paymentMessage: interaction.message, manualTrigger: true });
        if (result.state === 'approved') return interaction.editReply('Pagamento confirmado e renovação aplicada.');
        if (result.state === 'terminal') {
          saveSession(interaction.channel.id, { payment: { ...s.payment, status: 'terminal', terminalLabel: result.label } });
          return interaction.editReply(`A cobrança foi encerrada pelo gateway: **${String(result.label || 'ENCERRADA').slice(0, 80)}**. Escolha outro método no painel.`);
        }
        return interaction.editReply('Pagamento ainda não foi confirmado. Aguarde alguns segundos e tente novamente.');
      } catch (error) { return interaction.editReply(`Não foi possível consultar o pagamento agora: ${safeMessage(error, 600)}`); }
    }

    if (cid === 'renew:manual:approve' && interaction.isButton?.()) {
      const s = sessionOf(interaction.channel?.id);
      if (!s || !['semi','imap'].includes(s.payment?.provider) || !['pending','approved'].includes(s.payment?.status)) return interaction.reply({ content: 'Não existe um pagamento manual/IMAP pendente neste tópico.', flags: MessageFlags.Ephemeral });
      const roleId = logs.get('semi.roleAprove');
      const byRole = Boolean(roleId && interaction.member?.roles?.cache?.has?.(roleId));
      const byReviewer = purchaseReviewers.isReviewer(interaction.user.id);
      if (!byRole && !byReviewer) return interaction.reply({ content: roleId ? 'Você não possui permissão para aprovar pagamentos.' : 'Nenhum cargo aprovador foi configurado e você não faz parte da equipe dos tópicos.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        await finalizeRenewal(interaction.client, interaction.channel.id, s.payment?.provider === 'imap' ? `${s.payment.bankLabel || 'Banco Inter'} • aprovado manualmente por ${interaction.user.username}` : `PIX manual • aprovado por ${interaction.user.username}`, interaction.message);
        return interaction.editReply('Pagamento manual confirmado e renovação aplicada.');
      } catch (error) { return interaction.editReply(`Não foi possível concluir a renovação: ${safeMessage(error, 700)}`); }
    }

    if ((cid === 'renew:cancel' || cid === 'renew:close') && interaction.isButton?.()) return closeRenewalThread(interaction, 'Renovação encerrada pelo usuário');
  }
};
