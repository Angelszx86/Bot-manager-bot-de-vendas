const { Events, MessageFlags } = require('discord.js');
const referrals = require('../../Lib/referrals');
const { readCache, fmt } = require('../../Lib/managerEmojis');

function icon(guildId, key) { return fmt(readCache(guildId), key); }

module.exports = {
  name: Events.InteractionCreate,
  run: async (interaction) => {
    const id = interaction.customId || '';
    if (!id.startsWith('referral:')) return;
    if (!interaction.guildId) return interaction.reply({ content: 'Este painel só funciona dentro do servidor.', flags: MessageFlags.Ephemeral });
    const cfg = referrals.settings(interaction.guildId);
    if (!cfg.enabled) return interaction.reply({ content: `${icon(interaction.guildId, 'warn')} O programa de indicação está **desativado** no momento.`, flags: MessageFlags.Ephemeral });
    try {
      if (id === 'referral:create-link') {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const invite = await referrals.createInvite(interaction);
        return interaction.editReply({ content: `${icon(interaction.guildId, 'link')} Seu link individual:
https://discord.gg/${invite.code}

Somente entradas válidas por este convite contam no seu saldo.` });
      }
      if (id === 'referral:time') {
        const st = referrals.stats(interaction.guildId, interaction.user.id);
        return interaction.reply({ content: `${icon(interaction.guildId, 'clock')} Tempo disponível: **${referrals.formatMinutes(st.remainingMinutes)}**\nCréditos totais: **${referrals.formatMinutes(st.creditedMinutes)}** • usados: **${referrals.formatMinutes(st.consumedMinutes)}**`, flags: MessageFlags.Ephemeral });
      }
      if (id === 'referral:count') {
        const st = referrals.stats(interaction.guildId, interaction.user.id);
        return interaction.reply({ content: `${icon(interaction.guildId, 'users')} Você possui **${st.validInvites}** indicação(ões) válida(s).`, flags: MessageFlags.Ephemeral });
      }
      if (id === 'referral:test') {
        const st = referrals.stats(interaction.guildId, interaction.user.id);
        if (st.remainingMinutes < cfg.minimumMinutesToTest) return interaction.reply({ content: `${icon(interaction.guildId, 'warn')} Você precisa de pelo menos **${referrals.formatMinutes(cfg.minimumMinutesToTest)}**. Seu saldo atual é **${referrals.formatMinutes(st.remainingMinutes)}**.`, flags: MessageFlags.Ephemeral });
        const duration = Math.min(st.remainingMinutes, cfg.maxMinutesPerTest);
        return require('./gratis').openReferralTrialThread(interaction, duration);
      }
    } catch (error) {
      const msg = require('../../Lib/interactions').safeMessage(error, 700) || 'Não foi possível concluir esta ação.';
      if (interaction.deferred) return interaction.editReply({ content: `${icon(interaction.guildId, 'wrong')} ${msg}` }).catch(() => null);
      if (!interaction.replied) return interaction.reply({ content: `${icon(interaction.guildId, 'wrong')} ${msg}`, flags: MessageFlags.Ephemeral }).catch(() => null);
    }
  }
};
