const {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags
} = require('discord.js');
const axios = require('axios');
const QRCode = require('qrcode');
const { api, db1, logs, db, clientes } = require('../../databases/index');
const { readCache, fmt } = require('../../Lib/managerEmojis');
const { logError, safeMessage } = require('../../Lib/interactions');
const { ensureAndReport: ensureClientRole } = require('../../Lib/clientRole');
const purchaseSessions = require('../../Lib/purchaseSessions');
const { amountForSession, expirationForSession, notifyBuyer, money, linkingReadyEmbed } = require('../../Lib/planPurchase');

const pollers = new Map();
const timeouts = new Map();
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function sessionFor(channelId, interaction = null) {
  if (interaction) return purchaseSessions.resolve(interaction);
  return channelId ? db1.get(String(channelId)) : null;
}

function originalAmount(session) { return amountForSession(session); }
function clearWatch(channelId) {
  const poller = pollers.get(channelId); if (poller) clearInterval(poller);
  const timer = timeouts.get(channelId); if (timer) clearTimeout(timer);
  pollers.delete(channelId); timeouts.delete(channelId);
}
async function closeThreadLater(channel, delay = 8000) {
  setTimeout(async () => {
    try {
      if (channel?.isThread?.()) {
        await channel.setArchived(true, 'Compra ZENYX encerrada').catch(async () => {
          if (channel.deletable) await channel.delete('Compra ZENYX encerrada').catch(() => null);
        });
      }
    } catch {}
  }, delay).unref?.();
}
async function paymentRequest(token, body) {
  const { data } = await axios.post('https://api.mercadopago.com/v1/payments', body, {
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'X-Idempotency-Key': `zenyx-${Date.now()}-${Math.random().toString(36).slice(2)}` },
    timeout: 20000
  });
  return data;
}
async function paymentStatus(token, paymentId) {
  const { data } = await axios.get(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
    headers: { Authorization: `Bearer ${token}` }, timeout: 15000
  });
  return data;
}
async function refund(token, paymentId) {
  await axios.post(`https://api.mercadopago.com/v1/payments/${paymentId}/refunds`, {}, {
    headers: { Authorization: `Bearer ${token}` }, timeout: 15000
  });
}
function paymentButtons(appId, session, ticketUrl) {
  const row = new ActionRowBuilder();
  row.addComponents(new ButtonBuilder().setCustomId('copyCode').setLabel('Copiar Pix').setStyle(ButtonStyle.Primary));
  if (/^https?:\/\//i.test(ticketUrl || '')) row.addComponents(new ButtonBuilder().setURL(ticketUrl).setLabel('Abrir pagamento').setStyle(ButtonStyle.Link));
  row.addComponents(new ButtonBuilder().setCustomId(`${appId}_${session.plano}_cancel`).setLabel('Cancelar compra').setStyle(ButtonStyle.Secondary));
  return row;
}
async function successPanel(interaction, session, paymentMessage, bank = 'Mercado Pago') {
  clearWatch(interaction.channel.id);
  await db1.set(`${interaction.channel.id}.status`, 'aprovado');
  await ensureClientRole(interaction.guild, session.userid, { reason: 'Cliente ASTRA APPLICATION • pagamento purchase confirmado' });
  const amount = Number(db1.get(`${interaction.channel.id}.payment.amount`) ?? originalAmount(session));
  const expiration = expirationForSession(session);
  await paymentMessage.edit({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder().setColor('#3155ff').setTitle('Pagamento confirmado • ativando plano').setDescription('Seu PIX foi confirmado. Estamos registrando a assinatura e preparando a etapa de vínculo do bot...')],
    components: [], files: [], attachments: []
  }).catch(error => logError(error, 'purchase-loading-panel'));
  await sleep(1100);
  await paymentMessage.edit({
    content: `<@${session.userid}>`,
    embeds: [linkingReadyEmbed({ session, amount, provider: bank || 'PIX automático', expiration })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`${session.dias}_${session.aluguel}_uparbot`).setLabel('Vincular bot').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setURL('https://discord.com/developers/applications').setLabel('Discord Developer').setStyle(ButtonStyle.Link)
    )],
    files: [], attachments: []
  }).catch(error => logError(error, 'purchase-success-panel'));
  await notifyBuyer(interaction.client, session.userid, { session, amount, provider: bank || 'Mercado Pago PIX', expiration });
  require('../../Lib/salesFeed').announce(interaction.client, {
    type: 'purchase', user: interaction.user, guildId: interaction.guildId, plan: session.plano, days: session.dias
  }).catch(error => logError(error, 'purchase-sales-feed'));
}
async function createPix(interaction, amount) {
  const channelId = interaction.channel?.id;
  const session = sessionFor(channelId, interaction);
  if (!session) throw new Error('Esta sessão de compra expirou. Abra um novo carrinho.');
  const token = String(api.get('mp') || '').trim();
  if (!api.get('sistemaMp') || !token) throw new Error('Mercado Pago/Pix automático não está configurado no Manager.');
  const normalizedAmount = Number(amount);
  if (!Number.isFinite(normalizedAmount) || normalizedAmount < 0) throw new Error('Valor da compra inválido.');

  if (normalizedAmount === 0) {
    db1.set(`${channelId}.payment`, { provider: 'coupon', amount: 0, createdAt: Date.now() });
    const freeMessage = await interaction.channel.send({
      embeds: [new EmbedBuilder().setColor('#57F287').setTitle('Cupom de 100% aplicado').setDescription('Nenhum pagamento é necessário. Continue para vincular o bot.')]
    });
    await successPanel(interaction, session, freeMessage, 'Cupom 100%');
    return;
  }

  const body = {
    transaction_amount: normalizedAmount,
    description: `ZENYX Pro - ${interaction.user.username}`.slice(0, 250),
    payment_method_id: 'pix',
    payer: { email: `${interaction.user.id}@example.com` }
  };
  let data;
  try { data = await paymentRequest(token, body); }
  catch (error) {
    const detail = error?.response?.data?.message || error?.response?.data?.error || safeMessage(error, 300) || 'falha desconhecida';
    throw new Error(`Não foi possível gerar o Pix: ${detail}`);
  }
  const transaction = data?.point_of_interaction?.transaction_data || {};
  const qrCode = String(transaction.qr_code || '');
  if (!qrCode) throw new Error('O Mercado Pago respondeu sem código Pix. Revise a credencial/configuração do gateway.');
  const png = await QRCode.toBuffer(qrCode, { type: 'png', width: 640, margin: 2 });
  const attachment = new AttachmentBuilder(png, { name: 'zenyx-pix.png' });
  const expiresMinutes = Math.max(5, Math.min(60, Number(api.get('tempoPay')) || 15));
  const expireUnix = Math.floor((Date.now() + expiresMinutes * 60000) / 1000);
  const paymentMessage = await interaction.channel.send({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle('ASTRA APPLICATION • Checkout Mercado Pago')
      .setDescription('Sua cobrança PIX foi criada. Pague pelo QR Code e aguarde a confirmação automática.')
      .addFields(
        { name: 'Produto', value: '**bot de vendas**', inline: true },
        { name: 'Valor', value: `**${money(normalizedAmount)}**`, inline: true },
        { name: 'Plano', value: `**${session.plano}** • ${session.dias} dias`, inline: true },
        { name: 'Cobrança expira', value: `<t:${expireUnix}:F>\n<t:${expireUnix}:R>`, inline: false },
        { name: 'Após a compra', value: 'A validade do plano começa a ser registrada e, sem renovação, o bot será desligado quando ela terminar.', inline: false }
      )
      .setImage('attachment://zenyx-pix.png')
      .setFooter({ text: 'ASTRO SOLUTION • Mercado Pago PIX' })],
    components: [paymentButtons(session.aluguel, session, transaction.ticket_url)],
    files: [attachment]
  });
  db1.set(`${channelId}.copyCola`, qrCode);
  db1.set(`${channelId}.payment`, { id: String(data.id), amount: normalizedAmount, createdAt: Date.now() });

  clearWatch(channelId);
  const poller = setInterval(async () => {
    const current = sessionFor(channelId);
    if (!current) return clearWatch(channelId);
    try {
      const doc = await paymentStatus(token, data.id);
      if (doc.status !== 'approved') return;
      const bank = doc?.point_of_interaction?.transaction_data?.bank_info?.payer?.long_name || 'Mercado Pago';
      const blocked = Array.isArray(api.get('banksOff')) ? api.get('banksOff') : [];
      const hit = blocked.some(name => String(bank).toLowerCase().includes(String(name).toLowerCase()));
      if (hit) {
        clearWatch(channelId);
        await refund(token, data.id).catch(error => logError(error, 'purchase-refund'));
        await paymentMessage.edit({
          content: `<@${current.userid}>`,
          embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Pagamento recusado pelo antifraude').setDescription(`Banco identificado: **${String(bank).slice(0, 120)}**. O pagamento foi enviado para reembolso.`)],
          components: [], files: []
        }).catch(() => null);
        db1.delete(channelId);
        return closeThreadLater(interaction.channel);
      }
      await successPanel(interaction, current, paymentMessage, bank);
    } catch (error) { logError(error, 'purchase-payment-poll'); }
  }, 4000);
  poller.unref?.();
  pollers.set(channelId, poller);
  const timeout = setTimeout(async () => {
    clearWatch(channelId);
    const current = sessionFor(channelId);
    if (!current || current.status === 'aprovado') return;
    await paymentMessage.edit({
      content: `<@${current.userid}>`,
      embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Pagamento expirado').setDescription('O tempo desta cobrança terminou. Abra uma nova compra para gerar outro Pix.')],
      components: [], files: []
    }).catch(() => null);
    db1.delete(channelId);
    closeThreadLater(interaction.channel);
  }, expiresMinutes * 60000);
  timeout.unref?.();
  timeouts.set(channelId, timeout);
}

module.exports = {
  name: 'interactionCreate',
  run: async (interaction) => {
    const customId = interaction.customId || '';
    const channelId = interaction.channel?.id;

    if (customId === 'copyCode') {
      const code = db1.get(`${channelId}.copyCola`);
      return interaction.reply({ content: code || 'Código Pix indisponível ou expirado.', flags: MessageFlags.Ephemeral });
    }

    if (customId.endsWith('_reembolAluguel')) {
      const token = String(api.get('mp') || '').trim();
      const paymentId = customId.split('_')[0];
      if (!token || !paymentId) return interaction.reply({ content: 'Pagamento não encontrado.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try { await refund(token, paymentId); return interaction.editReply('Reembolso solicitado ao Mercado Pago.'); }
      catch (error) { logError(error, 'purchase-refund-manual'); return interaction.editReply(`Não foi possível reembolsar: ${safeMessage(error, 400) || 'erro no gateway'}`); }
    }

    if (customId.endsWith('_automaticPay') || customId.startsWith('zenyxpay:auto:')) {
      const session = sessionFor(channelId, interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão de compra expirou ou já foi encerrada. Abra um novo carrinho.', flags: MessageFlags.Ephemeral });
      if (!api.get('sistemaMp') || !String(api.get('mp') || '').trim()) return interaction.reply({ content: 'O Pix automático ainda não foi configurado pelo proprietário.', flags: MessageFlags.Ephemeral });
      const amount = originalAmount(session);
      const threadId = channelId;
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor('#3155ff').setTitle('Aplicar cupom?').setDescription(`Valor atual: **R$ ${amount.toFixed(2).replace('.', ',')}**\nEscolha como deseja continuar.`)],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`zenyx:coupon:${threadId}`).setLabel('Usar cupom').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`zenyx:nocoupon:${threadId}`).setLabel('Prosseguir sem cupom').setStyle(ButtonStyle.Success)
        )],
        flags: MessageFlags.Ephemeral
      });
    }

    if (customId.startsWith('zenyx:nocoupon:')) {
      const target = customId.split(':')[2];
      if (target !== channelId) return interaction.reply({ content: 'Esta cobrança pertence a outro carrinho.', flags: MessageFlags.Ephemeral });
      const session = sessionFor(channelId, interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão expirou.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        await createPix(interaction, originalAmount(session));
        return interaction.editReply('Pagamento gerado no tópico. Use o QR Code/Pix exibido acima.');
      } catch (error) {
        logError(error, 'purchase-create-pix');
        return interaction.editReply(`Não foi possível gerar o pagamento. ${safeMessage(error, 500)}`);
      }
    }

    if (customId.startsWith('zenyx:coupon:')) {
      const target = customId.split(':')[2];
      if (target !== channelId || !sessionFor(channelId)) return interaction.reply({ content: 'Esta sessão expirou.', flags: MessageFlags.Ephemeral });
      const modal = new ModalBuilder().setCustomId(`zenyx:couponmodal:${channelId}`).setTitle('Cupom ZENYX');
      modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code').setLabel('Código do cupom').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50)));
      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit?.() && customId.startsWith('zenyx:couponmodal:')) {
      const target = customId.split(':')[2];
      if (target !== channelId) return interaction.reply({ content: 'Esta sessão pertence a outro carrinho.', flags: MessageFlags.Ephemeral });
      const session = sessionFor(channelId);
      if (!session) return interaction.reply({ content: 'Esta sessão expirou.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      const code = interaction.fields.getTextInputValue('code').trim();
      const coupon = logs.get(`Cupoms.${code}`);
      const percent = Number(coupon?.desconto);
      if (!coupon || !Number.isFinite(percent) || percent < 0 || percent > 100) return interaction.editReply('Cupom inválido ou expirado.');
      const amount = Number((originalAmount(session) * (1 - percent / 100)).toFixed(2));
      try {
        await createPix(interaction, amount);
        return interaction.editReply(`Cupom aplicado: **${percent}%**. ${amount ? 'Pagamento gerado no tópico.' : 'Compra aprovada sem cobrança.'}`);
      } catch (error) {
        logError(error, 'purchase-create-pix-coupon');
        return interaction.editReply(`Não foi possível concluir o pagamento. ${safeMessage(error, 500)}`);
      }
    }
  }
};
