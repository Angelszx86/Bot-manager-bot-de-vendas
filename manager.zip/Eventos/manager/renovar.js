const { ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ChannelType, EmbedBuilder, ModalBuilder, TextInputBuilder, AttachmentBuilder } = require("discord.js");
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");
const mercadopago = require("mercadopago");
const axios = require("axios");
const fs = require("fs");
const QRCode = require('qrcode');
const { notifyBuyer, money } = require('../../Lib/planPurchase');
let mp = api.get("mp");

let copyCode = null;

module.exports = {
    name: `interactionCreate`,

    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        const parts = interaction.customId.split("_");
        let id = parts[0];
        let idApp = parts.length >= 3 ? parts.slice(1, -1).join("_") : parts[1];

        if (customId === "copyCodeR") {

            interaction.reply({
                content: copyCode || "\`🔴\` Chave não encontrada!",
                ephemeral: true
            });

        };

        if (customId.endsWith("_renovApp")) {

            const plano = db2.get(`${idApp}.plano`);

            const valor = parseFloat(db.get(`${id}.preco.${plano.toLowerCase()}.preco`) * db2.get(`${idApp}.quantia`)).toFixed(2);

            if (!api.get("mp")) {
                return interaction.reply({ content: `\`❌\` A forma de pagamento não foi configurada ainda!`, ephemeral: true });
            };

            const payment_data = {
                transaction_amount: Number(valor),
                description: `Cobrança - ${interaction.user.username}`,
                payment_method_id: "pix",
                payer: {
                    email: `${interaction.user?.id}@gmail.com`,
                }
            };

            mercadopago.configurations.setAccessToken(mp);
            await mercadopago.payment.create(payment_data)
                .then(async (paymentResponse) => {

                    const data = paymentResponse.body;
                    const qrCode = data.point_of_interaction.transaction_data.qr_code;
                    // QR Code limpo: não usa mais a antiga imagem/logotipo "P" sobre o PIX.
                    const buffer = await QRCode.toBuffer(qrCode, { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
                    const attachment = new AttachmentBuilder(buffer, { name: "zenyx-renovacao-pix.png" });

                    const dias = await db2.get(`${idApp}.dias`);
                    const quantia = await db2.get(`${idApp}.quantia`);

                    const expiresUnix = Math.floor((Date.now() + Number(dias) * 24 * 60 * 60 * 1000) / 1000);
                    const embed = new EmbedBuilder()
                        .setColor('#3155ff')
                        .setTitle('ASTRA APPLICATION • Renovação do bot de vendas')
                        .setDescription('Pague pelo QR Code ou pelo PIX Copia e Cola. A renovação é aplicada somente depois que o pagamento for confirmado.')
                        .addFields(
                            { name: 'Produto', value: '**bot de vendas**', inline: true },
                            { name: 'Valor', value: `**${money(valor)}**`, inline: true },
                            { name: 'Plano', value: `**${plano}** • ${Number(dias)} dias`, inline: true },
                            { name: 'Nova validade prevista', value: `<t:${expiresUnix}:F>\n<t:${expiresUnix}:R>`, inline: false },
                            { name: 'PIX Copia e Cola', value: `\`\`\`${qrCode}\`\`\``, inline: false },
                            { name: 'Expiração', value: 'Se o plano não for renovado novamente, o **bot de vendas** será desligado automaticamente quando a validade terminar.', inline: false }
                        )
                        .setImage('attachment://zenyx-renovacao-pix.png')
                        .setFooter({ text: 'ASTRO SOLUTION • renovação PIX sem logotipo sobre o QR Code' })
                        .setTimestamp();

                    interaction.update({
                        content: `${interaction.user}`,
                        embeds: [embed],
                        components: [
                            new ActionRowBuilder()
                                .addComponents(
                                    new ButtonBuilder().setCustomId(`copyCodeR`).setLabel(`Copiar PIX`).setEmoji(`📋`).setStyle(1),
                                    new ButtonBuilder().setURL(data.point_of_interaction.transaction_data.ticket_url).setLabel(`Pagar por site`).setEmoji(`👀`).setStyle(5)
                                )
                        ],
                        files: [attachment]
                    }).then(async (msg) => {

                        copyCode = qrCode;

                        const checkPaymentStatus = setInterval(() => {
                            axios.get(`https://api.mercadopago.com/v1/payments/${data?.id}`, {
                                headers: {
                                    'Authorization': `Bearer ${mp}`
                                }
                            }).then(async (doc) => {

                                if (doc?.data.status === "approved") {
                                    clearInterval(checkPaymentStatus);

                                    const blockedBanks = api.get("banksOff");
                                    const longName = doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name.toLowerCase();
                                    const encontrado = blockedBanks.some(banco => longName.includes(banco.toLowerCase()));

                                    const plano = db2.get(`${idApp}.plano`);

                                    if (encontrado) {

                                        await msg.edit({
                                            content: `${interaction.user}`,
                                            embeds: [
                                                new EmbedBuilder()
                                                .setAuthor({ name: `${interaction.user.username} - Anti Fraude Detectada`, iconURL: interaction.user.displayAvatarURL() })
                                                .setDescription(`-# \`🔎\` Por questão de segurança a sua renovação com o banco \`${doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name}\` foi cancelada.\n-# \`❓\` Está em dúvida ou precisa de ajuda com algo? Contate o suporte!`)
                                                .addFields(
                                                    { name: `Aluguel`, value: `\`${id} | R$${Number(db.get(`${id}.preco.${plano.toLowerCase()}.preco`) * Number(quantia)).toFixed(2)}\``, inline: true },
                                                    { name: `Plano`, value: `\`x${Number(quantia)} | ${plano}/${Number(dias)}d\``, inline: true },
                                                    { name: `User/Banco`, value: `<@${db1.get(`${interaction.channel.id}.userid`)}>/\`${doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name || "\`🔴 Não encontrado.\`"}\`` }
                                                )
                                                .setColor(`#FF0000`)
                                                .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                                                .setTimestamp()
                                            ],
                                            components: [],
                                            files: []
                                        }).catch(error => { });

                                        if (logs.get("channel_logs")) {
                                            const channel = interaction.guild.channels.cache.get(logs.get("channel_logs"));
                            
                                            channel.send({
                                                content: ``,
                                                embeds: [
                                                    new EmbedBuilder()
                                                        .setAuthor({ name: `${interaction.user.username} - Anti Fraude Detectada`, iconURL: interaction.user.displayAvatarURL() })
                                                        .setDescription(`-# \`❌\` Renovação cancelada por **Anti Fraude Detectada**.`)
                                                        .addFields(
                                                            { name: `Aluguel`, value: `\`${id} | R$${Number(db.get(`${id}.preco.${plano.toLowerCase()}.preco`) * Number(quantia)).toFixed(2)}\``, inline: true },
                                                            { name: `Plano`, value: `\`x${Number(quantia)} | ${plano}/${Number(dias)}d\``, inline: true },
                                                            { name: `User/Banco`, value: `<@${db1.get(`${interaction.channel.id}.userid`)}>/\`${doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name || "\`🔴 Não encontrado.\`"}\`` }
                                                        )
                                                        .setColor(`#FF0000`)
                                                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                                                        .setTimestamp()
                                                ],
                                                components: [
                                                    new ActionRowBuilder()
                                                        .addComponents(
                                                            new ButtonBuilder().setCustomId(`botN`).setLabel(`Notificação do Anti Fraude`).setStyle(2).setDisabled(true)
                                                        )
                                                ]
                                            }).catch(error => { });
                            
                                        };

                                        const axios = require('axios');
                                        await axios.post(`https://api.mercadopago.com/v1/payments/${data?.id}/refunds`, {}, {
                                            headers: {
                                                'Authorization': `Bearer ${mp}`
                                            }
                                        }).catch(error => { });

                                        return;

                                    };

                                    auto.set(`${db2.get(`${idApp}.owner`)}_owner.butecos`, {
                                        nome: db2.get(`${idApp}.nome`),
                                        dias: Number(dias),
                                        plano: db2.get(`${idApp}.plano`),
                                        quantia: db2.get(`${idApp}.quantia`),
                                        dataExpiracao: new Date(Date.now() + dias * 24 * 60 * 60 * 1000),
                                        idapp: idApp,
                                        token: db2.get(`${idApp}.token`),
                                        produto: db2.get(`${idApp}.produto`),
                                        notify: false
                                    });
                        
                                    const renewedExpiration = new Date(Date.now() + dias * 24 * 60 * 60 * 1000);
                                    db2.set(`${idApp}`, {
                                        nome: db2.get(`${idApp}.nome`),
                                        dias: Number(dias),
                                        plano: db2.get(`${idApp}.plano`),
                                        quantia: db2.get(`${idApp}.quantia`),
                                        dataExpiracao: renewedExpiration,
                                        idapp: idApp,
                                        token: db2.get(`${idApp}.token`),
                                        produto: db2.get(`${idApp}.produto`),
                                        owner: db2.get(`${idApp}.owner`)
                                    });

                                    await notifyBuyer(client, interaction.user.id, {
                                        session: { plano, dias: Number(dias), aluguel: id, quantia: Number(quantia) },
                                        amount: Number(valor),
                                        provider: 'Mercado Pago PIX • renovação',
                                        expiration: renewedExpiration
                                    });

                                    await msg.edit({
                                        content: `${interaction.user}`,
                                        embeds: [
                                            new EmbedBuilder()
                                            .setTitle('Renovação confirmada • bot de vendas')
                                            .setDescription('O pagamento foi confirmado e a validade do seu **bot de vendas** foi renovada.')
                                            .addFields(
                                                { name: 'Valor pago', value: `**${money(valor)}**`, inline: true },
                                                { name: 'Plano', value: `**${plano}** • ${Number(dias)} dias`, inline: true },
                                                { name: 'Banco', value: `**${String(doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name || 'Não identificado').slice(0, 100)}**`, inline: true },
                                                { name: 'Nova expiração', value: `<t:${Math.floor(renewedExpiration.getTime()/1000)}:F>\n<t:${Math.floor(renewedExpiration.getTime()/1000)}:R>`, inline: false },
                                                { name: 'Quando o bot desliga?', value: 'Sem uma nova renovação, o bot será desligado automaticamente quando a validade acima terminar.', inline: false }
                                            )
                                            .setColor(`#00FF00`)
                                            .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                                            .setTimestamp()
                                        ],
                                        components: [],
                                        files: []
                                    });

                                    if (logs.get("renov")) {
                                        const channel = interaction.guild.channels.cache.get(logs.get("renov"));
                        
                                        channel.send({
                                            content: ``,
                                            embeds: [
                                                new EmbedBuilder()
                                                .setAuthor({ name: `${interaction.user.username} - Aluguel Pago`, iconURL: interaction.user.displayAvatarURL() })
                                                .setDescription(`-# \`✅\` Aluguel plano \`${plano}\` renovado com êxito!\n-# \`🔎\` Veja algumas informações abaixo:`)
                                                .addFields(
                                                    { name: `Aluguel`, value: `\`${id} | R$${Number(db.get(`${id}.preco.${plano.toLowerCase()}.preco`) * Number(quantia)).toFixed(2)}\``, inline: true },
                                                    { name: `Plano`, value: `\`x${Number(quantia)} | ${plano}/${Number(dias)}d\``, inline: true },
                                                    { name: `Banco`, value: `\`${doc.data.point_of_interaction.transaction_data.bank_info.payer.long_name || "\`🔴 Não encontrado.\`"}\`` }
                                                )
                                                .setColor(`#00FF00`)
                                                .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                                                .setTimestamp()
                                            ],
                                            components: [
                                                new ActionRowBuilder()
                                                    .addComponents(
                                                        new ButtonBuilder().setCustomId(`botN`).setLabel(`Mensagem do Sistema`).setStyle(2).setDisabled(true)
                                                    )
                                            ]
                                        }).catch(error => { });
                        
                                    };

                                } else { };

                            });
                        }, 2000);

                    });

                });

        };

    }
}