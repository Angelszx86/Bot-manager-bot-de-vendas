const {
  Events, ChannelType, PermissionFlagsBits, MessageFlags,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder,
  TextInputStyle, ContainerBuilder, MediaGalleryBuilder, MediaGalleryItemBuilder,
  SeparatorBuilder, TextDisplayBuilder, AttachmentBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const JSZip = require('jszip');
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const { db2, auto } = require('../../databases/index');
const center = require('../../Lib/clientCenter');
const keys = require('../../Lib/keys');
const { readCache, id: emojiId, fmt } = require('../../Lib/managerEmojis');
const { configureZip, validateChildToken, identifyChildToken } = require('./enviarbot');
const { validateGuildMembership } = require('../../Lib/discordChildValidation');

const BRAND_BANNER = path.join(__dirname, '../../assets/branding/astra-applications-panel.png');

function em(gid) { return readCache(gid); }
function icon(gid, key) { return fmt(em(gid), key); }
function withEmoji(button, gid, semantic) { const eid = emojiId(em(gid), semantic, null); if (eid) button.setEmoji({ id: eid }); return button; }
function threadName(user, grantId) {
  const safe = String(user?.username || 'usuario').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 48) || 'usuario';
  return `bot-${safe}-${String(grantId).slice(0, 6)}`.slice(0, 100);
}
function active(grant) { return Boolean(grant) && (!grant.expiresAt || Date.parse(grant.expiresAt) > Date.now()); }
function validity(grant) { return grant?.expiresAt && Number.isFinite(Date.parse(grant.expiresAt)) ? `<t:${Math.floor(Date.parse(grant.expiresAt) / 1000)}:F> (<t:${Math.floor(Date.parse(grant.expiresAt) / 1000)}:R>)` : '**sem expiração definida**'; }
function configButton(gid, grantId, userId) {
  return withEmoji(new ButtonBuilder().setCustomId(`keybot:configure:${grantId}:${userId}`.slice(0,100)).setLabel('Configurar bot').setStyle(ButtonStyle.Primary), gid, 'settings');
}
function closeButton(gid, userId) {
  return withEmoji(new ButtonBuilder().setCustomId(`keybot:close:${userId}`.slice(0,100)).setLabel('Fechar tópico').setStyle(ButtonStyle.Danger), gid, 'delete');
}
function boundText(grant) {
  if (!grant?.childClientId) return '**Ainda não vinculada.** O primeiro bot validado ficará preso a esta Key.';
  return `**Vinculada permanentemente** ao Client ID \`${grant.childClientId}\`. Se o runtime for removido, somente esse mesmo bot poderá ser ligado novamente com esta Key.`;
}
function threadPayload(interaction, grant) {
  const container = new ContainerBuilder().setAccentColor(0x3155ff)
    .addMediaGalleryComponents(new MediaGalleryBuilder().addItems(new MediaGalleryItemBuilder().setURL('attachment://astra-applications-panel.png')))
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${icon(interaction.guildId, 'bot')} Configurar aplicação da sua Key`),
      new TextDisplayBuilder().setContent(
        `Este benefício pertence a ${interaction.user}. Informe o **token do bot** e o **ID do servidor** somente pelo formulário privado.\n\n` +
        `### ${icon(interaction.guildId, 'key')} Benefício\n` +
        `**Plano:** ${grant.plan || 'Key'}\n` +
        `**Validade:** ${validity(grant)}\n` +
        `**Status:** ${grant.childClientId ? 'Bot já identificado • pronto para recuperar/configurar' : 'Aguardando primeira vinculação'}\n\n` +
        `### ${icon(interaction.guildId, 'safety')} Proteção por Client ID\n${boundText(grant)}\n\n` +
        `-# O token nunca deve ser enviado diretamente no tópico. Use apenas o botão Configurar bot.`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      configButton(interaction.guildId, grant.grantId, interaction.user.id),
      closeButton(interaction.guildId, interaction.user.id)
    ));
  return {
    flags: MessageFlags.IsComponentsV2,
    components: [container],
    files: [new AttachmentBuilder(BRAND_BANNER, { name: 'astra-applications-panel.png' })]
  };
}
async function findThread(interaction, grantId) {
  const parent = interaction.channel;
  if (!parent?.threads) return null;
  const name = threadName(interaction.user, grantId);
  const cached = parent.threads.cache.find(t => t.name === name && !t.archived);
  if (cached) return cached;
  const activeThreads = await parent.threads.fetchActive().catch(() => null);
  return activeThreads?.threads?.find?.(t => t.name === name && !t.archived) || null;
}
async function createThread(interaction, grant) {
  if (!interaction.channel?.threads?.create) throw new Error('Abra a Central em um canal de texto onde o Manager possa criar tópicos.');
  const existing = await findThread(interaction, grant.grantId);
  if (existing) return existing;
  const me = interaction.guild?.members?.me;
  const perms = interaction.channel.permissionsFor(me);
  const canPrivate = Boolean(perms?.has(PermissionFlagsBits.CreatePrivateThreads));
  const canPublic = Boolean(perms?.has(PermissionFlagsBits.CreatePublicThreads));
  const canSend = Boolean(perms?.has(PermissionFlagsBits.SendMessagesInThreads));
  if (!canSend || (!canPrivate && !canPublic)) throw new Error('O Manager precisa de Criar Tópicos e Enviar Mensagens em Tópicos neste canal.');
  let thread;
  if (canPrivate) {
    thread = await interaction.channel.threads.create({ name: threadName(interaction.user, grant.grantId), type: ChannelType.PrivateThread, autoArchiveDuration: 60, invitable: false, reason: `Configuração de Key ${grant.grantId}` }).catch(() => null);
    if (thread) await thread.members.add(interaction.user.id).catch(() => null);
  }
  if (!thread && canPublic) thread = await interaction.channel.threads.create({ name: threadName(interaction.user, grant.grantId), type: ChannelType.PublicThread, autoArchiveDuration: 60, reason: `Configuração de Key ${grant.grantId}` });
  if (!thread) throw new Error('Não foi possível criar o tópico de configuração.');
  await thread.send(threadPayload(interaction, grant));
  return thread;
}
function modal(grantId, userId) {
  return new ModalBuilder().setCustomId(`keybot:submit:${grantId}:${userId}`.slice(0,100)).setTitle('Configurar bot da Key').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('name').setLabel('NOME DA APLICAÇÃO').setPlaceholder('Ex: Loja principal').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(40)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('token').setLabel('TOKEN DO BOT').setPlaceholder('Cole o token da aplicação Discord').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(200)),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('guild').setLabel('ID DO SERVIDOR').setPlaceholder('123456789012345678').setStyle(TextInputStyle.Short).setRequired(true).setMinLength(17).setMaxLength(20))
  );
}
async function health(api, appId) {
  const app = await api.applications.get(appId);
  await new Promise(resolve => setTimeout(resolve, 2200));
  const status = await app.getStatus();
  if (!status?.pid || Number(status.pid) <= 0) throw new Error('O processo iniciou, mas não permaneceu online. Nenhum benefício foi consumido.');
}
function ownedRuntime(grant, userId) {
  if (!grant?.runtimeId) return null;
  return center.findOwnedApp(userId, grant.runtimeId);
}
function prepareRecoverableGrant(userId, grant) {
  if (!grant) return grant;
  if (!grant.runtimeId || ownedRuntime(grant, userId)) return grant;
  // O runtime foi removido da conta, mas o Client ID continua preso ao benefício.
  // Isso permite recuperação do MESMO bot sem transformar a Key em uma licença reutilizável para outro bot.
  return keys.updateUserEntitlement(userId, grant.grantId, {
    previousRuntimeId: grant.runtimeId,
    runtimeId: '',
    status: grant.childClientId ? 'recoverable' : 'available'
  });
}
function assertClientBinding(grant, botId) {
  const bound = String(grant?.childClientId || '').trim();
  if (bound && bound !== String(botId)) {
    throw new Error(`Esta Key já está vinculada ao bot de Client ID ${bound}. Para recuperar/religar o benefício, use o token desse mesmo bot. Outro bot não pode assumir esta Key.`);
  }
}
function successPayload(interaction, grant, appId, guildId) {
  const container = new ContainerBuilder().setAccentColor(0x57f287)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${icon(interaction.guildId,'success')} Aplicação configurada`),
      new TextDisplayBuilder().setContent(
        `O bot está **online** e vinculado à sua Key.\n\n` +
        `**Runtime:** \`${appId}\`\n` +
        `**Client ID protegido:** \`${grant.childClientId || '—'}\`\n` +
        `**Servidor:** \`${guildId}\`\n` +
        `**Validade:** ${validity(grant)}\n\n` +
        `Se esta instância for removida, a Key poderá recuperar **somente este mesmo Client ID** enquanto continuar válida.`
      )
    )
    .addActionRowComponents(new ActionRowBuilder().addComponents(closeButton(interaction.guildId, interaction.user.id)));
  return { flags: MessageFlags.IsComponentsV2, components: [container] };
}

module.exports = {
  name: Events.InteractionCreate,
  run: async (interaction, client) => {
    const id = interaction.customId || '';
    if (!id.startsWith('keybot:')) return;
    try {
      if (id.startsWith('keybot:select:') && interaction.isStringSelectMenu?.()) {
        const expected = id.split(':')[2];
        if (expected !== interaction.user.id) return interaction.reply({ content: 'Este menu pertence a outro usuário.', flags: MessageFlags.Ephemeral });
        let grant = keys.getUserEntitlement(interaction.user.id, interaction.values[0]);
        if (!grant) return interaction.reply({ content: `${icon(interaction.guildId,'wrong')} Benefício da Key não encontrado.`, flags: MessageFlags.Ephemeral });
        if (!active(grant)) return interaction.reply({ content: `${icon(interaction.guildId,'warn')} Esta Key expirou e não pode mais iniciar uma aplicação.`, flags: MessageFlags.Ephemeral });
        grant = prepareRecoverableGrant(interaction.user.id, grant);
        const app = ownedRuntime(grant, interaction.user.id);
        if (app) return interaction.update(center.appDetailsPayload(app, interaction.user.id));
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const thread = await createThread(interaction, grant);
        return interaction.editReply({ content: `${icon(interaction.guildId,'success')} Configuração aberta em ${thread}. Use o botão dentro do tópico para informar token e servidor.` });
      }

      const close = id.match(/^keybot:close:(\d{15,25})$/i);
      if (close && interaction.isButton?.()) {
        const expected = close[1];
        if (expected !== interaction.user.id) return interaction.reply({ content: 'Este tópico pertence a outro usuário.', flags: MessageFlags.Ephemeral });
        if (!interaction.channel?.isThread?.()) return interaction.reply({ content: 'Este botão só funciona dentro do tópico da Key.', flags: MessageFlags.Ephemeral });
        await interaction.reply({ content: `${icon(interaction.guildId,'success')} Tópico fechado. Sua Key e o vínculo do Client ID continuam salvos.`, flags: MessageFlags.Ephemeral });
        setTimeout(() => {
          interaction.channel.setLocked?.(true, 'Fechado pelo proprietário da Key').catch(() => null);
          interaction.channel.setArchived?.(true, 'Fechado pelo proprietário da Key').catch(() => null);
        }, 700);
        return;
      }

      const configure = id.match(/^keybot:configure:([a-f0-9]{8,64}):(\d{15,25})$/i);
      if (configure && interaction.isButton?.()) {
        const [, grantId, expected] = configure;
        if (expected !== interaction.user.id) return interaction.reply({ content: 'Este controle pertence a outro usuário.', flags: MessageFlags.Ephemeral });
        let grant = keys.getUserEntitlement(interaction.user.id, grantId);
        if (!active(grant)) return interaction.reply({ content: `${icon(interaction.guildId,'warn')} A validade desta Key terminou.`, flags: MessageFlags.Ephemeral });
        grant = prepareRecoverableGrant(interaction.user.id, grant);
        if (ownedRuntime(grant, interaction.user.id)) return interaction.reply({ content: `${icon(interaction.guildId,'info')} Este benefício já possui uma aplicação ativa. Remova a instância atual antes de tentar recuperar o mesmo bot.`, flags: MessageFlags.Ephemeral });
        return interaction.showModal(modal(grantId, interaction.user.id));
      }

      const submit = id.match(/^keybot:submit:([a-f0-9]{8,64}):(\d{15,25})$/i);
      if (submit && interaction.isModalSubmit?.()) {
        const [, grantId, expected] = submit;
        if (expected !== interaction.user.id) return interaction.reply({ content: 'Este formulário pertence a outro usuário.', flags: MessageFlags.Ephemeral });
        let grant = keys.getUserEntitlement(interaction.user.id, grantId);
        if (!active(grant)) return interaction.reply({ content: `${icon(interaction.guildId,'warn')} Esta Key expirou antes da configuração ser concluída.`, flags: MessageFlags.Ephemeral });
        grant = prepareRecoverableGrant(interaction.user.id, grant);
        if (ownedRuntime(grant, interaction.user.id)) return interaction.reply({ content: `${icon(interaction.guildId,'info')} Este benefício já possui uma aplicação ativa.`, flags: MessageFlags.Ephemeral });
        const token = interaction.fields.getTextInputValue('token').trim();
        const guildId = interaction.fields.getTextInputValue('guild').trim();
        const name = interaction.fields.getTextInputValue('name').trim().slice(0,40) || 'Minha aplicação';
        if (!/^\d{17,20}$/.test(guildId)) return interaction.reply({ content: `${icon(interaction.guildId,'wrong')} ID de servidor inválido.`, flags: MessageFlags.Ephemeral });
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        // Trava a Key no primeiro TOKEN válido antes de validar o servidor.
        // Assim um erro de Guild ID nunca transforma a Key em licença reutilizável.
        const botInfo = await identifyChildToken(token, client.application?.id || client.user.id);
        grant = keys.getUserEntitlement(interaction.user.id, grantId);
        if (!active(grant)) throw new Error('A Key expirou durante a validação. Nenhum runtime foi criado.');
        grant = prepareRecoverableGrant(interaction.user.id, grant);
        assertClientBinding(grant, botInfo.id);
        if (!grant.childClientId) {
          grant = keys.updateUserEntitlement(interaction.user.id, grantId, {
            childClientId: String(botInfo.id),
            clientBoundAt: new Date().toISOString(),
            status: 'bound'
          });
        }
        const membership = await validateGuildMembership(token, guildId, botInfo.id, { attempts: 4, delayMs: 1200 }).catch(() => null);
        if (!membership?.ok) {
          const invite = center.inviteUrl(botInfo.id, guildId);
          const row = new ActionRowBuilder().addComponents(
            configButton(interaction.guildId, grantId, interaction.user.id),
            ...(invite ? [new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(invite).setLabel('Adicionar bot ao servidor')] : [])
          );
          return interaction.editReply({
            content: `${icon(interaction.guildId,'warn')} **Client ID protegido:** \`${botInfo.id}\`\nO token é válido, mas o Discord ainda não confirmou esta aplicação no servidor \`${guildId}\`.\n\nAdicione **esse mesmo bot** ao servidor ou abra **Configurar bot** para corrigir o ID/token. A Key continua presa a este Client ID.`,
            components: [row]
          });
        }
        const sourceFile = path.join(__dirname, '../../source/ZenyxPro.zip');
        if (!fs.existsSync(sourceFile)) throw new Error('Template do bot de vendas não encontrado.');
        const zip = await JSZip.loadAsync(fs.readFileSync(sourceFile));
        const daysLeft = grant.expiresAt ? Math.max(0.0007, (Date.parse(grant.expiresAt) - Date.now()) / 86400000) : 36500;
        await configureZip(zip, { token, ownerId: interaction.user.id, clientId: botInfo.id, guildId, days: daysLeft, expiresAt: grant.expiresAt || undefined });
        const clientDir = path.join(__dirname, '../../source/client');
        fs.mkdirSync(clientDir, { recursive: true });
        const temp = path.join(clientDir, `key-${grantId}-${crypto.randomUUID()}.zip`);
        let appId = '';
        const api = new SquareCloudAPI();
        try {
          fs.writeFileSync(temp, await zip.generateAsync({ type: 'nodebuffer' }), { mode: 0o600 });
          await interaction.editReply({ content: `${icon(interaction.guildId,'loading')} Dados validados. Iniciando sua aplicação...` });
          const created = await api.applications.create(temp);
          appId = String(created.id);
          await health(api, appId);
          grant = keys.getUserEntitlement(interaction.user.id, grantId);
          if (!active(grant)) {
            const runtime = await api.applications.get(appId).catch(() => null); await runtime?.stop?.().catch(() => null);
            throw new Error('A validade da Key terminou antes da conclusão. O runtime foi interrompido.');
          }
          const record = {
            nome: name, dias: grant.expiresAt ? Number(daysLeft.toFixed(4)) : 0, plano: grant.plan || 'Key', quantia: 1,
            dataExpiracao: grant.expiresAt || null, idapp: appId, token, produto: 'ZenyxPro', owner: interaction.user.id,
            guildId, childClientId: botInfo.id, notify: false, status: 'online', source: 'key', keyGrantId: grant.grantId, keyCode: grant.key
          };
          db2.set(appId, record);
          const ownerKey = `${interaction.user.id}_owner`;
          const ownerData = auto.get(ownerKey) || { owner: interaction.user.id, butecos: [] };
          ownerData.butecos = [...(ownerData.butecos || []).filter(x => String(x?.idapp) !== appId), record];
          auto.set(ownerKey, ownerData);
          grant = keys.updateUserEntitlement(interaction.user.id, grantId, { runtimeId: appId, provisionedAt: new Date().toISOString(), status: 'provisioned', childClientId: botInfo.id, guildId });
          await interaction.editReply({ content: `${icon(interaction.guildId,'success')} **Aplicação online.**\nRuntime: \`${appId}\`\nServidor: \`${guildId}\`\nValidade: ${validity(grant)}\n\nQuando a validade da Key terminar, o Manager desligará este runtime automaticamente.` });
          if (interaction.channel?.isThread?.()) {
            await interaction.channel.send(successPayload(interaction, grant, appId, guildId)).catch(() => null);
            const thread = interaction.channel;
            setTimeout(async () => {
              await thread.setLocked(true, 'ASTRA APPLICATION • Key vinculada com sucesso').catch(() => null);
              await thread.setArchived(true, 'ASTRA APPLICATION • configuração concluída').catch(() => null);
            }, 2500);
          }
        } catch (error) {
          if (appId && !db2.get(appId)) {
            const runtime = await api.applications.get(appId).catch(() => null);
            await runtime?.stop?.().catch(() => null);
            const recoverable = {
              nome: name, dias: grant.expiresAt ? Number(daysLeft.toFixed(4)) : 0, plano: grant.plan || 'Key', quantia: 1,
              dataExpiracao: grant.expiresAt || null, idapp: appId, token, produto: 'ZenyxPro', owner: interaction.user.id,
              guildId, childClientId: botInfo.id, notify: false, status: 'recoverable', recoverable: true,
              removedAt: new Date().toISOString(), source: 'key', keyGrantId: grant.grantId, keyCode: grant.key
            };
            db2.set(appId, recoverable);
            const ownerKey = `${interaction.user.id}_owner`;
            const ownerData = auto.get(ownerKey) || { owner: interaction.user.id, butecos: [] };
            ownerData.butecos = [...(ownerData.butecos || []).filter(x => String(x?.idapp) !== appId), recoverable];
            auto.set(ownerKey, ownerData);
            grant = keys.updateUserEntitlement(interaction.user.id, grantId, { runtimeId: appId, status: 'recoverable', childClientId: botInfo.id, guildId });
          }
          throw error;
        } finally { fs.rmSync(temp, { force: true }); }
        return;
      }
    } catch (error) {
      const text = `${icon(interaction.guildId,'wrong')} ${String(error?.message || error).slice(0,900)}`;
      if (interaction.deferred) return interaction.editReply({ content: text }).catch(() => null);
      if (interaction.replied) return interaction.followUp({ content: text, flags: MessageFlags.Ephemeral }).catch(() => null);
      return interaction.reply({ content: text, flags: MessageFlags.Ephemeral }).catch(() => null);
    }
  }
};
