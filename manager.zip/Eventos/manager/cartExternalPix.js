const {
  ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
  EmbedBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const QRCode = require('qrcode');
const { db1, logs, clientes } = require('../../databases/index');
const gateway = require('../../Lib/externalPixGateway');
const purchaseSessions = require('../../Lib/purchaseSessions');
const { amountForSession, expirationForSession, notifyBuyer, money, linkingReadyEmbed } = require('../../Lib/planPurchase');
const { logError, safeMessage } = require('../../Lib/interactions');
const { ensureAndReport: ensureClientRole } = require('../../Lib/clientRole');

const pollers = new Map();
const timers = new Map();
const MODE_TO_PROVIDER = { vyv: 'vyvence', mag: 'magnus', pro: 'promisse' };

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function clearWatch(channelId) {
  if (pollers.has(channelId)) clearInterval(pollers.get(channelId));
  if (timers.has(channelId)) clearTimeout(timers.get(channelId));
  pollers.delete(channelId); timers.delete(channelId);
}
async function qrAttachment(transaction, name) {
  const base64 = String(transaction?.qrCodeBase64 || '');
  if (base64) {
    const raw = base64.includes(',') ? base64.split(',').pop() : base64;
    try { return new AttachmentBuilder(Buffer.from(raw, 'base64'), { name }); } catch {}
  }
  const code = String(transaction?.qrCodeText || '');
  if (!code) throw new Error('O gateway não retornou um PIX Copia e Cola reconhecível.');
  const png = await QRCode.toBuffer(code, { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
  return new AttachmentBuilder(png, { name });
}
async function approved(interaction, session, message, transaction, amount, providerKey) {
  clearWatch(interaction.channel.id);
  const config = gateway.settings(providerKey);
  db1.set(`${interaction.channel.id}.status`, 'aprovado');
  await ensureClientRole(interaction.guild, session.userid, { reason: 'Cliente ASTRA APPLICATION • pagamento externalpix confirmado' });
  const expiration = expirationForSession(session);

  // Tela intermediária solicitada: confirma o pagamento, mostra o processamento
  // e então leva o usuário diretamente para a etapa de vincular o bot.
  await message.edit({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('Pagamento confirmado • ativando plano')
      .setDescription(`Recebemos a confirmação da **${config.label}**.\n\n**Carregando sua assinatura e preparando o vínculo do bot...**`)
      .setFooter({ text: 'ASTRO SOLUTION • aguarde alguns instantes' })],
    components: [], files: [], attachments: []
  }).catch(error => logError(error, 'externalpix-loading-edit'));
  await sleep(1100);

  await message.edit({
    content: `<@${session.userid}>`,
    embeds: [linkingReadyEmbed({ session, amount, provider: `${config.label} PIX`, expiration })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`${session.dias}_${session.aluguel}_uparbot`).setLabel('Vincular bot').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setURL('https://discord.com/developers/applications').setLabel('Discord Developer').setStyle(ButtonStyle.Link)
    )],
    files: [], attachments: []
  }).catch(error => logError(error, 'externalpix-success-edit'));
  await notifyBuyer(interaction.client, session.userid, { session, amount, provider: `${config.label} PIX`, expiration });
  require('../../Lib/salesFeed').announce(interaction.client, { type: 'purchase', user: interaction.user, guildId: interaction.guildId, plan: session.plano, days: session.dias }).catch(error => logError(error, 'externalpix-sales-feed'));
  db1.set(`${interaction.channel.id}.payment.paidAt`, transaction?.paidAt || new Date().toISOString());
}
async function createCharge(interaction, providerKey, amount, payer = {}) {
  const session = purchaseSessions.resolve(interaction);
  if (!session) throw new Error('Esta sessão de compra expirou. Abra um novo carrinho.');
  const config = gateway.settings(providerKey);
  if (!gateway.configured(providerKey)) throw new Error(`${config.label} está indisponível no momento.`);
  const reference = gateway.reference(`ZENYX-${interaction.channel.id}`);
  const transaction = await gateway.createPix(providerKey, {
    amount,
    clientReference: reference,
    customerName: interaction.user.globalName || interaction.user.username,
    payerName: payer.name || interaction.user.globalName || interaction.user.username,
    payerDocument: payer.document || '',
    expiresIn: config.expiresIn
  });
  const attachmentName = `zenyx-${providerKey}-pix.png`;
  const attachment = await qrAttachment(transaction, attachmentName);
  const copyCode = String(transaction.qrCodeText || '');
  const expiresAt = Date.now() + config.expiresIn * 1000;
  const unix = Math.floor(expiresAt / 1000);
  const buttons = [
    new ButtonBuilder().setCustomId(`copyExternalPix:${providerKey}`).setLabel('Copiar PIX').setStyle(ButtonStyle.Primary).setDisabled(!copyCode)
  ];
  if (transaction.qrCodeUrl && /^https:\/\//i.test(transaction.qrCodeUrl)) buttons.push(new ButtonBuilder().setURL(transaction.qrCodeUrl).setLabel('Abrir cobrança').setStyle(ButtonStyle.Link));
  buttons.push(new ButtonBuilder().setCustomId(purchaseSessions.paymentId('cancel', session)).setLabel('Cancelar').setStyle(ButtonStyle.Secondary));
  const paymentMessage = await interaction.channel.send({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle(`ASTRA APPLICATION • Checkout ${config.label}`)
      .setDescription('Sua cobrança PIX foi criada. Pague pelo QR Code e aguarde a confirmação automática.')
      .addFields(
        { name: 'Produto', value: '**bot de vendas**', inline: true },
        { name: 'Valor', value: `**${money(amount)}**`, inline: true },
        { name: 'Plano', value: `**${session.plano}** • ${session.dias} dias`, inline: true },
        { name: 'Cobrança expira', value: `<t:${unix}:F>\n<t:${unix}:R>`, inline: false }
      )
      .setImage(`attachment://${attachmentName}`)
      .setFooter({ text: `ASTRO SOLUTION • ${config.label} PIX` })],
    components: [new ActionRowBuilder().addComponents(...buttons)], files: [attachment]
  });
  db1.set(`${interaction.channel.id}.copyCola`, copyCode);
  db1.set(`${interaction.channel.id}.payment`, { provider: providerKey, id: String(transaction.id), clientReference: reference, amount: Number(amount), createdAt: Date.now(), expiresAt });

  clearWatch(interaction.channel.id);
  const poller = setInterval(async () => {
    const current = db1.get(String(interaction.channel.id));
    if (!current || current.status === 'aprovado') return clearWatch(interaction.channel.id);
    try {
      const status = await gateway.getPix(providerKey, { id: transaction.id, clientReference: reference });
      if (gateway.isPaidStatus(status?.status)) return approved(interaction, current, paymentMessage, status, amount, providerKey);
      if (gateway.isTerminalStatus(status?.status)) {
        clearWatch(interaction.channel.id);
        await paymentMessage.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Cobrança encerrada').setDescription(`${config.label} retornou o status **${String(status.status).slice(0,80)}**. Gere uma nova cobrança para tentar novamente.`)], components: [], files: [], attachments: [] }).catch(() => null);
      }
    } catch (error) { logError(error, `externalpix-poll-${providerKey}`); }
  }, 4000);
  poller.unref?.(); pollers.set(interaction.channel.id, poller);

  const timer = setTimeout(async () => {
    clearWatch(interaction.channel.id);
    const current = db1.get(String(interaction.channel.id));
    if (!current || current.status === 'aprovado') return;
    await paymentMessage.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Cobrança expirada').setDescription(`O prazo desta cobrança ${config.label} terminou. Gere um novo PIX para continuar.`)], components: [], files: [], attachments: [] }).catch(() => null);
  }, config.expiresIn * 1000 + 5000);
  timer.unref?.(); timers.set(interaction.channel.id, timer);
}

module.exports = {
  name: 'interactionCreate',
  run: async (interaction) => {
    const id = interaction.customId || '';
    if (id.startsWith('copyExternalPix:')) {
      const code = db1.get(`${interaction.channel?.id}.copyCola`);
      return interaction.reply({ content: code || 'O código PIX não está mais disponível.', flags: MessageFlags.Ephemeral });
    }
    if (id === 'magnusPayerData' && interaction.isModalSubmit?.()) {
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão expirou. Abra uma nova compra.', flags: MessageFlags.Ephemeral });
      if (String(session.userid || '') !== String(interaction.user.id)) return interaction.reply({ content: 'Somente o comprador pode continuar este checkout.', flags: MessageFlags.Ephemeral });
      if (!gateway.configured('magnus')) return interaction.reply({ content: 'MagnusPay está indisponível no momento.', flags: MessageFlags.Ephemeral });
      const payerName = String(interaction.fields.getTextInputValue('payerName') || '').trim();
      const payerDocument = String(interaction.fields.getTextInputValue('payerDocument') || '').replace(/\D/g, '');
      if (payerName.length < 2) return interaction.reply({ content: 'Informe o nome do pagador.', flags: MessageFlags.Ephemeral });
      if (![11, 14].includes(payerDocument.length)) return interaction.reply({ content: 'Informe um CPF ou CNPJ válido, apenas números.', flags: MessageFlags.Ephemeral });
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        await createCharge(interaction, 'magnus', amountForSession(session), { name: payerName, document: payerDocument });
        return interaction.editReply('Cobrança MagnusPay criada no tópico.');
      } catch (error) {
        logError(error, 'externalpix-create-magnus');
        return interaction.editReply(`Não foi possível gerar a cobrança: ${safeMessage(error, 700)}`);
      }
    }

    const match = id.match(/^zenyxpay:(vyv|mag|pro):/);
    if (!match) return;
    const providerKey = MODE_TO_PROVIDER[match[1]];
    const session = purchaseSessions.resolve(interaction);
    if (!session) return interaction.reply({ content: 'Esta sessão expirou. Abra uma nova compra.', flags: MessageFlags.Ephemeral });
    if (!gateway.configured(providerKey)) return interaction.reply({ content: `${gateway.settings(providerKey).label} está indisponível no momento.`, flags: MessageFlags.Ephemeral });

    if (providerKey === 'magnus') {
      const modal = new ModalBuilder().setCustomId('magnusPayerData').setTitle('MagnusPay • dados do pagador');
      const nameInput = new TextInputBuilder()
        .setCustomId('payerName')
        .setLabel('NOME DO PAGADOR')
        .setPlaceholder('Nome completo')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(120);
      const documentInput = new TextInputBuilder()
        .setCustomId('payerDocument')
        .setLabel('CPF OU CNPJ')
        .setPlaceholder('Somente números')
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMinLength(11)
        .setMaxLength(14);
      modal.addComponents(
        new ActionRowBuilder().addComponents(nameInput),
        new ActionRowBuilder().addComponents(documentInput)
      );
      return interaction.showModal(modal);
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });
    try {
      await createCharge(interaction, providerKey, amountForSession(session));
      return interaction.editReply(`Cobrança ${gateway.settings(providerKey).label} criada no tópico.`);
    } catch (error) {
      logError(error, `externalpix-create-${providerKey}`);
      return interaction.editReply(`Não foi possível gerar a cobrança: ${safeMessage(error, 700)}`);
    }
  }
};
