const { ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ButtonBuilder, ButtonStyle, ChannelType, EmbedBuilder, ModalBuilder, TextInputBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, MessageFlags } = require("discord.js");
const { api, db2, auto, db1, logs, perms, db } = require("../../databases/index");
const { readCache, fmt, id: emojiId } = require("../../Lib/managerEmojis");
const purchaseSessions = require('../../Lib/purchaseSessions');
const earlyAccess = require('../../Lib/earlyAccess');
const evopay = require('../../Lib/evopay');
const externalPix = require('../../Lib/externalPixGateway');
const managerPlans = require('../../Lib/managerPlans');
const imapPix = require('../../Lib/nubankImap');
const { resetPublishedPanel } = require('../../Lib/refreshSalesPanel');
const purchaseReviewers = require('../../Lib/purchaseReviewers');

module.exports = {
    name: `interactionCreate`,

    run: async (interaction, client) => {
        const { customId } = interaction;
        if (!customId) return;

        //if (logs.get("vendas_on") === false) interaction.reply({ content: "✅ Bot não está disponivel no momento!"});

        let id = interaction.customId.split("_")[0];
        if (id === 'NexusPro') id = 'ZenyxPro';

        const sessionRequired = ['_editEstoque', '_modalMultiplique', '_cancel', '_prosseguir'].some(suffix => customId.endsWith(suffix)) || customId.startsWith('zenyxpay:cancel:');
        if (sessionRequired && !purchaseSessions.resolve(interaction)) {
            const payload = { content: 'Esta sessão de compra expirou ou já foi encerrada. Abra um novo carrinho pelo painel de venda.', flags: 64 };
            if (interaction.isModalSubmit?.()) return interaction.reply(payload).catch(() => null);
            return interaction.reply(payload).catch(() => null);
        }

        if (customId.endsWith('_saibamais')) {
            const saibaMaisText = db.get(`${id}.saibamais`);
            if (saibaMaisText && typeof saibaMaisText === 'string' && saibaMaisText.trim() !== '') {
                await interaction.reply({ content: saibaMaisText, ephemeral: true });
            } else {
                await interaction.reply({ content: 'Nenhuma informação extra cadastrada.', ephemeral: true });
            }
            return;
        }

        if (customId.endsWith("_buy")) {

            const selectedAction = interaction.isStringSelectMenu?.() ? interaction.values?.[0] : null;
            const isEarly = String(selectedAction || '').endsWith('_buy_ant');
            // Re-renderiza a mensagem pública sem nenhum option default. Isso limpa
            // o check visual que o Discord deixa no select depois do clique.
            if (interaction.isStringSelectMenu?.() && interaction.message && interaction.guild && !interaction.message.flags?.has?.(MessageFlags.Ephemeral)) {
                setTimeout(() => void resetPublishedPanel(interaction.message, interaction.guild), 120).unref?.();
            }
            if (isEarly && !earlyAccess.isEnabled()) {
                return interaction.reply({ content: '`⏳` **Acesso antecipado está desativado no momento.** Aguarde a liberação pelo administrador.', flags: 64 });
            }
            if (String(selectedAction || '').endsWith('_unavailable')) {
                return interaction.reply({ content: '`❌` Nenhum plano está ativo no momento.', flags: 64 });
            }

            if (!logs.get("sistema")) return interaction.reply({ content: '`📡` Ops... O sistema de aluguel está atualmente fora de serviço.', flags: 64 });
            const automaticReady = Boolean((api.get("sistemaMp") && String(api.get("mp") || "").trim()) || evopay.configured() || externalPix.configured("vyvence") || externalPix.configured("magnus") || externalPix.configured("promisse"));
            const manualReady = Boolean(logs.get("semi.sistema") && String(logs.get("semi.chave") || "").trim());
            const imapReady = await imapPix.isManagerPaymentReady();
            if (!automaticReady && !manualReady && !imapReady) return interaction.reply({ content: '`❌` Nenhum método de pagamento está ativado e configurado no momento.', flags: 64 });

            const plans = managerPlans.enabled();
            if (!plans.length) return interaction.reply({ content: '`❌` Todos os planos estão offline no momento.', flags: 64 });
            const em = readCache(interaction.guildId);
            const select = new StringSelectMenuBuilder().setCustomId(`${id}_selectPlano`).setPlaceholder('Selecione um dos planos abaixo para prosseguir...').setMinValues(1).setMaxValues(1);
            const planEmoji = emojiId(em, 'clock', null) || emojiId(em, 'time', null);
            for (const plan of plans.slice(0, 25)) {
                const option = new StringSelectMenuOptionBuilder()
                    .setValue(`plan:${plan.id}`.slice(0,100))
                    .setLabel(plan.label.slice(0,100))
                    .setDescription(`${plan.days} dias • ${managerPlans.money(plan.price)}`.slice(0,100));
                if (planEmoji) option.setEmoji({ id: planEmoji });
                select.addOptions(option);
            }
            const container = new ContainerBuilder().setAccentColor(0x3155ff)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('## Astra Application • Selecione seu plano'),
                    new TextDisplayBuilder().setContent('Escolha uma das opções ativas. O tópico privado só será criado depois da seleção.')
                )
                .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
                .addActionRowComponents(new ActionRowBuilder().addComponents(select));
            return interaction.reply({ flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2, components:[container] });
        };

        if (customId.endsWith("_selectPlano") && interaction.isStringSelectMenu()) {
            const raw = String(interaction.values?.[0] || '');

            // R18.9.45: reconhece o clique imediatamente. Criar/fetch de thread,
            // checar permissões e publicar o painel pode levar alguns segundos;
            // o ACK antecipado evita o primeiro clique parecer morto/expirar.
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            // Só depois do ACK limpamos visualmente o ✓ do seletor público,
            // impedindo a edição da vitrine Components V2 de disputar a interação.
            if (interaction.message && interaction.guild && !interaction.message.flags?.has?.(MessageFlags.Ephemeral)) setTimeout(() => void resetPublishedPanel(interaction.message, interaction.guild), 180).unref?.();
            if (raw.endsWith('_unavailable')) return interaction.editReply({ content: '`❌` Nenhum plano está ativo no momento.', components: [] });
            if (raw.endsWith('_buy_ant')) {
                if (!earlyAccess.isEnabled()) return interaction.editReply({ content: '`⏳` Acesso antecipado está desativado no momento.', components: [] });
                const plans = managerPlans.enabled();
                if (!plans.length) return interaction.editReply({ content: '`❌` Nenhum plano está ativo no momento.', components: [] });
                const em = readCache(interaction.guildId);
                const select = new StringSelectMenuBuilder().setCustomId(`${id}_selectPlano`).setPlaceholder('Selecione um plano disponível').setMinValues(1).setMaxValues(1);
                const planEmoji = emojiId(em, 'clock', null) || emojiId(em, 'time', null);
                for (const item of plans.slice(0,25)) {
                    const option = new StringSelectMenuOptionBuilder().setValue(`plan:${item.id}`.slice(0,100)).setLabel(item.label.slice(0,100)).setDescription(`${item.days} dias • ${managerPlans.money(item.price)}`.slice(0,100));
                    if (planEmoji) option.setEmoji({ id: planEmoji });
                    select.addOptions(option);
                }
                return interaction.editReply({ content:`### Acesso Antecipado\nEscolha o plano que deseja contratar.`, components:[new ActionRowBuilder().addComponents(select)] });
            }
            const planId = raw.startsWith('plan:') ? raw.slice(5) : ({ mensalPlanBuy:'mensal', trimenPlanBuy:'trimensal', anualPlanBuy:'anual' }[raw] || '');
            const plan = managerPlans.find(planId);
            if (!plan) return interaction.editReply({ content: '`❌` Plano inválido ou removido.', components: [] });

            // A resposta efêmera já foi deferida acima. A vitrine pública fica
            // intacta e todo o restante do checkout atualiza somente esse ACK.

            if (!plan.enabled) {
                return interaction.editReply({ content: '`📅` Este plano foi desativado enquanto o menu estava aberto.', components: [] });
            }
            if (!interaction.guild || !interaction.channel?.threads?.create) {
                return interaction.editReply({ content: '`❌` Este painel precisa estar em um canal de texto para abrir o tópico.', components: [] });
            }

            await interaction.channel.threads.fetchActive().catch(() => null);
            const threadName = `compra-${interaction.user.username}`.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 90);
            let exist = interaction.channel.threads.cache.find(thread => thread.name === threadName && !thread.archived);
            if (exist) {
                const existingSession = db1.get(String(exist.id));
                const sameBuyer = existingSession && String(existingSession.userid || '') === String(interaction.user.id);
                let panelStillExists = false;
                if (sameBuyer && existingSession?.msg?.id) {
                    panelStillExists = Boolean(await exist.messages.fetch(String(existingSession.msg.id)).catch(() => null));
                }
                if (sameBuyer && panelStillExists) {
                    return interaction.editReply({
                        content: `\`⚠️\` Você já possui uma compra aberta. Use o botão abaixo para continuar.`,
                        components: [new ActionRowBuilder().addComponents(
                            new ButtonBuilder().setURL(exist.url).setLabel('Abrir tópico da compra').setStyle(ButtonStyle.Link)
                        )]
                    });
                }

                // Builds antigas conseguiam criar o tópico e falhavam antes de
                // publicar o painel por causa do conflito content + Components V2.
                // Um tópico assim não pode bloquear novas compras para sempre.
                db1.delete(String(exist.id));
                if (exist.deletable) await exist.delete('Removendo tópico de compra órfão/incompleto').catch(() => null);
                else if (exist.setArchived) await exist.setArchived(true, 'Removendo tópico de compra órfão/incompleto').catch(() => null);
                exist = null;
            }

            const me = interaction.guild.members.me;
            const permissions = interaction.channel.permissionsFor(me);
            if (!permissions?.has(PermissionFlagsBits.CreatePrivateThreads) || !permissions?.has(PermissionFlagsBits.SendMessagesInThreads)) {
                return interaction.editReply({ content: '`⚠️` Preciso de **Criar Tópicos Privados** e **Enviar Mensagens em Tópicos** neste canal.', components: [] });
            }

            let thread;
            try {
                thread = await interaction.channel.threads.create({
                    name: threadName,
                    type: ChannelType.PrivateThread,
                    reason: `Compra iniciada por ${interaction.user.tag || interaction.user.username}`,
                    autoArchiveDuration: 60,
                    invitable: true
                });
                await thread.members.add(interaction.user.id);
                await purchaseReviewers.addToThread(thread, { includeBuyerId: interaction.user.id });
            } catch (error) {
                require('../../Lib/interactions').logError(error, 'purchase-thread');
                if (thread?.deletable) await thread.delete('Falha ao adicionar comprador ao tópico').catch(() => null);
                return interaction.editReply({ content: '`❌` Não consegui abrir o tópico da compra. Confira as permissões do bot.', components: [] });
            }

            const price = Number(plan.price).toFixed(2).replace('.', ',');
            const baseSession = {
                quantia: 1,
                userid: interaction.user.id,
                aluguel: id,
                plano: plan.shortLabel || plan.label,
                planId: plan.id,
                baseDays: plan.days,
                unitPrice: plan.price,
                dias: plan.days,
                status: 'proccess',
                msg: { channel: interaction.channel.id, guild: interaction.guild.id }
            };

            // Grave a sessão ANTES da mensagem para que qualquer clique no
            // carrinho seja recuperável, mas só confirme a criação ao usuário
            // depois que o painel inicial realmente existir dentro do tópico.
            purchaseSessions.persist(thread.id, baseSession, { ...interaction, channel: thread });

            let send;
            try {
                send = await thread.send({
                    content: `${interaction.user}${logs.get('roleAprove') ? ` | ${interaction.guild.roles.cache.get(logs.get('roleAprove'))}` : ''}`,
                    embeds: [new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Aluguel de Aplicação`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription('Contratação protegida da aplicação Astra Application.')
                        .addFields(
                            { name: 'Aplicação', value: `**Astra Application** • R$ ${price}`, inline: true },
                            { name: 'Plano', value: `**${plan.label}** • ${plan.days} dias`, inline: true }
                        )
                        .setColor('#00FFFF')
                        .setFooter({ text: interaction.user.displayName, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()],
                    components: [new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`${id}_prosseguir`).setLabel('Prosseguir Compra').setStyle(ButtonStyle.Success),
                        new ButtonBuilder().setCustomId(`${id}_dynamic_editEstoque`).setLabel('Multiplicador').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`${id}_dynamic_cancel`).setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
                    )]
                });
            } catch (error) {
                db1.delete(thread.id);
                require('../../Lib/interactions').logError(error, 'purchase-thread-message');
                if (thread?.deletable) await thread.delete('Falha ao publicar painel inicial da compra').catch(() => null);
                else if (thread?.setArchived) await thread.setArchived(true, 'Falha ao publicar painel inicial da compra').catch(() => null);
                return interaction.editReply({ content: '`❌` O tópico foi criado, mas o painel da compra não pôde ser publicado. O tópico inválido foi fechado; tente novamente.', components: [] });
            }

            purchaseSessions.persist(thread.id, { ...baseSession, msg: { id: send.id, channel: interaction.channel.id, guild: interaction.guild.id } }, { ...interaction, channel: thread, message: send });

            const logChannelId = logs.get('channel_logs');
            const logChannel = logChannelId ? interaction.guild.channels.cache.get(logChannelId) : null;
            if (logChannel?.isTextBased()) {
                logChannel.send({ embeds: [new EmbedBuilder()
                    .setTitle('Pendência ZENYX criada')
                    .setDescription(`${interaction.user} iniciou **${plan.label}** (${plan.days} dias) por **R$ ${price}**.`)
                    .setColor('#00FF00')
                    .setTimestamp()] }).catch(() => null);
            }

            // Resposta efêmera separada do painel público. O botão é sempre
            // mostrado depois de o painel interno do tópico ter sido enviado.
            return interaction.editReply({
                content: `${fmt(readCache(interaction.guildId), 'success')} **Astra Application • compra iniciada**\nSeu tópico privado para **${plan.label}** está pronto.`,
                components: [new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setURL(thread.url).setLabel('Abrir tópico da compra').setStyle(ButtonStyle.Link)
                )]
            });
        };

        if (customId.endsWith("_editEstoque")) {
            const session=purchaseSessions.resolve(interaction);
            if(!session)return interaction.reply({content:'Esta sessão de compra expirou.',flags:64});
            const modal=new ModalBuilder().setCustomId(`${id}_dynamic_modalMultiplique`).setTitle('Multiplicador');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('mult').setLabel('QUANTOS MÚLTIPLOS DESEJA?').setPlaceholder('Ex: 2').setMaxLength(4).setStyle(1).setRequired(true)));
            return interaction.showModal(modal);
        };

        if (customId.endsWith("_modalMultiplique")) {
            const session=purchaseSessions.resolve(interaction);
            if(!session)return interaction.reply({content:'Esta sessão de compra expirou.',flags:64});
            const raw=interaction.fields.getTextInputValue('mult');
            if(!/^\d+$/.test(raw)||Number(raw)<1||Number(raw)>9999)return interaction.reply({content:'`❌` Informe um número entre 1 e 9999.',flags:64});
            const mult=Number(raw); const baseDays=Math.max(1,Number(session.baseDays)||Math.round(Number(session.dias||30)/Math.max(1,Number(session.quantia)||1))); const unitPrice=Math.max(0,Number(session.unitPrice)||0);
            const updated=purchaseSessions.persist(interaction.channel.id,{...session,quantia:mult,dias:baseDays*mult,baseDays,unitPrice},interaction);
            return interaction.update({content:`${interaction.user}${logs.get('roleAprove')?` | ${interaction.guild.roles.cache.get(logs.get('roleAprove'))}`:''}`,embeds:[new EmbedBuilder().setTitle('Astra Application • Plano atualizado').addFields({name:'Plano',value:`**${updated.plano}** × ${mult}`,inline:true},{name:'Validade',value:`**${updated.dias} dias**`,inline:true},{name:'Valor',value:`**${managerPlans.money(unitPrice*mult)}**`,inline:true}).setColor('#3155ff')],components:[]});
        };

        if (customId.endsWith("_cancel") || customId.startsWith('zenyxpay:cancel:')) {
            const session = purchaseSessions.resolve(interaction);
            if (!session) {
                return interaction.reply({ content: 'Esta sessão já foi encerrada.', flags: 64 }).catch(() => null);
            }
            // Reconhece o clique imediatamente e não depende de canais/logs
            // opcionais para conseguir fechar a compra.
            await interaction.deferUpdate();
            await interaction.message.edit({
                content: `${fmt(readCache(interaction.guildId), 'success')} Compra cancelada. Este tópico será fechado em alguns segundos.`,
                embeds: [],
                components: []
            }).catch(error => require('../../Lib/interactions').logError(error, 'purchase-cancel-edit'));

            const logChannelId = logs.get('channel_logs');
            const logChannel = logChannelId ? interaction.guild.channels.cache.get(logChannelId) : null;
            if (logChannel?.isTextBased?.()) {
                logChannel.send({
                    embeds: [new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle('Compra ZENYX cancelada')
                        .setDescription(`${interaction.user} encerrou o carrinho antes do pagamento.`)
                        .addFields(
                            { name: 'Aplicação', value: '**Astra Application**', inline: true },
                            { name: 'Plano', value: `**${session.plano || 'não informado'}**`, inline: true }
                        )
                        .setTimestamp()]
                }).catch(() => null);
            }
            db1.delete(interaction.channel.id);
            setTimeout(async () => {
                try {
                    if (interaction.channel?.isThread?.()) {
                        await interaction.channel.setArchived(true, 'Compra cancelada pelo usuário').catch(async () => {
                            if (interaction.channel.deletable) await interaction.channel.delete('Compra cancelada pelo usuário').catch(() => null);
                        });
                    }
                } catch {}
            }, 4000).unref?.();
            return;
        };

        if (customId.endsWith("_prosseguir")) {
            const session = purchaseSessions.resolve(interaction);
            if (!session) return interaction.reply({ content: 'Esta sessão de compra expirou ou já foi encerrada. Abra um novo carrinho pelo painel de venda.', flags: 64 });

            // R18.9.76: o interruptor do /botconfig controla SOMENTE a oferta do
            // IMAP no checkout do Manager original. O watcher continua ativo
            // para cobranças já abertas e os bots filhos mantêm configuração
            // própria. Quando oculto, o botão nem aparece para o cliente.
            const imapCfg = await imapPix.getStoredConfig();
            const imapVisible = imapCfg.managerCheckoutEnabled !== false;
            const imapReady = imapPix.managerPaymentReady(imapCfg);

            const firstRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('auto', session)).setLabel(`Mercado Pago PIX`).setStyle(ButtonStyle.Success).setDisabled(!api.get("sistemaMp") || !String(api.get("mp") || '').trim()),
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('evo', session)).setLabel(`EvoPay PIX`).setStyle(ButtonStyle.Primary).setDisabled(!evopay.configured()),
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('vyv', session)).setLabel(`VyvencePay`).setStyle(ButtonStyle.Primary).setDisabled(!externalPix.configured("vyvence")),
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('mag', session)).setLabel(`MagnusPay`).setStyle(ButtonStyle.Primary).setDisabled(!externalPix.configured("magnus")),
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('pro', session)).setLabel(`PromissePay`).setStyle(ButtonStyle.Primary).setDisabled(!externalPix.configured("promisse"))
            );
            const secondButtons = [];
            if (imapVisible) secondButtons.push(
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('imap', session)).setLabel(`IMAP PIX`).setStyle(ButtonStyle.Primary).setDisabled(!imapReady)
            );
            secondButtons.push(
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('semi', session)).setLabel(`PIX manual`).setStyle(ButtonStyle.Secondary).setDisabled(!logs.get("semi.sistema") || !logs.get("semi.chave")),
                new ButtonBuilder().setCustomId(purchaseSessions.paymentId('cancel', session)).setStyle(ButtonStyle.Danger).setLabel("Cancelar")
            );

            await interaction.update({
                content: `# Checkout ZENYX\n\nConfira o plano e escolha **um método de pagamento disponível**. Ao continuar, você confirma a contratação nas condições exibidas.\n\n> Nunca envie senhas, tokens do Discord ou códigos de recuperação no checkout.\n\n-# ASTRO SOLUTION • pagamento seguro`,
                embeds: [],
                components: [firstRow, new ActionRowBuilder().addComponents(...secondButtons)]
            });
            return;

        };

    }
}
