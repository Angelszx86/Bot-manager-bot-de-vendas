const { ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const { db2 } = require('../../databases/index');
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const center = require('../../Lib/clientCenter');
const { fmt, readCache } = require('../../Lib/managerEmojis');
const { getBotIdentity, getApplication, validateGuildMembership, messageContentIntent, waitForRuntimeGuildReady } = require('../../Lib/discordChildValidation');

function icon(k){return fmt(readCache(),k)}
function ownerRecord(appId,userId){ return center.findOwnedApp(userId, appId); }
async function privateReply(interaction,payload){
  if(!interaction.deferred&&!interaction.replied) await interaction.deferReply({flags:MessageFlags.Ephemeral});
  const clean={...payload}; delete clean.flags;
  return interaction.editReply(clean);
}
function correctionButtons(app,ownerId){
  const runtimeId=String(app.idapp||app.id);
  const row=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`center:app:repair:${runtimeId}:${ownerId}`.slice(0,100)).setLabel('Corrigir token / servidor').setStyle(ButtonStyle.Primary)
  );
  const invite=center.inviteUrl(app.childClientId,app.guildId);
  if(invite) row.addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(invite).setLabel('Adicionar bot ao servidor'));
  return [row];
}
async function ensureManagerMember(guild,userId){
  if(!guild) return null;
  return guild.members.fetch(String(userId)).catch(()=>null);
}

module.exports={
  name:'interactionCreate',
  run: async(interaction)=>{
    const id=interaction.customId||'';
    if(!id.startsWith('center:')) return;
    if(id.startsWith('center:app:renew:')) return;
    try {
      if(id==='center:open-private') return privateReply(interaction,center.privateCentralPayload(interaction.user.id,interaction.guildId));
      if(id==='center:apps') return privateReply(interaction,center.appSelectPayload(interaction.user.id,'manage'));
      if(id==='center:view-bot') return privateReply(interaction,center.viewBotPayload(interaction.user.id));
      if(id==='center:view-key-bot') return privateReply(interaction,center.keyBotSelectPayload(interaction.user.id));
      if(id==='center:renew') return privateReply(interaction,center.appSelectPayload(interaction.user.id,'renew'));
      if(id==='center:key') return interaction.showModal(center.keyModal());
      if(id==='center:recover') return privateReply(interaction,{content:`${icon('mail')} **Recuperação de acesso**\nUse **/recuperar** para recuperar uma aplicação vinculada ao seu e-mail. Nenhum dado de outro usuário é exibido aqui.`});
      if(id==='center:reactivate') {
        const apps=center.ownedApps(interaction.user.id);
        const recoverable=apps.filter(a=>String(a.status||'').toLowerCase()!=='online');
        if(!recoverable.length) return privateReply(interaction,{content:`${icon('info')} Você não possui bots parados disponíveis para reativação.`});
        return privateReply(interaction,center.appSelectPayload(interaction.user.id,'manage'));
      }
      if(id==='center:key:submit' && interaction.isModalSubmit()){
        try{const r=center.keyStore.redeemKey(interaction.fields.getTextInputValue('code'),interaction.user.id);const validity=r.expiresAt?`<t:${Math.floor(new Date(r.expiresAt).getTime()/1000)}:F>`:'sem expiração';return interaction.reply({content:`${icon('success')} Key ativada. Plano **${r.plan}** • validade **${validity}**. Use **Ver bot** na Central para configurar a aplicação liberada.`,flags:MessageFlags.Ephemeral});}
        catch(error){return interaction.reply({content:`${icon('wrong')} ${error.message||'Não foi possível resgatar a Key.'}`,flags:MessageFlags.Ephemeral});}
      }
      if((id.startsWith('center:manage:select:')||id.startsWith('center:renew:select:')) && interaction.isStringSelectMenu()){
        // ACK vem antes de qualquer consulta/validação. Em hosts ocupados, até
        // uma leitura de banco grande podia consumir a janela do Discord e gerar
        // "MANAGER não respondeu a tempo".
        if(!interaction.deferred&&!interaction.replied) await interaction.deferUpdate();
        const expected=id.split(':').pop();
        if(expected!==interaction.user.id) return interaction.editReply({content:'Este menu pertence a outro usuário.',components:[],embeds:[]});
        const appId=interaction.values[0];
        const app=ownerRecord(appId,interaction.user.id); if(!app)return interaction.editReply({content:`${icon('wrong')} Aplicação não encontrada ou sem permissão.`,components:[],embeds:[]});
        return interaction.editReply(center.appDetailsPayload(app,interaction.user.id));
      }

      const repair=id.match(/^center:app:repair:(.*?):(\d{15,25})$/);
      if(repair && interaction.isButton?.()){
        const [,appId,expected]=repair;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada.`,flags:MessageFlags.Ephemeral});
        return interaction.showModal(center.repairModal(app,interaction.user.id));
      }
      const repairSubmit=id.match(/^center:app:repair-submit:(.*?):(\d{15,25})$/);
      if(repairSubmit && interaction.isModalSubmit?.()){
        const [,appId,expected]=repairSubmit;if(expected!==interaction.user.id)return interaction.reply({content:'Este formulário pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        let app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada.`,flags:MessageFlags.Ephemeral});
        const token=interaction.fields.getTextInputValue('token').trim();const guildId=interaction.fields.getTextInputValue('guild').trim();
        if(!/^\d{15,22}$/.test(guildId)) return interaction.reply({content:`${icon('wrong')} ID de servidor inválido.`,flags:MessageFlags.Ephemeral});
        await interaction.deferReply({flags:MessageFlags.Ephemeral});
        const identity=await getBotIdentity(token);
        if(String(identity.id)===String(interaction.client.application?.id||interaction.client.user.id)) throw new Error('O token do Manager não pode ser usado como bot filho.');
        const bound=String(app.childClientId||'').trim();
        if(bound && bound!==String(identity.id)) throw new Error(`Este plano já está preso ao Client ID ${bound}. Use o token atual desse mesmo bot.`);
        if(!bound) db2.set(`${appId}.childClientId`,String(identity.id));
        // O Client ID é persistido antes da checagem do guild. Mesmo com ID de servidor errado,
        // o benefício não pode ser trocado por outro bot depois.
        db2.set(`${appId}.token`,token);db2.set(`${appId}.guildId`,guildId);
        center.updateRuntimeCredentials(appId,{token,guildId,clientId:identity.id,ownerId:interaction.user.id});
        app={...app,childClientId:String(identity.id),guildId,token};
        const membership=await validateGuildMembership(token,guildId,identity.id,{attempts:4,delayMs:1200});
        if(!membership.ok){
          db2.set(`${appId}.status`,'stopped');db2.set(`${appId}.desiredState`,'stopped');db2.set(`${appId}.userStopped`,true);db2.set(`${appId}.userStoppedAt`,new Date().toISOString());
          return interaction.editReply({content:`${icon('warn')} **Token salvo e Client ID protegido.** O Discord ainda não confirmou este bot no servidor \`${guildId}\`.\n\nAdicione **essa mesma aplicação** ao servidor ou corrija o ID e tente novamente. Seus produtos, embeds, banco e configurações continuam preservados.`,components:correctionButtons(app,interaction.user.id)});
        }
        const application=await new SquareCloudAPI().applications.get(appId);
        await application.stop().catch(()=>null);
        const started=await application.start();
        if(started?.ok===false) throw new Error(started.msg||'O runtime não confirmou a inicialização.');
        await waitForRuntimeGuildReady(new SquareCloudAPI(),appId,{timeoutMs:65000,token,guildId,botId:identity.id});
        db2.set(`${appId}.status`,'online');db2.set(`${appId}.desiredState`,'running');db2.set(`${appId}.userStopped`,false);db2.delete(`${appId}.userStoppedAt`);center.clearRecoveryFlags(appId);
        const applicationMeta=await getApplication(token).catch(()=>null);const intent=messageContentIntent(applicationMeta);
        return interaction.editReply({content:`${icon('success')} **Acesso corrigido e bot ligado.**\nServidor: \`${guildId}\`\nClient ID protegido: \`${identity.id}\`\nConfigurações existentes: **preservadas**.${!intent.ok&&!intent.unknown?'\n\n⚠️ MESSAGE CONTENT INTENT está desativado; funções que leem mensagens comuns ficam limitadas.':''}`,components:[]});
      }

      const transfer=id.match(/^center:app:transfer:(.*?):(\d{15,25})$/);
      if(transfer && interaction.isButton?.()){
        const [,appId,expected]=transfer;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada.`,flags:MessageFlags.Ephemeral});
        return privateReply(interaction,center.transferSelectPayload(app,interaction.user.id));
      }
      const transferSelect=id.match(/^center:app:transfer-select:(.*?):(\d{15,25})$/);
      if(transferSelect && interaction.isUserSelectMenu?.()){
        const [,appId,expected]=transferSelect;if(expected!==interaction.user.id)return interaction.reply({content:'Este menu pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada.`,flags:MessageFlags.Ephemeral});
        await interaction.deferUpdate();
        const targetId=interaction.values?.[0];const member=await ensureManagerMember(interaction.guild,targetId);
        if(!member||member.user?.bot)return interaction.editReply({content:`${icon('wrong')} O destino precisa ser uma pessoa que esteja no servidor do Manager.`,components:[],embeds:[]});
        if(String(targetId)===interaction.user.id)return interaction.editReply({content:`${icon('warn')} Escolha outro usuário.`,components:[],embeds:[]});
        return interaction.editReply(center.transferConfirmPayload(appId,interaction.user.id,member.user));
      }
      const transferCancel=id.match(/^center:app:transfer-cancel:(\d{15,25})$/);
      if(transferCancel && interaction.isButton?.()){
        if(transferCancel[1]!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        return interaction.update({content:'Transferência cancelada.',components:[],embeds:[]});
      }
      const transferConfirm=id.match(/^center:app:transfer-confirm:(.*?):(\d{15,25}):(\d{15,25})$/);
      if(transferConfirm && interaction.isButton?.()){
        const [,appId,targetId,expected]=transferConfirm;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const source=await ensureManagerMember(interaction.guild,interaction.user.id);const target=await ensureManagerMember(interaction.guild,targetId);
        if(!source||!target||target.user?.bot)return interaction.reply({content:`${icon('wrong')} A transferência só funciona enquanto os dois usuários estiverem no servidor do Manager.`,flags:MessageFlags.Ephemeral});
        await interaction.deferUpdate();
        const transferred=center.transferOwnership(appId,interaction.user.id,targetId);

        // ownerIds é carregado no boot do bot filho. Recarregue imediatamente
        // se ele estiver online para o novo dono assumir e o antigo perder acesso.
        const applied = await center.applyTransferredOwnerRuntime(appId);
        if(applied?.stoppedForSafety) throw new Error(`A posse foi salva para <@${targetId}>, mas o bot foi desligado por segurança porque não conseguiu recarregar o novo proprietário. Ligue-o novamente pela Central.`);
        await target.send({content:`${icon('success')} Você recebeu a aplicação **${transferred.nome||appId}** de <@${interaction.user.id}>. Abra **Ver bot** na Central do Manager para gerenciá-la.`}).catch(()=>null);
        return interaction.editReply({content:`${icon('success')} **Transferência concluída.** <@${targetId}> agora é o único proprietário configurado da aplicação.${applied?.restarted?' O bot foi reiniciado para aplicar a nova posse aos comandos imediatamente.':''} O runtime, plano, validade e todas as configurações foram preservados.`,components:[],embeds:[]});
      }

      const deleteRequest=id.match(/^center:app:delete:(.*?):(\d{15,25})$/);
      if(deleteRequest && interaction.isButton?.()){
        const [,appId,expected]=deleteRequest;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada ou sem permissão.`,flags:MessageFlags.Ephemeral});
        return interaction.showModal(center.deleteModal(appId,interaction.user.id));
      }
      const deleteConfirm=id.match(/^center:app:delete-confirm:(.*?):(\d{15,25})$/);
      if(deleteConfirm && interaction.isModalSubmit?.()){
        const [,appId,expected]=deleteConfirm;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        const app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada ou sem permissão.`,flags:MessageFlags.Ephemeral});
        const confirmation=interaction.fields.getTextInputValue('confirm').trim().toUpperCase();if(confirmation!=='REMOVER')return interaction.reply({content:`${icon('warn')} Remoção cancelada. Digite exatamente **REMOVER** para confirmar.`,flags:MessageFlags.Ephemeral});
        await interaction.deferReply({flags:MessageFlags.Ephemeral});
        const runtimeId=String(app.idapp||app.id);const runtimeApp=await new SquareCloudAPI().applications.get(runtimeId);const result=await runtimeApp.stop();if(result?.ok===false)throw new Error(result.msg||'O runtime não confirmou o desligamento.');
        db2.set(`${runtimeId}.status`,'recoverable');db2.set(`${runtimeId}.desiredState`,'stopped');db2.set(`${runtimeId}.userStopped`,true);db2.set(`${runtimeId}.recoverable`,true);db2.set(`${runtimeId}.removedAt`,new Date().toISOString());
        return interaction.editReply({content:`${icon('success')} **Bot removido da execução.** Ele foi desligado, mas arquivos, produtos e configurações foram preservados. Abra **Ver bot** para recuperar.`});
      }

      const m=id.match(/^center:app:(start|stop|restart|logs):(.*?):(\d{15,25})$/);
      if(m){
        const [,action,appId,expected]=m;if(expected!==interaction.user.id)return interaction.reply({content:'Este controle pertence a outro usuário.',flags:MessageFlags.Ephemeral});
        let app=ownerRecord(appId,interaction.user.id);if(!app)return interaction.reply({content:`${icon('wrong')} Aplicação não encontrada.`,flags:MessageFlags.Ephemeral});
        const exp=app.dataExpiracao?new Date(app.dataExpiracao):null;if(action==='start'&&exp&&Number.isFinite(exp.getTime())&&exp.getTime()<=Date.now())return interaction.reply({content:`${icon('warn')} Seu plano expirou. Renove antes de ligar o bot novamente.`,flags:MessageFlags.Ephemeral});
        await interaction.deferReply({flags:MessageFlags.Ephemeral});
        try{
          const result=await center.runtimeAction(appId,action);
          if(action==='logs'){const text=typeof result==='string'?result:JSON.stringify(result,null,2);return interaction.editReply({content:`${icon('file')} **Últimos logs**\n\`\`\`\n${String(text).slice(-1700).replace(/\`\`\`/g,'')}\n\`\`\``});}
          db2.set(`${appId}.status`,action==='stop'?'stopped':'online');
          if(action==='stop'){db2.set(`${appId}.desiredState`,'stopped');db2.set(`${appId}.userStopped`,true);db2.set(`${appId}.userStoppedAt`,new Date().toISOString());}
          if(action==='start'||action==='restart'){db2.set(`${appId}.desiredState`,'running');db2.set(`${appId}.userStopped`,false);db2.delete(`${appId}.userStoppedAt`);center.clearRecoveryFlags(appId);}
          return interaction.editReply({content:`${icon('success')} ${action==='start'&&app.recoverable?'Aplicação recuperada e ligada com as configurações preservadas.':`Ação **${action}** executada na aplicação.`}`});
        }catch(error){
          app=ownerRecord(appId,interaction.user.id)||app;
          return interaction.editReply({content:`${icon('wrong')} **Não foi possível ligar a aplicação.**\n${String(error?.message||error).slice(0,700)}\n\nUse **Corrigir token / servidor** para atualizar o acesso do mesmo bot sem perder suas configurações.`,components:correctionButtons(app,interaction.user.id)});
        }
      }
      if(!interaction.replied&&!interaction.deferred)return interaction.reply({content:`${icon('warn')} Este controle expirou. Reabra a Central de Gerenciamento.`,flags:MessageFlags.Ephemeral});
    } catch(error) {
      const text=`${icon('wrong')} Não foi possível concluir esta ação. ${String(error?.message||error).slice(0,800)}`;
      if(interaction.deferred)return interaction.editReply({content:text}).catch(()=>null);
      if(interaction.replied)return interaction.followUp({content:text,flags:MessageFlags.Ephemeral}).catch(()=>null);
      return interaction.reply({content:text,flags:MessageFlags.Ephemeral}).catch(()=>null);
    }
  }
};
