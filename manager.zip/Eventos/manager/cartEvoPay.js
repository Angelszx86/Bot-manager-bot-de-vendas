const {
  ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle,
  EmbedBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const QRCode = require('qrcode');
const { db1, logs, clientes } = require('../../databases/index');
const evopay = require('../../Lib/evopay');
const purchaseSessions = require('../../Lib/purchaseSessions');
const { amountForSession, expirationForSession, notifyBuyer, money, linkingReadyEmbed } = require('../../Lib/planPurchase');
const { logError, safeMessage } = require('../../Lib/interactions');
const { ensureAndReport: ensureClientRole } = require('../../Lib/clientRole');

const pollers = new Map();
const timers = new Map();
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function clearWatch(channelId) {
  if (pollers.has(channelId)) clearInterval(pollers.get(channelId));
  if (timers.has(channelId)) clearTimeout(timers.get(channelId));
  pollers.delete(channelId); timers.delete(channelId);
}
function qrAttachment(transaction) {
  const base64 = String(transaction?.qrCodeBase64 || '');
  if (base64) {
    const raw = base64.includes(',') ? base64.split(',').pop() : base64;
    try { return new AttachmentBuilder(Buffer.from(raw, 'base64'), { name: 'zenyx-evopay-pix.png' }); } catch {}
  }
  return null;
}
async function buildQr(transaction) {
  const direct = qrAttachment(transaction);
  if (direct) return direct;
  const code = String(transaction?.qrCodeText || '');
  if (!code) throw new Error('A EvoPay não retornou o código PIX Copia e Cola.');
  const png = await QRCode.toBuffer(code, { type: 'png', width: 720, margin: 2, errorCorrectionLevel: 'M' });
  return new AttachmentBuilder(png, { name: 'zenyx-evopay-pix.png' });
}
async function approved(interaction, session, message, transaction, amount) {
  clearWatch(interaction.channel.id);
  db1.set(`${interaction.channel.id}.status`, 'aprovado');
  await ensureClientRole(interaction.guild, session.userid, { reason: 'Cliente ASTRA APPLICATION • pagamento evopay confirmado' });
  const expiration = expirationForSession(session);
  await message.edit({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder().setColor('#3155ff').setTitle('Pagamento confirmado • ativando plano').setDescription('Seu PIX foi confirmado. Estamos registrando a assinatura e preparando a etapa de vínculo do bot...')],
    components: [], files: [], attachments: []
  }).catch(error => logError(error, 'evopay-loading-edit'));
  await sleep(1100);
  await message.edit({
    content: `<@${session.userid}>`,
    embeds: [linkingReadyEmbed({ session, amount, provider: 'PIX automático', expiration })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`${session.dias}_${session.aluguel}_uparbot`).setLabel('Vincular bot').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setURL('https://discord.com/developers/applications').setLabel('Discord Developer').setStyle(ButtonStyle.Link)
    )],
    files: [], attachments: []
  }).catch(error => logError(error, 'evopay-success-edit'));
  await notifyBuyer(interaction.client, session.userid, { session, amount, provider: 'EvoPay PIX', expiration });
  require('../../Lib/salesFeed').announce(interaction.client, { type: 'purchase', user: interaction.user, guildId: interaction.guildId, plan: session.plano, days: session.dias }).catch(error => logError(error, 'evopay-sales-feed'));
  db1.set(`${interaction.channel.id}.payment.paidAt`, transaction?.paidAt || new Date().toISOString());
}
async function createCharge(interaction, amount) {
  const session = purchaseSessions.resolve(interaction);
  if (!session) throw new Error('Esta sessão de compra expirou. Abra um novo carrinho.');
  const config = evopay.settings();
  if (!config.enabled || !config.token) throw new Error('EvoPay não está ativada/configurada no Manager.');
  const reference = evopay.reference(`ZENYX-${interaction.channel.id}`);
  const transaction = await evopay.createPix({
    amount,
    clientReference: reference,
    generatedName: interaction.user.globalName || interaction.user.username,
    expiresIn: config.expiresIn
  });
  const copyCode = String(transaction.qrCodeText || '');
  const attachment = await buildQr(transaction);
  const expiresAt = Date.now() + config.expiresIn * 1000;
  const unix = Math.floor(expiresAt / 1000);
  const paymentMessage = await interaction.channel.send({
    content: `<@${session.userid}>`,
    embeds: [new EmbedBuilder()
      .setColor('#3155ff')
      .setTitle('ASTRA APPLICATION • Checkout EvoPay')
      .setDescription('Sua cobrança PIX foi criada. Pague pelo QR Code e aguarde: a confirmação é consultada automaticamente na EvoPay.')
      .addFields(
        { name: 'Produto', value: '**bot de vendas**', inline: true },
        { name: 'Valor', value: `**${money(amount)}**`, inline: true },
        { name: 'Plano', value: `**${session.plano}** • ${session.dias} dias`, inline: true },
        { name: 'Cobrança expira', value: `<t:${unix}:F>\n<t:${unix}:R>`, inline: false }
      )
      .setImage('attachment://zenyx-evopay-pix.png')
      .setFooter({ text: 'ASTRO SOLUTION • não compartilhe tokens ou senhas no checkout' })],
    components: [new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('copyEvoPix').setLabel('Copiar PIX').setStyle(ButtonStyle.Primary).setDisabled(!copyCode),
      ...(transaction.qrCodeUrl && /^https:\/\//i.test(transaction.qrCodeUrl) ? [new ButtonBuilder().setURL(transaction.qrCodeUrl).setLabel('Abrir cobrança').setStyle(ButtonStyle.Link)] : []),
      new ButtonBuilder().setCustomId(purchaseSessions.paymentId('cancel', session)).setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
    )],
    files: [attachment]
  });
  db1.set(`${interaction.channel.id}.copyCola`, copyCode);
  db1.set(`${interaction.channel.id}.payment`, { provider: 'evopay', id: String(transaction.id), clientReference: reference, amount: Number(amount), createdAt: Date.now(), expiresAt });

  clearWatch(interaction.channel.id);
  const poller = setInterval(async () => {
    const current = db1.get(String(interaction.channel.id));
    if (!current || current.status === 'aprovado') return clearWatch(interaction.channel.id);
    try {
      const status = await evopay.getPix({ id: transaction.id });
      const state = String(status?.status || '').toUpperCase();
      if (state === 'COMPLETED') return approved(interaction, current, paymentMessage, status, amount);
      if (['CANCELED', 'EXPIRED', 'ERROR', 'REFUNDED'].includes(state)) {
        clearWatch(interaction.channel.id);
        await paymentMessage.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Cobrança encerrada').setDescription(`A EvoPay retornou o status **${state}**. Gere uma nova cobrança para tentar novamente.`)], components: [], files: [], attachments: [] }).catch(() => null);
      }
    } catch (error) { logError(error, 'evopay-poll'); }
  }, 4000);
  poller.unref?.(); pollers.set(interaction.channel.id, poller);

  const timer = setTimeout(async () => {
    clearWatch(interaction.channel.id);
    const current = db1.get(String(interaction.channel.id));
    if (!current || current.status === 'aprovado') return;
    await paymentMessage.edit({ embeds: [new EmbedBuilder().setColor('#ED4245').setTitle('Cobrança expirada').setDescription('O prazo desta cobrança EvoPay terminou. Gere um novo PIX para continuar.')], components: [], files: [], attachments: [] }).catch(() => null);
  }, config.expiresIn * 1000 + 5000);
  timer.unref?.(); timers.set(interaction.channel.id, timer);
}

module.exports = {
  name: 'interactionCreate',
  run: async (interaction) => {
    const id = interaction.customId || '';
    if (id === 'copyEvoPix') {
      const code = db1.get(`${interaction.channel?.id}.copyCola`);
      return interaction.reply({ content: code || 'O código PIX não está mais disponível.', flags: MessageFlags.Ephemeral });
    }
    if (id.startsWith('zenyxpay:evo:')) {
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Esta sessão expirou. Abra uma nova compra.', flags: MessageFlags.Ephemeral });
      if (!evopay.configured()) return interaction.reply({ content: 'EvoPay está indisponível no momento.', flags: MessageFlags.Ephemeral });
      const amount = amountForSession(session);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor('#3155ff').setTitle('EvoPay • continuar pagamento').setDescription(`Valor do plano: **${money(amount)}**\nVocê pode aplicar um cupom ou gerar a cobrança agora.`)],
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`zenyx:evo:coupon:${interaction.channel.id}`).setLabel('Usar cupom').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId(`zenyx:evo:nocoupon:${interaction.channel.id}`).setLabel('Gerar PIX').setStyle(ButtonStyle.Success)
        )], flags: MessageFlags.Ephemeral
      });
    }
    if (id.startsWith('zenyx:evo:nocoupon:')) {
      if (id.split(':')[3] !== interaction.channel?.id) return interaction.reply({ content: 'Esta cobrança pertence a outro carrinho.', flags: 64 });
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Sessão expirada.', flags: 64 });
      await interaction.deferReply({ flags: 64 });
      try { await createCharge(interaction, amountForSession(session)); return interaction.editReply('Cobrança EvoPay criada no tópico.'); }
      catch (error) { logError(error, 'evopay-create'); return interaction.editReply(`Não foi possível gerar a cobrança: ${safeMessage(error, 600)}`); }
    }
    if (id.startsWith('zenyx:evo:coupon:')) {
      if (id.split(':')[3] !== interaction.channel?.id) return interaction.reply({ content: 'Esta sessão pertence a outro carrinho.', flags: 64 });
      const m = new ModalBuilder().setCustomId(`zenyx:evo:couponmodal:${interaction.channel.id}`).setTitle('Cupom ZENYX');
      m.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code').setLabel('CÓDIGO DO CUPOM').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50)));
      return interaction.showModal(m);
    }
    if (interaction.isModalSubmit?.() && id.startsWith('zenyx:evo:couponmodal:')) {
      if (id.split(':')[3] !== interaction.channel?.id) return interaction.reply({ content: 'Esta sessão pertence a outro carrinho.', flags: 64 });
      const session = purchaseSessions.resolve(interaction);
      if (!session) return interaction.reply({ content: 'Sessão expirada.', flags: 64 });
      const code = interaction.fields.getTextInputValue('code').trim();
      const coupon = logs.get(`Cupoms.${code}`);
      const percent = Number(coupon?.desconto);
      if (!coupon || !Number.isFinite(percent) || percent < 0 || percent > 100) return interaction.reply({ content: 'Cupom inválido ou expirado.', flags: 64 });
      const amount = Number((amountForSession(session) * (1 - percent / 100)).toFixed(2));
      if (amount <= 0) return interaction.reply({ content: 'Cupom de 100% deve ser concluído pelo fluxo Mercado Pago/cupom gratuito para manter o provisionamento consistente.', flags: 64 });
      await interaction.deferReply({ flags: 64 });
      try { await createCharge(interaction, amount); return interaction.editReply(`Cupom de **${percent}%** aplicado. Cobrança EvoPay criada no tópico.`); }
      catch (error) { return interaction.editReply(`Não foi possível gerar a cobrança: ${safeMessage(error, 600)}`); }
    }
  }
};
