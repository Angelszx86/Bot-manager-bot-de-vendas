const { Events } = require('discord.js');

module.exports = {
  name: Events.InteractionCreate,

  async run(interaction) {
    try {
      if (!interaction.isButton()) return;

      const { customId } = interaction;

      function getContent(id) {
        if (id === 'info_regras') {
          return (
            '📜 **Regras do Servidor Astra Application**\n\n' +
            '**1. Respeito e convivência**\n' +
            '1.1. Trate todos com respeito e educação.\n' +
            '1.2. Ofensas, discriminação, ataques pessoais ou discurso de ódio são proibidos.\n' +
            '1.3. Conflitos devem ser resolvidos com calma e respeito.\n\n' +

            '**2. Comunicação adequada**\n' +
            '2.1. Evite spam, flood ou mensagens repetidas.\n' +
            '2.2. Não envie anúncios, links ou conteúdos fora do contexto dos canais.\n' +
            '2.3. Use linguagem clara e evite palavrões.\n\n' +

            '**3. Conteúdo permitido**\n' +
            '3.1. Compartilhe apenas temas relacionados a apps, desenvolvimento, tecnologia e assuntos do servidor.\n' +
            '3.2. Conteúdos impróprios, pornográficos, ilegais ou piratas são proibidos.\n\n' +

            '**4. Organização dos canais**\n' +
            '4.1. Leia as descrições antes de postar.\n' +
            '4.2. Use o canal correto para cada tipo de mensagem.\n\n' +

            '**5. Proibição de pirataria**\n' +
            '5.1. Não compartilhe apps, códigos, ferramentas piratas ou que violem direitos autorais.\n' +
            '5.2. Respeite o trabalho e direitos dos desenvolvedores.\n\n' +

            '**6. Pedidos de ajuda**\n' +
            '6.1. Seja claro e detalhado nas dúvidas.\n' +
            '6.2. Evite repetir perguntas já respondidas.\n\n' +

            '**7. Divulgação**\n' +
            '7.1. Divulgações só são permitidas com autorização da equipe.\n' +
            '7.2. Respeite os limites e regras para promoções.\n\n' +

            '**8. Privacidade e segurança**\n' +
            '8.1. Não compartilhe dados pessoais seus ou de terceiros.\n' +
            '8.2. Preserve a segurança de todos no servidor.\n\n' +

            '**9. Cumprimento das regras do Discord**\n' +
            '9.1. Respeite os Termos de Serviço e Diretrizes da comunidade do Discord.\n\n' +

            '**10. Punições**\n' +
            '10.1. O descumprimento pode resultar em advertências, silenciamento, expulsão ou banimento.\n' +
            '10.2. A equipe se reserva o direito de agir conforme necessário para manter o ambiente saudável.\n\n' +

            'Contamos com a colaboração de todos para manter o Astra Application um espaço amigável, produtivo e seguro! 🚀'
          );
        }

        if (id === 'info_faq') {
          return (
            '❓ **FAQ – Dúvidas Frequentes | Astra Application**\n\n' +
            '**1. Astra Application**\n' +
            '1.1. Para adquirir um Astra Application podem ser adquiridos no canal <#1399745607295307826>.\n' +
            '1.2. Confira preços, planos e formas de pagamento fixados no canal.\n\n' +

            '**2. Teste 24H**\n' +
            '2.1. Para testar nossos serviços em 24h, acesse <#1399893401909989518>.\n' +
            '2.2. Utilize este canal apenas para fins de teste.\n\n' +

            '**3. Comandos de bot**\n' +
            '3.1. Use comandos apenas em <#1399746370423750757>.\n' +
            '3.2. Evite executar comandos em canais de conversa para manter a organização.\n\n' +

            '**4. Conversas**\n' +
            '4.1. Para interagir e conversar com outros membros, utilize <#1399746111668752506>.\n' +
            '4.2. Respeite os outros membros e mantenha um ambiente amigável.\n\n' +

            '**5. Sugestões**\n' +
            '5.1. Envie suas ideias e melhorias em <#1399746420130713630>.\n' +
            '5.2. Seja claro na explicação para facilitar a análise da equipe.\n\n' +

            '**6. Feedbacks**\n' +
            '6.1. Para opiniões sobre nossos serviços, use <#1402103328493801552>.\n' +
            '6.2. Feedbacks construtivos ajudam a melhorar a experiência de todos.\n\n' +

            '**7. Anúncios e novidades**\n' +
            '7.1. Todas as atualizações são publicadas em <#1399743843238285322>.\n' +
            '7.2. Ative as notificações para não perder nada importante.\n\n' +

            '**8. Suporte**\n' +
            '8.1. Para dúvidas rápidas, use <#1399744766350065706>.\n' +
            '8.2. Para casos específicos, abra um ticket em <#252627>.'
          );
        }

        if (id === 'info_terms') {
          return (
            '📄 **Termos de Uso – Astra Application**\n\n' +
            '**1. Uso permitido dos serviços**\n' +
            '1.1. O servidor é destinado para interação, uso e teste de aplicativos e bots autorizados pela equipe.\n' +
            '1.2. É proibido usar nossos serviços para atividades ilegais, fraudulentas ou que violem leis.\n\n' +

            '**2. Propriedade intelectual**\n' +
            '2.1. Todo o conteúdo criado pela equipe pertence aos seus respectivos autores.\n' +
            '2.2. É proibida a cópia, venda ou redistribuição sem autorização prévia.\n\n' +

            '**3. Segurança e privacidade**\n' +
            '3.1. Não solicite ou compartilhe dados pessoais de terceiros.\n' +
            '3.2. É proibido explorar falhas ou vulnerabilidades para prejudicar o servidor.\n\n' +

            '**4. Garantias e limitações**\n' +
            '4.1. Os serviços são fornecidos “como estão” e podem conter falhas.\n' +
            '4.2. Não garantimos funcionamento ininterrupto ou livre de erros.\n\n' +

            '**5. Compras e pagamentos**\n' +
            '5.1. Transações devem ser feitas apenas por canais autorizados.\n' +
            '5.2. Reembolsos serão concedidos apenas em casos previstos pela equipe.\n\n' +

            '**6. Uso de bots e apps**\n' +
            '6.1. É proibido modificar, desativar ou burlar sistemas de segurança.\n' +
            '6.2. Bots não autorizados serão removidos sem aviso prévio.\n\n' +

            '**7. Conduta dos usuários**\n' +
            '7.1. É obrigatório seguir as regras do servidor.\n' +
            '7.2. Atos de assédio, spam ou ofensas resultam em punição.\n\n' +

            '**8. Responsabilidade do usuário**\n' +
            '8.1. Você é responsável pelo conteúdo e ações realizadas em sua conta.\n' +
            '8.2. Compartilhar acesso da conta é por sua conta e risco.\n\n' +

            '**9. Alterações nos serviços**\n' +
            '9.1. A equipe pode modificar, suspender ou encerrar serviços a qualquer momento.\n' +
            '9.2. Alterações serão comunicadas por meio dos canais oficiais.\n\n' +

            '**10. Isenção de responsabilidade**\n' +
            '10.1. Não nos responsabilizamos por danos causados pelo uso indevido dos serviços.\n' +
            '10.2. Usuários devem manter backups próprios.\n\n' +

            '**11. Suspensão e banimento**\n' +
            '11.1. O não cumprimento dos termos pode levar à suspensão ou banimento.\n' +
            '11.2. Banimentos não são passíveis de reembolso.\n\n' +

            '**12. Uso de marca**\n' +
            '12.1. É proibido usar a marca Astra Application sem permissão.\n' +
            '12.2. Qualquer uso indevido será passível de ação.\n\n' +

            '**13. Atualizações dos termos**\n' +
            '13.1. Os termos podem ser atualizados a qualquer momento.\n' +
            '13.2. Continuar no servidor significa aceitar as alterações.\n\n' +

            '**14. Canal de comunicação oficial**\n' +
            '14.1. Comunicados oficiais serão feitos em **<#1399743843238285322>**.\n' +
            '14.2. Mensagens fora desses canais podem ser ignoradas.\n\n' +

            '**15. Disposições finais**\n' +
            '15.1. A adesão ao servidor implica aceitação integral destes termos.\n' +
            '15.2. Casos omissos serão analisados e resolvidos pela equipe Astra Application.'
          );
        }

        return null;
      }

      async function replyLongMessage(interaction, fullText) {
        const MAX_LENGTH = 2000;

        if (fullText.length <= MAX_LENGTH) {
          if (interaction.deferred || interaction.replied) {
            return await interaction.followUp({ content: fullText, ephemeral: true });
          } else {
            return await interaction.reply({ content: fullText, ephemeral: true });
          }
        }

        // Dividir texto em partes <= 2000 caracteres
        const parts = [];
        for (let i = 0; i < fullText.length; i += MAX_LENGTH) {
          parts.push(fullText.substring(i, i + MAX_LENGTH));
        }

        if (interaction.deferred || interaction.replied) {
          // Já respondeu, só fazer followUp das partes
          await interaction.followUp({ content: parts[0], ephemeral: true });
          for (let i = 1; i < parts.length; i++) {
            await interaction.followUp({ content: parts[i], ephemeral: true });
          }
        } else {
          // Ainda não respondeu
          await interaction.deferReply({ ephemeral: true });
          await interaction.editReply({ content: parts[0] });
          for (let i = 1; i < parts.length; i++) {
            await interaction.followUp({ content: parts[i], ephemeral: true });
          }
        }
      }

      if (customId === "faq") {
        return await interaction.reply({
          content: `# ❓ Perguntas Frequentes — Simple\n\n\n1. Como posso adquirir um bot?\n\nPara adquirir um **bot da Simple**, acesse o canal: https://discord.com/channels/1312428786591076463/1399745607295307826 para adquirir o seu **Astra Application**  ou caso queira um bot Personalizavel acesse: https://discord.com/channels/1312428786591076463/1400268067451179180. Lá, você encontrará um botão de compra. Basta clicar nele para iniciar a transação de forma rápida e segura.\n\n\n2. Como recebo meu bot após a compra\n\nLogo após a compra, você receberá um tutorial completo no seu carrinho, contendo todas as informações necessárias para configurar e utilizar seu bot automaticamente.\n\n\n3. Como faço para renovar minha aplicação?\n\nA renovação é simples: utilize o comando /renovar no canal de comandos. Após a confirmação do pagamento, os dias adquiridos serão adicionados à sua aplicação, estendendo sua validade sem interrupções.\n\n\n4. Meu bot fica online 24 horas por dia?\n\nSim, os bots fornecidos pela Astra Application operam 24 horas por dia, 7 dias por semana. Caso seu bot fique offline por algum motivo, você pode reativá-lo com o comando /apps. Persistindo o problema, entre em contato com nosso suporte.\n\n\n5. Como saber quando meu bot vai expirar?\n\nVocê pode verificar a validade do seu bot a qualquer momento usando o comando /apps. Além disso, nosso sistema envia um aviso automático via mensagem privada com até 3 dias de antecedência antes do vencimento.\n\n\n6. Como configurar permissões no bot de vendas?\n\nApós adicionar o bot em seu servidor, utilize o comando /permadd e mencione o seu perfil para configurar as permissões necessárias.`,
          ephemeral: true
        });
      }

      const content = getContent(customId);
      if (!content) return;

      await replyLongMessage(interaction, content);
    } catch (err) {
      console.error('[ERRO] interactionCreate:', err);
      try {
        if (!interaction.deferred && !interaction.replied) {
          await interaction.reply({ content: '❌ Ocorreu um erro.', ephemeral: true });
        }
      } catch {}
    }
  }
};