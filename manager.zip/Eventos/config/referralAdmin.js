const {
  Events, MessageFlags, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const referrals = require('../../Lib/referrals');
const perms = require('../../Lib/permissions');
const { readCache, id: emojiId, fmt } = require('../../Lib/managerEmojis');

function cache(guildId){ return readCache(guildId); }
function icon(guildId,key){ return fmt(cache(guildId),key); }
function btn(guildId,cid,label,semantic,style=ButtonStyle.Secondary,disabled=false){
  const b=new ButtonBuilder().setCustomId(cid).setLabel(label).setStyle(style).setDisabled(disabled);
  const eid=emojiId(cache(guildId),semantic,null); if(eid)b.setEmoji({id:eid}); return b;
}
function summary(guildId){
  const s=referrals.adminSummary(guildId);
  const embed=new EmbedBuilder().setColor(s.color||'#3155ff')
    .setTitle(`${icon(guildId,'gift')} Indicação • Manager`)
    .setDescription('Programa individual de indicações. Cada usuário possui seu próprio link, saldo e histórico; os créditos nunca são compartilhados entre usuários.')
    .addFields(
      {name:'Status',value:s.enabled?'**Ativado**':'**Desativado**',inline:true},
      {name:'Publicação',value:s.channelId&&s.messageId?`<#${s.channelId}>`:'não publicada',inline:true},
      {name:'Canal dos convites',value:s.inviteChannelId?`<#${s.inviteChannelId}>`:'usa o canal do painel',inline:true},
      {name:'Tempo por indicação',value:`**${referrals.formatMinutes(s.rewardMinutesPerInvite)}**`,inline:true},
      {name:'Mínimo para testar',value:`**${referrals.formatMinutes(s.minimumMinutesToTest)}**`,inline:true},
      {name:'Máximo por teste',value:`**${referrals.formatMinutes(s.maxMinutesPerTest)}**`,inline:true},
      {name:'Participantes',value:`**${s.users}**`,inline:true},
      {name:'Indicações válidas',value:`**${s.totalInvites}**`,inline:true},
      {name:'Expiração',value:'O teste gerado usa exatamente o saldo consumido. Quando o tempo termina, o runtime é desligado e o Manager notifica o usuário por DM.',inline:false}
    ).setTimestamp();
  return {embeds:[embed],components:[
    new ActionRowBuilder().addComponents(
      btn(guildId,'refadmin:toggle',s.enabled?'Desativar':'Ativar','power',s.enabled?ButtonStyle.Danger:ButtonStyle.Success),
      btn(guildId,'refadmin:time','Configurar tempo','clock',ButtonStyle.Primary),
      btn(guildId,'refadmin:appearance','Editar painel','edit'),
      btn(guildId,'refadmin:publish-channel','Publicar','announcement',ButtonStyle.Success)
    ),
    new ActionRowBuilder().addComponents(
      btn(guildId,'refadmin:invite-channel','Canal dos convites','channels'),
      btn(guildId,'refadmin:preview','Pré-visualizar','preview'),
      btn(guildId,'refadmin:refresh','Atualizar','reload')
    )
  ]};
}
function ephemeral(payload){ return {...payload,flags:MessageFlags.Ephemeral}; }
function appearanceModal(guildId){
  const s=referrals.settings(guildId);
  return new ModalBuilder().setCustomId('refadmin:appearance-submit').setTitle('Indicação • Aparência').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('TÍTULO').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(256).setValue(String(s.title||'').slice(0,256))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('DESCRIÇÃO').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setValue(String(s.description||'').slice(0,4000))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image').setLabel('LINK DA IMAGEM / BANNER (OPCIONAL)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(1000).setValue(String(s.imageUrl||'').slice(0,1000))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('COR HEX').setPlaceholder('#3155ff').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(7).setValue(String(s.color||'#3155ff').slice(0,7)))
  );
}
function timeModal(guildId){
  const s=referrals.settings(guildId);
  return new ModalBuilder().setCustomId('refadmin:time-submit').setTitle('Indicação • Tempo').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reward').setLabel('MINUTOS POR INDICAÇÃO').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(6).setValue(String(s.rewardMinutesPerInvite))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('minimum').setLabel('MÍNIMO PARA INICIAR TESTE').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(6).setValue(String(s.minimumMinutesToTest))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('maximum').setLabel('MÁXIMO CONSUMIDO POR TESTE').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(6).setValue(String(s.maxMinutesPerTest)))
  );
}
function validHttps(raw){
  const v=String(raw||'').trim(); if(!v)return '';
  try{const u=new URL(v);return ['http:','https:'].includes(u.protocol)?u.toString():null;}catch{return null;}
}
function validColor(raw){ return /^#[0-9a-f]{6}$/i.test(String(raw||'').trim()); }

module.exports={
  name:Events.InteractionCreate,
  run:async(interaction)=>{
    const cid=interaction.customId||'';
    if(!cid.startsWith('refadmin:'))return;
    if(!perms.isOwner(interaction.user.id)) return interaction.reply({content:'Este painel é exclusivo do proprietário do Manager.',flags:MessageFlags.Ephemeral}).catch(()=>null);
    if(!interaction.guildId) return interaction.reply({content:'Use esta opção dentro de um servidor.',flags:MessageFlags.Ephemeral}).catch(()=>null);
    const gid=interaction.guildId;
    try{
      if(cid==='refadmin:open') return interaction.reply(ephemeral(summary(gid)));
      if(cid==='refadmin:refresh') return interaction.update(summary(gid));
      if(cid==='refadmin:toggle'){
        const current=referrals.settings(gid); referrals.updateSettings(gid,{enabled:!current.enabled});
        await referrals.refreshPublished(interaction.client,gid).catch(()=>null);
        return interaction.update(summary(gid));
      }
      if(cid==='refadmin:time') return interaction.showModal(timeModal(gid));
      if(cid==='refadmin:appearance') return interaction.showModal(appearanceModal(gid));
      if(cid==='refadmin:publish-channel'){
        const menu=new ChannelSelectMenuBuilder().setCustomId('refadmin:publish-set').setPlaceholder('Canal do painel de indicação').setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);
        return interaction.reply({content:'Escolha o canal onde o painel público será publicado/atualizado.',components:[new ActionRowBuilder().addComponents(menu)],flags:MessageFlags.Ephemeral});
      }
      if(cid==='refadmin:invite-channel'){
        const menu=new ChannelSelectMenuBuilder().setCustomId('refadmin:invite-set').setPlaceholder('Canal usado para criar convites').setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);
        return interaction.reply({content:'Escolha o canal usado como destino dos links individuais.',components:[new ActionRowBuilder().addComponents(menu)],flags:MessageFlags.Ephemeral});
      }
      if(cid==='refadmin:publish-set' && interaction.isChannelSelectMenu?.()){
        const channelId=interaction.values[0]; await referrals.publish(interaction.client,gid,channelId);
        return interaction.update({content:`${icon(gid,'success')} Painel de indicação publicado/atualizado em <#${channelId}>.`,components:[]});
      }
      if(cid==='refadmin:invite-set' && interaction.isChannelSelectMenu?.()){
        const channelId=interaction.values[0]; referrals.updateSettings(gid,{inviteChannelId:channelId});
        return interaction.update({content:`${icon(gid,'success')} Canal dos convites salvo: <#${channelId}>.`,components:[]});
      }
      if(cid==='refadmin:preview') return interaction.reply({...referrals.panelPayload(gid),flags:MessageFlags.Ephemeral});
      if(cid==='refadmin:time-submit' && interaction.isModalSubmit?.()){
        const reward=Number(interaction.fields.getTextInputValue('reward'));
        const minimum=Number(interaction.fields.getTextInputValue('minimum'));
        const maximum=Number(interaction.fields.getTextInputValue('maximum'));
        if(![reward,minimum,maximum].every(Number.isFinite)||reward<1||minimum<1||maximum<minimum) return interaction.reply({content:`${icon(gid,'wrong')} Use números válidos; o máximo não pode ser menor que o mínimo.`,flags:MessageFlags.Ephemeral});
        referrals.updateSettings(gid,{rewardMinutesPerInvite:reward,minimumMinutesToTest:minimum,maxMinutesPerTest:maximum});
        await referrals.refreshPublished(interaction.client,gid).catch(()=>null);
        return interaction.reply({content:`${icon(gid,'success')} Tempos atualizados.`,flags:MessageFlags.Ephemeral});
      }
      if(cid==='refadmin:appearance-submit' && interaction.isModalSubmit?.()){
        const title=interaction.fields.getTextInputValue('title').trim();
        const description=interaction.fields.getTextInputValue('description').trim();
        const imageRaw=interaction.fields.getTextInputValue('image').trim();
        const color=interaction.fields.getTextInputValue('color').trim();
        const imageUrl=validHttps(imageRaw);
        if(imageRaw && !imageUrl) return interaction.reply({content:`${icon(gid,'wrong')} O link da imagem precisa usar HTTP ou HTTPS.`,flags:MessageFlags.Ephemeral});
        if(!validColor(color)) return interaction.reply({content:`${icon(gid,'wrong')} Use uma cor HEX como **#3155ff**.`,flags:MessageFlags.Ephemeral});
        referrals.updateSettings(gid,{title,description,imageUrl:imageUrl||'',color});
        await referrals.refreshPublished(interaction.client,gid).catch(()=>null);
        return interaction.reply({content:`${icon(gid,'success')} Aparência atualizada.`,flags:MessageFlags.Ephemeral});
      }
    }catch(error){
      const text=require('../../Lib/interactions').safeMessage(error,700)||'Não foi possível concluir esta ação.';
      if(interaction.deferred)return interaction.editReply({content:`${icon(gid,'wrong')} ${text}`}).catch(()=>null);
      if(interaction.replied)return interaction.followUp({content:`${icon(gid,'wrong')} ${text}`,flags:MessageFlags.Ephemeral}).catch(()=>null);
      return interaction.reply({content:`${icon(gid,'wrong')} ${text}`,flags:MessageFlags.Ephemeral}).catch(()=>null);
    }
  }
};
