const { ModalBuilder, TextInputBuilder, ActionRowBuilder } = require('discord.js');
const { perms } = require('../../databases');
const { isOwner, list, ownerIds } = require('../../Lib/permissions');
const IDS = new Set(['selectMenuPerms', 'modalAddPerm', 'modalRemPerm']);
function modal(add) {
  return new ModalBuilder().setCustomId(add ? 'modalAddPerm' : 'modalRemPerm')
    .setTitle(add ? 'Adicionar administrador' : 'Remover administrador')
    .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder()
      .setCustomId(add ? 'optionAddPerm' : 'optionRemPerm').setLabel('ID do usuário')
      .setPlaceholder('Cole o ID numérico do Discord').setStyle(1).setRequired(true).setMinLength(17).setMaxLength(20)));
}
async function change(interaction, id, add) {
  if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Apenas o dono do manager pode alterar administradores.', flags: 64 });
  await interaction.deferReply({ flags: 64 });
  if (!/^\d{17,20}$/.test(id)) return interaction.editReply('ID do usuário inválido.');
  if (!add && ownerIds().includes(String(id))) return interaction.editReply('Os proprietários mantêm acesso pelo OWNER_ID/OWNER_IDS.');
  if (add) {
    const member = await interaction.guild.members.fetch(id).catch(() => null);
    if (!member || member.user.bot) return interaction.editReply('Informe um usuário humano que esteja neste servidor.');
  }
  const users = list();
  perms.set('usersPerms', add ? [...new Set([...users, id])] : users.filter(x => x !== id));
  return interaction.editReply(add ? `Permissão concedida a <@${id}>.` : `Permissão removida de <@${id}>.`);
}
module.exports = {
  name: 'interactionCreate', modal, change,
  async run(interaction) {
    if (!IDS.has(interaction.customId)) return;
    if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Apenas o dono do manager pode alterar administradores.', flags: 64 });
    if (interaction.isStringSelectMenu()) return interaction.showModal(modal(interaction.values[0] === 'addPermBot'));
    if (interaction.isModalSubmit()) {
      const add = interaction.customId === 'modalAddPerm';
      return change(interaction, interaction.fields.getTextInputValue(add ? 'optionAddPerm' : 'optionRemPerm').trim(), add);
    }
  }
};
