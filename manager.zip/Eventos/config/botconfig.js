const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ChannelSelectMenuBuilder, ChannelType, RoleSelectMenuBuilder, UserSelectMenuBuilder, ModalBuilder, TextInputBuilder, Embed, ButtonStyle, MessageFlags, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder } = require("discord.js");
const { readCache, id, fmt } = require('../../Lib/managerEmojis');
const { api, db2, auto, db1, logs, perms, db, clientes } = require("../../databases/index");
const mercadopago = require("mercadopago");
const JSZip = require('jszip');
const fs = require("fs");
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const { testNubankImapConnection, getStoredConfig, normalizeImapPassword, inferImapProvider, interSenderDefaults } = require('../../Lib/nubankImap');
const keyStore = require('../../Lib/keys');
const sftp = require('../../source/sftp');
const earlyAccess = require('../../Lib/earlyAccess');
const zcloudControl = require('../../Lib/zcloudControl');
const walletControl = require('../../Lib/walletControl');
const magnusControl = require('../../Lib/magnusControl');
const childBioControl = require('../../Lib/childBioControl');
const shardcloudControl = require('../../Lib/shardcloudControl');
const shardcloudApi = require('../../source/shardcloud_api');
const evopay = require('../../Lib/evopay');
const externalPix = require('../../Lib/externalPixGateway');
const storefront = require('../../Lib/storefrontConfig');
const managerPlans = require('../../Lib/managerPlans');
const trialSettings = require('../../Lib/trialSettings');
const salesPanels = require('../../Lib/refreshSalesPanel');
const purchaseReviewers = require('../../Lib/purchaseReviewers');

const { PAGE_COUNT, pagePayload, legacyPayloadToV2 } = require('../../Lib/botconfigPages');
function ensureBuiltinSalesBot() {
    const key = 'AstraVendas';
    if (db.get(`${key}.nomeproduto`)) return;
    db.set(key, {
        nomeproduto: key,
        displayName: 'Astra Vendas',
        type: 'embed',
        source: 'source/AstraVendas.zip',
        builtin: true,
        preco: {
            anual: { onoff: true, preco: 10 },
            mensal: { onoff: true, preco: 5 },
            trimensal: { onoff: true, preco: 8.5 },
            embed: { cor: 'Default', titulo: 'Astra Vendas', desc: 'Bot de vendas Astra Vendas integrado ao Manager.' }
        },
        banner: null,
        link: 'remover'
    });
}
ensureBuiltinSalesBot();
const MANAGER_INTERACTION_IDS = new Set([
  'antFraudSet',
  'antiScamToggle',
  'apiConfig',
  'appid',
  'aprovedRoleSemi',
  'atualizarStatus',
  'autoMsgConfig',
  'autoMsgModal',
  'autoMsgPanel',
  'autoRepostConfig',
  'automaticConfig',
  'automationConfig',
  'back',
  'backD',
  'canalId',
  'channelsRolesEdit',
  'code',
  'configureNubankImap',
  'configureBankImapPix',
  'consoleBotGrc',
  'createBotAluguel',
  'criarCanaisVozRealtime',
  'definitions',
  'deleteAppUser',
  'deleteAutoMsg',
  'devConsoleSubmit',
  'diversesAluguel',
  'editApiSquare',
  'editAutoMsgChannel',
  'editAutoMsgInterval',
  'editAutoMsgMsg',
  'editTempPay',
  'editTempPay2',
  'expiry',
  'gerenciamentDev',
  'gerenciarApps',
  'imapFrom',
  'imapHost',
  'imapInterval',
  'imapPass',
  'imapUser',
  'intervalo',
  'keyGenerateModal',
  'keyGenerateSubmit',
  'keyListActive',
  'keyManagement',
  'linkedBotsView',
  'checkoutReviewers',
  'checkoutReviewersSelect',
  'checkoutReviewersClear',
  'checkoutReviewersSync',
  'checkoutReviewersAddOwner',
  'keyRevokeModal',
  'keyRevokeSubmit',
  'liberarTudo',
  'managerDiagnostics',
  'managerRefresh',
  'repairMissingRuntimes',
  'partnerManagersAdmin',
  'mensagem',
  'modalAccessToken',
  'modalAgenceSemi',
  'modalDeleteApp',
  'modalEditAutoMsgChannel',
  'modalEditAutoMsgInterval',
  'modalEditAutoMsgMsg',
  'modalEditSquare',
  'modalNubankImap',
  'modalBankImapPix',
  'modalRemAluguel',
  'modalRepostHour',
  'modalTempPay',
  'modalTempPay2',
  'modal_criar_bot',
  'moderationConfig',
  'note',
  'nubankImapConfig',
  'paymentsConfig',
  'plan',
  'removeAluguel',
  'removeNubankImap',
  'repostHour',
  'repostSetHour',
  'repostToggle',
  'selectAntiFraudBanks',
  'selectBackupEdit',
  'selectChannelEdit',
  'selectClientEdit',
  'selectGerenciamentDev',
  'selectHospedagemEdit',
  'selectLogsEdit',
  'selectMenuDeleteApp',
  'selectRenovEdit',
  'selectRoleAprovedSemi',
  'selectRolesEdit',
  'selectVencidosEdit',
  'selectVendasEdit',
  'semiAutoConfig',
  'setAccessToken',
  'setAgenceSemi',
  'setConfigSemi',
  'sistemaMpOnOff',
  'sistemaOnOff',
  'sistemaSemiOnOff',
  'statusRealtime',
  'testNubankImap',
  'text',
  'text1',
  'toggleNubankImap',
  'trialAdminPanel',
  'uses',
  'salesFeedConfig',
  'salesFeedChannel',
  'salesFeedBuyChannel',
  'salesFeedTestChannel',
  'salesFeedSupportChannel',
  'salesFeedRenewalChannel',
  'salesFeedPreview',
  'salesFeedPreviewPurchase',
  'salesFeedPreviewTrial',
  'salesFeedPreviewRenewal',
  'salesFeedImageToggle',
  'salesFeedTextConfig',
  'salesFeedTextSubmit',
  'clientCenterPublish',
  'clientCenterPublishChannel',
  'mgrnav',
  'earlyAccessToggle',
  'zcloudManagerToggle',
  'walletManagerToggle',
  'zcloudManagerUrl',
  'zcloudManagerUrlSubmit',
  'evopayConfig',
  'evopaySetToken',
  'evopayTokenModal',
  'evopayToggle',
  'evopayTest',
  'evopaySetExpiry',
  'evopayExpiryModal',
  'vyvenceConfig',
  'vyvenceSet',
  'vyvenceModal',
  'vyvenceToggle',
  'vyvenceTest',
  'magnusConfig',
  'magnusSet',
  'magnusModal',
  'magnusToggle',
  'magnusTest',
  'promisseConfig',
  'promisseSet',
  'promisseModal',
  'promisseToggle',
  'promisseTest',
  'magnusGlobalToggle',
  'childBioConfig',
  'childBioModal',
  'childBioApply',
  'shardcloudFallback',
  'shardcloudToggle',
  'shardcloudToken',
  'shardcloudTokenSubmit',
  'shardcloudTest',
]);
function belongsToManagerPanel(interaction, customId) {
  if (customId?.startsWith('mgrpage:') || customId?.startsWith('devAction:') || customId?.startsWith('storefront:') || customId?.startsWith('plans:') || customId?.startsWith('trialcfg:')) return true;
  if (!MANAGER_INTERACTION_IDS.has(customId)) return false;
  if (interaction.isModalSubmit?.()) return true;
  // Componentes do /botconfig são sempre efêmeros. Esta condição evita que
  // IDs genéricos como "back" capturem botões públicos de trial/compra.
  return Boolean(interaction.message?.flags?.has?.(MessageFlags.Ephemeral));
}

function v2AdminInteraction(interaction) {
  if (!interaction.message?.flags?.has?.(MessageFlags.IsComponentsV2)) return interaction;
  const originalUpdate = interaction.update.bind(interaction);
  return new Proxy(interaction, {
    get(target, prop) {
      if (prop === 'update') {
        return async (payload = {}) => {
          const converted = legacyPayloadToV2(payload, 'ASTRA APPLICATION MANAGER');
          return originalUpdate(converted);
        };
      }
      const value = Reflect.get(target, prop, target);
      return typeof value === 'function' ? value.bind(target) : value;
    }
  });
}

function salesFeedAdminPayload(interaction, forUpdate = false) {
    const feed = require('../../Lib/salesFeed');
    const c = feed.settings();
    const em = readCache(interaction.guildId);
    const pick = (cid, label) => new ActionRowBuilder().addComponents(
        new ChannelSelectMenuBuilder().setCustomId(cid).setPlaceholder(label).setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1)
    );
    const imageToggle = new ButtonBuilder()
        .setCustomId('salesFeedImageToggle')
        .setLabel(c.imageEnabled ? 'Imagem ativada' : 'Imagem desativada')
        .setStyle(c.imageEnabled ? ButtonStyle.Success : ButtonStyle.Danger);
    const imageEmoji = id(em, 'image', null) || id(em, 'preview', null);
    if (imageEmoji) imageToggle.setEmoji({ id: imageEmoji });
    const previewPurchase = new ButtonBuilder().setCustomId('salesFeedPreviewPurchase').setLabel('Prévia compra').setStyle(ButtonStyle.Primary);
    const cartEmoji = id(em, 'cart', null) || id(em, 'carrinho', null); if (cartEmoji) previewPurchase.setEmoji({ id: cartEmoji });
    const previewTrial = new ButtonBuilder().setCustomId('salesFeedPreviewTrial').setLabel('Prévia teste').setStyle(ButtonStyle.Secondary);
    const testEmoji = id(em, 'science', null) || id(em, 'test', null); if (testEmoji) previewTrial.setEmoji({ id: testEmoji });
    const previewRenewal = new ButtonBuilder().setCustomId('salesFeedPreviewRenewal').setLabel('Prévia renovação').setStyle(ButtonStyle.Success);
    const renewEmoji = id(em, 'refresh', null) || id(em, 'clock', null); if (renewEmoji) previewRenewal.setEmoji({ id: renewEmoji });
    const container = new ContainerBuilder().setAccentColor(0x3155ff)
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${fmt(em,'announcement')} Feed público de vendas`),
            new TextDisplayBuilder().setContent(
                `Os anúncios de **compra** e **teste** usam Components V2 e podem mostrar o banner da ZENYX + avatar do cliente.\n\n` +
                `**Feed:** ${c.channelId ? `<#${c.channelId}>` : 'não configurado'}\n` +
                `**Canal de compra:** ${c.buyChannelId ? `<#${c.buyChannelId}>` : 'não configurado'}\n` +
                `**Canal de teste:** ${c.testChannelId ? `<#${c.testChannelId}>` : 'não configurado'}\n` +
                `**Suporte:** ${c.supportChannelId ? `<#${c.supportChannelId}>` : 'não configurado'}\n` +
                `**Canal de renovações:** ${c.renewalChannelId ? `<#${c.renewalChannelId}>` : 'não configurado'}\n` +
                `**Imagem/banner:** ${c.imageEnabled ? 'ativada' : 'desativada'}\n\n` +
                `O botão principal dos anúncios é **Adquirir Plano** e leva diretamente ao canal de compra configurado.`
            )
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addActionRowComponents(
            pick('salesFeedChannel','Canal onde os anúncios serão publicados'),
            pick('salesFeedBuyChannel','Canal para o botão Adquirir Plano'),
            pick('salesFeedTestChannel','Canal do teste gratuito'),
            pick('salesFeedSupportChannel','Canal de suporte'),
            pick('salesFeedRenewalChannel','Canal onde serão anunciadas as renovações'),
            new ActionRowBuilder().addComponents(imageToggle, previewPurchase, previewTrial, previewRenewal, new ButtonBuilder().setCustomId('salesFeedTextConfig').setLabel('Texto dos anúncios').setStyle(ButtonStyle.Secondary))
        );
    const payload = { components: [container] };
    if (!forUpdate) payload.flags = MessageFlags.Ephemeral | MessageFlags.IsComponentsV2;
    return payload;
}


function modalInput(customId, label, value='', style=1, required=true, maxLength=100) {
  const input = new TextInputBuilder().setCustomId(customId).setLabel(label).setStyle(style).setRequired(required).setMaxLength(maxLength);
  if (String(value || '').length) input.setValue(String(value).slice(0,maxLength));
  return new ActionRowBuilder().addComponents(input);
}
function storefrontAdminView(interaction) {
  const c=storefront.settings(), em=readCache(interaction.guildId);
  const styles=new StringSelectMenuBuilder().setCustomId('storefront:style').setPlaceholder('Escolher estilo da vitrine').setMinValues(1).setMaxValues(1).addOptions(
    new StringSelectMenuOptionBuilder().setLabel('Banner minimalista').setDescription('Banner → seletor → botões, como a referência').setValue('VELTRIX'),
    new StringSelectMenuOptionBuilder().setLabel('Detalhado').setDescription('Título, descrição, banner e controles').setValue('DETAILED'),
    new StringSelectMenuOptionBuilder().setLabel('Compacto').setDescription('Texto curto + seletor e botões').setValue('COMPACT')
  );
  const b=(cid,label,style=ButtonStyle.Secondary)=>new ButtonBuilder().setCustomId(cid).setLabel(label).setStyle(style);
  const container=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`## ${fmt(em,'store')} Vitrine do Manager`),
    new TextDisplayBuilder().setContent(`**Estilo atual:** ${c.style}\n**Título:** ${c.title}\n**Banner:** ${c.bannerUrl||'arquivo local da ZENYX'}\n**Cor:** ${c.accent}\n**Placeholder:** ${c.selectPlaceholder}\n\n**Visibilidade**\nSaiba Mais: ${c.showInfo?'sim':'não'} • Demo: ${c.showDemo?'sim':'não'} • Teste: ${c.showTrial?'sim':'não'} • Suporte: ${c.showSupport?'sim':'não'} • Acesso antecipado: ${c.showEarlyAccess?'sim':'não'}`)
  ).addSeparatorComponents(new SeparatorBuilder().setDivider(true)).addActionRowComponents(
    new ActionRowBuilder().addComponents(styles),
    new ActionRowBuilder().addComponents(b('storefront:text','Texto e cor',ButtonStyle.Primary),b('storefront:banner','Banner'),b('storefront:support','Link de suporte'),b('storefront:preview','Prévia',ButtonStyle.Primary)),
    new ActionRowBuilder().addComponents(b('storefront:toggle:showInfo',c.showInfo?'Ocultar Saiba Mais':'Mostrar Saiba Mais'),b('storefront:toggle:showDemo',c.showDemo?'Ocultar Demo':'Mostrar Demo'),b('storefront:toggle:showTrial',c.showTrial?'Ocultar Teste':'Mostrar Teste'),b('storefront:toggle:showSupport',c.showSupport?'Ocultar Suporte':'Mostrar Suporte')),
    new ActionRowBuilder().addComponents(b('storefront:toggle:showEarlyAccess',c.showEarlyAccess?'Ocultar Acesso antecipado':'Mostrar Acesso antecipado'),b('storefront:refresh','Atualizar publicado',ButtonStyle.Success),b('mgrpage:4','Voltar'))
  );
  return {components:[container]};
}
function plansAdminView(interaction) {
  const plans=managerPlans.all();
  const text=plans.length?plans.map((p,i)=>`${i+1}. **${p.label}** • ${p.days}d • ${managerPlans.money(p.price)} • ${p.enabled?'ativo':'desativado'} • \`${p.id}\``).join('\n'):'Nenhum plano cadastrado.';
  const container=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent('## Planos dinâmicos'),new TextDisplayBuilder().setContent(`${text}\n\nMáximo de 25 planos. Compras e renovações usam esta lista.`)).addSeparatorComponents(new SeparatorBuilder().setDivider(true));
  if(plans.length){const select=new StringSelectMenuBuilder().setCustomId('plans:select').setPlaceholder('Selecionar um plano para editar').setMinValues(1).setMaxValues(1);for(const p of plans.slice(0,25))select.addOptions(new StringSelectMenuOptionBuilder().setLabel(p.label.slice(0,100)).setDescription(`${p.days} dias • ${managerPlans.money(p.price)} • ${p.enabled?'ativo':'off'}`.slice(0,100)).setValue(p.id));container.addActionRowComponents(new ActionRowBuilder().addComponents(select));}
  container.addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('plans:create').setLabel('Criar plano').setStyle(ButtonStyle.Success),new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Voltar').setStyle(ButtonStyle.Secondary)));
  return {components:[container]};
}
function planDetailView(interaction, plan) {
  const container=new ContainerBuilder().setAccentColor(plan.enabled?0x3155ff:0x747f8d).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${plan.label}`),new TextDisplayBuilder().setContent(`ID: \`${plan.id}\`\nPreço: **${managerPlans.money(plan.price)}**\nValidade base: **${plan.days} dias**\nDescrição: ${plan.description||'—'}\nStatus: **${plan.enabled?'Ativo':'Desativado'}**`)).addActionRowComponents(new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`plans:edit:${plan.id}`).setLabel('Editar').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`plans:toggle:${plan.id}`).setLabel(plan.enabled?'Desativar':'Ativar').setStyle(plan.enabled?ButtonStyle.Danger:ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`plans:delete:${plan.id}`).setLabel('Remover').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('plans:open').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
  ));return {components:[container]};
}
function planModal(customId, plan={}) {
  return new ModalBuilder().setCustomId(customId).setTitle(plan.id?'Editar plano':'Criar plano').addComponents(
    modalInput('id','ID DO PLANO',plan.id||'',1,true,24),modalInput('label','NOME DO PLANO',plan.label||'',1,true,80),modalInput('days','DURAÇÃO EM DIAS',plan.days||30,1,true,6),modalInput('price','PREÇO EM R$',Number(plan.price||0).toFixed(2),1,true,12),modalInput('description','DESCRIÇÃO',plan.description||'',2,false,100)
  );
}
function trialAdminViewV2(interaction){
  const c=trialSettings.settings();const container=new ContainerBuilder().setAccentColor(0x3155ff).addTextDisplayComponents(new TextDisplayBuilder().setContent('## Teste gratuito • configuração'),new TextDisplayBuilder().setContent(`**Duração:** ${trialSettings.label(c.durationMinutes)}\n**Título:** ${c.title}\n**Botão:** ${c.buttonLabel}\n**Banner:** ${c.bannerUrl||'não configurado'}\n**Como funciona:** ${c.showHowItWorks?'visível':'oculto'} • Duração: ${c.showDuration?'visível':'oculto'} • Segurança: ${c.showSecurity?'visível':'oculto'} • Suporte: ${c.showSupport?'visível':'oculto'}`)).addSeparatorComponents(new SeparatorBuilder().setDivider(true)).addActionRowComponents(
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('trialcfg:content').setLabel('Texto e botão').setStyle(ButtonStyle.Primary),new ButtonBuilder().setCustomId('trialcfg:duration').setLabel('Duração').setStyle(ButtonStyle.Primary),new ButtonBuilder().setCustomId('trialcfg:banner').setLabel('Banner e suporte').setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId('trialcfg:preview').setLabel('Prévia').setStyle(ButtonStyle.Secondary)),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('trialcfg:toggle:showHowItWorks').setLabel(c.showHowItWorks?'Ocultar Como funciona':'Mostrar Como funciona').setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId('trialcfg:toggle:showDuration').setLabel(c.showDuration?'Ocultar Duração':'Mostrar Duração').setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId('trialcfg:toggle:showSecurity').setLabel(c.showSecurity?'Ocultar Segurança':'Mostrar Segurança').setStyle(ButtonStyle.Secondary)),
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('trialcfg:toggle:showSupport').setLabel(c.showSupport?'Ocultar Suporte':'Mostrar Suporte').setStyle(ButtonStyle.Secondary),new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Voltar').setStyle(ButtonStyle.Secondary))
  );return{components:[container]};
}
function parseTrialDuration(raw){const v=String(raw||'').trim().toLowerCase().replace(/\s+/g,'');const m=v.match(/^(\d+(?:[.,]\d+)?)(min|m|h|d|dia|dias|hora|horas)?$/);if(!m)throw new Error('Use 90min, 12h, 24h, 2d ou minutos.');const n=Number(m[1].replace(',','.'));let minutes=(m[2]||'min').startsWith('d')?n*1440:(m[2]||'').startsWith('h')||(m[2]||'').startsWith('hora')?n*60:n;minutes=Math.round(minutes);if(!Number.isFinite(minutes)||minutes<5||minutes>525600)throw new Error('Duração entre 5 minutos e 365 dias.');return minutes;}


function checkoutReviewersView(interaction) {
  const reviewers = purchaseReviewers.list();
  const em = readCache(interaction.guildId);
  const mentions = reviewers.length ? reviewers.map(userId => `<@${userId}>`).join('\n') : 'Nenhum supervisor configurado.';
  const picker = new UserSelectMenuBuilder()
    .setCustomId('checkoutReviewersSelect')
    .setPlaceholder('Escolha até 10 supervisores dos tópicos privados')
    .setMinValues(1)
    .setMaxValues(10);
  if (reviewers.length) picker.setDefaultUsers(...reviewers.slice(0, 10));

  const container = new ContainerBuilder().setAccentColor(0x3155ff)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ${fmt(em, 'users')} Equipe dos tópicos privados`),
      new TextDisplayBuilder().setContent(
        `Estas pessoas são adicionadas automaticamente aos tópicos privados de **compra de plano** e **teste**.\n` +
        `Elas também podem confirmar pagamentos PIX manuais mesmo sem o cargo aprovador.\n\n` +
        `**Supervisores atuais (${reviewers.length}/10):**\n${mentions}`
      )
    )
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(picker),
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('checkoutReviewersSync').setLabel('Aplicar aos tópicos abertos').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('checkoutReviewersAddOwner').setLabel('Adicionar proprietário').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('checkoutReviewersClear').setLabel('Remover todos').setStyle(ButtonStyle.Danger).setDisabled(!reviewers.length),
        new ButtonBuilder().setCustomId('managerRefresh').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
      )
    );
  return { components: [container] };
}

function shardcloudAdminPayload(interaction) {
  const st = shardcloudControl.settings();
  const emojis = readCache(interaction.guildId);
  const em = (key) => emojis?.[key] || null;
  const btn = (id, label, style, key) => { const b=new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style); const e=em(key); if(e)b.setEmoji(e); return b; };
  const c = new ContainerBuilder().setAccentColor(st.enabled ? 0x57F287 : 0x5865F2)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `## CamposCloud • hospedagem remota\n`+
      `Use somente quando o host local atingir o limite configurado. **O fallback não substitui a HidenCloud enquanto houver capacidade local.**\n\n`+
      `**Estado:** ${st.enabled ? 'Ativado' : 'Desativado'}\n`+
      `**API Key:** ${shardcloudControl.maskedToken()}\n`+
      `**Limite de memória local:** ${Math.round(st.memoryRatio*100)}%\n`+
      `**Memória solicitada por bot remoto:** ${st.childMemoryMb} MB\n`+
      `-# A chave nunca é exibida inteira nem enviada em logs.`
    ))
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
    .addActionRowComponents(new ActionRowBuilder().addComponents(
      btn('shardcloudToggle', st.enabled ? 'Desativar CamposCloud' : 'Ativar CamposCloud', st.enabled ? ButtonStyle.Danger : ButtonStyle.Success, 'power'),
      btn('shardcloudToken', 'Configurar API CamposCloud', ButtonStyle.Primary, 'key'),
      btn('shardcloudTest', 'Testar CamposCloud', ButtonStyle.Secondary, 'status'),
      btn('mgrpage:1', 'Voltar', ButtonStyle.Secondary, 'back')
    ));
  return { components:[c] };
}

module.exports = {
    name: `interactionCreate`,

    run: async (interaction, client) => {
        const { customId } = interaction;
        // Fluxos públicos nunca passam pelo gate administrativo do /botconfig.
        // Isso evita que o botão de trial seja bloqueado para usuários comuns
        // caso algum ID genérico seja reutilizado em outro painel.
        if (customId === 'botfree' || customId === 'teste_gratis' || customId === 'zenyx_trial_submit' || customId?.startsWith('zenyx_trial_submit:') || customId?.startsWith('select_tipo_bot_trial:')) return;
        if (!customId || !belongsToManagerPanel(interaction, customId)) return;
        // Nunca bloqueie a janela de 3s da interação esperando sincronização remota de emojis.
        // O painel usa o cache atual imediatamente e atualiza os Application Emojis em background.
        void require('../../Lib/managerEmojis').ensureManagerEmojis(interaction).catch(() => null);
        if (!require('../../Lib/permissions').isOwner(interaction.user.id)) {
            if (!interaction.replied && !interaction.deferred && (interaction.isButton?.() || interaction.isStringSelectMenu?.() || interaction.isChannelSelectMenu?.() || interaction.isRoleSelectMenu?.() || interaction.isUserSelectMenu?.() || interaction.isModalSubmit?.())) {
                return interaction.reply({ content: 'Este painel é exclusivo do proprietário do Manager.', flags: MessageFlags.Ephemeral }).catch(() => null);
            }
            return;
        }

        // A tela principal do /botconfig é Components V2. Handlers legados ainda
        // podem produzir embed + ActionRows; o proxy converte qualquer update para
        // um Container V2, evitando Invalid Form Body ao navegar/editar opções.
        interaction = v2AdminInteraction(interaction);

        if (customId === 'antiScamToggle') {
            const enabled = logs.get('antiScam.enabled') !== false;
            await logs.set('antiScam.enabled', !enabled);
            return interaction.update(pagePayload(3, interaction, true));
        }

        if (customId === 'plans:revoke-user') {
            const picker = new UserSelectMenuBuilder().setCustomId('plans:revoke-user-select').setPlaceholder('Selecione o usuário').setMinValues(1).setMaxValues(1);
            return interaction.update({ components: [new ContainerBuilder().setAccentColor(0xed4245)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Revogar plano de usuário\nSelecione o membro. Depois escolha qual aplicação terá o acesso encerrado. **Os dados do runtime não serão apagados.**`))
              .addActionRowComponents(new ActionRowBuilder().addComponents(picker), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Cancelar').setStyle(ButtonStyle.Secondary)))] });
        }
        if (customId === 'plans:revoke-user-select' && interaction.isUserSelectMenu?.()) {
            const targetId = interaction.values?.[0];
            const apps = db2.all().map(row => ({ id: String(row.ID || ''), ...(row.data || {}) })).filter(app => app.id && String(app.owner) === String(targetId));
            if (!apps.length) return interaction.update({ components: [new ContainerBuilder().setAccentColor(0xed4245).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Revogar plano
<@${targetId}> não possui aplicações vinculadas.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Voltar').setStyle(ButtonStyle.Secondary)))] });
            const select = new StringSelectMenuBuilder().setCustomId(`plans:revoke-app:${targetId}`).setPlaceholder('Escolha a aplicação').addOptions(apps.slice(0,25).map(app => new StringSelectMenuOptionBuilder().setLabel(String(app.nome || app.id).slice(0,100)).setDescription(`${app.plano || 'Plano'} • runtime ${app.id}`.slice(0,100)).setValue(app.id)));
            return interaction.update({ components: [new ContainerBuilder().setAccentColor(0xed4245).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Revogar plano
Usuário: <@${targetId}>
Escolha a aplicação. Ela será desligada e ficará expirada, **sem apagar produtos, embeds, banco ou configurações**.`)).addActionRowComponents(new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Cancelar').setStyle(ButtonStyle.Secondary)))] });
        }
        if (customId.startsWith('plans:revoke-app:') && interaction.isStringSelectMenu?.()) {
            const targetId = customId.slice('plans:revoke-app:'.length);
            const runtimeId = interaction.values?.[0];
            const current = db2.get(runtimeId);
            if (!current || String(current.owner) !== String(targetId)) throw new Error('Aplicação não encontrada para este usuário.');
            await interaction.deferUpdate();
            const now = new Date().toISOString();
            db2.set(`${runtimeId}.dataExpiracao`, now);
            db2.set(`${runtimeId}.status`, 'expired');
            db2.set(`${runtimeId}.revokedAt`, now);
            db2.set(`${runtimeId}.revokedBy`, interaction.user.id);
            for (const row of db1.all()) {
              const key = String(row?.ID || ''); const data = row?.data || {};
              if (key && String(data.boundRuntimeId || '') === String(runtimeId)) db1.set(`${key}.entitlementExpiresAt`, now);
            }
            try { const app = await new SquareCloudAPI().applications.get(runtimeId); await app.stop(); } catch {}
            return interaction.editReply({ components: [new ContainerBuilder().setAccentColor(0x57f287).addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Plano revogado
A aplicação **${String(current.nome || runtimeId).slice(0,80)}** de <@${targetId}> foi desligada e marcada como expirada. Os dados foram preservados para auditoria/reativação.`)).addActionRowComponents(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('mgrpage:5').setLabel('Voltar aos planos').setStyle(ButtonStyle.Secondary)))] });
        }

        // R18.9.24 • Vitrine, planos dinâmicos e trial configurável.
        if (customId === 'storefront:open') return interaction.update(storefrontAdminView(interaction));
        if (customId === 'storefront:style' && interaction.isStringSelectMenu?.()) {
            storefront.save({ style: interaction.values[0] });
            return interaction.update(storefrontAdminView(interaction));
        }
        if (customId.startsWith('storefront:toggle:')) {
            storefront.toggle(customId.split(':')[2]);
            return interaction.update(storefrontAdminView(interaction));
        }
        if (customId === 'storefront:text') {
            const c=storefront.settings();
            return interaction.showModal(new ModalBuilder().setCustomId('storefront:text:submit').setTitle('Vitrine • texto e cor').addComponents(
                modalInput('title','TÍTULO',c.title,1,true,100),
                modalInput('description','DESCRIÇÃO',c.description,2,false,3000),
                modalInput('footer','RODAPÉ',c.footer,1,false,300),
                modalInput('accent','COR #RRGGBB',c.accent,1,true,7),
                modalInput('placeholder','TEXTO DO SELETOR',c.selectPlaceholder,1,true,120)
            ));
        }
        if (interaction.isModalSubmit?.() && customId === 'storefront:text:submit') {
            const accent=interaction.fields.getTextInputValue('accent').trim();
            if(!/^#[0-9a-f]{6}$/i.test(accent)) return interaction.reply({content:'Use uma cor no formato #RRGGBB.',flags:64});
            storefront.save({title:interaction.fields.getTextInputValue('title'),description:interaction.fields.getTextInputValue('description'),footer:interaction.fields.getTextInputValue('footer'),accent,selectPlaceholder:interaction.fields.getTextInputValue('placeholder')});
            return interaction.reply({content:'Vitrine atualizada. Use **Atualizar publicado** para aplicar na mensagem pública.',flags:64});
        }
        if (customId === 'storefront:banner') {
            const c=storefront.settings();return interaction.showModal(new ModalBuilder().setCustomId('storefront:banner:submit').setTitle('Vitrine • banner').addComponents(modalInput('url','URL HTTPS (vazio = banner local)',c.bannerUrl,1,false,1000)));
        }
        if (interaction.isModalSubmit?.() && customId === 'storefront:banner:submit') {
            const raw=interaction.fields.getTextInputValue('url').trim();if(raw&&!storefront.validUrl(raw))return interaction.reply({content:'O banner precisa ser uma URL HTTPS válida.',flags:64});storefront.save({bannerUrl:raw});return interaction.reply({content:raw?'Banner personalizado salvo.':'Banner local da ZENYX restaurado.',flags:64});
        }
        if (customId === 'storefront:support') {
            const c=storefront.settings();return interaction.showModal(new ModalBuilder().setCustomId('storefront:support:submit').setTitle('Vitrine • suporte').addComponents(modalInput('url','LINK HTTPS DE SUPORTE',c.supportUrl,1,true,1000)));
        }
        if (interaction.isModalSubmit?.() && customId === 'storefront:support:submit') {
            const raw=interaction.fields.getTextInputValue('url').trim();if(!storefront.validUrl(raw))return interaction.reply({content:'Informe uma URL HTTPS válida.',flags:64});storefront.save({supportUrl:raw});return interaction.reply({content:'Link de suporte atualizado.',flags:64});
        }
        if (customId === 'storefront:preview') {
            const payload=salesPanels.buildZenyxPanel(interaction.guild,'ZenyxPro');return interaction.reply({...payload,flags:MessageFlags.Ephemeral|MessageFlags.IsComponentsV2});
        }
        if (customId === 'storefront:refresh') {
            await interaction.deferReply({flags:64});const count=await salesPanels.refreshPublishedZenyxPanels(client);return interaction.editReply({content:`${count} painel(is) público(s) atualizado(s).`});
        }

        if (customId === 'plans:open') return interaction.update(plansAdminView(interaction));
        if (customId === 'plans:create') return interaction.showModal(planModal('plans:create:submit'));
        if (interaction.isModalSubmit?.() && customId === 'plans:create:submit') {
            const days=Number(interaction.fields.getTextInputValue('days').replace(',','.'));const price=Number(interaction.fields.getTextInputValue('price').replace(',','.'));if(!Number.isFinite(days)||days<1||days>36500)return interaction.reply({content:'Duração inválida (1 a 36500 dias).',flags:64});if(!Number.isFinite(price)||price<0)return interaction.reply({content:'Preço inválido.',flags:64});
            const requested=managerPlans.cleanId(interaction.fields.getTextInputValue('id'));if(managerPlans.find(requested))return interaction.reply({content:'Já existe um plano com este ID.',flags:64});managerPlans.upsert({id:requested,label:interaction.fields.getTextInputValue('label'),days,price,description:interaction.fields.getTextInputValue('description'),enabled:true});return interaction.reply({content:`Plano **${requested}** criado.`,flags:64});
        }
        if (customId === 'plans:select' && interaction.isStringSelectMenu?.()) {const p=managerPlans.find(interaction.values[0]);if(!p)return interaction.update(plansAdminView(interaction));return interaction.update(planDetailView(interaction,p));}
        if (customId.startsWith('plans:edit:')) {const plan=managerPlans.find(customId.slice('plans:edit:'.length));if(!plan)throw new Error('Plano não encontrado.');return interaction.showModal(planModal(`plans:edit-submit:${plan.id}`,plan));}
        if (interaction.isModalSubmit?.() && customId.startsWith('plans:edit-submit:')) {const oldId=customId.slice('plans:edit-submit:'.length),old=managerPlans.find(oldId);if(!old)return interaction.reply({content:'Plano não encontrado.',flags:64});const newId=managerPlans.cleanId(interaction.fields.getTextInputValue('id'));if(newId!==oldId&&managerPlans.find(newId))return interaction.reply({content:'Já existe outro plano com este ID.',flags:64});const days=Number(interaction.fields.getTextInputValue('days').replace(',','.')),price=Number(interaction.fields.getTextInputValue('price').replace(',','.'));if(!Number.isFinite(days)||days<1||days>36500||!Number.isFinite(price)||price<0)return interaction.reply({content:'Preço ou duração inválidos.',flags:64});if(newId!==oldId)managerPlans.remove(oldId);managerPlans.upsert({...old,id:newId,label:interaction.fields.getTextInputValue('label'),days,price,description:interaction.fields.getTextInputValue('description')});return interaction.reply({content:'Plano atualizado.',flags:64});}
        if (customId.startsWith('plans:toggle:')) {const p=managerPlans.toggle(customId.slice('plans:toggle:'.length));if(!p)throw new Error('Plano não encontrado.');return interaction.update(planDetailView(interaction,p));}
        if (customId.startsWith('plans:delete:')) {const plan=managerPlans.find(customId.slice('plans:delete:'.length));if(!plan)throw new Error('Plano não encontrado.');return interaction.showModal(new ModalBuilder().setCustomId(`plans:delete-submit:${plan.id}`).setTitle('Remover plano').addComponents(modalInput('confirm','DIGITE REMOVER PARA CONFIRMAR','',1,true,10)));}
        if (interaction.isModalSubmit?.() && customId.startsWith('plans:delete-submit:')) {if(interaction.fields.getTextInputValue('confirm').trim().toUpperCase()!=='REMOVER')return interaction.reply({content:'Remoção cancelada.',flags:64});const planId=customId.slice('plans:delete-submit:'.length);const ok=managerPlans.remove(planId);return interaction.reply({content:ok?'Plano removido.':'Plano já não existe.',flags:64});}

        if (customId === 'trialcfg:open') return interaction.update(trialAdminViewV2(interaction));
        if (customId.startsWith('trialcfg:toggle:')) {trialSettings.toggle(customId.split(':')[2]);return interaction.update(trialAdminViewV2(interaction));}
        if (customId === 'trialcfg:duration') {const c=trialSettings.settings();return interaction.showModal(new ModalBuilder().setCustomId('trialcfg:duration:submit').setTitle('Duração do teste').addComponents(modalInput('duration','EX: 90min, 12h, 24h, 2d',trialSettings.label(c.durationMinutes),1,true,20)));}
        if (interaction.isModalSubmit?.() && customId === 'trialcfg:duration:submit') {try{const durationMinutes=parseTrialDuration(interaction.fields.getTextInputValue('duration'));trialSettings.save({durationMinutes});return interaction.reply({content:`Duração do teste alterada para **${trialSettings.label(durationMinutes)}**. Novos testes usarão este tempo.`,flags:64});}catch(e){return interaction.reply({content:e.message,flags:64});}}
        if (customId === 'trialcfg:content') {const c=trialSettings.settings();return interaction.showModal(new ModalBuilder().setCustomId('trialcfg:content:submit').setTitle('Teste • conteúdo').addComponents(modalInput('title','TÍTULO',c.title,1,true,100),modalInput('description','DESCRIÇÃO',c.description,2,true,1200),modalInput('button','TEXTO DO BOTÃO',c.buttonLabel,1,true,80)));}
        if (interaction.isModalSubmit?.() && customId === 'trialcfg:content:submit') {trialSettings.save({title:interaction.fields.getTextInputValue('title'),description:interaction.fields.getTextInputValue('description'),buttonLabel:interaction.fields.getTextInputValue('button')});return interaction.reply({content:'Conteúdo do painel de teste atualizado.',flags:64});}
        if (customId === 'trialcfg:banner') {const c=trialSettings.settings();return interaction.showModal(new ModalBuilder().setCustomId('trialcfg:banner:submit').setTitle('Teste • banner e suporte').addComponents(modalInput('banner','URL DO BANNER (vazio = remover)',c.bannerUrl,1,false,1000),modalInput('support','URL DE SUPORTE',c.supportUrl,1,true,1000),modalInput('accent','COR #RRGGBB',c.accent,1,true,7)));}
        if (interaction.isModalSubmit?.() && customId === 'trialcfg:banner:submit') {const banner=interaction.fields.getTextInputValue('banner').trim(),support=interaction.fields.getTextInputValue('support').trim(),accent=interaction.fields.getTextInputValue('accent').trim();if(banner&&!trialSettings.validUrl(banner))return interaction.reply({content:'Banner inválido.',flags:64});if(!trialSettings.validUrl(support))return interaction.reply({content:'URL de suporte inválida.',flags:64});if(!/^#[0-9a-f]{6}$/i.test(accent))return interaction.reply({content:'Cor inválida.',flags:64});trialSettings.save({bannerUrl:banner,supportUrl:support,accent});return interaction.reply({content:'Banner/suporte do teste atualizados.',flags:64});}
        if (customId === 'trialcfg:preview') {const cmd=require('../../Comandos/config/gratis');const payload=cmd._test.panelPayload(interaction,trialSettings.settings());return interaction.reply({...payload,flags:MessageFlags.Ephemeral|MessageFlags.IsComponentsV2});}

        if (customId === 'clientCenterPublish') {
            const picker = new ChannelSelectMenuBuilder()
              .setCustomId('clientCenterPublishChannel')
              .setPlaceholder('Escolha o canal da Central de Gerenciamento')
              .setChannelTypes(ChannelType.GuildText)
              .setMinValues(1)
              .setMaxValues(1);
            return interaction.reply({
              content: '',
              embeds: [new EmbedBuilder().setTitle(`${fmt(readCache(interaction.guildId),'announcement')} Publicar Central de Gerenciamento`).setDescription('Escolha o canal. A Central será enviada como **uma nova mensagem do Zenyx Host**. O painel administrativo continua aberto acima.').setColor('#3155ff')],
              components: [new ActionRowBuilder().addComponents(picker)],
              flags: MessageFlags.Ephemeral
            });
        }
        if (customId === 'clientCenterPublishChannel' && interaction.isChannelSelectMenu?.()) {
            const channelId = interaction.values[0];
            const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);
            if (!channel?.isTextBased?.() || !channel?.send) return interaction.reply({ content:'Selecione um canal de texto válido.', flags:64 });
            const payload = require('../../Lib/clientCenter').centralPayload(client, { guildId: interaction.guildId });
            await channel.send(payload);
            return interaction.update({ content:`${fmt(readCache(interaction.guildId),'success')} Central publicada em <#${channelId}>.`, embeds: [], components: [] });
        }
        if (customId === 'salesFeedConfig') {
            return interaction.reply(salesFeedAdminPayload(interaction, false));
        }
        if (['salesFeedChannel','salesFeedBuyChannel','salesFeedTestChannel','salesFeedSupportChannel','salesFeedRenewalChannel'].includes(customId) && interaction.isChannelSelectMenu?.()) {
            const map={salesFeedChannel:'channelId',salesFeedBuyChannel:'buyChannelId',salesFeedTestChannel:'testChannelId',salesFeedSupportChannel:'supportChannelId',salesFeedRenewalChannel:'renewalChannelId'};
            require('../../Lib/salesFeed').save({[map[customId]]:interaction.values[0]});
            return interaction.update(salesFeedAdminPayload(interaction, true));
        }
        if (customId === 'salesFeedImageToggle') {
            const feed = require('../../Lib/salesFeed');
            const current = feed.settings();
            feed.save({ imageEnabled: !current.imageEnabled });
            return interaction.update(salesFeedAdminPayload(interaction, true));
        }
        if (customId === 'salesFeedPreview' || customId === 'salesFeedPreviewTrial') {
            await require('../../Lib/salesFeed').announce(client,{type:'trial',user:interaction.user,guildId:interaction.guildId,plan:'Teste 24h • Prévia',days:1,appId:'preview'});
            return interaction.reply({content:`${fmt(readCache(),'success')} Prévia enviada ao feed configurado.`,flags:64});
        }
        if (customId === 'salesFeedPreviewPurchase') {
            await require('../../Lib/salesFeed').announce(client,{type:'purchase',user:interaction.user,guildId:interaction.guildId,plan:'Mensal • Prévia',days:30,appId:'preview'});
            return interaction.reply({content:`${fmt(readCache(),'success')} Prévia de compra enviada ao feed configurado.`,flags:64});
        }
        if (customId === 'salesFeedPreviewRenewal') {
            const ok = await require('../../Lib/salesFeed').announce(client,{type:'renewal',user:interaction.user,guildId:interaction.guildId,plan:'Mensal • Prévia',days:30,amount:0.90,appId:'preview'});
            return interaction.reply({content: ok ? `${fmt(readCache(),'success')} Prévia de renovação enviada.` : 'Configure primeiro o **Canal de renovações**.',flags:64});
        }
        if (customId === 'salesFeedTextConfig') {
            const feed=require('../../Lib/salesFeed').settings();
            return interaction.showModal(new ModalBuilder().setCustomId('salesFeedTextSubmit').setTitle('Feed • textos').addComponents(
                modalInput('purchaseTitle','TÍTULO DA COMPRA',feed.purchaseTitle,1,true,100),
                modalInput('trialTitle','TÍTULO DO TESTE',feed.trialTitle,1,true,100),
                modalInput('purchaseText','TEXTO DA COMPRA',feed.purchaseText,2,true,1000),
                modalInput('trialText','TEXTO DO TESTE',feed.trialText,2,true,1000),
                modalInput('footer','RODAPÉ',feed.footer,1,false,300)
            ));
        }
        if (interaction.isModalSubmit?.() && customId === 'salesFeedTextSubmit') {
            require('../../Lib/salesFeed').save({purchaseTitle:interaction.fields.getTextInputValue('purchaseTitle').trim(),trialTitle:interaction.fields.getTextInputValue('trialTitle').trim(),purchaseText:interaction.fields.getTextInputValue('purchaseText').trim(),trialText:interaction.fields.getTextInputValue('trialText').trim(),footer:interaction.fields.getTextInputValue('footer').trim()});
            return interaction.reply({content:'Textos dos anúncios salvos. Placeholders disponíveis: {user}, {plan}, {validity}, {app}.',flags:64});
        }

        if (customId === 'mgrnav' && interaction.isStringSelectMenu?.()) {
            const page = Number(interaction.values?.[0]);
            if (!Number.isInteger(page) || page < 0 || page >= PAGE_COUNT) return interaction.deferUpdate?.().catch(() => null);
            // pagePayload(forUpdate) não tenta alterar flags da mensagem V2.
            return interaction.update(pagePayload(client, interaction, page, { forUpdate: true }));
        }
        if (customId.startsWith('mgrpage:')) {
            const page = Number(customId.split(':')[1]);
            if (!Number.isInteger(page)) return interaction.deferUpdate?.().catch(() => null);
            return interaction.update(pagePayload(client, interaction, page, { forUpdate: true }));
        }

        async function deleteManagedApp(appid) {
            const record = db2.get(appid);
            if (!record) throw new Error('Aplicação não encontrada.');
            const app = await new SquareCloudAPI(api.get('square')).applications.get(appid);
            const result = await app.delete();
            if (result?.ok === false) throw new Error(result.msg || 'O runtime não confirmou a exclusão.');

            const owner = record.owner;
            if (owner) {
                const ownerKey = `${owner}_owner`;
                const ownerData = auto.get(ownerKey);
                if (ownerData && Array.isArray(ownerData.butecos)) {
                    ownerData.butecos = ownerData.butecos.filter(item => String(item?.idapp) !== String(appid));
                    auto.set(ownerKey, ownerData);
                }
            }
            db2.delete(appid);
            return record;
        }

        if (customId === 'keyManagement') {
            const st = keyStore.stats();
            const em = readCache(interaction.guildId);
            const eb = (key, builder) => { if (em[key]) builder.setEmoji(em[key]); return builder; };
            return interaction.update({
                content: '',
                embeds: [new EmbedBuilder().setTitle(`${fmt(em,'key')} ASTRA APPLICATION • GERENCIADOR DE KEYS`).setDescription('Gere chaves por plano, defina validade, limite de usuários e revogue acessos sem editar arquivos.').addFields(
                    { name:'Ativas', value:`**${st.active}**`, inline:true },
                    { name:'Resgates', value:`**${st.redemptions}**`, inline:true },
                    { name:'Total', value:`**${st.total}**`, inline:true }
                ).setColor('#5865F2').setTimestamp()],
                components:[
                    new ActionRowBuilder().addComponents(
                        eb('key', new ButtonBuilder().setCustomId('keyGenerateModal').setLabel('Gerar Key').setStyle(ButtonStyle.Success)),
                        eb('database', new ButtonBuilder().setCustomId('keyListActive').setLabel('Listar Keys').setStyle(ButtonStyle.Secondary)),
                        eb('delete', new ButtonBuilder().setCustomId('keyRevokeModal').setLabel('Revogar Key').setStyle(ButtonStyle.Danger))
                    ),
                    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back').setLabel('Voltar').setStyle(ButtonStyle.Secondary))
                ]
            });
        }
        if (customId === 'keyGenerateModal') {
            const modal = new ModalBuilder().setCustomId('keyGenerateSubmit').setTitle('ASTRA APPLICATION • Gerar Key');
            modal.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('plan').setLabel('PLANO').setPlaceholder('PRO / PREMIUM / ENTERPRISE').setStyle(1).setRequired(true).setMaxLength(32)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('expiry').setLabel('EXPIRAÇÃO').setPlaceholder('DD/MM/AAAA').setStyle(1).setRequired(true).setMaxLength(10)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('uses').setLabel('QUANTOS USUÁRIOS PODEM USAR?').setPlaceholder('1').setStyle(1).setRequired(true).setMaxLength(5)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('note').setLabel('NOTA ADMINISTRATIVA').setPlaceholder('Opcional').setStyle(1).setRequired(false).setMaxLength(300))
            );
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit?.() && customId === 'keyGenerateSubmit') {
            try {
                const r = keyStore.createKey({ plan: interaction.fields.getTextInputValue('plan'), expiresAt: interaction.fields.getTextInputValue('expiry'), maxUses: Number(interaction.fields.getTextInputValue('uses')), note: interaction.fields.getTextInputValue('note') || '', createdBy: interaction.user.id });
                return interaction.reply({ content:`Key criada: \`${r.code}\`\nPlano: **${r.plan}** • Limite: **${r.maxUses}** • Expira: <t:${Math.floor(new Date(r.expiresAt).getTime()/1000)}:F>`, flags:64 });
            } catch (error) { return interaction.reply({ content:error.message, flags:64 }); }
        }
        if (customId === 'keyListActive') {
            const list = keyStore.listKeys().slice(0,20);
            return interaction.update({ content:'', embeds:[new EmbedBuilder().setTitle('ASTRA APPLICATION • Keys recentes').setDescription(list.map(k=>`\`${k.code}\` • **${k.plan}** • ${k.uses?.length||0}/${k.maxUses} • ${k.revokedAt?'revogada':keyStore.isExpired(k)?'expirada':'ativa'}`).join('\n') || 'Nenhuma Key criada.').setColor('#5865F2')], components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('keyManagement').setLabel('Voltar').setStyle(2))] });
        }
        if (customId === 'keyRevokeModal') {
            const modal = new ModalBuilder().setCustomId('keyRevokeSubmit').setTitle('ASTRA APPLICATION • Revogar Key').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('code').setLabel('CÓDIGO DA KEY').setPlaceholder('ZENYX-XXXX-XXXX-XXXX').setStyle(1).setRequired(true)));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit?.() && customId === 'keyRevokeSubmit') {
            try { const r=keyStore.revokeKey(interaction.fields.getTextInputValue('code'), interaction.user.id); return interaction.reply({ content:`Key \`${r.code}\` revogada.`, flags:64 }); }
            catch(error){ return interaction.reply({ content:error.message, flags:64 }); }
        }
        if (customId === 'trialAdminPanel') return interaction.update(trialAdminViewV2(interaction));
        if (customId === 'managerDiagnostics') {
            const hs=sftp.status(); const ks=keyStore.stats();
            return interaction.update({ content:'', embeds:[new EmbedBuilder().setTitle(`${fmt(readCache(interaction.guildId),'dev')} ASTRA APPLICATION • DIAGNÓSTICO`).addFields(
                {name:'Manager',value:`Application ID: \`${interaction.client.application?.id||interaction.client.user.id}\`\nGuilds: **${interaction.client.guilds.cache.size}**\nPing: **${Math.round(interaction.client.ws.ping||0)}ms**`},
                {name:'Hospedagem',value:`SFTP: **${hs.ok?'OK':'Revisar'}**\nApps: **${db2.all().length}**\nRuntime: **local/HidenCloud**`},
                {name:'Isolamento de comandos',value:'Manager: um conjunto global único; registros antigos por guild são removidos e verificados novamente no boot.\nAplicação filha: comandos globais são limpos e registrados somente no guildId configurado.'},
                {name:'Keys',value:`Ativas: **${ks.active}** • Resgates: **${ks.redemptions}**`}
            ).setColor(hs.ok?'#57F287':'#FEE75C').setTimestamp()], components:[new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back').setLabel('Voltar').setStyle(2))] });
        }
        if (customId === 'managerRefresh') return inicio();
        if (customId === 'repairMissingRuntimes') {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            const runtime = require('../../source/runtime');
            const rows = db2.all();
            let recovered = 0, alreadyOk = 0, failed = 0, restarted = 0;
            const details = [];
            for (const row of rows) {
                const appId = String(row?.ID || row?.data?.idapp || '').trim();
                if (!appId) continue;
                try {
                    if (fs.existsSync(runtime.appDir(appId))) { alreadyOk++; continue; }
                    const result = await runtime.recoverMissingRuntime(appId);
                    if (!result?.ok) { failed++; details.push(`• ${appId}: ${String(result?.msg || 'backup não localizado').slice(0,120)}`); continue; }
                    recovered++;
                    const data = row?.data || {};
                    const shouldRun = String(data.desiredState || '').toLowerCase() !== 'stopped' && data.userStopped !== true && !['expired','removed','suspended','revoked'].includes(String(data.status || '').toLowerCase());
                    if (shouldRun) {
                        const started = await runtime.start(appId, { bootWaitMs: 2500 });
                        if (started?.ok) { restarted++; db2.set(`${appId}.status`, 'online'); db2.set(`${appId}.desiredState`, 'running'); db2.delete(`${appId}.lastStartError`); }
                    }
                } catch (error) { failed++; details.push(`• ${appId}: ${String(error?.message || error).slice(0,120)}`); }
            }
            const em = readCache(interaction.guildId);
            const okEmoji = fmt(em,'success') || '✅';
            return interaction.editReply({ content: `${okEmoji} **Verificação de runtimes concluída**
-# Localizados: ${alreadyOk} • recuperados: ${recovered} • religados: ${restarted} • falhas: ${failed}${details.length ? `

${details.slice(0,8).join('\n')}` : ''}` });
        }
        if (customId === 'partnerManagersAdmin') {
            const panel = require('../../Lib/partnerManagerPanel');
            return interaction.update(panel.adminPayload(interaction.guildId));
        }
        if (customId === 'shardcloudFallback') return interaction.update(shardcloudAdminPayload(interaction));
        if (customId === 'shardcloudToggle') {
            const current = shardcloudControl.settings();
            if (!current.enabled && !current.token) return interaction.reply({content:'Configure a API Key da CamposCloud antes de ativar.',flags:MessageFlags.Ephemeral});
            shardcloudControl.toggle();
            return interaction.update(shardcloudAdminPayload(interaction));
        }
        if (customId === 'shardcloudToken') {
            const modal = new ModalBuilder().setCustomId('shardcloudTokenSubmit').setTitle('CamposCloud • API Key').addComponents(
              new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('token').setLabel('API KEY DA CAMPOSCLOUD').setPlaceholder('Cole a API key criada na CamposCloud').setStyle(1).setRequired(true).setMinLength(8).setMaxLength(500))
            );
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit?.() && customId === 'shardcloudTokenSubmit') {
            const token = String(interaction.fields.getTextInputValue('token') || '').trim();
            if (token.length < 8) return interaction.reply({content:'API Key inválida.',flags:MessageFlags.Ephemeral});
            shardcloudControl.save({token});
            return interaction.reply({content:'API Key da CamposCloud salva com segurança. Use **Testar CamposCloud** antes de ativar.',flags:MessageFlags.Ephemeral});
        }
        if (customId === 'shardcloudTest') {
            await interaction.deferReply({flags:MessageFlags.Ephemeral});
            const result = await shardcloudApi.testToken();
            return interaction.editReply({content:result.ok?'✅ Conexão com a API da CamposCloud confirmada.':`❌ Não foi possível validar a CamposCloud: ${result.error}`});
        }
        if (customId === 'earlyAccessToggle') {
            earlyAccess.toggle();
            return interaction.update(pagePayload(client, interaction, 2, { forUpdate: true }));
        }
        if (customId === 'zcloudManagerToggle') {
            const state = zcloudControl.toggle();
            await require('../../source/runtime').syncZcloudFeatureForAll().catch(() => []);
            return interaction.update(pagePayload(client, interaction, 2, { forUpdate: true }));
        }
        if (customId === 'walletManagerToggle') {
            walletControl.toggle();
            await require('../../source/runtime').syncWalletFeatureForAll().catch(() => []);
            return interaction.update(pagePayload(client, interaction, 2, { forUpdate: true }));
        }
        if (customId === 'zcloudManagerUrl') {
            const current = zcloudControl.effectivePublicBaseUrl();
            const modal = new ModalBuilder().setCustomId('zcloudManagerUrlSubmit').setTitle('ASTRA APPLICATION • URL pública ZCloud').addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder().setCustomId('url').setLabel('REVERSE PROXY HTTPS').setPlaceholder('https://auth.seudominio.com').setValue(current || '').setStyle(1).setRequired(true).setMaxLength(500)
                )
            );
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit?.() && customId === 'zcloudManagerUrlSubmit') {
            const raw = interaction.fields.getTextInputValue('url').trim();
            const clean = zcloudControl.cleanBase(raw);
            if (!clean) return interaction.reply({ content:'Informe uma URL HTTPS pública válida. Localhost e IP local não são aceitos.', flags:MessageFlags.Ephemeral });
            zcloudControl.save({ publicBaseUrl: clean });
            await require('../../source/runtime').syncZcloudFeatureForAll().catch(() => []);
            return interaction.reply({ content:`URL pública do ZCloud salva. As instâncias Zenyx usarão o Reverse Proxy do Manager.`, flags:MessageFlags.Ephemeral });
        }

        if (customId === "sistemaOnOff") {

            const sistema = await logs.get("sistema");

            if (sistema) {
                await logs.set("sistema", false);
            } else {
                await logs.set("sistema", true);
            };

            await inicio();

        };

        if (customId === "channelsRolesEdit") {
            await channelsRolesEdit();
        };

        if (customId === "back") {
            await inicio();
        };

        if (customId === "selectChannelEdit") {

            const option = interaction.values[0];

            if (option === "logsEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectLogsEdit`)
                                    .setPlaceholder(`📫 Selecionar canal de texto`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

            if (option === "renovEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectRenovEdit`)
                                    .setPlaceholder(`📫 Selecionar canal de texto`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

            if (option === "vendasEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectVendasEdit`)
                                    .setPlaceholder(`📫 Selecionar canal de texto`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

            if (option === "backupEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectBackupEdit`)
                                    .setPlaceholder(`📫 Selecionar canal de texto`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

            if (option === "hospedagemEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectHospedagemEdit`)
                                    .setPlaceholder(`🚀 Selecionar canal de logs de hospedagem`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

            if (option === "vencidosEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ChannelSelectMenuBuilder()
                                    .setCustomId(`selectVencidosEdit`)
                                    .setPlaceholder(`⚠️ Selecionar canal de logs de vencidos`)
                                    .setChannelTypes(ChannelType.GuildText)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

        };

        if (customId === "selectLogsEdit") {

            const channel = interaction.values[0];

            await logs.set("channel_logs", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectRenovEdit") {

            const channel = interaction.values[0];

            await logs.set("renov", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectVendasEdit") {

            const channel = interaction.values[0];

            await logs.set("vendas", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectBackupEdit") {

            const channel = interaction.values[0];

            await logs.set("logs_backup", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectHospedagemEdit") {

            const channel = interaction.values[0];

            await logs.set("logs_hospedagem", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectVencidosEdit") {

            const channel = interaction.values[0];

            await logs.set("logs_vencidos", channel);
            await channelsRolesEdit();

        };

        if (customId === "selectRolesEdit") {

            const option = interaction.values[0];

            if (option === "clientEdit") {

                await interaction.update({
                    content: ``,
                    embeds: [],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new RoleSelectMenuBuilder()
                                    .setCustomId(`selectClientEdit`)
                                    .setPlaceholder(`⚡ Selecionar cargo existente`)
                            ),
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId(`channelsRolesEdit`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });

            };

        };

        if (customId === "selectClientEdit") {

            const role = interaction.values[0];

            await logs.set("cargo_client", role);
            await channelsRolesEdit();

        };

        if (customId === "gerenciarApps") {
            await gerenciarApps();
        };

        if (customId === "createBotAluguel") {

            const modal = new ModalBuilder()
                .setCustomId("modal_criar_bot")
                .setTitle(`Novo Aluguel Bot`);

            const text = new TextInputBuilder()
                .setLabel("Nome do Bot (ALUGUEL)")
                .setPlaceholder("Ex: Vendas / Ticket / OAuth2")
                .setRequired(true)
                .setStyle(ButtonStyle.Secondary)
                .setCustomId("text");

            const text1 = new TextInputBuilder()
                .setCustomId("text1")
                .setStyle(ButtonStyle.Secondary)
                .setLabel("Arquivo Principal")
                .setPlaceholder("Ex: index.js / main.js / bot.py")
                .setRequired(true)

            const textx = new ActionRowBuilder().addComponents(text);
            const textx1 = new ActionRowBuilder().addComponents(text1);

            modal.addComponents(textx, textx1);
            await interaction.showModal(modal);

        };


        if (customId === "modal_criar_bot") {
            const nome = interaction.fields.getTextInputValue("text");
            const principal = interaction.fields.getTextInputValue("text1");

            if (db.get(`${nome}`) === nome) {
                return interaction.reply({ content: `\`❌\` Ops... Já existe um bot aluguel com este nome!`, ephemeral: true });
            };

            const msg = await interaction.update({
                content: `${interaction.user}`,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Enviar Arquivo Bot (ALUGUEL)`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`📁\` Coletando arquivo **.zip**!`)
                        .addFields(
                            { name: `Formatação`, value: `\`.zip\``, inline: true },
                            { name: `Necessário`, value: `\`package.json\` ou \`camposcloud.config\`; Python: \`bot.py\` + \`requirements.txt\``, inline: true }
                        )
                        .setColor(`#FFFF00`)
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: []
            });

            const collector = interaction.channel.createMessageCollector({
                filter: m => m.author.id === interaction.user.id && m.attachments.first() && m.attachments.first().name.toLowerCase().endsWith('.zip'),
                max: 1,
                time: 120000,
            });

            collector.on('end', (collected, reason) => {
                if (!collected.size && reason === 'time') msg.edit({ content: '⌛ Tempo esgotado. Execute o cadastro novamente e envie o ZIP em até 2 minutos.', embeds: [], components: [] }).catch(() => null);
            });

            const processUpload = async (message) => {
                const attachment = message.attachments.first();
                try {
                const zip = new JSZip();

                const data = await fetch(attachment.url).then(async res => {
                    if (!res.ok) throw new Error(`Falha ao baixar o anexo (HTTP ${res.status}).`);
                    return res.arrayBuffer();
                });
                const zipFile = await zip.loadAsync(data);

                msg.edit({
                    content: `\`🔄️\` Aguarde... Estamos verificando o arquivo enviado!`,
                    embeds: [],
                    components: []
                });

                const packageFile = zipFile.file('package.json');
                const configFileName = ['camposcloud.config', 'squarecloud.config', 'squarecloud.app']
                    .find(name => Boolean(zipFile.file(name)));
                const hasPythonEntry = Boolean(zipFile.file(principal)) && /\.py$/i.test(principal);
                if (!packageFile && !configFileName && !hasPythonEntry) {
                    throw new Error('ZIP sem formato reconhecido. Inclua package.json, camposcloud.config ou o arquivo principal Python (bot.py).');
                }
                if (packageFile) {
                    let packageJson;
                    try { packageJson = JSON.parse(await packageFile.async('string')); }
                    catch { throw new Error('package.json inválido.'); }
                    packageJson.main = principal;
                    zipFile.file('package.json', JSON.stringify(packageJson, null, 2));
                } else if (configFileName) {
                    const current = await zipFile.file(configFileName).async('string');
                    const lines = current.split(/\r?\n/).filter(Boolean);
                    let changed = false;
                    const next = lines.map(line => {
                        if (/^MAIN\s*=/.test(line)) { changed = true; return `MAIN=${principal}`; }
                        return line;
                    });
                    if (!changed) next.push(`MAIN=${principal}`);
                    zipFile.file(configFileName, `${next.join('\n')}\n`);
                }

                const dir = './source';
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir);
                };

                fs.writeFileSync(`${dir}/${nome}.zip`, await zipFile.generateAsync({ type: "nodebuffer" }))

                db.set(`${nome}`, {
                    nomeproduto: nome,
                    type: "embed",
                    preco: {
                        anual: {
                            onoff: true,
                            preco: 10,
                        },
                        mensal: {
                            onoff: true,
                            preco: 5
                        },
                        trimensal: {
                            onoff: true,
                            preco: 8.50
                        },
                        embed: {
                            cor: "Default",
                            titulo: `${nome}`,
                            desc: `👋 Olá, está preparado para uma esperiencia inovadora com o bot da **${interaction.guild.name}**? Clique no botão abaixo agora e adquira nosso bot **${nome}**`
                        },
                        content: {
                            content: `# ${nome}\n\n👋 Olá, está preparado para uma esperiencia inovadora com o bot da **${interaction.guild.name}**? Clique no botão abaixo agora e adquira nosso bot **${nome}**`
                        }
                    },
                    banner: null,
                    link: "remover"
                });

                msg.edit({
                    content: `${interaction.user}`,
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `${interaction.user.username} - Sucesso no envio`, iconURL: interaction.user.displayAvatarURL() })
                            .setDescription(`-# \`✅\` O bot aluguel foi criado com êxito!`)
                            .addFields(
                                { name: `Bot Aluguel`, value: `\`${nome}\``, inline: true },
                                { name: `Útil`, value: `\`/alugueis\``, inline: true }
                            )
                            .setColor(`#00FF00`)
                            
                            .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setCustomId("gerenciarApps").setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                            )
                    ]
                });
                } catch (error) {
                    collector.stop('error');
                    await msg.edit({ content: `❌ Erro ao processar o ZIP: ${String(error?.message || error).slice(0, 700)}`, embeds: [], components: [] }).catch(() => null);
                }
            };
            collector.on('collect', processUpload);
            const recent = await interaction.channel.messages.fetch({ limit: 25 }).catch(() => null);
            const previousUpload = recent?.filter(message => message.author.id === interaction.user.id && [...message.attachments.values()].some(file => file.name?.toLowerCase().endsWith('.zip')))
                .sort((a, b) => b.createdTimestamp - a.createdTimestamp).first();
            if (previousUpload) {
                collector.stop('previous-upload');
                await processUpload(previousUpload);
            }

        };

        if (customId === "removeAluguel") {

            const modal = new ModalBuilder()
                .setCustomId(`modalRemAluguel`)
                .setTitle(`Remover Aluguel`)

            const option1 = new TextInputBuilder()
                .setCustomId(`aluguel`)
                .setLabel(`QUAL O NOME DO BOT ALUGUEL A REMOVER?`)
                .setPlaceholder(`Ex: Vendas / Ticket / OAuth2`)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);

            modal.addComponents(optionx1);
            await interaction.showModal(modal);

        };

        if (customId === "modalRemAluguel") {
            const aluguel = interaction.fields.getTextInputValue("aluguel");

            if (!db.get(aluguel)) {
                return interaction.reply({ content: `\`❌\` Ops... Não existe nenhum bot aluguel com este nome no banco de dados.`, ephemeral: true });
            };

            await db.delete(aluguel);
            await gerenciarApps();

        };

        if (customId === "diversesAluguel") {

            await interaction.reply({
                content: ``,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`gerenciamentDev`).setLabel(`Gerenciamento`).setEmoji(`💳`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`deleteAppUser`).setLabel(`Deletar Aplicação`).setEmoji(`➕`).setStyle(ButtonStyle.Secondary)
                        )
                ],
                ephemeral: true
            });

        };

        if (customId === "gerenciamentDev") {
            await gerenciamentDev();
        };

        if (customId === "backD") {
            await diversesAluguel();
        };

        if (customId === "deleteAppUser") {

            if (db2.all().length <= 0) {
                return interaction.reply({ content: `\`❌\` Não existe nenhuma aplicação existente no momento.`, ephemeral: true });
            };

            if (db2.all().length > 25) {

                const modal = new ModalBuilder()
                    .setCustomId(`modalDeleteApp`)
                    .setTitle(`Deletar Aplicação`)

                const option1 = new TextInputBuilder()
                    .setCustomId(`appid`)
                    .setLabel(`QUAL O APP-ID A DELETAR?`)
                    .setPlaceholder(`APP-ID AQUI`)
                    .setStyle(1)

                const optionx1 = new ActionRowBuilder().addComponents(option1);

                modal.addComponents(optionx1);
                await interaction.showModal(modal);

                return;

            };

            const select = new StringSelectMenuBuilder()
                .setCustomId(`selectMenuDeleteApp`)
                .setPlaceholder(`🔎 Deletar Aplicação`)

            for (const apps of db2.all()) {
                const app = apps.data;

                const option = {
                    label: `${app.nome}`,
                    description: `APP-ID: ${app.idapp}`,
                    value: app.idapp,
                    emoji: '🤖'
                };

                select.addOptions(option);
            };

            await interaction.update({
                content: ``,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(select),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`backD`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        if (customId === "selectMenuDeleteApp") {
            const appid = interaction.values[0];
            try {
                const record = await deleteManagedApp(appid);
                return interaction.update({ content: `Aplicação **${record.nome || appid}** removida do runtime e do Manager.`, embeds: [], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('backD').setLabel('Voltar').setStyle(2))] });
            } catch (error) {
                return interaction.reply({ content: `Não foi possível excluir a aplicação: ${String(error?.message || error).slice(0,700)}`, flags: 64 });
            }
        };

        if (customId === "modalDeleteApp") {
            const appid = interaction.fields.getTextInputValue("appid").trim();
            try {
                const record = await deleteManagedApp(appid);
                return interaction.reply({ content: `Aplicação **${record.nome || appid}** removida do runtime e do Manager.`, flags: 64 });
            } catch (error) {
                return interaction.reply({ content: `Não foi possível excluir a aplicação: ${String(error?.message || error).slice(0,700)}`, flags: 64 });
            }
        };

        if (customId === "definitions") {
            await interaction.update({
                content: `**PAINEL MANAGER V2**\nSeja bem vindo ao Painel de controle do Manager! Oque deseja fazer hoje?.`,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`apiConfig`).setLabel(`Hospedagem`).setEmoji(id(readCache(interaction.guildId),'cloud','☁️')).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`moderationConfig`).setLabel(`Moderação`).setEmoji(id(readCache(interaction.guildId),'moderation','🛡️')).setStyle(ButtonStyle.Secondary).setDisabled(false)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`automationConfig`).setLabel(`Automação`).setEmoji(id(readCache(interaction.guildId),'automation','🤖')).setDisabled(false).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`paymentsConfig`).setLabel(`ChaveRecibo`).setEmoji(id(readCache(interaction.guildId),'receipt','🧾')).setStyle(ButtonStyle.Secondary)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`back`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });
        }

        if (customId === 'moderationConfig') {
            const em = readCache(interaction.guildId);
            const antiRaidFile = require('path').join(__dirname, '../../Functions/antiRaidHandler.js');
            const antiRaidLoaded = fs.existsSync(antiRaidFile);
            const delegated = (() => { try { return Object.keys(JSON.parse(fs.readFileSync(require('path').join(__dirname,'../../databases/perms.json'),'utf8')) || {}).length; } catch { return 0; } })();
            const eb = (key, cid, label) => { const b = new ButtonBuilder().setCustomId(cid).setLabel(label).setStyle(ButtonStyle.Secondary); const eid = id(em,key,null); if (eid) b.setEmoji(eid); return b; };
            return interaction.update({
                content: '',
                embeds: [new EmbedBuilder()
                    .setTitle(`${fmt(em,'moderation')} ASTRA APPLICATION • CENTRAL DE MODERAÇÃO`)
                    .setDescription('Área administrativa para segurança do Manager e manutenção do servidor. As ações sensíveis continuam restritas ao proprietário/delegados autorizados.')
                    .addFields(
                        { name:'Proteção anti-raid', value:`**${antiRaidLoaded ? 'Carregada' : 'Indisponível'}** • monitora criação/remoção anormal de canais.`, inline:false },
                        { name:'Antigolpe', value:`**${logs.get('antiScam.enabled') === false ? 'Desativado' : 'Ativado'}** • quando ativo, o Manager pode apagar mensagens classificadas como golpe/link suspeito.`, inline:false },
                        { name:'Delegações', value:`**${delegated}** registro(s) de permissão administrativa.`, inline:true },
                        { name:'Ações disponíveis', value:'Use os comandos administrativos de mute, nuke, cargos e permissões; os atalhos abaixo levam às áreas de configuração relacionadas.', inline:false }
                    ).setColor('#5865F2').setTimestamp()],
                components: [
                    new ActionRowBuilder().addComponents(eb('channels','channelsRolesEdit','Canais e cargos'), eb('lock','managerDiagnostics','Diagnóstico de segurança')),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('antiScamToggle').setLabel(logs.get('antiScam.enabled') === false ? 'Ativar filtro de mensagens' : 'Desativar filtro de mensagens').setStyle(logs.get('antiScam.enabled') === false ? ButtonStyle.Success : ButtonStyle.Danger),
                        eb('back','back','Voltar')
                    )
                ]
            });
        }

        if (customId === 'autoMsgPanel') {
            const config = await logs.get('autoMsg');
            let desc = '';
            if (config) {
                desc = `**Canal:** <#${config.canalId}>
**Mensagem:** ${config.mensagem}
**Intervalo:** ${config.intervalo} minuto(s)`;
            } else {
                desc = 'Nenhuma mensagem automática configurada.';
            }
            return interaction.update({
                content: '',
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciar Mensagem Automática`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(desc)
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('editAutoMsgChannel').setLabel('Editar Canal').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('editAutoMsgMsg').setLabel('Editar Mensagem').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('editAutoMsgInterval').setLabel('Editar Intervalo').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('deleteAutoMsg').setLabel('Deletar').setStyle(ButtonStyle.Secondary).setDisabled(!config)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('automationConfig').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }

        if (customId === 'editAutoMsgChannel') {
            const modal = new ModalBuilder()
                .setCustomId('modalEditAutoMsgChannel')
                .setTitle('Editar Canal da Mensagem Automática');
            const canalInput = new TextInputBuilder()
                .setCustomId('canalId')
                .setLabel('ID do Canal')
                .setPlaceholder('Ex: 123456789012345678')
                .setRequired(true)
                .setStyle(ButtonStyle.Secondary);
            modal.addComponents(new ActionRowBuilder().addComponents(canalInput));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit() && interaction.customId === 'modalEditAutoMsgChannel') {
            const canalId = interaction.fields.getTextInputValue('canalId');
            const config = await logs.get('autoMsg') || {};
            config.canalId = canalId;
            await logs.set('autoMsg', config);
            return interaction.reply({ content: 'Canal atualizado com sucesso!', ephemeral: true });
        }

        if (customId === 'editAutoMsgMsg') {
            const modal = new ModalBuilder()
                .setCustomId('modalEditAutoMsgMsg')
                .setTitle('Editar Mensagem Automática');
            const msgInput = new TextInputBuilder()
                .setCustomId('mensagem')
                .setLabel('Mensagem')
                .setRequired(true)
                .setStyle(2);
            modal.addComponents(new ActionRowBuilder().addComponents(msgInput));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit() && interaction.customId === 'modalEditAutoMsgMsg') {
            const mensagem = interaction.fields.getTextInputValue('mensagem');
            const config = await logs.get('autoMsg') || {};
            config.mensagem = mensagem;
            await logs.set('autoMsg', config);
            return interaction.reply({ content: 'Mensagem atualizada com sucesso!', ephemeral: true });
        }

        if (customId === 'editAutoMsgInterval') {
            const modal = new ModalBuilder()
                .setCustomId('modalEditAutoMsgInterval')
                .setTitle('Editar Intervalo da Mensagem Automática');
            const intervaloInput = new TextInputBuilder()
                .setCustomId('intervalo')
                .setLabel('Intervalo (minutos)')
                .setPlaceholder('Ex: 60')
                .setRequired(true)
                .setStyle(ButtonStyle.Secondary);
            modal.addComponents(new ActionRowBuilder().addComponents(intervaloInput));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit() && interaction.customId === 'modalEditAutoMsgInterval') {
            const intervalo = parseInt(interaction.fields.getTextInputValue('intervalo'));
            if (isNaN(intervalo) || intervalo < 1) {
                return interaction.reply({ content: 'Intervalo inválido!', ephemeral: true });
            }
            const config = await logs.get('autoMsg') || {};
            config.intervalo = intervalo;
            await logs.set('autoMsg', config);
            return interaction.reply({ content: 'Intervalo atualizado com sucesso!', ephemeral: true });
        }

        if (customId === 'deleteAutoMsg') {
            await logs.set('autoMsg', null);
            await logs.set('autoMsgLastId', null);
            return interaction.update({
                content: 'Mensagem automática deletada com sucesso!',
                embeds: [],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('automationConfig').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }


        if (customId === 'checkoutReviewers') {
            return interaction.update(checkoutReviewersView(interaction));
        }
        if (customId === 'checkoutReviewersSelect' && interaction.isUserSelectMenu?.()) {
            // Salva e responde ANTES de qualquer chamada REST. A sincronização dos
            // tópicos acontece em segundo plano para nunca deixar a interação presa.
            await interaction.deferUpdate();
            const previous = purchaseReviewers.list();
            const selected = purchaseReviewers.set(interaction.values || []);
            const removedIds = previous.filter(userId => !selected.includes(userId));
            const payload = checkoutReviewersView(interaction);
            if (payload.components?.[0]?.addTextDisplayComponents) payload.components[0].addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`-# Configuração salva imediatamente • ${selected.length} supervisor(es). Aplicando aos tópicos abertos em segundo plano.`)
            );
            await interaction.editReply(payload);
            setImmediate(() => purchaseReviewers.syncOpenThreads(interaction.guild, { removeIds: removedIds }).catch(error => console.warn('[ZENYX REVIEWERS] sync:', error?.message || error)));
            return;
        }
        if (customId === 'checkoutReviewersAddOwner') {
            const ownerId = require('../../Lib/permissions').ownerId();
            if (!ownerId) return interaction.reply({ content: 'Não foi possível identificar o proprietário configurado do Manager.', flags: MessageFlags.Ephemeral });
            await interaction.deferUpdate();
            const selected = purchaseReviewers.set([...purchaseReviewers.list(), ownerId]);
            const payload = checkoutReviewersView(interaction);
            if (payload.components?.[0]?.addTextDisplayComponents) payload.components[0].addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`-# Proprietário incluído • ${selected.length} supervisor(es). Acesso aos tópicos sendo aplicado em segundo plano.`)
            );
            await interaction.editReply(payload);
            setImmediate(() => purchaseReviewers.syncOpenThreads(interaction.guild).catch(error => console.warn('[ZENYX REVIEWERS] owner sync:', error?.message || error)));
            return;
        }
        if (customId === 'checkoutReviewersClear') {
            await interaction.deferUpdate();
            const previous = purchaseReviewers.list();
            purchaseReviewers.clear();
            await interaction.editReply(checkoutReviewersView(interaction));
            setImmediate(() => purchaseReviewers.syncOpenThreads(interaction.guild, { removeIds: previous }).catch(error => console.warn('[ZENYX REVIEWERS] clear sync:', error?.message || error)));
            return;
        }
        if (customId === 'checkoutReviewersSync') {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            await interaction.editReply({ content: 'Sincronização iniciada. Você pode continuar usando o painel normalmente.' });
            setImmediate(async () => {
              const result = await purchaseReviewers.syncOpenThreads(interaction.guild).catch(() => ({ touched: 0, added: 0, removed: 0, failed: 1 }));
              await interaction.followUp({ content: `Equipe sincronizada em **${result.touched}** tópico(s). Acessos adicionados: **${result.added}**${result.failed ? ` • falhas isoladas: **${result.failed}**` : ''}.`, flags: MessageFlags.Ephemeral }).catch(() => null);
            });
            return;
        }

        if (customId === 'linkedBotsView') {
            const rows = db2.all().map((row) => ({ id: row.ID, ...(row.data || {}) }));
            const lines = rows.slice(0, 20).map((app, index) => {
                const expMs = Date.parse(app.dataExpiracao || '');
                const validity = Number.isFinite(expMs) ? `<t:${Math.floor(expMs/1000)}:R>` : 'sem validade';
                const status = String(app.status || 'online').toLowerCase();
                return `**${index+1}. ${String(app.nome || 'Aplicação').slice(0,50)}**
` +
                  `Dono: <@${app.owner}> • Client ID: \`${app.childClientId || 'não registrado'}\`
` +
                  `Runtime: \`${app.idapp || app.id}\` • Status: **${status}** • ${validity}`;
            });
            const container = new ContainerBuilder().setAccentColor(0x3155ff)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## Bots vinculados
-# ${rows.length} aplicação(ões) registrada(s) no Manager

${lines.join('\n\n') || 'Nenhum bot foi vinculado ainda.'}`))
              .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
              .addActionRowComponents(new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('linkedBotsView').setLabel('Atualizar').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('gerenciarApps').setLabel('Gerenciar apps').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('managerRefresh').setLabel('Voltar').setStyle(ButtonStyle.Secondary)
              ));
            const payload = { components:[container], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) return interaction.editReply({components:[container]});
            if (interaction.isButton?.()) return interaction.update({components:[container]});
            return interaction.reply(payload);
        }

        if (customId === 'selectGerenciamentDev') {
            const action = interaction.values?.[0];
            const allowed = new Set(['ligarBotGrc','reiniciarBotGrc','desligarBotGrc','statusBotGrc']);
            if (!allowed.has(action)) return interaction.reply({ content:'Ação de runtime inválida.', flags:64 });
            const modal = new ModalBuilder().setCustomId(`devAction:${action}`).setTitle('ASTRA APPLICATION • Runtime da aplicação');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('appid').setLabel('ID TÉCNICO DA APLICAÇÃO').setPlaceholder('Ex: sh_ab12cd34ef56').setStyle(1).setRequired(true).setMaxLength(80)));
            return interaction.showModal(modal);
        }

        if (interaction.isModalSubmit?.() && customId.startsWith('devAction:')) {
            const action = customId.split(':')[1];
            const appid = interaction.fields.getTextInputValue('appid').trim();
            const record = db2.get(appid);
            if (!record) return interaction.reply({ content:'Aplicação não encontrada no Manager.', flags:64 });
            await interaction.deferReply({ flags:64 });
            try {
                const app = await new SquareCloudAPI(api.get('square')).applications.get(appid);
                if (action === 'ligarBotGrc') { const r=await app.start(); return interaction.editReply({ content:`Aplicação **${record.nome || appid}** iniciada. ${r?.pid ? `PID: \`${r.pid}\`` : ''}` }); }
                if (action === 'reiniciarBotGrc') { const r=await app.restart(); if (r && typeof r.then === 'function') await r; return interaction.editReply({ content:`Aplicação **${record.nome || appid}** reiniciada.` }); }
                if (action === 'desligarBotGrc') { await app.stop(); return interaction.editReply({ content:`Aplicação **${record.nome || appid}** desligada.` }); }
                const st = await app.getStatus();
                return interaction.editReply({ content:`**${record.nome || 'Aplicação'}**
Status: **${st.status || 'desconhecido'}**
PID: \`${st.pid || 0}\`
Uptime base: <t:${Math.floor((st.uptimeTimestamp || Date.now())/1000)}:R>` });
            } catch (error) {
                console.error(`[ZENYX DEV] ${action} ${appid}:`, error?.message || error);
                return interaction.editReply({ content:`Não foi possível executar a ação: ${String(error?.message || error).slice(0,700)}` });
            }
        }

        if (customId === 'consoleBotGrc') {
            const modal = new ModalBuilder().setCustomId('devConsoleSubmit').setTitle('ASTRA APPLICATION • Logs da aplicação');
            modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('appid').setLabel('ID TÉCNICO DA APLICAÇÃO').setPlaceholder('Ex: sh_ab12cd34ef56').setStyle(1).setRequired(true).setMaxLength(80)));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit?.() && customId === 'devConsoleSubmit') {
            const appid = interaction.fields.getTextInputValue('appid').trim();
            const record = db2.get(appid);
            if (!record) return interaction.reply({ content:'Aplicação não encontrada no Manager.', flags:64 });
            await interaction.deferReply({ flags:64 });
            try {
                const app = await new SquareCloudAPI(api.get('square')).applications.get(appid);
                const raw = String(await app.getLogs() || 'Sem logs.');
                const safe = raw.replace(/```/g, '\`\`\`').slice(-1800);
                return interaction.editReply({ content:`**ASTRA APPLICATION • LOGS • ${record.nome || appid}**
\`\`\`text
${safe}
\`\`\`` });
            } catch (error) {
                return interaction.editReply({ content:`Não foi possível ler os logs: ${String(error?.message || error).slice(0,700)}` });
            }
        }

        if (customId === "apiConfig") {
            await apiConfig();
        };

        if (customId === "editApiSquare") {

            const modal = new ModalBuilder()
                .setCustomId(`modalEditSquare`)
                .setTitle(`Alterar Key Api`)

            const option1 = new TextInputBuilder()
                .setCustomId(`keyApi`)
                .setLabel(`QUAL SUA KEY API SQUARECLOUD?`)
                .setPlaceholder(`YOU KEY API SQUARECLOUD HERE`)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);

            modal.addComponents(optionx1);
            await interaction.showModal(modal);

        };

        if (customId === "modalEditSquare") {
            const keyApi = interaction.fields.getTextInputValue("keyApi");

            const apiInstance = new SquareCloudAPI(keyApi);

            try {

                await apiInstance.users.get();

                await api.set("square", keyApi);
                await apiConfig();

            } catch (error) {

                await interaction.reply({
                    content: `\`❌\` A chave da API SquareCloud é inválida. Por favor, verifique e tente novamente.`,
                    ephemeral: true
                });

            };

        };

        if (customId === "paymentsConfig") {
            await paymentsConfig();
        };

        if (customId === "evopayConfig") {
            await evopayConfig();
        };

        if (customId === "evopaySetToken") {
            const modal = new ModalBuilder().setCustomId("evopayTokenModal").setTitle("EvoPay • Token Bearer");
            modal.addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId("token").setLabel("TOKEN DA EVOPAY").setPlaceholder("Cole o token Bearer da API").setStyle(1).setRequired(true).setMaxLength(1000)
            ));
            return interaction.showModal(modal);
        };

        if (customId === "evopayTokenModal" && interaction.isModalSubmit?.()) {
            const token = interaction.fields.getTextInputValue("token").trim();
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            try {
                await evopay.testCredentials(token);
                await api.set("evopay.token", token);
                await api.set("evopay.enabled", true);
                return interaction.editReply("EvoPay configurada e ativada. O token foi aceito pela API.");
            } catch (error) {
                return interaction.editReply(`Não foi possível validar o token EvoPay: ${String(error?.message || error).slice(0, 500)}`);
            }
        };

        if (customId === "evopayToggle") {
            const current = evopay.settings();
            if (!current.enabled && !current.token) return interaction.reply({ content: "Configure o token EvoPay antes de ativar.", flags: MessageFlags.Ephemeral });
            await api.set("evopay.enabled", !current.enabled);
            return evopayConfig();
        };

        if (customId === "evopayTest") {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            try { await evopay.testCredentials(); return interaction.editReply("Conexão EvoPay validada com sucesso."); }
            catch (error) { return interaction.editReply(`Falha no teste EvoPay: ${String(error?.message || error).slice(0, 500)}`); }
        };

        if (customId === "evopaySetExpiry") {
            const modal = new ModalBuilder().setCustomId("evopayExpiryModal").setTitle("EvoPay • Validade do PIX");
            modal.addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId("seconds").setLabel("EXPIRA EM QUANTOS SEGUNDOS?").setPlaceholder("900").setStyle(1).setRequired(true).setMaxLength(5)
            ));
            return interaction.showModal(modal);
        };

        if (customId === "evopayExpiryModal" && interaction.isModalSubmit?.()) {
            const seconds = Number(interaction.fields.getTextInputValue("seconds"));
            if (!Number.isInteger(seconds) || seconds < 180 || seconds > 7200) return interaction.reply({ content: "Use um valor entre 180 e 7200 segundos.", flags: MessageFlags.Ephemeral });
            await api.set("evopay.expiresIn", seconds);
            return interaction.reply({ content: `Validade das cobranças EvoPay alterada para **${seconds} segundos**.`, flags: MessageFlags.Ephemeral });
        };

        if (customId === "childBioConfig") {
            const current = childBioControl.bio();
            const modal = new ModalBuilder().setCustomId('childBioModal').setTitle('Bio global • bots de vendas');
            const field = new TextInputBuilder().setCustomId('childBioText').setLabel('Bio usada por todos os bots filhos').setStyle(2).setRequired(false).setMaxLength(400).setPlaceholder('Deixe vazio para voltar à Bio institucional padrão.');
            if (current) field.setValue(current);
            modal.addComponents(new ActionRowBuilder().addComponents(field));
            return interaction.showModal(modal);
        }
        if (customId === "childBioModal" && interaction.isModalSubmit?.()) {
            const value = String(interaction.fields.getTextInputValue('childBioText') || '').trim().slice(0,400);
            childBioControl.save(value);
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            const result = await childBioControl.applyAll();
            return interaction.editReply({ content: `${value ? '✅ Bio global salva.' : '✅ Bio global personalizada removida; novos boots usarão o padrão ZENYX.'} Aplicada agora em ${result.applied || 0} bot(s) • falhas ${result.failed || 0}. Os runtimes oficiais também receberão essa configuração no próximo start/restart.` });
        }
        if (customId === "magnusGlobalToggle") {
            const next = magnusControl.toggle(interaction.user.id);
            try {
                const synced = await require('../../source/runtime').syncMagnusFeatureForAll({ restartOnline: false });
                const failed = synced.filter(item => !item.ok).length;
                console.log(`[MAGNUSPAY] Disponibilidade global ${next.enabled ? 'ativada' : 'desativada'}; runtimes sincronizados=${synced.length - failed}/${synced.length}.`);
            } catch (error) {
                console.log(`[MAGNUSPAY] Falha ao sincronizar flag global: ${String(error?.message || error).slice(0,240)}`);
            }
            return interaction.update(require('../../Lib/botconfigPages').pagePayload(client, interaction, 2, { forUpdate: true }));
        };

        if (customId === "vyvenceConfig") return externalGatewayConfig("vyvence");
        if (customId === "magnusConfig") return externalGatewayConfig("magnus");
        if (customId === "promisseConfig") return externalGatewayConfig("promisse");

        if (customId === "vyvenceSet") return externalGatewayModal("vyvence");
        if (customId === "magnusSet") return externalGatewayModal("magnus");
        if (customId === "promisseSet") return externalGatewayModal("promisse");

        if ((customId === "vyvenceModal" || customId === "magnusModal" || customId === "promisseModal") && interaction.isModalSubmit?.()) {
            const provider = customId === "vyvenceModal" ? "vyvence" : (customId === "magnusModal" ? "magnus" : "promisse");
            const current = externalPix.settings(provider);
            try {
                const values = provider === 'promisse'
                    ? { token: interaction.fields.getTextInputValue("token") }
                    : {
                        baseUrl: interaction.fields.getTextInputValue("baseUrl"),
                        token: interaction.fields.getTextInputValue("token"),
                        createPath: interaction.fields.getTextInputValue("createPath"),
                        statusPath: interaction.fields.getTextInputValue("statusPath"),
                        authSpec: interaction.fields.getTextInputValue("authSpec") || current.authSpec
                    };
                const next = externalPix.save(provider, values);
                return interaction.reply({
                    content: `✅ **${next.label}** salva. Use **Testar conexão** e depois **Ativar**.`,
                    flags: MessageFlags.Ephemeral
                });
            } catch (error) {
                return interaction.reply({ content: `❌ Não foi possível salvar: ${String(error?.message || error).slice(0, 700)}`, flags: MessageFlags.Ephemeral });
            }
        };

        if (customId === "vyvenceToggle" || customId === "magnusToggle") {
            const provider = customId === "vyvenceToggle" ? "vyvence" : "magnus";
            const current = externalPix.settings(provider);
            const hasConfig = Boolean(current.baseUrl && current.token && current.createPath && current.statusPath);
            if (!current.enabled && !hasConfig) return interaction.reply({ content: `Configure URL, token e rotas da **${current.label}** antes de ativar.`, flags: MessageFlags.Ephemeral });
            externalPix.save(provider, { enabled: !current.enabled });
            return externalGatewayConfig(provider);
        };

        if (customId === "promisseToggle") {
            const current = externalPix.settings('promisse');
            if (!current.enabled && !current.token) return interaction.reply({ content: 'Configure a API key da PromissePay antes de ativar.', flags: MessageFlags.Ephemeral });
            externalPix.save('promisse', { enabled: !current.enabled });
            return externalGatewayConfig('promisse');
        };

        if (customId === "vyvenceTest" || customId === "magnusTest" || customId === "promisseTest") {
            const provider = customId === "vyvenceTest" ? "vyvence" : (customId === "magnusTest" ? "magnus" : "promisse");
            const label = externalPix.settings(provider).label;
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            try {
                await externalPix.testConnection(provider);
                return interaction.editReply(`✅ Conexão **${label}** respondeu sem erro de autenticação.`);
            } catch (error) {
                return interaction.editReply(`❌ Falha no teste **${label}**: ${String(error?.message || error).slice(0, 700)}`);
            }
        };

        if (customId === "automaticConfig") {
            await automaticConfig();
        };

        if (customId === "nubankImapConfig") {
            await nubankImapConfig();
        };

        if (customId === "configureNubankImap") {
            const current = await getStoredConfig();
            const modal = new ModalBuilder().setCustomId("modalNubankImap").setTitle("Inter IMAP • E-mail");
            const fields = [
                new TextInputBuilder().setCustomId("imapUser").setLabel("E-MAIL QUE RECEBE OS AVISOS DO INTER").setValue(current.user || "").setPlaceholder("seuemail@gmail.com").setStyle(1).setRequired(true),
                new TextInputBuilder().setCustomId("imapPass").setLabel("SENHA DE APLICATIVO DO E-MAIL").setPlaceholder(current.pass ? "Deixe vazio para manter a senha já salva" : "Senha de aplicativo do seu provedor de e-mail").setStyle(1).setRequired(!current.pass),
                new TextInputBuilder().setCustomId("imapHost").setLabel("HOST IMAP (OPCIONAL)").setPlaceholder("Automático pelo e-mail • ex: imap.gmail.com").setStyle(1).setRequired(false),
                new TextInputBuilder().setCustomId("imapInterval").setLabel("INTERVALO EM SEGUNDOS (MÍNIMO 15)").setValue(String(Math.round((current.intervalMs || 30000) / 1000))).setPlaceholder("30").setStyle(1).setRequired(true)
            ];
            modal.addComponents(...fields.map(field => new ActionRowBuilder().addComponents(field)));
            await interaction.showModal(modal);
        };

        if (customId === "modalNubankImap") {
            const intervalSeconds = Number(interaction.fields.getTextInputValue("imapInterval"));
            if (!Number.isFinite(intervalSeconds) || intervalSeconds < 15 || intervalSeconds > 3600) {
                return interaction.reply({ content: "`❌` O intervalo deve ser um número entre 15 e 3600 segundos.", ephemeral: true });
            }
            const previous = await getStoredConfig();
            const user = interaction.fields.getTextInputValue("imapUser").trim();
            const explicitHost = interaction.fields.getTextInputValue("imapHost").trim();
            const provider = inferImapProvider(user, explicitHost);
            if (!provider.host) {
                return interaction.reply({ content: "`❌` Esse provedor não oferece IMAP direto compatível. Use uma caixa Gmail, Outlook/Hotmail, Yahoo, iCloud ou informe um host IMAP válido.", ephemeral: true });
            }
            const typedPass = interaction.fields.getTextInputValue("imapPass");
            const rawPass = typedPass.trim() ? typedPass : previous.pass;
            const config = {
                ...previous,
                enabled: false,
                bankLabel: 'Banco Inter',
                host: provider.host,
                port: provider.port || 993,
                secure: provider.secure !== false,
                providerLabel: provider.label,
                user,
                pass: normalizeImapPassword(provider.host, rawPass),
                mailbox: "INBOX",
                intervalMs: intervalSeconds * 1000,
                allowedFrom: interSenderDefaults(['inter.co', 'bancointer.com.br']),
                hostManual: Boolean(explicitHost),
                lastTestOk: false,
                lastTestAt: Date.now(),
                lastTestError: ''
            };
            await interaction.deferReply({ ephemeral: true });
            try {
                const tested = await testNubankImapConnection(config);
                config.pass = tested.normalizedPass || config.pass;
                config.lastTestOk = true;
                config.lastTestAt = Date.now();
                await logs.set("nubankImap.config", config);
                await interaction.editReply({ content: `\`✅\` **E-mail conectado.** Provedor: **${provider.label}** • servidor: \`${provider.host}:993\`.\n\nO remetente do Banco Inter já foi configurado automaticamente para o domínios oficiais **@inter.co** e **@bancointer.com.br**. Agora configure sua chave PIX e ative.` });
            } catch (error) {
                config.lastTestOk = false;
                config.lastTestAt = Date.now();
                config.lastTestError = String(error.message || error).slice(0, 500);
                await logs.set("nubankImap.config", config);
                await interaction.editReply({ content: `\`❌\` Não foi possível autenticar a **caixa de e-mail** usada para receber os avisos do Inter.\n\n${String(error.message || error).slice(0, 900)}\n\n-# O Banco Inter já está pré-configurado como remetente. Este erro é do login IMAP do seu provedor de e-mail, não da conta bancária.` });
            }
        };

        if (customId === "configureBankImapPix") {
            const current = await getStoredConfig();
            const modal = new ModalBuilder().setCustomId("modalBankImapPix").setTitle("Banco Inter • PIX").addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("bankPixKey").setLabel("CHAVE PIX DO BANCO INTER").setValue(current.pixKey || "").setPlaceholder("CPF, e-mail, telefone ou chave aleatória").setStyle(1).setRequired(true).setMaxLength(180)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("bankPixType").setLabel("TIPO DA CHAVE PIX").setValue(current.pixType || "aleatoria").setPlaceholder("cpf, email, telefone, aleatoria").setStyle(1).setRequired(true).setMaxLength(30))
            );
            return interaction.showModal(modal);
        };

        if (customId === "modalBankImapPix") {
            const previous = await getStoredConfig();
            await logs.set("nubankImap.config", {
                ...previous,
                bankLabel: 'Banco Inter',
                pixKey: interaction.fields.getTextInputValue("bankPixKey").trim(),
                pixType: interaction.fields.getTextInputValue("bankPixType").trim().toLowerCase()
            });
            return interaction.reply({ content: "`✅` Chave PIX do **Banco Inter** salva. O checkout só exibirá **Inter IMAP** quando o e-mail, a chave PIX e o sistema estiverem ativos. Os remetentes oficiais do Inter já são automáticos.", flags: MessageFlags.Ephemeral });
        };

        if (customId === "toggleNubankImap") {
            const config = await getStoredConfig();
            if (config.enabled) {
                await logs.set("nubankImap.config.enabled", false);
                return nubankImapConfig();
            }
            if (!config.user || !config.pass || !config.allowedFrom.length || !config.pixKey) return interaction.reply({ content: "`❌` Configure o e-mail IMAP e a chave PIX do Inter antes de ativar. Os remetentes oficiais do Inter já são definidos automaticamente.", ephemeral: true });
            await interaction.deferReply({ ephemeral: true });
            try {
                const tested = await testNubankImapConnection(config);
                await logs.set("nubankImap.config", { ...config, pass: tested.normalizedPass || config.pass, enabled: true, lastTestOk: true, lastTestAt: Date.now(), lastTestError: '' });
                return interaction.editReply({ content: "`✅` **Inter IMAP ativado.** Login e caixa INBOX validados antes da ativação." });
            } catch (error) {
                await logs.set("nubankImap.config", { ...config, enabled: false, lastTestOk: false, lastTestAt: Date.now(), lastTestError: String(error.message || error).slice(0, 500) });
                return interaction.editReply({ content: `\`❌\` Não foi possível ativar porque a conexão IMAP falhou.\n\n${String(error.message || error).slice(0, 900)}` });
            }
        };

        if (customId === "testNubankImap") {
            await interaction.deferReply({ ephemeral: true });
            const current = await getStoredConfig();
            try {
                const tested = await testNubankImapConnection(current);
                await logs.set("nubankImap.config", { ...current, pass: tested.normalizedPass || current.pass, lastTestOk: true, lastTestAt: Date.now(), lastTestError: '' });
                await interaction.editReply({ content: "`✅` IMAP conectado com sucesso e a caixa **INBOX** está acessível. A configuração está pronta para o verificador de pagamentos." });
            } catch (error) {
                await logs.set("nubankImap.config", { ...current, enabled: false, lastTestOk: false, lastTestAt: Date.now(), lastTestError: String(error.message || error).slice(0, 500) });
                await interaction.editReply({ content: `\`❌\` Falha no teste IMAP.

${String(error.message || error).slice(0, 900)}

-# Por segurança, o pagamento IMAP foi desativado até um teste concluir com sucesso.` });
            }
        };

        if (customId === "removeNubankImap") {
            await logs.delete("nubankImap.config");
            await nubankImapConfig();
        };

        if (customId === "sistemaMpOnOff") {

            const sistemaMp = await api.get("sistemaMp");

            if (sistemaMp) {
                await api.set("sistemaMp", false);
            } else {
                await api.set("sistemaMp", true);
            };

            await automaticConfig();

        };

        if (customId === "setAccessToken") {

            const modal = new ModalBuilder()
                .setCustomId(`modalAccessToken`)
                .setTitle(`Alterar Access Token`)

            const option1 = new TextInputBuilder()
                .setCustomId(`access`)
                .setLabel(`QUAL O SEU ACCESS TOKEN?`)
                .setPlaceholder(`APP_USR-000000000000000-XX...`)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);

            modal.addComponents(optionx1);
            await interaction.showModal(modal);

        };

        if (customId === "modalAccessToken") {
            const access = interaction.fields.getTextInputValue("access");

            mercadopago.configurations.setAccessToken(access);

            try {

                const payment_data = {
                    transaction_amount: parseFloat('10'),
                    description: 'Testando se o token é válido',
                    payment_method_id: 'pix',
                    payer: {
                        email: 'skyapps2024@gmail.com',
                        first_name: 'Adilson Lima',
                        last_name: 'de Souza',
                        identification: {
                            type: 'CPF',
                            number: '63186896215',
                        },
                        address: {
                            zip_code: '86063190',
                            street_name: 'Rua Jácomo Piccinin',
                            street_number: '871',
                            neighborhood: 'Pinheiros',
                            city: 'Londrina',
                            federal_unit: 'PR',
                        },
                    },
                };

                await mercadopago.payment.create(payment_data);

            } catch (error) {

                const pc = "https://www.youtube.com/watch?v=w7kyGZUrkVY&t=162s";
                const mobile = "https://www.youtube.com/watch?v=ctwqHp1H0-0";

                await interaction.reply({
                    content: ``,
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: `${interaction.user.username} - Erro Access Token`, iconURL: interaction.user.displayAvatarURL() })
                            .setDescription(`-# \`❌\` Erro na setagem do access token.`)
                            .addFields(
                                { name: `Erro`, value: `\`Access Token Inválido\``, inline: true },
                                { name: `Útil`, value: `\`Assista ao tutorial\``, inline: true }
                            )
                            .setColor(`#FF0000`)
                            
                            .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                            .setTimestamp()
                    ],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder().setURL(pc).setLabel(`TUTORIAL ACCESS TOKEN (PC)`).setEmoji(`👀`).setStyle(5),
                                new ButtonBuilder().setURL(mobile).setLabel(`TUTORIAL ACCESS TOKEN (MOBILE)`).setEmoji(`👀`).setStyle(5)
                            )
                    ],
                    ephemeral: true,
                });

                return;

            };

            await api.set("mp", access);
            await automaticConfig();

        };

        if (customId === "editTempPay") {

            const modal = new ModalBuilder()
                .setCustomId(`modalTempPay`)
                .setTitle(`Alterar Tempo Pagamento`)

            const option1 = new TextInputBuilder()
                .setCustomId(`temp`)
                .setLabel(`QUAL O NOVO TEMPO PARA PAGAR? (MINUTOS)`)
                .setPlaceholder(`EX: 10`)
                .setMaxLength(3)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);

            modal.addComponents(optionx1);
            await interaction.showModal(modal);

        };

        if (customId === "modalTempPay") {
            const temp = interaction.fields.getTextInputValue("temp");

            if (isNaN(temp)) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento está inválido, use apenas números.`, ephemeral: true });
            };

            if (temp < 3) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento não pode ser menos que **3** Minutos`, ephemeral: true });
            };

            if (temp > 120) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento não pode ser mais que **120** Minutos`, ephemeral: true });
            };

            await api.set("tempoPay", temp);
            await automaticConfig();

        };

        if (customId === "semiAutoConfig") {
            await semiAutoConfig();
        };

        if (customId === "sistemaSemiOnOff") {

            const sistemaSemi = await logs.get("semi.sistema");

            if (sistemaSemi) {
                await logs.set("semi.sistema", false);
            } else {
                await logs.set("semi.sistema", true);
            };

            await semiAutoConfig();

        };

        if (customId === "setAgenceSemi") {
            await setAgenceSemi();
        };

        if (customId === "editTempPay2") {

            const modal = new ModalBuilder()
                .setCustomId(`modalTempPay2`)
                .setTitle(`Alterar Tempo Pagamento`)

            const option1 = new TextInputBuilder()
                .setCustomId(`temp`)
                .setLabel(`QUAL O NOVO TEMPO PARA PAGAR? (MINUTOS)`)
                .setPlaceholder(`EX: 10`)
                .setMaxLength(3)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);

            modal.addComponents(optionx1);
            await interaction.showModal(modal);

        };

        if (customId === "modalTempPay2") {
            const temp = interaction.fields.getTextInputValue("temp");

            if (isNaN(temp)) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento está inválido, use apenas números.`, ephemeral: true });
            };

            if (temp < 3) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento não pode ser menos que **3** Minutos`, ephemeral: true });
            };

            if (temp > 120) {
                return interaction.reply({ content: `\`❌\` O tempo para pagamento não pode ser mais que **120** Minutos`, ephemeral: true });
            };

            await logs.set("semi.tempoPay", temp);
            await semiAutoConfig();

        };

        if (customId === "setConfigSemi") {

            const modal = new ModalBuilder()
                .setCustomId(`modalAgenceSemi`)
                .setTitle(`Agencia Semi Auto`)

            const option1 = new TextInputBuilder()
                .setCustomId(`chave`)
                .setLabel(`QUAL É A SUA CHAVE PIX?`)
                .setPlaceholder(`EX: profissional@gmail.com`)
                .setMaxLength(500)
                .setStyle(1)

            const option2 = new TextInputBuilder()
                .setCustomId(`tipo`)
                .setLabel(`QUAL O TIPO DA SUA CHAVE PIX?`)
                .setPlaceholder(`EX: Email / Telefone / CPF`)
                .setMaxLength(100)
                .setStyle(1)

            const optionx1 = new ActionRowBuilder().addComponents(option1);
            const optionx2 = new ActionRowBuilder().addComponents(option2);

            modal.addComponents(optionx1, optionx2);
            await interaction.showModal(modal);

        };

        if (customId === "modalAgenceSemi") {
            const tipo = interaction.fields.getTextInputValue("tipo");
            const chave = interaction.fields.getTextInputValue("chave");

            await logs.set("semi.tipo", tipo);
            await logs.set("semi.chave", chave);
            await semiAutoConfig();

        };

        if (customId === "aprovedRoleSemi") {

            await interaction.update({
                content: ``,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new RoleSelectMenuBuilder()
                                .setCustomId(`selectRoleAprovedSemi`)
                                .setPlaceholder(`⚡ Selecionar Cargo`)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`setAgenceSemi`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        if (customId === "selectRoleAprovedSemi") {

            const role = interaction.values[0];

            await logs.set("semi.roleAprove", role);
            await setAgenceSemi();

        };

        if (customId === "antFraudSet") {

            await interaction.update({
                content: ``,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                        .setCustomId(`selectAntiFraudBanks`)
                        .setPlaceholder(`🏦 Bloquear Banco`)
                        .addOptions(
                            {
                                value: `inter`,
                                label: `Banco: Inter`,
                                emoji: `🏦`
                            },
                            {
                                value: `picpay`,
                                label: `Banco: PicPay`,
                                emoji: `🏦`
                            },
                            {
                                value: `nubank`,
                                label: `Banco: NuBank`,
                                emoji: `🏦`
                            },
                            {
                                value: `99pay`,
                                label: `Banco: 99Pay`,
                                emoji: `🏦`
                            },
                            {
                                value: `pagseguro`,
                                label: `Banco: PagBank`,
                                emoji: `🏦`
                            }
                        )
                        .setMaxValues(5)
                    ),
                    new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`liberarTudo`).setLabel(`Liberar Tudo`).setEmoji(`➕`).setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`automaticConfig`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                    )
                ]
            });

        };

        if (customId === "selectAntiFraudBanks") {

            const options = interaction.values;
            
            await api.set("banksOff", options);
            await automaticConfig();

        };

        if (customId === "liberarTudo") {

            await api.set("banksOff", []);
            await automaticConfig();

        };

        if (customId === 'automationConfig') {
            return interaction.update({
                content: '',
                embeds: [
                    new EmbedBuilder()
                        .setTitle('Painel Automação')
                        .setDescription(`Olá ${interaction.user.username} Seja bem-vindo ao painel de automação. Atualmente temos 2 automações disponíveis, **Mensagem Automática** e **Repostagem**.`)
                        .setColor('#00FFFF')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('autoMsgConfig').setLabel('Mensagem Automática').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('autoRepostConfig').setLabel('Repostagem').setStyle(2)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('back').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }

        if (customId === 'autoMsgConfig') {
            const config = await logs.get('autoMsg');
            let desc = '';
            if (config) {
                desc = `**Canal:** <#${config.canalId}>\n**Mensagem:** ${config.mensagem}\n**Intervalo:** ${config.intervalo} minuto(s)`;
            } else {
                desc = 'Nenhuma mensagem automática configurada.';
            }
            return interaction.update({
                content: '',
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciar Mensagem Automática`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(desc)
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('editAutoMsgChannel').setLabel('Editar Canal').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('editAutoMsgMsg').setLabel('Editar Mensagem').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('editAutoMsgInterval').setLabel('Editar Intervalo').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('deleteAutoMsg').setLabel('Deletar').setStyle(ButtonStyle.Secondary).setDisabled(!config)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('automationConfig').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }

        if (customId === 'autoMsgModal') {
            const canalId = interaction.fields.getTextInputValue('canalId');
            const mensagem = interaction.fields.getTextInputValue('mensagem');
            const intervalo = parseInt(interaction.fields.getTextInputValue('intervalo'));
            if (isNaN(intervalo) || intervalo < 1) {
                return interaction.reply({ content: 'Intervalo inválido!', ephemeral: true });
            }
            await logs.set('autoMsg', { canalId, mensagem, intervalo });
            return interaction.reply({ content: 'Mensagem automática configurada com sucesso!', ephemeral: true });
        }

        if (customId === 'autoRepostConfig') {
            const repostConfig = await logs.get('repost') || { on: false, horario: null };
            let desc = '';
            desc += `Status: ${repostConfig.on ? '🟢 Ligado' : '🔴 Desligado'}\n`;
            desc += `Horário: ${repostConfig.horario ? repostConfig.horario + ' (Brasília)' : 'Não configurado'}\n`;
            return interaction.update({
                content: '',
                embeds: [
                    new EmbedBuilder()
                        .setTitle('Painel de Repostagem')
                        .setDescription(desc)
                        .setColor(repostConfig.on ? '#00FF00' : '#FF0000')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('repostToggle').setLabel(repostConfig.on ? 'Desligar' : 'Ligar').setStyle(repostConfig.on ? 4 : 3),
                        new ButtonBuilder().setCustomId('repostSetHour').setLabel('Configurar Horário').setStyle(ButtonStyle.Secondary).setDisabled(!repostConfig.on)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('automationConfig').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }

        if (customId === 'repostToggle') {
            const repostConfig = await logs.get('repost') || { on: false, horario: null };
            repostConfig.on = !repostConfig.on;
            await logs.set('repost', repostConfig);
            const desc = `Status: ${repostConfig.on ? '🟢 Ligado' : '🔴 Desligado'}\nHorário: ${repostConfig.horario ? repostConfig.horario + ' (Brasília)' : 'Não configurado'}\n`;
            return interaction.update({
                content: '',
                embeds: [
                    new EmbedBuilder()
                        .setTitle('Painel de Repostagem')
                        .setDescription(desc)
                        .setColor(repostConfig.on ? '#00FF00' : '#FF0000')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('repostToggle').setLabel(repostConfig.on ? 'Desligar' : 'Ligar').setStyle(repostConfig.on ? 4 : 3),
                        new ButtonBuilder().setCustomId('repostSetHour').setLabel('Configurar Horário').setStyle(ButtonStyle.Secondary).setDisabled(!repostConfig.on)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('automationConfig').setLabel('Voltar').setStyle(2)
                    )
                ]
            });
        }

        if (customId === 'repostSetHour') {
            const modal = new ModalBuilder()
                .setCustomId('modalRepostHour')
                .setTitle('Configurar Horário de Repostagem');
            const hourInput = new TextInputBuilder()
                .setCustomId('repostHour')
                .setLabel('Horário (HH:mm, 24h, Brasília)')
                .setPlaceholder('Ex: 14:00')
                .setRequired(true)
                .setStyle(ButtonStyle.Secondary);
            modal.addComponents(new ActionRowBuilder().addComponents(hourInput));
            return interaction.showModal(modal);
        }
        if (interaction.isModalSubmit() && interaction.customId === 'modalRepostHour') {
            const hour = interaction.fields.getTextInputValue('repostHour');
            if (!/^([01]?\d|2[0-3]):[0-5]\d$/.test(hour)) {
                return interaction.reply({ content: 'Horário inválido! Use o formato HH:mm (24h).', ephemeral: true });
            }
            const repostConfig = await logs.get('repost') || { on: false, horario: null };
            repostConfig.horario = hour;
            await logs.set('repost', repostConfig);
            return interaction.reply({ content: 'Horário de repostagem atualizado com sucesso!', ephemeral: true });
        }

        if (customId === 'statusRealtime') {
            let listaClientes = await clientes.get('lista') || [];
            let aplicacoes = db2.all().map(app => app.data.nome).filter(Boolean);
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('Status Realtime')
                        .addFields(
                            { name: 'Clientes Registrados', value: `👥 ${listaClientes.length}`, inline: true },
                            { name: 'Aplicações Registradas', value: `📊 ${aplicacoes.length}`, inline: true }
                        )
                        .setColor('#6B7280')
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('atualizarStatus').setLabel('Atualizar Agora').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('criarCanaisVozRealtime').setLabel('Criar/Atualizar Canais de Voz').setStyle(ButtonStyle.Secondary).setEmoji(id(readCache(interaction.guildId),'automation','🔊'))
                    )
                ],
                ephemeral: true
            });
        }
        if (customId === 'criarCanaisVozRealtime') {
            try {
                let listaClientes = await clientes.get('lista') || [];
                let aplicacoes = db2.all().map(app => app.data.nome).filter(Boolean);
                let categoria = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === 'STATUS REALTIME');
                if (!categoria) {
                    categoria = await interaction.guild.channels.create({ name: 'STATUS REALTIME', type: ChannelType.GuildCategory });
                    await logs.set('realtime.categoria', categoria.id);
                } else {
                    await logs.set('realtime.categoria', categoria.id);
                }
                const canaisDesejados = [
                    { nome: `Aplicações: ${aplicacoes.length}`, tipo: 'aplicacoes', key: 'realtime.aplicacoes' },
                    { nome: `Clientes: ${listaClientes.length}`, tipo: 'clientes', key: 'realtime.clientes' }
                ];
                let criadosOuAtualizados = [];
                for (const canal of canaisDesejados) {
                    let canalExistente = interaction.guild.channels.cache.find(c => c.parentId === categoria.id && c.type === ChannelType.GuildVoice && c.name.includes(canal.tipo === 'aplicacoes' ? 'Aplicações' : 'Clientes'));
                    const everyoneRole = interaction.guild.roles.everyone;
                    if (canalExistente) {
                        if (canalExistente.name !== canal.nome) {
                            await canalExistente.setName(canal.nome);
                        }
                        await canalExistente.permissionOverwrites.edit(everyoneRole, {
                            ViewChannel: true,
                            Connect: false
                        });
                        await logs.set(canal.key, canalExistente.id);
                        criadosOuAtualizados.push(canal.nome + ' (atualizado)');
                    } else {
                        const novoCanal = await interaction.guild.channels.create({
                            name: canal.nome,
                            type: ChannelType.GuildVoice,
                            parent: categoria.id,
                            permissionOverwrites: [
                                {
                                    id: everyoneRole.id,
                                    allow: ['ViewChannel'],
                                    deny: ['Connect']
                                }
                            ]
                        });
                        await logs.set(canal.key, novoCanal.id);
                        criadosOuAtualizados.push(canal.nome + ' (criado)');
                    }
                }
                if (criadosOuAtualizados.length > 0) {
                    await interaction.reply({ content: `Canais de voz criados/atualizados: ${criadosOuAtualizados.join(', ')}`, ephemeral: true });
                } else {
                    await interaction.reply({ content: `Os canais de voz já estão atualizados.`, ephemeral: true });
                }
            } catch (err) {
                await interaction.reply({ content: `Erro ao criar canais: ${err.message}`, ephemeral: true });
            }
        }
        if (customId === 'atualizarStatus') {
            let listaClientes = await clientes.get('lista') || [];
            let aplicacoes = db2.all().map(app => app.data.nome).filter(Boolean);
            return interaction.update({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('Status Realtime')
                        .addFields(
                            { name: 'Clientes Registrados', value: `${listaClientes.length}`, inline: true },
                            { name: 'Aplicações Registradas', value: `${aplicacoes.length}`, inline: true }
                        )
                        .setColor('#6B7280')
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('atualizarStatus').setLabel('Atualizar Agora').setStyle(ButtonStyle.Secondary)
                    )
                ]
            });
        }

        async function inicio() {
            // Sempre volta à mesma página principal Components V2. Não recria um
            // embed legado por cima/baixo da mensagem, evitando o painel "empilhado".
            return interaction.update(pagePayload(client, interaction, 0, { forUpdate: true }));
        };

        async function gerenciarApps() {

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Aplicações`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`📡\` Gerenciamento das aplicações e dentre outras.\n\n**Bot padrão integrado:** Astra Vendas — disponível em \`/alugueis\` e salvo em \`source/AstraVendas.zip\`.`)
                        .addFields(
                            { name: `Aluguéis Existentes`, value: `\`x${db2.all().filter(app => app?.data?.nome || app?.data?.idapp || app?.data?.owner).length}\`` }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`createBotAluguel`).setLabel(`Add Aluguel`).setEmoji(`➕`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`removeAluguel`).setLabel(`Deletação`).setEmoji(`➕`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`diversesAluguel`).setEmoji(`🗑️`).setStyle(2)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`back`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function channelsRolesEdit() {

            const renov = await interaction.guild.channels.cache.get(logs.get("renov"));
            const vendas = await interaction.guild.channels.cache.get(logs.get("vendas"));
            const backup = await interaction.guild.channels.cache.get(logs.get("logs_backup"));
            const cLogs = await interaction.guild.channels.cache.get(logs.get("channel_logs"));
            const cHospedagem = await interaction.guild.channels.cache.get(logs.get("logs_hospedagem"));
            const cVencidos = await interaction.guild.channels.cache.get(logs.get("logs_vencidos"));

            const client = await interaction.guild.roles.cache.get(logs.get("cargo_client"));

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Canais/Cargos`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`🔧\` Gerenciamento dos canais e cargos do sistema.`)
                        .addFields(
                            {
                                name: `📫 Canais`,
                                value: `**Logs Sistema:** ${logs.get("channel_logs") ? cLogs : "Não definido."}
                        **Logs Renovação:** ${logs.get("renov") ? renov : "Não definido."}
                        **Logs Vendas:** ${logs.get("vendas") ? vendas : "Não definido."}
                        **Logs Backup:** ${logs.get("logs_backup") ? backup : "Não definido."}
                        **Logs Hospedagem:** ${logs.get("logs_hospedagem") ? cHospedagem : "Não definido."}
                        **Logs Vencidos:** ${logs.get("logs_vencidos") ? cVencidos : "Não definido."}`
                            },
                            {
                                name: `⚡ Cargos`,
                                value: `**Cargo Cliente:** ${logs.get("cargo_client") ? client : "Não definido."}`
                            }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                                .setCustomId(`selectChannelEdit`)
                                .setPlaceholder(`📫 Definir Canal`)
                                .setOptions(
                                    {
                                        value: `logsEdit`,
                                        label: `Gerenciar Logs`,
                                        emoji: `📜`
                                    },
                                    {
                                        value: `renovEdit`,
                                        label: `Gerenciar Renovações`,
                                        emoji: `➕`
                                    },
                                    {
                                        value: `vendasEdit`,
                                        label: `Gerenciar Vendas`,
                                        emoji: `💰`
                                    },
                                    {
                                        value: `backupEdit`,
                                        label: `Gerenciar Backup`,
                                        emoji: `💾`
                                    },
                                    {
                                        value: `hospedagemEdit`,
                                        label: `Gerenciar Hospedagem`,
                                        description: `Canal de logs de bots hospedados (Pagos/Trial)`,
                                        emoji: `🚀`
                                    },
                                    {
                                        value: `vencidosEdit`,
                                        label: `Gerenciar Vencidos`,
                                        description: `Canal de logs de bots excluídos por vencimento`,
                                        emoji: `⚠️`
                                    }
                                )
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                                .setCustomId(`selectRolesEdit`)
                                .setPlaceholder(`⚡ Definir Cargo`)
                                .setOptions(
                                    {
                                        value: `clientEdit`,
                                        label: `Gerenciar Cliente`,
                                        emoji: `👤`
                                    }
                                )
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`back`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function diversesAluguel() {

            await interaction.update({
                content: ``,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`gerenciamentDev`).setLabel(`Gerenciamento`).setEmoji(`💳`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`deleteAppUser`).setLabel(`Deletar Aplicação`).setEmoji(`➕`).setStyle(ButtonStyle.Secondary)
                        )
                ]
            });

        };

        async function gerenciamentDev() {

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Developer Tool`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`💻\` Gerenciamento do sistema **Developer Tool**.`)
                        .addFields(
                            { name: `Aplicações em Host`, value: `\`x${db2.all().length}\`` }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                                .setCustomId(`selectGerenciamentDev`)
                                .setPlaceholder(`📡 Developer Tool`)
                                .addOptions(
                                    {
                                        value: `ligarBotGrc`,
                                        label: `Ligar App`,
                                        emoji: `▶️`
                                    },
                                    {
                                        value: `reiniciarBotGrc`,
                                        label: `Reiniciar App`,
                                        emoji: `🔄`
                                    },
                                    {
                                        value: `desligarBotGrc`,
                                        label: `Desligar App`,
                                        emoji: `⏹️`
                                    },
                                    {
                                        value: `statusBotGrc`,
                                        label: `Status App`,
                                        emoji: `🛡️`
                                    }
                                )
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`consoleBotGrc`).setEmoji(`🔧`).setStyle(2),
                            new ButtonBuilder().setCustomId(`backD`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function definitions() {

            await interaction.update({
                content: `**PAINEL MANAGER V2**\nSeja bem vindo ao Painel de controle do Manager! Oque deseja fazer hoje?.`,
                embeds: [],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`apiConfig`).setLabel(`Hospedagem`).setEmoji(id(readCache(interaction.guildId),'cloud','☁️')).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`moderationConfig`).setLabel(`Moderação`).setEmoji(id(readCache(interaction.guildId),'moderation','🛡️')).setStyle(ButtonStyle.Secondary).setDisabled(false)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`automationConfig`).setLabel(`Automação`).setEmoji(id(readCache(interaction.guildId),'automation','🤖')).setDisabled(false).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`paymentsConfig`).setLabel(`ChaveRecibo`).setEmoji(id(readCache(interaction.guildId),'receipt','🧾')).setStyle(ButtonStyle.Secondary)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`back`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function apiConfig() {

            const sftpStatus = require('../../source/sftp').status();

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`Gerenciando Hospedagem (HidenCloud)`)
                        .setDescription(`-# \`☁️\` Hospedagem dos bots via **HidenCloud** (SFTP, sem API key) + runtime local.`)
                        .addFields(
                            { name: `Status`, value: `${sftpStatus.text}`, inline: false }
                        )
                        .setColor('#6B7280')
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`definitions`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function paymentsConfig() {
            const sistemaMp = Boolean(api.get("sistemaMp"));
            const mp = String(api.get("mp") || "").trim();
            const sistemaSemi = Boolean(logs.get("semi.sistema"));
            const chave = String(logs.get("semi.chave") || "").trim();
            const evo = evopay.settings();
            const vyv = externalPix.settings("vyvence");
            const mag = externalPix.settings("magnus");
            const pro = externalPix.settings("promisse");
            const gatewayStatus = item => `${item.enabled ? "🟢 Ativada" : "🔴 Desativada"} • ${item.baseUrl && item.token && item.createPath && item.statusPath ? "configurada" : "configuração incompleta"}`;

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`ASTRA APPLICATION • Pagamentos`)
                        .setDescription(`Configure os métodos usados para cobrar planos. O checkout só exibe métodos que estejam **ativados e configurados**.`)
                        .addFields(
                            { name: `Mercado Pago PIX`, value: `${sistemaMp ? "🟢 Ativado" : "🔴 Desativado"} • ${mp ? "credencial configurada" : "sem credencial"}`, inline: false },
                            { name: `EvoPay PIX`, value: `${evo.enabled ? "🟢 Ativada" : "🔴 Desativada"} • ${evo.token ? "token configurado" : "sem token"}`, inline: false },
                            { name: `VyvencePay`, value: gatewayStatus(vyv), inline: true },
                            { name: `MagnusPay`, value: gatewayStatus(mag), inline: true },
                            { name: `PromissePay`, value: `${pro.enabled ? "🟢 Ativada" : "🔴 Desativada"} • ${pro.token ? "API key configurada" : "sem API key"}`, inline: true },
                            { name: `PIX manual / assistido`, value: `${sistemaSemi ? "🟢 Ativado" : "🔴 Desativado"} • ${chave ? "chave configurada" : "sem chave"}`, inline: false },
                            { name: `Banco Inter • IMAP`, value: `Confirmação automática de PIX do **Banco Inter** por e-mail, conferindo **valor + nome exato do pagador**.`, inline: false }
                        )
                        .setColor('#3155ff')
                        .setFooter({ text: `Astra Application • gateways de pagamento` })
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`automaticConfig`).setLabel(`Mercado Pago`).setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`evopayConfig`).setLabel(`EvoPay`).setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`vyvenceConfig`).setLabel(`VyvencePay`).setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`magnusConfig`).setLabel(`MagnusPay`).setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(`promisseConfig`).setLabel(`PromissePay`).setStyle(ButtonStyle.Primary)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`semiAutoConfig`).setLabel(`PIX manual`).setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`nubankImapConfig`).setLabel(`Inter IMAP`).setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`definitions`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(ButtonStyle.Secondary)
                    )
                ]
            });
        };

        async function externalGatewayConfig(provider) {
            const item = externalPix.settings(provider);
            const complete = Boolean(item.baseUrl && item.token && item.createPath && item.statusPath);
            const masked = item.token ? `${item.token.slice(0, 5)}••••••${item.token.slice(-4)}` : 'Não configurado';
            return interaction.update({
                content: '',
                embeds: [new EmbedBuilder()
                    .setColor('#3155ff')
                    .setTitle(`${item.label} • PIX automático`)
                    .setDescription('Gateway de planos configurável por HTTPS. Informe as rotas exatamente como fornecidas pela documentação/conta do provedor. Após o PIX ser confirmado, o plano é ativado e o cliente segue para o vínculo do bot.')
                    .addFields(
                        { name: 'Sistema', value: item.enabled ? '🟢 Ativado' : '🔴 Desativado', inline: true },
                        { name: 'Configuração', value: complete ? '🟢 Completa' : '🔴 Incompleta', inline: true },
                        { name: 'Token', value: `\`${masked}\``, inline: true },
                        { name: 'URL base', value: item.baseUrl ? `\`${item.baseUrl.slice(0, 250)}\`` : '`Não configurada`', inline: false },
                        { name: 'Criar cobrança', value: item.createPath ? `\`${item.createPath}\`` : '`Não configurada`', inline: true },
                        { name: 'Consultar cobrança', value: item.statusPath ? `\`${item.statusPath}\`` : '`Não configurada`', inline: true },
                        { name: 'Autenticação', value: `\`${item.authSpec}\``, inline: true }
                    )
                    .setFooter({ text: 'Nenhuma credencial completa é exibida no painel.' })],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(provider === 'vyvence' ? 'vyvenceToggle' : (provider === 'magnus' ? 'magnusToggle' : 'promisseToggle')).setLabel(item.enabled ? 'Desativar' : 'Ativar').setStyle(item.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                        new ButtonBuilder().setCustomId(provider === 'vyvence' ? 'vyvenceSet' : (provider === 'magnus' ? 'magnusSet' : 'promisseSet')).setLabel('Configurar API').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId(provider === 'vyvence' ? 'vyvenceTest' : (provider === 'magnus' ? 'magnusTest' : 'promisseTest')).setLabel('Testar conexão').setStyle(ButtonStyle.Secondary).setDisabled(!complete)
                    ),
                    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('paymentsConfig').setLabel('Voltar').setStyle(ButtonStyle.Secondary))
                ]
            });
        };

        async function externalGatewayModal(provider) {
            const item = externalPix.settings(provider);
            const modal = new ModalBuilder().setCustomId(provider === 'vyvence' ? 'vyvenceModal' : (provider === 'magnus' ? 'magnusModal' : 'promisseModal')).setTitle(`${item.label} • API PIX`);
            const field = (customId, label, placeholder, value, maxLength = 1000) => {
                const input = new TextInputBuilder().setCustomId(customId).setLabel(label).setPlaceholder(placeholder).setStyle(1).setRequired(true).setMaxLength(maxLength);
                const current = String(value || '').slice(0, maxLength);
                if (current) input.setValue(current);
                return new ActionRowBuilder().addComponents(input);
            };
            if (provider === 'promisse') {
                modal.addComponents(field('token', 'API KEY DA PROMISSEPAY', 'Cole somente a API key da sua conta', item.token));
            } else {
                modal.addComponents(
                    field('baseUrl', 'URL BASE HTTPS', 'https://api.provedor.com.br', item.baseUrl),
                    field('token', 'TOKEN / API KEY', 'Cole a credencial da API', item.token),
                    field('createPath', 'ROTA PARA CRIAR PIX', '/pix ou /payments', item.createPath),
                    field('statusPath', 'ROTA PARA CONSULTAR • USE {id}', '/pix/{id}', item.statusPath),
                    field('authSpec', 'HEADER DE AUTENTICAÇÃO', 'Authorization:Bearer ou x-api-key:', item.authSpec || 'Authorization:Bearer', 120)
                );
            }
            return interaction.showModal(modal);
        };

        async function evopayConfig() {
            const evo = evopay.settings();
            const masked = evo.token ? `${evo.token.slice(0, 6)}••••••${evo.token.slice(-4)}` : 'Não configurado';
            return interaction.update({
                content: '',
                embeds: [new EmbedBuilder()
                    .setColor('#3155ff')
                    .setTitle('EvoPay • PIX automático')
                    .setDescription('Gera a cobrança PIX diretamente na EvoPay e acompanha o status pela API até a confirmação ou expiração.')
                    .addFields(
                        { name: 'Sistema', value: evo.enabled ? '🟢 Ativado' : '🔴 Desativado', inline: true },
                        { name: 'Token', value: `\`${masked}\``, inline: true },
                        { name: 'Expiração', value: `**${evo.expiresIn}s**`, inline: true }
                    )
                    .setFooter({ text: 'O token completo nunca é mostrado no painel.' })],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId('evopayToggle').setLabel(evo.enabled ? 'Desativar' : 'Ativar').setStyle(evo.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                        new ButtonBuilder().setCustomId('evopaySetToken').setLabel('Configurar token').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId('evopaySetExpiry').setLabel('Tempo do PIX').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('evopayTest').setLabel('Testar conexão').setStyle(ButtonStyle.Secondary).setDisabled(!evo.token)
                    ),
                    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('paymentsConfig').setLabel('Voltar').setStyle(ButtonStyle.Secondary))
                ]
            });
        };

        async function nubankImapConfig() {
            const config = await getStoredConfig();
            const configured = Boolean(config.user && config.pass && config.allowedFrom.length);
            const pixReady = Boolean(config.pixKey);
            const maskedUser = config.user ? config.user.replace(/(^.).*(@.*$)/, "$1***$2") : "Não configurado";
            const connectionState = !config.lastTestAt ? '`⚪ Ainda não testado`' : (config.lastTestOk ? '`🟢 Conexão validada`' : '`🔴 Último teste falhou`');
            const connectionWhen = config.lastTestAt ? `<t:${Math.floor(config.lastTestAt / 1000)}:R>` : '—';
            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Banco Inter • IMAP`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# ` + `🟠` + ` Use os avisos de PIX do **Banco Inter** recebidos no seu e-mail. A aprovação automática exige **valor + nome exato do pagador**.`)
                        .addFields(
                            { name: `Sistema`, value: config.enabled ? "`🟢 Ativado`" : "`🔴 Desativado`", inline: true },
                            { name: `Configuração`, value: configured ? "`✅ Credenciais salvas`" : "`❌ Não configurado`", inline: true },
                            { name: `Conexão`, value: `${connectionState}\n-# ${connectionWhen}`, inline: true },
                            { name: `Conta`, value: `\`${maskedUser}\``, inline: false },
                            { name: `Servidor do e-mail`, value: `\`${config.host || "imap.gmail.com"}:${config.port || 993}\`\n-# ${config.providerLabel || 'IMAP'}`, inline: true },
                            { name: `Verificação`, value: `\`${Math.round((config.intervalMs || 30000) / 1000)} segundos\``, inline: true },
                            { name: `Remetente Inter`, value: `\`@inter.co\`\n-# definido automaticamente pelo Manager`, inline: false },
                            { name: `Banco / método`, value: `**${config.bankLabel || 'Banco Inter'}**`, inline: true },
                            { name: `Chave PIX`, value: pixReady ? `\`${String(config.pixKey).slice(0,6)}••••${String(config.pixKey).slice(-4)}\`` : "`Não configurada`", inline: true },
                            { name: `Conferência`, value: `Valor exato + nome do pagador informado no checkout`, inline: false }
                        )
                        .setColor(`#FF7A00`)
                        .setFooter({ text: `Use uma senha de aplicativo do e-mail. Nunca informe a senha principal da conta.` })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`configureNubankImap`).setLabel(`E-mail IMAP`).setEmoji(id(readCache(interaction.guildId),'settings','⚙️')).setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`configureBankImapPix`).setLabel(`PIX do Inter`).setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`toggleNubankImap`).setLabel(config.enabled ? `Desativar` : `Ativar`).setEmoji(config.enabled ? `🔴` : `🟢`).setStyle(config.enabled ? 4 : 3),
                        new ButtonBuilder().setCustomId(`testNubankImap`).setLabel(`Testar conexão`).setEmoji(`🧪`).setStyle(2),
                        new ButtonBuilder().setCustomId(`removeNubankImap`).setLabel(`Remover`).setEmoji(`🗑️`).setStyle(ButtonStyle.Secondary).setDisabled(!configured)
                    ),
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder().setCustomId(`paymentsConfig`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                    )
                ]
            });
        };

        async function automaticConfig() {

            const sistemaMp = await api.get("sistemaMp");
            const mp = await api.get("mp");
            const tempoPay = await api.get("tempoPay");
            const banksOffArray = await api.get("banksOff") || [];

            const banksOff = banksOffArray.map(bank => `${bank} `).join('\n');

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Automático`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`⚡\` Gerenciamento do sistema **Automático**.\n\n-# **Observação:** Na área de automação de pagamento, você vai agilizar o seu processo sem ter que aprovar manualmente um carrinho criado. Use as funções abaixo para setar sua **Creandencia do Access Token** & **Bloquear bancos** que tem índices de fraudes.`)
                        .addFields(
                            { name: `Sistema`, value: `${sistemaMp ? "\`🟢 Online\`" : "\`🔴 Offline\`"}` },
                            { name: `Tempo Pagar`, value: `\`${tempoPay} Minuto(s)\`` },
                            { name: `Crendencias Access Token`, value: `${!mp ? "\`\`\`APP_USR-000000000000000-XXXXXXX-XXXXXXXXX\`\`\`" : `\`\`\`${mp.slice(0, -33) + '***************************'}\`\`\``}` },
                            { name: `Bancos Bloqueados`, value: `${banksOffArray.length <= 0 ? `Nenhum` : `\`\`\`${banksOff}\`\`\``}` }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`sistemaMpOnOff`).setLabel(sistemaMp ? "Online" : "Offline").setEmoji(sistemaMp ? "⚡" : "⚡").setStyle(sistemaMp ? 3 : 4),
                            new ButtonBuilder().setCustomId(`setAccessToken`).setLabel(`Access Token`).setEmoji(`🔑`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`editTempPay`).setLabel(`Tempo Pagar`).setEmoji(`➡️`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`antFraudSet`).setLabel(`Anti Fraude`).setEmoji(`🛡️`).setStyle(2)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`paymentsConfig`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function semiAutoConfig() {

            const sistemaSemi = await logs.get("semi.sistema");
            const qrcode = await logs.get("semi.qrcode");
            const tempoPay = await logs.get("semi.tempoPay");

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Semi Auto`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`📋\` Gerenciamento do **PIX manual / assistido**.\n\n-# **Observação:** A área de Semi Auto é um sistema útil para quem não tem o mercado pago, esse sistema é preciso aprovar manualmente o pagamento da pessoa que está adquirindo os alugueis da loja/apps. Configire **Tipo/Chave**, **QrCode** & **Cargo Aprovador** logo abaixo.`)
                        .addFields(
                            { name: `Sistema`, value: `${sistemaSemi ? "\`🟢 Online\`" : "\`🔴 Offline\`"}` },
                            { name: `Tempo Pagar`, value: `\`${tempoPay} Minuto(s)\`` },
                            { name: `QrCode`, value: `${!qrcode ? `\`🔴 Gerando Automatico caso a chave for em email.\`` : `[Clique aqui para visualizar](<${qrcode}>)`}` }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`sistemaSemiOnOff`).setLabel(sistemaSemi ? "Desativar PIX manual" : "Ativar PIX manual").setEmoji(sistemaSemi ? "⚡" : "⚡").setStyle(sistemaSemi ? 4 : 3),
                            new ButtonBuilder().setCustomId(`setAgenceSemi`).setLabel(`Setar Agências`).setEmoji(`✏️`).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`editTempPay2`).setLabel(`Tempo Pagar`).setEmoji(`➡️`).setStyle(ButtonStyle.Secondary)
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`paymentsConfig`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        async function setAgenceSemi() {

            const tipo = await logs.get("semi.tipo");
            const chave = await logs.get("semi.chave");
            const roleAprove = await logs.get("semi.roleAprove");

            const roleMention = roleAprove ? interaction.guild.roles.cache.get(roleAprove) : null;

            await interaction.update({
                content: ``,
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({ name: `${interaction.user.username} - Gerenciando Agências`, iconURL: interaction.user.displayAvatarURL() })
                        .setDescription(`-# \`🧪\` Gerenciamento do sistema **Agências**.`)
                        .addFields(
                            { name: `Configuração`, value: `${tipo && chave ? `\`${chave} | ${tipo}\`` : `\`🔴 Não configurado.\``}`, inline: true },
                            { name: `Cargo Aprovador`, value: `${roleMention ? `${roleMention}` : `Não configurado.`}`, inline: true }
                        )
                        .setColor('#6B7280')
                        .setFooter({ text: `${interaction.user.displayName}`, iconURL: interaction.user.displayAvatarURL() })
                        .setTimestamp()
                ],
                components: [
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`setConfigSemi`).setLabel(`Setar Configuração`).setEmoji(id(readCache(interaction.guildId),'receipt','🧾')).setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`aprovedRoleSemi`).setLabel(`Cargo Aprovador`).setEmoji(`⚙️`).setStyle(ButtonStyle.Secondary),
                        ),
                    new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`semiAutoConfig`).setEmoji(id(readCache(interaction.guildId),'back','↩️')).setStyle(2)
                        )
                ]
            });

        };

        function link(n) {
            const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
            return urlRegex.test(n)
        };

    }
}

setInterval(async () => {
    try {
        const botClient = global.client || global._client;
        if (!botClient || !botClient.guilds || !botClient.guilds.cache) return;
        const guilds = botClient.guilds.cache;
        for (const guild of guilds.values()) {
            const listaClientes = await clientes.get('lista') || [];
            const aplicacoes = db2.all().map(app => app.data.nome).filter(Boolean);
            const categoriaId = await logs.get('realtime.categoria');
            const canalAplicacoesId = await logs.get('realtime.aplicacoes');
            const canalClientesId = await logs.get('realtime.clientes');
            if (!categoriaId) continue;
            const categoria = guild.channels.cache.get(categoriaId);
            if (!categoria) continue;
            const canaisDesejados = [
                { nome: `📊 | Aplicações: ${aplicacoes.length}`, id: canalAplicacoesId },
                { nome: `👥 | Clientes: ${listaClientes.length}`, id: canalClientesId }
            ];
            const everyoneRole = guild.roles.everyone;
            for (const canal of canaisDesejados) {
                if (!canal.id) continue;
                let canalExistente = guild.channels.cache.get(canal.id);
                if (canalExistente && canalExistente.parentId === categoria.id && canalExistente.type === ChannelType.GuildVoice) {
                    if (canalExistente.name !== canal.nome) {
                        await canalExistente.setName(canal.nome);
                    }
                    await canalExistente.permissionOverwrites.edit(everyoneRole, {
                        ViewChannel: true,
                        Connect: false
                    });
                }
            }
        }
    } catch (e) { console.log('[Realtime Status Job] Erro:', e); }
}, 30000).unref();
