const {
  Events, MessageFlags, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelSelectMenuBuilder, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const welcome = require('../../Lib/managerWelcome');
const perms = require('../../Lib/permissions');
const { readCache, id: emojiId, fmt } = require('../../Lib/managerEmojis');

function cache(guildId){return readCache(guildId)}
function icon(guildId,key){return fmt(cache(guildId),key)}
function btn(guildId,cid,label,semantic,style=ButtonStyle.Secondary){
  const b=new ButtonBuilder().setCustomId(cid).setLabel(label).setStyle(style);
  const eid=emojiId(cache(guildId),semantic,null);if(eid)b.setEmoji({id:eid});return b;
}
function summary(guildId){
  const s=welcome.settings(guildId);
  return {embeds:[new EmbedBuilder().setColor(s.color||'#3155ff').setTitle(`${icon(guildId,'home')} Manager • Boas-vindas`).setDescription('Mensagem automática de entrada no servidor do Manager, configurável no estilo da Loritta. Cada servidor do Manager mantém sua própria configuração.').addFields(
    {name:'Status',value:s.enabled?'**Ativado**':'**Desativado**',inline:true},
    {name:'Canal',value:s.channelId?`<#${s.channelId}>`:'não configurado',inline:true},
    {name:'Formato',value:s.mode==='NORMAL'?'**Mensagem normal**':'**Embed**',inline:true},
    {name:'Avatar lateral',value:s.showAvatar?'**Sim**':'**Não**',inline:true},
    {name:'Mencionar usuário',value:s.mentionUser?'**Sim**':'**Não**',inline:true},
    {name:'Título',value:`\`${String(s.title||'').slice(0,150)}\``,inline:false},
    {name:'Placeholders',value:'`{user}` `{username}` `{displayName}` `{server}` `{memberCount}`',inline:false}
  ).setTimestamp()],components:[
    new ActionRowBuilder().addComponents(
      btn(guildId,'weladmin:toggle',s.enabled?'Desativar':'Ativar','power',s.enabled?ButtonStyle.Danger:ButtonStyle.Success),
      btn(guildId,'weladmin:channel','Escolher canal','channels',ButtonStyle.Primary),
      btn(guildId,'weladmin:edit','Editar mensagem','edit',ButtonStyle.Primary),
      btn(guildId,'weladmin:preview','Pré-visualizar','preview')
    ),
    new ActionRowBuilder().addComponents(
      btn(guildId,'weladmin:avatar',`Avatar: ${s.showAvatar?'ON':'OFF'}`,'user',s.showAvatar?ButtonStyle.Success:ButtonStyle.Secondary),
      btn(guildId,'weladmin:mention',`Menção: ${s.mentionUser?'ON':'OFF'}`,'message',s.mentionUser?ButtonStyle.Success:ButtonStyle.Secondary),
      btn(guildId,'weladmin:mode',s.mode==='NORMAL'?'Formato: Normal':'Formato: Embed','customize',ButtonStyle.Primary),
      btn(guildId,'weladmin:refresh','Atualizar','reload')
    )
  ]};
}
function editModal(guildId){
  const s=welcome.settings(guildId);
  return new ModalBuilder().setCustomId('weladmin:edit-submit').setTitle('Manager • Boas-vindas').addComponents(
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('TÍTULO').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(256).setValue(String(s.title||'').slice(0,256))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('DESCRIÇÃO').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setValue(String(s.description||'').slice(0,4000))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image').setLabel('LINK DA IMAGEM (OPCIONAL)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(1000).setValue(String(s.imageUrl||'').slice(0,1000))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('COR HEX').setPlaceholder('#3155ff').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(7).setValue(String(s.color||'#3155ff').slice(0,7))),
    new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footer').setLabel('RODAPÉ (OPCIONAL)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(String(s.footer||'').slice(0,500)))
  );
}
module.exports={name:Events.InteractionCreate,run:async(interaction)=>{
  const cid=interaction.customId||'';if(!cid.startsWith('weladmin:'))return;
  if(!perms.isOwner(interaction.user.id))return interaction.reply({content:'Este painel é exclusivo do proprietário do Manager.',flags:MessageFlags.Ephemeral}).catch(()=>null);
  if(!interaction.guildId)return interaction.reply({content:'Use esta opção dentro de um servidor.',flags:MessageFlags.Ephemeral}).catch(()=>null);
  const gid=interaction.guildId;
  try{
    if(cid==='weladmin:open')return interaction.reply({...summary(gid),flags:MessageFlags.Ephemeral});
    if(cid==='weladmin:refresh')return interaction.update(summary(gid));
    if(cid==='weladmin:toggle'){const s=welcome.settings(gid);welcome.save(gid,{enabled:!s.enabled});return interaction.update(summary(gid));}
    if(cid==='weladmin:avatar'){const s=welcome.settings(gid);welcome.save(gid,{showAvatar:!s.showAvatar});return interaction.update(summary(gid));}
    if(cid==='weladmin:mention'){const s=welcome.settings(gid);welcome.save(gid,{mentionUser:!s.mentionUser});return interaction.update(summary(gid));}
    if(cid==='weladmin:mode'){const s=welcome.settings(gid);welcome.save(gid,{mode:s.mode==='NORMAL'?'EMBED':'NORMAL'});return interaction.update(summary(gid));}
    if(cid==='weladmin:channel'){
      const menu=new ChannelSelectMenuBuilder().setCustomId('weladmin:channel-set').setPlaceholder('Canal das boas-vindas').setChannelTypes(ChannelType.GuildText).setMinValues(1).setMaxValues(1);
      return interaction.reply({content:'Escolha o canal onde o Manager enviará as mensagens de boas-vindas.',components:[new ActionRowBuilder().addComponents(menu)],flags:MessageFlags.Ephemeral});
    }
    if(cid==='weladmin:channel-set'&&interaction.isChannelSelectMenu?.()){
      const channelId=interaction.values[0];welcome.save(gid,{channelId});return interaction.update({content:`${icon(gid,'success')} Canal salvo: <#${channelId}>.`,components:[]});
    }
    if(cid==='weladmin:edit')return interaction.showModal(editModal(gid));
    if(cid==='weladmin:edit-submit'&&interaction.isModalSubmit?.()){
      const title=interaction.fields.getTextInputValue('title').trim();
      const description=interaction.fields.getTextInputValue('description').trim();
      const imageRaw=interaction.fields.getTextInputValue('image').trim();
      const color=interaction.fields.getTextInputValue('color').trim();
      const footer=interaction.fields.getTextInputValue('footer').trim();
      const imageUrl=welcome.safeUrl(imageRaw);if(imageRaw&&!imageUrl)return interaction.reply({content:`${icon(gid,'wrong')} O link da imagem precisa usar HTTP ou HTTPS.`,flags:MessageFlags.Ephemeral});
      if(!/^#[0-9a-f]{6}$/i.test(color))return interaction.reply({content:`${icon(gid,'wrong')} Use uma cor HEX como **#3155ff**.`,flags:MessageFlags.Ephemeral});
      welcome.save(gid,{title,description,imageUrl:imageUrl||'',color,footer});
      return interaction.reply({content:`${icon(gid,'success')} Mensagem de boas-vindas atualizada.`,flags:MessageFlags.Ephemeral});
    }
    if(cid==='weladmin:preview'){
      const member=interaction.member;
      if(!member?.user||!member?.guild)return interaction.reply({content:'Não consegui montar a prévia deste membro.',flags:MessageFlags.Ephemeral});
      const p=welcome.payload(member,{...welcome.settings(gid),mentionUser:false});p.allowedMentions={parse:[]};p.flags=MessageFlags.Ephemeral;return interaction.reply(p);
    }
  }catch(error){
    const text=require('../../Lib/interactions').safeMessage(error,700)||'Não foi possível concluir esta ação.';
    if(interaction.deferred)return interaction.editReply({content:`${icon(gid,'wrong')} ${text}`}).catch(()=>null);
    if(interaction.replied)return interaction.followUp({content:`${icon(gid,'wrong')} ${text}`,flags:MessageFlags.Ephemeral}).catch(()=>null);
    return interaction.reply({content:`${icon(gid,'wrong')} ${text}`,flags:MessageFlags.Ephemeral}).catch(()=>null);
  }
}};
