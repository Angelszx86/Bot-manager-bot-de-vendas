const mercadopago = require("mercadopago");
const axios = require("axios");
const { SquareCloudAPI } = require('../../source/hidencloud_api');
const Discord = require("discord.js");
const JSZip = require('jszip');
const fs = require("fs");
const { api, db2, auto, db1, logs, perms, db, tickets } = require("../../databases/index");
const {
  StringSelectMenuBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ComponentType,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
} = require("discord.js");
const moment = require('moment-timezone');

const notifyCooldown = {};

module.exports = {
  name: "interactionCreate",
  run: async (interaction, client) => {

    if (interaction.isButton() && interaction.customId == "tickettopen") {

      const member = interaction.guild.members.cache.get(interaction.user.id);
      const cargoId = "1443620216939610214";
      
      if (member.roles.cache.has(cargoId)) {
        //interaction.reply({ content: "> ✅ parece que você não está authenticado, se authentica-se em: <#1443621424098050118>", ephemeral: true });
      } else {
        return interaction.reply({ content: "> ✅ parece que você não está authenticado, se authentica-se em: <#1443621424098050118>", ephemeral: true });
      }

      
      const config = require("../../databases/config.json");
      const atendimento = config.horario_atendimento;
      const diasSemana = ["domingo", "segunda", "terca", "quarta", "quinta", "sexta", "sabado"];
      const agora = moment().tz("America/Sao_Paulo");
      const dia = diasSemana[agora.day()];
      const horarioDia = atendimento[dia];
      if (!horarioDia) {
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('Fora do horário de atendimento')
          .setDescription('✅ O sistema de tickets está fechado hoje. Horário de atendimento indisponível.');
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }
      const [hInicio, mInicio] = horarioDia.inicio.split(":").map(Number);
      const [hFim, mFim] = horarioDia.fim.split(":").map(Number);
      const inicio = agora.clone().set({ hour: hInicio, minute: mInicio, second: 0, millisecond: 0 });
      const fim = agora.clone().set({ hour: hFim, minute: mFim, second: 0, millisecond: 0 });
      /*if (!(agora.isSameOrAfter(inicio) && agora.isBefore(fim))) {
        const embed = new EmbedBuilder()
          .setColor('#FF0000')
          .setTitle('Fora do horário de atendimento')
          .setDescription(`👎 Atualmente estamos fora do horário de atendimento, o horário de atendimento é das ${horarioDia.inicio} às ${horarioDia.fim} (horário de Brasília).\n Tente novamente no horário de atendimento.`)
          .setFooter({ text: `${interaction.user.displayName} - Astra Application`, iconURL: interaction.guild.iconURL() })
          .setTimestamp()
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }*/

      const modal = new ModalBuilder()
        .setTitle(`Motivo de Abertura`)
        .setCustomId(`modal_ticket`);

      const titlet = new TextInputBuilder()
        .setCustomId("title")
        .setLabel("Assunto")
        .setPlaceholder(`EX: Bots`)
        .setStyle(1)
        .setRequired(true);

      const desc = new TextInputBuilder()
        .setCustomId("desc")
        .setLabel("Descrição do ticket")
        .setPlaceholder(`Ex: meus bots estão com defeito`)
        .setStyle(2)
        .setRequired(false);

      modal.addComponents(
        new ActionRowBuilder().addComponents(titlet),
        new ActionRowBuilder().addComponents(desc)
      );

      return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_ticket") {

      const categoriaId = logs.get("ticket_categoria"); 
      const staffRoleId = logs.get("roleStaff");
      

      const existingChannel = interaction.guild.channels.cache.find(
        c => c.name === `🎫・${interaction.user.username}・${interaction.user.id}` && c.parentId === categoriaId
      );
      if (existingChannel) {
        return interaction.reply({ content: `\`⚠️\` Você já tem um ticket aberto em <#${existingChannel.id}>`, ephemeral: true });
      }

      interaction.reply({ content: `⏳ Criando seu ticket...`, ephemeral: true });


      const channel = await interaction.guild.channels.create({
        name: `🎫・${interaction.user.username}`,
        type: ChannelType.GuildText,
        parent: categoriaId || null,
        permissionOverwrites: [
          {
            id: interaction.guild.id, 
            deny: ["ViewChannel"],
          },
          {
            id: interaction.user.id, 
            allow: ["ViewChannel", "SendMessages", "AttachFiles"],
          },
          {
            id: staffRoleId, 
            allow: ["ViewChannel", "SendMessages"],
          },
          {
            id: client.user.id, 
            allow: ["ViewChannel", "SendMessages", "ManageChannels"],
          },
        ],
        reason: `Ticket aberto por ${interaction.user.tag}`,
      });

      const assumeButton = new ButtonBuilder()
        .setCustomId("assumir_ticket")
        .setLabel("Assumir Ticket")
        .setStyle(3)
        .setEmoji("👑");
      const notifyButton = new ButtonBuilder()
        .setCustomId("notificar_usuario")
        .setLabel("Notificar Usuário")
        .setStyle(1)
        .setEmoji("🔹");
      const closeButton = new ButtonBuilder()
        .setCustomId("fechar_ticket")
        .setLabel("Fechar Ticket")
        .setStyle(4)
        .setEmoji("🔹");
      const row = new ActionRowBuilder().addComponents(assumeButton, notifyButton, closeButton);

      const ticketTitle = interaction.fields.getTextInputValue("title");
      const ticketDesc = interaction.fields.getTextInputValue("desc");

      const ticketMessage = await channel.send({
        content: `|| ${interaction.user} | <@&${staffRoleId}> ||`,
        embeds: [
          new EmbedBuilder()
            .setAuthor({ name: `${interaction.user.username} - Ticket Aberto - Astra Application`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription((ticketTitle ? `**Assunto:** **${ticketTitle}**\n\n` : '') + (ticketDesc ? `**Descrição:** **${ticketDesc}**\n\n` : '') + '-# Este é seu ticket, fique tranquilo e aguarde nossa equipe!')
            .setColor(`#00FFFF`)
            .setImage("https://cdn.discordapp.com/attachments/1442689111117791332/1442886668574134373/1764080959930.jpg?ex=6927106d&is=6925beed&hm=cc1b60da1abc092c7008d96b9ae308b98b42bfcfcd6429d4cf3e151673f62355&")
            .setFooter({ text: `${interaction.user.displayName} - Astra Application`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp(),
          new EmbedBuilder()
            //.setAuthor({ name: `${interaction.user.username} - Ticket Aberto - Astra Application`, iconURL: interaction.user.displayAvatarURL() })
            .setDescription("> ✨ Espere nossa equipe, evite marcações (tem punições), seja respeitoso!\n-# ✨ | Equipe Viruts App")
            .setColor(`#ed111c`)
            //.setFooter({ text: `${interaction.user.displayName} - Astra Application`, iconURL: interaction.user.displayAvatarURL() })
            //.setTimestamp()
        ],
        components: [row]
      });

      tickets.set(channel.id, {
        userid: interaction.user.id,
        motivo: interaction.fields.getTextInputValue("title"),
        desc: interaction.fields.getTextInputValue("desc") || "Nada...",
        status: "open",
        staff: null,
        msg: {
          id: ticketMessage.id,
          channel: channel.id,
          guild: interaction.guild.id
        }
      });

      return interaction.editReply({ content: `\`✅\` Seu ticket foi criado em <#${channel.id}>!`, ephemeral: true });
    }


    if (interaction.isButton() && interaction.customId === "assumir_ticket") {

      const staffRoleId = logs.get("roleStaff");
      if (!interaction.member.roles.cache.has(staffRoleId)) {
        return interaction.reply({ content: "✅ | Apenas membros da staff podem assumir tickets!", ephemeral: true });
      }

      const ticketData = tickets.get(interaction.channel.id);
      if (!ticketData) {
        return interaction.reply({ content: "✅ | Ticket não encontrado.", ephemeral: true });
      }
      if (ticketData.staff) {
        return interaction.reply({ content: `✅ Este ticket já foi assumido por <@${ticketData.staff}>.`, ephemeral: true });
      }

      tickets.set(`${interaction.channel.id}.staff`, interaction.user.id);
      tickets.set(`${interaction.channel.id}.status`, "assumido");

      const msg = await interaction.channel.messages.fetch(ticketData.msg.id);
      const embed = msg.embeds[0];
      const ticketTitle = ticketData.motivo || null;
      const ticketDesc = ticketData.desc || null;
      const assumidoEmbed = EmbedBuilder.from(embed)
        .setDescription((ticketTitle ? `**Assunto:** **${ticketTitle}**\n\n` : '') + (ticketDesc ? `**Descrição:** **${ticketDesc}**\n\n` : '') + '-# Este é seu ticket, fique tranquilo e aguarde nossa equipe!\n\n🛡️ Staff responsável: <@' + interaction.user.id + '>')
        .setColor("#FFD700");
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("assumir_ticket")
          .setLabel("Assumir Ticket")
          .setStyle(3)
          .setEmoji("👑")
          .setDisabled(true),
        new ButtonBuilder()
          .setCustomId("notificar_usuario")
          .setLabel("Notificar Usuário")
          .setStyle(1)
          .setEmoji("🔹"),
        new ButtonBuilder()
          .setCustomId("fechar_ticket")
          .setLabel("Fechar Ticket")
          .setStyle(4)
          .setEmoji("🔹")
      );
      await msg.edit({ embeds: [assumidoEmbed], components: [row] });

      try {
        const user = await client.users.fetch(ticketData.userid);
        const goToTicketButton = new ButtonBuilder()
          .setLabel('Ir para o ticket')
          .setStyle(5)
          .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`);
        const rowDM = new ActionRowBuilder().addComponents(goToTicketButton);
        await user.send({
          content: `Olá <@${ticketData.userid}>, o seu ticket foi assumido poor <@${interaction.user.id}>, para ver o ticket, clique no botão abaixo.`,
          components: [rowDM]
        });
      } catch (e) {}
      return interaction.reply({ content: `👍 | Você assumiu este ticket!`, ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId === "notificar_usuario") {
      const staffRoleId = logs.get("roleStaff");
      if (!interaction.member.roles.cache.has(staffRoleId)) {
        return interaction.reply({ content: "✅ | Apenas membros da staff podem notificar o usuário!", ephemeral: true });
      }
      const ticketData = tickets.get(interaction.channel.id);
      if (!ticketData) {
        return interaction.reply({ content: "✅ | Ticket não encontrado.", ephemeral: true });
      }

      const cooldownKey = `${interaction.channel.id}_${interaction.user.id}`;
      const now = Date.now();
      if (notifyCooldown[cooldownKey] && now - notifyCooldown[cooldownKey] < 5 * 60 * 1000) {
        const timeLeft = Math.ceil((5 * 60 * 1000 - (now - notifyCooldown[cooldownKey])) / 1000);
        return interaction.reply({ content: `✅ | Você só pode notificar o usuário a cada 5 minutos! Tente novamente em ${timeLeft} segundos.`, ephemeral: true });
      }
      notifyCooldown[cooldownKey] = now;

      try {
        const user = await client.users.fetch(ticketData.userid);
        const goToTicketButton = new ButtonBuilder()
          .setLabel('Ir para o ticket')
          .setStyle(5)
          .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`);
        const rowDM = new ActionRowBuilder().addComponents(goToTicketButton);
        await user.send({
          content: `Olá <@${ticketData.userid}>, o staff <@${interaction.user.id}> está aguardando sua resposta no ticket! Para ver o ticket, clique no botão abaixo.`,
          components: [rowDM]
        });
      } catch (e) {
        return interaction.reply({ content: "✅ | Não foi possível enviar DM ao usuário.", ephemeral: true });
      }
      return interaction.reply({ content: `👍 | Usuário notificado com sucesso!`, ephemeral: true });
    }

    if (interaction.isButton() && interaction.customId === "fechar_ticket") {
      const staffRoleId = logs.get("roleStaff");
      if (!interaction.member.roles.cache.has(staffRoleId)) {
        return interaction.reply({ content: "✅ | Apenas membros da staff podem fechar tickets!", ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setTitle("Motivo do Fechamento")
        .setCustomId("modal_fechar_ticket");
      const motivoInput = new TextInputBuilder()
        .setCustomId("motivo")
        .setLabel("Motivo do fechamento")
        .setPlaceholder("Descreva o motivo do fechamento do ticket")
        .setStyle(1)
        .setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(motivoInput));
      return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === "modal_fechar_ticket") {
      const staffRoleId = logs.get("roleStaff");
      if (!interaction.member.roles.cache.has(staffRoleId)) {
        return interaction.reply({ content: "✅ | Apenas membros da staff podem fechar tickets!", ephemeral: true });
      }
      const ticketData = tickets.get(interaction.channel.id);
      if (!ticketData) {
        return interaction.reply({ content: "✅ | Ticket não encontrado.", ephemeral: true });
      }

      const motivo = interaction.fields.getTextInputValue("motivo");
      tickets.set(`${interaction.channel.id}.status`, "fechado");
      tickets.set(`${interaction.channel.id}.motivo_fechamento`, motivo);
      tickets.set(`${interaction.channel.id}.fechado_por`, interaction.user.id);

      try {
        await interaction.channel.permissionOverwrites.edit(ticketData.userid, { ViewChannel: false });
      } catch (e) {}

      try {
        const config = require("../../databases/config.json");
        const channelLogsId = config.logs_ticket;
        const channelLogs = interaction.guild.channels.cache.get(channelLogsId);
        if (channelLogs) {
          const userAbriu = await client.users.fetch(ticketData.userid);
          const userFechou = interaction.user;
          let userAssumiu = 'Ninguém Assumiu';
          if (ticketData.staff) {
            try {
              const staffUser = await client.users.fetch(ticketData.staff);
              userAssumiu = `<@${staffUser.id}>`;
            } catch {}
          }
          const motivoFechamento = motivo || ticketData.motivo_fechamento || 'Não informado';
          const dataAbertura = ticketData.msg && ticketData.msg.id ? (await interaction.channel.messages.fetch(ticketData.msg.id)).createdAt : null;
          const dataFechamento = new Date();
          const aberturaTimestamp = dataAbertura ? Math.floor(dataAbertura.getTime() / 1000) : null;
          const fechamentoTimestamp = Math.floor(dataFechamento.getTime() / 1000);
          const aberturaFormatada = aberturaTimestamp
            ? `<t:${aberturaTimestamp}:f> (<t:${aberturaTimestamp}:R>)`
            : 'Desconhecido';
          const fechamentoFormatada = `<t:${fechamentoTimestamp}:f> (<t:${fechamentoTimestamp}:R>)`;
          const embedLog = new EmbedBuilder()
            .setColor('#2b2d31')
            .setTitle('Logs Ticket')
            .addFields(
              { name: '👤 **Usuário que abriu:**', value: `<@${userAbriu.id}>`, inline: false },
              { name: '👤 **Usuário que fechou:**', value: `<@${userFechou.id}>`, inline: false },
              { name: '👤 **Quem assumiu:**', value: userAssumiu, inline: false },
              { name: '✨ **Motivo do Fechamento:**', value: motivoFechamento, inline: false },
              { name: '⏰ Horário de abertura:', value: aberturaTimestamp ? `<t:${aberturaTimestamp}:f> (<t:${aberturaTimestamp}:R>)` : 'Desconhecido', inline: false },
              { name: '⏰ Horário do fechamento:', value: `<t:${fechamentoTimestamp}:f> (<t:${fechamentoTimestamp}:R>)`, inline: false },
            )
            .setFooter({ text: `${interaction.guild.name} • Ticket Logs • Hoje às ${moment(dataFechamento).tz('America/Sao_Paulo').locale('pt-br').format('HH:mm')}`, iconURL: interaction.guild.iconURL() })
            .setTimestamp();
          await channelLogs.send({ embeds: [embedLog] });
        }
      } catch (e) { console.error('Erro ao enviar log do ticket:', e); }

      try {
        const msg = await interaction.channel.messages.fetch(ticketData.msg.id);
        const embed = msg.embeds[0];
        const fechadoEmbed = EmbedBuilder.from(embed)
          .setColor("#FF0000")
          .setDescription(`-# Este ticket foi fechado por <@${interaction.user.id}>.\n\nMotivo: ${motivo}`);
        await msg.edit({ embeds: [fechadoEmbed], components: [] });
      } catch (e) {}
      await interaction.reply({ content: `👍 | Ticket fechado com sucesso!`, ephemeral: true });
      try {
        const user = await client.users.fetch(ticketData.userid);
        await user.send(`Olá <@${ticketData.userid}>, o seu ticket foi fechado por <@${interaction.user.id}>.\nMotivo: ${motivo}`);
      } catch (e) {}
      setTimeout(() => {
        interaction.channel.delete("Ticket fechado e excluído");
      }, 2000);
    }
  
  }
}