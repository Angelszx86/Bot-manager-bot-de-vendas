const antiRaidHandler = require('../../Functions/antiRaidHandler');

module.exports = {
  name: 'channelDelete',

  async run(channel) {
    if (!channel.guild) return;
    await antiRaidHandler(channel.guild, 'delete');
  }
};