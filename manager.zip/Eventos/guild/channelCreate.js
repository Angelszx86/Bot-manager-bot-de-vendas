const antiRaidHandler = require('../../Functions/antiRaidHandler');

module.exports = {
  name: 'channelCreate',

  async run(channel) {
    if (!channel.guild) return;
    await antiRaidHandler(channel.guild, 'create');
  }
};