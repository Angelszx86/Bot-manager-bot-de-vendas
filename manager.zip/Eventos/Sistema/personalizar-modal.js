const { Events, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const fs = require("fs");
const path = require("path");

const PEDIDOS_PATH = path.join(__dirname, "../../databases/pedidos.json");
const CANAL_ID = "1442890788731224144"

module.exports = {
    name: Events.InteractionCreate,
    async run(interaction, client) {
      
        if (interaction.isButton() && interaction.customId === "abrir_form_personalizar") {
            const modal = new ModalBuilder()
                .setCustomId("form_personalizar")
                .setTitle("📋 Pedido de Bot Personalizado");

            const perguntas = [
                { id: "o_que_faz", label: "O que ele vai fazer?", style: TextInputStyle.Paragraph },
                { id: "para_que", label: "Para que vai usá-lo?", style: TextInputStyle.Short },
                { id: "funcoes", label: "Funções/Comandos principais", style: TextInputStyle.Paragraph },
                { id: "personalizacao", label: "Quer personalização total? (Sim ou Não)", style: TextInputStyle.Short },
                { id: "linguagem", label: "Linguagem preferida (JS, Python, etc)", style: TextInputStyle.Short }
            ];

            perguntas.forEach((p) => {
                modal.addComponents(
                    new ActionRowBuilder().addComponents(
                        new TextInputBuilder()
                            .setCustomId(p.id)
                            .setLabel(p.label)
                            .setStyle(p.style)
                            .setRequired(true)
                    )
                );
            });

            return interaction.showModal(modal);
        }

        if (interaction.isModalSubmit() && interaction.customId === "form_personalizar") {
            const respostas = {};
            interaction.fields.fields.forEach((field, key) => {
                respostas[key] = field.value;
            });

            let pedidos = [];
            if (fs.existsSync(PEDIDOS_PATH)) {
                try {
                    pedidos = JSON.parse(fs.readFileSync(PEDIDOS_PATH, "utf8"));
                } catch (e) {
                    pedidos = [];
                }
            }
            pedidos.push({
                id: interaction.user.id,
                nome: interaction.user.tag,
                ...respostas,
                data: new Date().toISOString()
            });
            fs.writeFileSync(PEDIDOS_PATH, JSON.stringify(pedidos, null, 2));


            const embed = new EmbedBuilder()
                .setTitle("📥 Novo Pedido de Bot")
                .setColor("#2F3136")
                .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            for (let [key, value] of Object.entries(respostas)) {
                embed.addFields({ name: key.replace(/_/g, " "), value: value || "Não informado" });
            }

            const canal = client.channels.cache.get(CANAL_ID);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`aprovar_${interaction.user.id}`).setLabel("✅ Aprovar").setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`fazendo_${interaction.user.id}`).setLabel("⏳ Estamos fazendo").setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId(`nao_${interaction.user.id}`).setLabel("❌ Não concluído").setStyle(ButtonStyle.Danger)
            );

            if (canal) {
                await canal.send({ embeds: [embed], components: [row], content: "@everyone" }).catch(console.error);
            }

            await interaction.reply({ content: "`✅` Seu pedido foi enviado com sucesso! Lembre-se de abrir sua DM para o bot te mandar o progresso de seu Aplicativo, e aguarde contato.", ephemeral: true });
        }
    }
};
