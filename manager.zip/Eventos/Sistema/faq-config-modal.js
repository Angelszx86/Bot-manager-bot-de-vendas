const { Events, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");

const CONFIG_PATH = path.join(__dirname, "../../databases/faq_config.json");

module.exports = {
    name: Events.InteractionCreate,
    async run(interaction, client) {
        
        // Abrir o Modal
        if (interaction.isButton() && interaction.customId === "configurar_faq_modal") {
            const modal = new ModalBuilder()
                .setCustomId("modal_faq_config")
                .setTitle("⚙️ Configurar Mensagem do FAQ");

            const inputTitulo = new TextInputBuilder()
                .setCustomId("faq_titulo")
                .setLabel("Título da Embed")
                .setPlaceholder("Ex: Faq e Termos da Astra Application")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            const inputDescricao = new TextInputBuilder()
                .setCustomId("faq_descricao")
                .setLabel("Descrição da Embed")
                .setPlaceholder("Use \n para pular linha. Suporta Markdown.")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);

            const inputImagem = new TextInputBuilder()
                .setCustomId("faq_imagem")
                .setLabel("URL da Imagem (Opcional)")
                .setPlaceholder("https://link-da-imagem.png")
                .setStyle(TextInputStyle.Short)
                .setRequired(false);

            modal.addComponents(
                new ActionRowBuilder().addComponents(inputTitulo),
                new ActionRowBuilder().addComponents(inputDescricao),
                new ActionRowBuilder().addComponents(inputImagem)
            );

            return interaction.showModal(modal);
        }

        // Receber o Modal
        if (interaction.isModalSubmit() && interaction.customId === "modal_faq_config") {
            const titulo = interaction.fields.getTextInputValue("faq_titulo");
            const descricao = interaction.fields.getTextInputValue("faq_descricao");
            const imagem = interaction.fields.getTextInputValue("faq_imagem");

            const config = {
                titulo,
                descricao,
                imagem: imagem || null,
                ultima_atualizacao: new Date().toISOString(),
                atualizado_por: interaction.user.tag
            };

            fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));

            await interaction.reply({
                content: "✅ Configuração do FAQ salva com sucesso! Agora você pode usar o comando `/faq` para enviar a nova mensagem.",
                ephemeral: true
            });
        }
    }
};
