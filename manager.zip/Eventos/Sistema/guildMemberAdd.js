const { EmbedBuilder } = require("discord.js");
const sorteioHandler = require("../../Functions/sorteioHandler");

module.exports = {
    name: "guildMemberAdd",

    async run(member, client) {
        // Verifica se existe algum sorteio ativo no servidor
        const gw = sorteioHandler.getGiveaway(member.guild.id);
        if (!gw) return;

        try {
            const channel = await member.guild.channels.fetch(gw.channelId);
            const msg = await channel.messages.fetch(gw.messageId);

            // Atualiza o contador
            gw.serverJoins = (gw.serverJoins || 0) + 1;
            sorteioHandler.saveGiveaway(gw);

            // Atualiza o embed
            const oldEmbed = msg.embeds[0];

            const updated = EmbedBuilder.from(oldEmbed).setFields(
                { name: "⏰ Duração:", value: `\`${gw.tempo}\``, inline: true },
                { name: "💰 Vencedores:", value: `\`${gw.winners || 1}x\``, inline: true },
                { name: "👤 Participantes:", value: `\`${gw.serverJoins}\``, inline: true }
            );

            await msg.edit({ embeds: [updated] });

        } catch (err) {
            console.error("Erro ao atualizar o sorteio:", err);
        }
    }
};