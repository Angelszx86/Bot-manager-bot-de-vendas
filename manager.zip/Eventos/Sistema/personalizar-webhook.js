const { Events, ModalBuilder, ActionRowBuilder, TextInputBuilder } = require("discord.js");

module.exports = {
  name: Events.InteractionCreate,
  async run(interaction) {

    // 🛑 CORREÇÃO AQUI 🛑
    // Garante que a interação tem um customId (evita falhar em comandos /)
    if (!interaction.customId || (!interaction.isButton() && !interaction.isModalSubmit() && !interaction.isStringSelectMenu())) {
        return; // Ignora interações sem customId ou que não são de componente
    }

    const [acao, userId] = interaction.customId.split("_"); // <-- LINHA 7 AGORA É SEGURA
    const user = await interaction.client.users.fetch(userId).catch(() => null);
    if (!user) {
      if (!interaction.replied && !interaction.deferred) {
        //return interaction.reply({ content: "Enviado!.", ephemeral: true });
      }
      return;
    }

    async function enviarDM(mensagem) {
      try {
        await user.send(mensagem);
        return true;
      } catch {
        return false;
      }
    }

    if (acao === "aprovar") {
      const enviado = await enviarDM("> Olá, vim lhe informar que:\n\`✅\` Seu bot está pronto! Entre em contato para receber o acesso.");
      if (!interaction.replied && !interaction.deferred) {
        if (enviado) {
          await interaction.reply({ content: "Pedido aprovado e DM enviada.", ephemeral: true });
        } else {
          await interaction.reply({ content: "Pedido aprovado, mas não consegui enviar DM ao usuário.", ephemeral: true });
        }
      }
    }

    if (acao === "fazendo") {
      
        const enviado = await enviarDM(`> Olá, sua solicitação de um bot foi aprovada!!\n\`⏳\` Estamos fazendo seu bot. Isso levará de 6 dias até 2 semanas`);
        if (!interaction.replied && !interaction.deferred) {
          if (enviado) {
            await interaction.reply({ content: "Mensagem de 'fazendo' enviada.", ephemeral: true });
          } else {
            await interaction.reply({ content: "Não consegui enviar DM ao usuário.", ephemeral: true });
          }
        }
    }

    // O bloco de observação (obs) está comentado no código original. 
    // Se você ativá-lo, o tratamento do submit do modal deve ficar FORA do `if (acao === "obs")`
    // e o `if (acao === "obs")` deve ser transformado para usar `interaction.isButton()`.

    if (acao === "nao") {
      const enviado = await enviarDM("`❌` Não podemos fornecer esse pedido no Discord.");
      if (!interaction.replied && !interaction.deferred) {
        if (enviado) {
          await interaction.reply({ content: "Pedido marcado como não concluído.", ephemeral: true });
        } else {
          await interaction.reply({ content: "Não consegui enviar DM ao usuário.", ephemeral: true });
        }
      }
    }
  }
};