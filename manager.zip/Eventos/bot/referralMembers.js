const { Events } = require('discord.js');
const referrals = require('../../Lib/referrals');

module.exports = {
  name: Events.ClientReady,
  run: async (client) => {
    for (const guild of client.guilds.cache.values()) await referrals.reconcileGuildInvites(guild).catch(() => null);
    client.on(Events.GuildMemberAdd, member => void referrals.handleMemberAdd(member).catch(error => require('../../Lib/interactions').logError(error, 'referral-member-add')));
  }
};
