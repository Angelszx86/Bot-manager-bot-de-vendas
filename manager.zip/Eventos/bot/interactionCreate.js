const { Events, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');
const handleVote = require('../../Functions/handleSugestaoVote');
// const ticketHandler = require('../../Functions/ticketHandler'); // REMOVIDO

module.exports = {
  name: Events.InteractionCreate,

  async run(interaction, client) {
    try {
      // ticketHandler removido - sem chamada aqui

      // 🧩 BOTÕES DE SUGESTÃO
      if (interaction.isCommand()) {
        const command = client.slashCommands.get(interaction.commandName);
        if (!command) return interaction.reply({ content: "Comando antigo ou indisponível. Reabra a lista de comandos e use /perms ou /botconfig.", flags: 64 });
        if (command.__ownerOnly && !require('../../Lib/permissions').isOwner(interaction.user.id)) {
          return interaction.reply({ content: 'Este comando é exclusivo do proprietário do Manager.', flags: 64 });
        }
        try {
          return await command.run(client, interaction);
        } catch (error) {
          console.error(`Erro ao executar comando ${interaction.commandName}:`, error);
          return require('../../Lib/interactions').fail(interaction, error);
        }
      }

      if (interaction.isButton()) {
        const { customId } = interaction;

        // Integração com sugestão (Concordo/Discordo)
        if (customId === 'sugestao_concordo' || customId === 'sugestao_discordo') {
          return await handleVote(interaction);
        }

        switch (customId) {
          case 'saiba_mais':
            return interaction.reply({
              ephemeral: true,
              content:
                `🚀 **Astra Application – O sistema de vendas definitivo para transformar seu servidor!**\n\n` +
                `🔐 **Segurança em Primeiro Lugar**\n` +
                `- Escudo automático contra ataques e travamentos.\n` +
                `- Proteção contra alterações em cargos administrativos.\n` +
                `- Pagamentos com antifraude e OAuth2.\n\n` +
                `📊 **Gestão e Controle Total**\n` +
                `- Pagamentos via Pix com histórico completo.\n` +
                `- Tickets organizados por categoria.\n` +
                `- Logs em tempo real e boas-vindas automáticas.\n\n` +
                `⚙️ **Automação Inteligente**\n` +
                `- Mensagens e alertas programados.\n` +
                `- Limpeza automática de canais inativos.\n` +
                `- Reembolso automático com proteção contra abusos.\n\n` +
                `🎨 **Personalização Completa**\n` +
                `- Nome, avatar, cores e status editáveis.\n` +
                `- Painel simples e QR Codes exclusivos.\n\n` +
                `✨ **Feito para impressionar**\n` +
                `Comandos exclusivos, suporte ágil e sistema confiável.`
            });

          case 'abrir_gerenciar':
            return interaction.reply({
              ephemeral: true,
              content: "**📦 Veja as funções disponíveis:**\nEscolha abaixo o que deseja Alterar/Adicionar.",
              components: [
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setCustomId("vincula")
                    .setLabel("Vincular Gmail")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji((global.emojis && global.emojis.gmail) || "📧"),
                  new ButtonBuilder()
                    .setCustomId("recupera")
                    .setLabel("Recuperar Bots")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji((global.emojis && global.emojis.recupera) || "🔁"),
                  new ButtonBuilder()
                    .setCustomId("limpar")
                    .setLabel("Limpar Dm")
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji((global.emojis && global.emojis.clear) || "🧹")
                    .setDisabled(true)
                )
              ]
            });

          case 'demo_visual':
            return interaction.reply({
              ephemeral: true,
              content: "**🎥 Veja previews disponíveis:**\nEscolha abaixo o que deseja visualizar.",
              components: [
                new ActionRowBuilder().addComponents(
                  new ButtonBuilder()
                    .setLabel("Preview Astra Application")
                    .setStyle(ButtonStyle.Link)
                    .setEmoji(global.emojis?.carrinho || "🛒")
                    .setURL("https://www.youtube.com/watch?v=PAINEL_DEMO")
                    .setDisabled(true),

                  new ButtonBuilder()
                    .setLabel("Preview Zenyx Cloud")
                    .setStyle(ButtonStyle.Link)
                    .setEmoji(global.emojis?.nuvem || "☁️")
                    .setURL("https://www.youtube.com/watch?v=BOT_DEMO")
                    .setDisabled(true),

                  new ButtonBuilder()
                    .setLabel("Como Adquirir")
                    .setStyle(ButtonStyle.Link)
                    .setEmoji(global.emojis?.money || "💵")
                    .setURL("https://exemplo.com/adquirir")
                    .setDisabled(true),

                  new ButtonBuilder()
                    .setLabel("Como Configurar")
                    .setStyle(ButtonStyle.Link)
                    .setEmoji(global.emojis?.config || "⚙️")
                    .setURL("https://exemplo.com/configurar")
                    .setDisabled(true)
                )
              ]
            });

          case 'teste_gratis':
            return require('../manager/gratis').openTrialThread(interaction);

          case 'canal_suporte':
            return interaction.reply({
              ephemeral: true,
              content: '📨 Suporte disponível em: https://discord.com/channels/1488667900775501854/1519894827372646502'
            });

          case 'ver_horario':
            return interaction.reply({
              ephemeral: true,
              content:
                `⏰ **Horários de Atendimento:**\n\n` +
                `\`📅\` Segunda a Sexta: 09:00 às 00:00\n` +
                `\`📅\` Sábado e Domingo: 10:00 às 18:00\n\n` +
                `\`⏰\` Responderemos o mais breve possível!`
            });

          case 'ver_status': {
            const filePath = path.join(__dirname, '../../databases/tickets.json');
            if (!fs.existsSync(filePath)) {
              return interaction.reply({ ephemeral: true, content: '❌ Arquivo de tickets não encontrado.' });
            }

            const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            const tickets = Array.isArray(data?.tickets) ? data.tickets : [];

            if (tickets.length === 0) {
              return interaction.reply({ ephemeral: true, content: '📊 Nenhum ticket foi aberto ainda. Total de tickets: 0' });
            }

            const abertos = tickets.filter(t => t.status === 'aberto').length;
            const fechados = tickets.filter(t => t.status === 'fechado').length;

            return interaction.reply({
              ephemeral: true,
              content:
                `📊 **Status dos Tickets:**\n\n` +
                `🟢 Abertos: **${abertos}**\n` +
                `🔴 Fechados: **${fechados}**\n` +
                `📁 Total: **${tickets.length}**`
            });
          }

          case 'inf_duvidas':
            return interaction.reply({
              ephemeral: true,
              content: '📨 Em caso de dúvidas, abra um ticket em <#ID_DO_CANAL_DE_TICKET>.'
            });

          case 'appls':
            try {
              const commandPath = path.join(__dirname, '../../Comandos/clients/apps.js');
              const command = require(commandPath);
              return command.run(interaction.client, interaction);
            } catch (err) {
              console.error('Erro ao executar comando appls:', err);
              return interaction.reply({ ephemeral: true, content: '❌ Erro ao executar Apps.' });
            }

          case 'vincula':
            try {
              const commandPath = path.join(__dirname, '../../Comandos/clients/vincular.js');
              const command = require(commandPath);
              return command.run(interaction.client, interaction);
            } catch (err) {
              console.error('Erro ao executar comando vincula:', err);
              return interaction.reply({ ephemeral: true, content: '❌ Erro ao executar Vincular Gmail.' });
            }

            case 'limpar':
            try {
              const commandPath = path.join(__dirname, '../../Comandos/clients/limpardm.js');
              const command = require(commandPath);
              return command.run(interaction.client, interaction);
            } catch (err) {
              console.error('Erro ao executar comando limpar-dm:', err);
              return interaction.reply({ ephemeral: true, content: '❌ Erro ao executar Vincular Gmail.' });
            }

          case 'recupera':
            try {
              const commandPath = path.join(__dirname, '../../Comandos/clients/recuperar.js');
              const command = require(commandPath);
              return command.run(interaction.client, interaction);
            } catch (err) {
              console.error('Erro ao executar comando recupera:', err);
              return interaction.reply({ ephemeral: true, content: '❌ Erro ao executar Recuperar Bot.' });
            }
        }
      }
    } catch (error) {
      console.error('[ERRO] na interactionCreate:', error);
      if (!interaction.replied && !interaction.deferred) {
        interaction.reply({
          content: '❌ Ocorreu um erro ao processar esta ação.',
          ephemeral: true
        }).catch(() => {});
      }
    }
  }
};