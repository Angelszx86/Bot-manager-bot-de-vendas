const { Events } = require('discord.js');
module.exports = {
  name: Events.ClientReady,
  once: true,
  async run(client) {
    global.client = client;
    global.emojis = global.emojis || {};
    const { ensureManagerEmojis, populateGlobal } = require('../../Lib/managerEmojis');
    try {
      // Prefer Application Emojis: they are owned by the bot application and do
      // not consume the guild emoji slots that were causing Discord code 30008.
      await ensureManagerEmojis(client, { force: true });
      populateGlobal();
      // Mensagens antigas podem carregar IDs de Application Emoji recriados.
      // Republicar o painel de venda após o sync garante componentes atuais.
      await require('../../Lib/refreshSalesPanel').refreshPublishedZenyxPanels(client).catch(error =>
        console.warn(`[PAINEL] Falha ao republicar painel Astra Application: ${error?.message || error}`)
      );
    } catch (error) {
      console.warn(`[EMOJIS] Falha na sincronização: code=${error?.code || 'unknown'}`);
    }
  }
};
