const { EmbedBuilder, Events } = require('discord.js');
const { api, db2, logs, auto } = require('../../databases/index');
const { SquareCloudAPI } = require('../../source/hidencloud_api');

const EXPIRED_RETENTION_MS = 10 * 24 * 60 * 60 * 1000;

function purgeDeadline(expiresAt) {
  return Number.isFinite(expiresAt) ? expiresAt + EXPIRED_RETENTION_MS : NaN;
}

function isPurgeDue(data, now = Date.now()) {
  const expiresAt = Date.parse(data?.dataExpiracao || '');
  return Number.isFinite(expiresAt) && now >= purgeDeadline(expiresAt);
}

function unlinkOwnerApplication(ownerId, appId) {
  if (!ownerId) return;
  const ownerKey = `${ownerId}_owner`;
  const ownerData = auto.get(ownerKey);
  if (!ownerData || !Array.isArray(ownerData.butecos)) return;
  const before = ownerData.butecos.length;
  ownerData.butecos = ownerData.butecos.filter(item => String(item?.idapp || item?.id || '') !== String(appId));
  if (ownerData.butecos.length !== before) auto.set(ownerKey, ownerData);
}

module.exports = {
  name: Events.ClientReady,
  run: async (client) => {
    const CHECK_INTERVAL_MS = 60_000;
    let running = false;

    async function notifyUser(userId, payload) {
      const user = await client.users.fetch(String(userId)).catch(() => null);
      if (!user) return;
      await user.send(payload).catch(() => null);
    }

    async function verificarExpiracao() {
      if (running) return;
      running = true;
      try {
        const provider = new SquareCloudAPI(api.get('square'));
        const now = Date.now();
        for (const row of db2.all()) {
          const data = row?.data || {};
          const expiresAt = Date.parse(data.dataExpiracao || '');
          if (!Number.isFinite(expiresAt)) continue;

          if (now >= expiresAt) {
            const purgeAt = purgeDeadline(expiresAt);

            // Depois de 10 dias sem renovação, a aplicação deixa de ocupar
            // runtime/armazenamento. A validade é relida imediatamente antes
            // da exclusão para impedir que uma renovação concorrente seja apagada.
            if (isPurgeDue(data, now)) {
              let purged = false;
              let purgeError = '';
              try {
                const current = db2.get(row.ID);
                if (!current || !isPurgeDue(current, Date.now())) continue;
                const application = await provider.applications.get(row.ID);
                const latest = db2.get(row.ID);
                if (!latest || !isPurgeDue(latest, Date.now())) continue;
                const result = await application.delete();
                if (result?.ok === false) throw new Error(result.msg || 'Runtime não confirmou a exclusão.');
                unlinkOwnerApplication(latest.owner, row.ID);
                db2.delete(row.ID);
                purged = true;

                await notifyUser(latest.owner, {
                  embeds: [new EmbedBuilder()
                    .setColor('#747F8D')
                    .setTitle('ASTRA APPLICATION • APLICAÇÃO REMOVIDA')
                    .setDescription('Seu plano permaneceu expirado por **10 dias** sem renovação. A aplicação foi removida da infraestrutura para liberar recursos do serviço.')
                    .addFields(
                      { name: 'Aplicação', value: `\`${row.ID}\` • **${latest.nome || 'Aplicação'}**`, inline: false },
                      { name: 'Expirou em', value: `<t:${Math.floor(expiresAt / 1000)}:F>`, inline: true },
                      { name: 'Prazo de retenção', value: '**10 dias**', inline: true }
                    )
                    .setTimestamp()]
                });
              } catch (error) {
                purgeError = String(error?.message || error).slice(0, 500);
                try { db2.set(`${row.ID}.lastPurgeAttemptAt`, new Date(now).toISOString()); } catch {}
                try { db2.set(`${row.ID}.lastRuntimeError`, purgeError); } catch {}
              }

              const logChannel = client.channels.cache.get(logs.get('logs_vencidos'));
              if (logChannel?.isTextBased?.()) {
                await logChannel.send({
                  embeds: [new EmbedBuilder()
                    .setColor(purged ? '#747F8D' : '#ED4245')
                    .setTitle(purged ? 'ASTRA APPLICATION • LIMPEZA DE APLICAÇÃO EXPIRADA' : 'ASTRA APPLICATION • FALHA NA LIMPEZA DE APLICAÇÃO')
                    .setDescription(purged
                      ? 'Aplicação expirada há 10 dias removida do runtime e do índice do Manager.'
                      : 'A aplicação já ultrapassou o período de retenção, mas a remoção não foi confirmada. O Manager tentará novamente no próximo ciclo.')
                    .addFields(
                      { name: 'App ID', value: `\`${row.ID}\``, inline: true },
                      { name: 'Dono', value: data.owner ? `<@${data.owner}>` : 'não informado', inline: true },
                      ...(purgeError ? [{ name: 'Erro', value: `\`${purgeError}\``, inline: false }] : [])
                    )
                    .setTimestamp()]
                }).catch(() => null);
              }
              continue;
            }

            if (String(data.status || '').toLowerCase() === 'expired') {
              if (!data.purgeAfter) db2.set(`${row.ID}.purgeAfter`, new Date(purgeAt).toISOString());
              continue;
            }
            let stopped = false;
            let stopError = '';
            try {
              const application = await provider.applications.get(row.ID);
              const result = await application.stop();
              if (result?.ok === false) throw new Error(result.msg || 'Runtime não confirmou o desligamento.');
              stopped = true;
            } catch (error) {
              stopError = String(error?.message || error).slice(0, 500);
            }

            db2.set(`${row.ID}.status`, stopped ? 'expired' : 'expiration_stop_failed');
            db2.set(`${row.ID}.expiredAt`, new Date(now).toISOString());
            db2.set(`${row.ID}.purgeAfter`, new Date(purgeAt).toISOString());
            db2.set(`${row.ID}.notify`, true);
            db2.set(`${row.ID}.lastRuntimeError`, stopError || null);

            await notifyUser(data.owner, {
              embeds: [new EmbedBuilder()
                .setColor(stopped ? '#ED4245' : '#FEE75C')
                .setTitle('ASTRA APPLICATION • PLANO EXPIRADO')
                .setDescription(stopped
                  ? `A validade terminou e sua aplicação foi **desligada**. Os dados serão preservados por **10 dias**. Renove antes de <t:${Math.floor(purgeAt / 1000)}:F> para manter a aplicação; depois desse prazo ela será removida automaticamente da infraestrutura.`
                  : `A validade terminou, porém o runtime não confirmou o desligamento. A equipe foi avisada. O período de retenção termina em <t:${Math.floor(purgeAt / 1000)}:F>.`)
                .addFields(
                  { name: 'Aplicação', value: `\`${row.ID}\` • **${data.nome || 'Aplicação'}**`, inline: false },
                  { name: 'Plano', value: `**${data.plano || 'não informado'}**`, inline: true },
                  { name: 'Expiração', value: `<t:${Math.floor(expiresAt / 1000)}:F>`, inline: true },
                  { name: 'Remoção automática', value: `<t:${Math.floor(purgeAt / 1000)}:R>`, inline: true }
                )
                .setTimestamp()]
            });

            const logChannel = client.channels.cache.get(logs.get('logs_vencidos'));
            if (logChannel?.isTextBased?.()) {
              await logChannel.send({
                embeds: [new EmbedBuilder()
                  .setColor(stopped ? '#ED4245' : '#FEE75C')
                  .setTitle('ASTRA APPLICATION • EXPIRAÇÃO DE APLICAÇÃO')
                  .setDescription(stopped ? 'Runtime desligado automaticamente.' : 'Falha ao confirmar desligamento automático.')
                  .addFields(
                    { name: 'App ID', value: `\`${row.ID}\``, inline: true },
                    { name: 'Nome', value: `**${data.nome || 'Aplicação'}**`, inline: true },
                    { name: 'Dono', value: `<@${data.owner}>`, inline: true },
                    { name: 'Retenção', value: `10 dias • remove <t:${Math.floor(purgeAt / 1000)}:R>`, inline: false },
                    ...(stopError ? [{ name: 'Runtime', value: `\`${stopError}\``, inline: false }] : [])
                  )
                  .setTimestamp()]
              }).catch(() => null);
            }
            continue;
          }

          if (now >= expiresAt - 2 * 24 * 60 * 60 * 1000 && !data.notify) {
            await db2.set(`${row.ID}.notify`, true);
            await notifyUser(data.owner, {
              embeds: [new EmbedBuilder()
                .setColor('#3155ff')
                .setTitle('ASTRA APPLICATION • RENOVAÇÃO PRÓXIMA')
                .setDescription('Sua aplicação está próxima do vencimento. Renove antes do prazo para evitar desligamento automático.')
                .addFields(
                  { name: 'Aplicação', value: `\`${row.ID}\` • **${data.nome || 'Aplicação'}**`, inline: false },
                  { name: 'Plano', value: `**${data.plano || 'não informado'}**`, inline: true },
                  { name: 'Expira', value: `<t:${Math.floor(expiresAt / 1000)}:F> (<t:${Math.floor(expiresAt / 1000)}:R>)`, inline: true }
                )
                .setTimestamp()]
            });
          }
        }
      } finally {
        running = false;
      }
    }

    await verificarExpiracao();
    const timer = setInterval(() => void verificarExpiracao(), CHECK_INTERVAL_MS);
    timer.unref?.();
  }
};
