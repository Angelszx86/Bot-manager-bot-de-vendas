const { Events } = require('discord.js');
const sugestoesHandler = require('../../Functions/sugestoes.js');

module.exports = {
  name: Events.MessageCreate,

  async run(message) {
    try {
      if (message.author.bot) return;

      // ID do canal de feedback
      const canalFeedbackId = '1442311068272689233'; // 🔁 Substitua pelo ID real do canal de feedback

      // Verifica se a mensagem está no canal correto para feedback
      if (message.channel.id === canalFeedbackId) {
        const content = message.content.trim();

        if (content === '10/10') {
          return message.react('✨');
        }

        if (content === '9/10') {
          return message.react('✨');
        }

        const regexNotaInvalida = /^([0-8]|[0-9])\/10$/;
        if (regexNotaInvalida.test(content)) {
          try {
            await message.delete();
            await message.channel.send({
              content: `${message.author}, sabemos que voce está mentindo, para dar esse feedback.`,
              ephemeral: true
            });
            return;
          } catch (err) {
            console.error('Erro ao deletar feedback inválido:', err);
          }
        }
      }

      // Executa handler de sugestões normalmente
      await sugestoesHandler(message);

    } catch (err) {
      console.error("[ERRO NO messageCreate.js]", err);
    }
  }
};