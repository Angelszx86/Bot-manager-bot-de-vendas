const { InteractionType } = require("discord.js");

/**
 * Este handler NÃO despacha comandos de barra — isso é feito em
 * Eventos/bot/interactionCreate.js (evita dupla execução que causava
 * "erro de aplicação"). Aqui ficam apenas: modals, autocomplete e botões
 * específicos dos comandos `vincular` e `recuperar` (backup).
 */
module.exports = {
    name: "interactionCreate",
    run: async (interaction, client) => {
        try {
            // autocomplete
            if (interaction.isAutocomplete()) {
                const command = client.slashCommands.get(interaction.commandName);
                if (!command || typeof command.autocomplete !== "function") {
                    return interaction.respond([]).catch(() => {});
                }
                if (command.__ownerOnly && !require('../../Lib/permissions').isOwner(interaction.user.id)) {
                    return interaction.respond([]).catch(() => {});
                }
                try {
                    await command.autocomplete(interaction);
                } catch (err) {
                    try { await interaction.respond([]).catch(() => {}); } catch {}
                }
                return;
            }

            // modal submit (vincular / recuperar-backup)
            if (interaction.isModalSubmit()) {
                const customId = interaction.customId;
                let cmd = null;
                if (customId.startsWith('vincular')) {
                    cmd = client.slashCommands.get('vincular');
                } else if (customId.startsWith('recuperar') || customId.startsWith('backup')) {
                    cmd = client.slashCommands.get('backup') || client.slashCommands.get('recuperar');
                } else if (customId === 'setar_bot_gratis_config') {
                    cmd = client.slashCommands.get('setar-bot-gratis');
                } else if (customId.startsWith('recovery_config_')) {
                    cmd = client.slashCommands.get('setar-recuperacao');
                }
                if (cmd && typeof cmd.modalSubmit === 'function') {
                    return await cmd.modalSubmit(client, interaction);
                }
                return;
            }

            // botões específicos (vincular_ / recuperar_)
            if (interaction.isButton()) {
                let cmd = null;
                if (interaction.customId.startsWith('vincular_')) {
                    cmd = client.slashCommands.get('vincular');
                } else if (interaction.customId.startsWith('recuperar_') || interaction.customId.startsWith('backup_')) {
                    cmd = client.slashCommands.get('backup') || client.slashCommands.get('recuperar');
                } else if (interaction.customId.startsWith('recovery_config_')) {
                    cmd = client.slashCommands.get('setar-recuperacao');
                }
                if (cmd && typeof cmd.button === 'function') {
                    return await cmd.button(client, interaction);
                }
            }
        } catch (err) {
            console.error('[slash.js] erro:', err);
            try {
                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({ content: '❌ Ocorreu um erro.', ephemeral: true }).catch(() => {});
                }
            } catch {}
        }
    }
}
