const { Events } = require('discord.js');
const welcome = require('../../Lib/managerWelcome');
module.exports = {
  name: Events.GuildMemberAdd,
  run: async (member) => {
    if (member.user.bot) return;
    const cfg = welcome.settings(member.guild.id);
    if (!cfg.enabled || !cfg.channelId) return;
    const channel = await member.guild.channels.fetch(cfg.channelId).catch(() => null);
    if (!channel?.isTextBased?.() || !channel?.send) return;
    await channel.send(welcome.payload(member, cfg)).catch(error => require('../../Lib/interactions').logError(error, 'manager-welcome'));
  }
};
