const { ActivityType, Events } = require('discord.js');
const criarMensagem = require('../../Functions/message');
const enviarMensagemPersonalizados = require('../../Functions/personalizados');
const fs = require('fs');

const ZENYX_ASCII = String.raw`
███████╗███████╗███╗   ██╗██╗   ██╗██╗  ██╗
╚══███╔╝██╔════╝████╗  ██║╚██╗ ██╔╝╚██╗██╔╝
  ███╔╝ █████╗  ██╔██╗ ██║ ╚████╔╝  ╚███╔╝
 ███╔╝  ██╔══╝  ██║╚██╗██║  ╚██╔╝   ██╔██╗
███████╗███████╗██║ ╚████║   ██║   ██╔╝ ██╗
╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝`;

module.exports = {
  name: Events.ClientReady,
  run: async (client) => {
    const channelId = '1399746370423750757';
    const guildId = '1312428786591076463';
    let listaClientes = [];
    let aplicacoes = [];
    try { listaClientes = JSON.parse(fs.readFileSync('./DataBaseJson/clientes.json', 'utf-8')); }
    catch { console.warn('[AVISO] Não foi possível ler clientes.json'); }
    try { aplicacoes = JSON.parse(fs.readFileSync('./DataBaseJson/applications.json', 'utf-8')); }
    catch { console.warn('[AVISO] Não foi possível ler applications.json'); }

    const contar = value => Array.isArray(value) ? value.length : (value && typeof value === 'object' ? Object.keys(value).length : 0);
    console.log(ZENYX_ASCII);
    console.log('================ ASTRA APPLICATION MANAGER ================');
    console.log(`[MANAGER] Application ID: ${client.application?.id || client.user.id}`);
    console.log(`[USERS] Usuários em cache: ${client.users.cache.size}`);
    console.log(`[SERVERS] Servidores: ${client.guilds.cache.size}`);
    console.log(`[CLIENTES] Clientes: ${contar(listaClientes)}`);
    console.log(`[APLICATIVOS] Bots cadastrados: ${contar(aplicacoes)}`);
    console.log('[ISOLAMENTO] Manager e bots filhos usam Application IDs e registros de comandos separados.');
    console.log('=================================================');

    client.user.setPresence({
      activities: [{ name: 'Astra Application', type: ActivityType.Streaming, url: 'https://twitch.tv/discord' }],
      status: 'dnd'
    });

    const canal = await client.channels.fetch(channelId).catch(() => null);
    if (!canal || !canal.isTextBased()) {
      console.warn(`[READY] Canal fixo ${channelId} não está acessível; rotina de mensagem fixa ignorada.`);
    } else {
      let mensagemFixa = null;
      async function atualizarMensagem() {
        try {
          const { embed, buttons } = criarMensagem(client, guildId);
          const mensagens = await canal.messages.fetch({ limit: 50 });
          mensagemFixa = mensagens.find(msg => msg.author.id === client.user.id && msg.embeds.length > 0 && msg.components.length > 0);
          if (!mensagemFixa) mensagemFixa = await canal.send({ embeds: [embed], components: [buttons] });
          else await mensagemFixa.edit({ embeds: [embed], components: [buttons] });
          const paraDeletar = mensagens.filter(msg => msg.id !== mensagemFixa.id);
          if (paraDeletar.size > 0) await canal.bulkDelete(paraDeletar, true).catch(() => null);
        } catch (error) {
          console.warn(`[READY] Não foi possível atualizar a mensagem fixa: ${error?.message || error}`);
        }
      }
      await atualizarMensagem();
      const fixedTimer = setInterval(atualizarMensagem, 5 * 60 * 1000);
      fixedTimer.unref?.();
      client.on('messageCreate', async message => {
        if (message.channel.id === channelId && !message.author.bot) await message.delete().catch(() => null);
      });
    }

    // A descrição do Manager NÃO é alterada aqui. A marca automática é aplicada somente aos bots filhos.
    if (typeof enviarMensagemPersonalizados === 'function') await enviarMensagemPersonalizados(client);
  }
};
