# Astra Application Manager — Campus Cloud

## Inicialização

O projeto usa Node.js 22 e inicia com:

```bash
npm ci --omit=dev
npm start
```

O `package.json` já contém o script `start` apontando para `index.js`. Também foi incluído um `Dockerfile` para painéis que aceitam deploy por imagem/container.

O pacote também inclui `camposcloud.app`, com `MAIN=index.js`, runtime Node.js, memória de 1024 MB, porta 3000 e reinício automático.

## Variáveis secretas

Cadastre no painel da Campus Cloud, sem colocar valores reais no ZIP:

```text
DISCORD_TOKEN=token_do_bot_manager
OWNER_ID=id_principal_do_manager
OWNER_IDS=id_principal,id_secundario,id_terciario
PORT=3000
```

O Manager aceita vários proprietários por `OWNER_IDS` (separados por vírgula, espaço ou ponto e vírgula). `OWNER_ID` e `config.json > owner` continuam disponíveis como compatibilidade; os IDs adicionais também podem ser informados em `config.json > owners`.

O `/faq` e o `/config-faq` usam a mesma regra de acesso do `/botconfig`: proprietários configurados e administradores delegados.

Para habilitar `/vincular` e `/recuperar`, são necessários `SUPABASE_URL`, `SUPABASE_SECRET_KEY`, `SUPABASE_PROJECT_REF` e `SUPABASE_MANAGEMENT_TOKEN`. Para enviar códigos a Gmail, Outlook e Yahoo, recomenda-se também configurar SMTP próprio no projeto Supabase.

Os donos também podem usar `/setar-recuperacao`. O comando abre um painel para cadastrar Supabase e SMTP/Gmail; as credenciais são salvas criptografadas em `databases/recovery-secrets.json`, que fica fora do ZIP e deve permanecer no servidor da CamposCloud.

A integração PromissePay, quando ativada, deve usar a documentação oficial em `https://docs.promisse.com.br/`: API base `https://api.promisse.com.br`, `POST /transactions`, autenticação no header `Authorization`, valor em centavos e webhook HTTPS com resposta HTTP 200. A API é somente produção, sem sandbox; não são feitos testes criando cobranças reais.

Nesta entrega, a credencial de API da **CamposCloud** fornecida foi colocada diretamente em `databases/apis.json`, no campo `square`, que é o campo consumido pelos fluxos de hospedagem legados do Manager. Se o ZIP for compartilhado com terceiros, remova ou substitua essa credencial antes do compartilhamento e gere outra no provedor.

O Manager usa `PORT`, `SERVER_PORT` ou `ZCLOUD_WEB_PORT` para o gateway HTTP interno. A hospedagem remota usa a API oficial da CamposCloud em `https://api.camposcloud.com`, com autenticação Bearer e memória padrão de **300 MB por bot**. A API key é configurada no botão **CamposCloud** do `/botconfig`.

As chaves de pagamento e integrações devem continuar no painel do Manager ou nas variáveis privadas correspondentes. Nunca publique `Token.json`, `.env` ou `config/private-credentials.json`.

## Persistência

A hospedagem precisa manter o diretório do projeto persistente. O Manager grava aplicações, clientes, carrinhos, pagamentos, permissões e configurações dentro de `databases/`, `DataBaseJson/`, `database/` e `source/runtime/`. Não use armazenamento temporário para o processo principal.

## Discord

O bot precisa estar convidado ao servidor com as intents e permissões exigidas pelos módulos utilizados. O comando `/botconfig` agora exige a permissão de servidor **Administrador**; não é mais limitado apenas ao proprietário configurado.

## Imagem do painel

`assets/branding/astra-public-generation-panel.png` é usada na Central pública de geração/compra. O banner operacional `assets/branding/astra-applications-panel.png` permanece reservado ao `/botconfig`. Os arquivos de dados do Manager não são substituídos pelas artes.
