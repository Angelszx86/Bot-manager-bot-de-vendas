DISPLAY_NAME=Astra Application Manager
DESCRIPTION=Manager Discord para hospedagem e gerenciamento de bots
MAIN=index.js
RUNTIME=nodejs
MEMORY=1024
VERSION=recommended
AUTORESTART=true
PORT=3000
