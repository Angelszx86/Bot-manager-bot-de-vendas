const path = require('path');
const fs = require('fs');
const { JsonDatabase } = require("wio.db");

for (const name of ['apis.json', 'applications.json', 'autocomplete.json', 'carrinhos.json', 'config.json', 'perms.json', 'produtos.json', 'clientes.json', 'tickets.json']) {
    const file = path.join(__dirname, name);
    try {
        if (!fs.existsSync(file) || fs.statSync(file).size === 0) fs.writeFileSync(file, '{}\n');
    } catch (error) {
        console.warn(`[DATABASE] Não foi possível preparar ${name}: ${error?.message || error}`);
    }
}

const api = new JsonDatabase({ databasePath: path.join(__dirname, "apis.json") });
const db2 = new JsonDatabase({ databasePath: path.join(__dirname, "applications.json") });
const auto = new JsonDatabase({ databasePath: path.join(__dirname, "autocomplete.json") });
const db1 = new JsonDatabase({ databasePath: path.join(__dirname, "carrinhos.json") });
const logs = new JsonDatabase({ databasePath: path.join(__dirname, "config.json") });
const perms = new JsonDatabase({ databasePath: path.join(__dirname, "perms.json") });
const db = new JsonDatabase({ databasePath: path.join(__dirname, "produtos.json") });
const clientes = new JsonDatabase({ databasePath: path.join(__dirname, "clientes.json") });
const tickets = new JsonDatabase({ databasePath: path.join(__dirname, "tickets.json") });

module.exports = {
    api,
    db2,
    auto,
    db1,
    logs,
    perms,
    db,
    clientes,
    tickets
}
